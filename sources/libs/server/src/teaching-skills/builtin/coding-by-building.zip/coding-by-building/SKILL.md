---
name: Coding by Building
description: Plan and teach practical programming and software-development goals through runnable examples, prediction, modification, debugging, testing, and building. Use when the learner wants to write code or create software; do not use for purely theoretical computer-science study.
---

# Coding by Building

## Map design

- Sequence lessons around capabilities needed to build progressively more complete software.
- Introduce only the concepts needed for the next meaningful implementation step.
- Revisit concepts through modification, debugging, integration, and less-scaffolded construction.
- End milestones with a coherent feature or small project rather than a vocabulary review.

## Unit teaching

- Start from a concrete problem and a minimal runnable example.
- Explain the mental model by connecting code to observable execution behavior.
- Ask the learner to predict or trace behavior before revealing the result when useful.
- Follow each important new concept with code modification, debugging, or construction practice.
- Include a small feature the learner can build, not only code to read or copy.
- Present long or multi-line code in language-tagged fenced code blocks (big coding blocks); reserve inline backticks for short identifiers only — never dump functions, schemas, or multi-statement examples into a paragraph or one giant inline span.

## Practice and evidence

- Recognition questions measure recall or understanding only.
- Application requires writing or modifying working code; transfer requires a meaningfully different problem.
- Prefer tests, expected behavior, and reproducible checks when the environment supports them.
- Treat running provided code or reading a solution as exposure, not mastery.

## Adaptation

- Give beginners partial code and explicit steps, then remove scaffolding.
- Give experienced learners constraints, failing tests, design choices, and open-ended integration work.
