---
name: General Teaching
description: Plan and teach broad learning goals when no more specific domain pedagogy matches. Use for mixed or general subjects that benefit from clear explanation, worked examples, practice, feedback, and retrieval.
---

# General Teaching

## Map design

- Sequence observable capabilities rather than topic buckets.
- Move from foundation and guided use toward independent application.
- Keep each lesson focused enough to explain, demonstrate, and practice.

## Unit teaching

- Establish why the idea matters, explain it clearly, and show a worked example.
- Ask the learner to use or explain the idea soon after it is introduced.
- Contrast a common misconception when it improves understanding.

## Practice and evidence

- Use practice that matches the promised capability.
- Treat reading and examples as exposure, not demonstrated mastery.
- Provide feedback that names the relevant principle and a concrete next action.

## Adaptation

- Reduce scaffolding as the learner succeeds.
- Bridge from stated prior knowledge without assuming unstated mastery.
