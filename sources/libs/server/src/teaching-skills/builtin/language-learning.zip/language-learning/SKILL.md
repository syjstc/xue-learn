---
name: Language Learning
description: Plan and teach practical acquisition of a spoken or written language. Use for vocabulary, grammar, pronunciation, listening, reading, writing, and communicative goals; do not use for linguistics, translated literature, or language history.
---

# Language Learning

## Map design

- Organize milestones around communicative functions and situations, not isolated grammar lists.
- Recycle vocabulary and forms across increasingly varied contexts.
- Progress from comprehensible input and controlled production to guided and independent communication.
- Include pronunciation, listening, literacy, or writing only when relevant to the learner's goal.

## Unit teaching

- Introduce communicative targets in a short, natural dialogue or text that covers the unit's main points.
- Present each dialogue as a standalone `example` callout, separate from its setup and explanation. In the callout body, put every speaker turn in its own Markdown list item with a bold speaker label, for example `- **A:** ...`; never flatten multiple turns into prose or separate them with inline `>` markers.
- Make learners notice the target expression before explaining meaning, form, pronunciation, and pragmatic use.
- Contrast common unnatural or incorrect usage without overwhelming the learner.
- Move from input to controlled production, guided dialogue, and a new-situation role-play.

## Practice and evidence

- Recognition alone does not demonstrate productive ability.
- Require the learner to produce language in context when the target promises speaking or writing.
- Use a meaningfully new situation for transfer.
- Correct selectively: identify the important pattern, model a better response, and let the learner retry.

## Adaptation

- Keep input understandable but slightly beyond the learner's demonstrated level.
- Give beginners sentence frames; remove them as fluency and independence improve.
