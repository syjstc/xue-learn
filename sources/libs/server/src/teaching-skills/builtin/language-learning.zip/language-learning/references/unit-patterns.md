# Language unit patterns

For a communicative unit, use: situation and intention → natural dialogue → noticing → concise explanation → recognition/listening check → controlled production → guided dialogue → new-situation role-play → corrective retry.

Format the natural dialogue as its own `example` callout. Keep any setup in the preceding paragraph and analysis in the following paragraph. Use one Markdown list item per turn with a bold speaker label:

- **A:** How was the conference?
- **B:** Amazing! Not only did I meet the CEO, but I also presented our project.
- **A:** Wow! You handled it well.

Do not place dialogue turns inline inside an explanatory paragraph, and do not use `>` characters as turn separators.

For reading or writing goals, replace spoken role-play with an authentic text response while preserving input, noticing, guided production, independent production, and feedback.
