import type { DisplayNode, DisplayTimelineCue } from '../../../libs/display/src/types.js';
/** Individually narrated columns and grids use the whole video viewport for the current page.
 * Only paginate when every child is covered, so untargeted context is never lost. */
export declare function compositionPages(node: DisplayNode, timeline: readonly DisplayTimelineCue[], tick: number, mode: 'video' | 'interactive'): readonly number[] | undefined;
