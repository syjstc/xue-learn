import type { DisplayComponentManifest, DisplayPluginManifest } from '../../../libs/display/src/types.js';
/** Pure serializable metadata. Agents discover these schemas without loading React or executing plugin code. */
export declare const builtinDisplayManifests: readonly DisplayPluginManifest[];
export declare const builtinDisplayComponentKinds: string[];
export declare const builtinDisplayPluginForKind: (kind: string) => Readonly<{
    apiVersion: 1;
    id: string;
    version: string;
    integrity?: string;
    title?: string;
    description?: string;
    domains?: readonly string[];
    execution: "trusted" | "declarative";
    components: readonly DisplayComponentManifest[];
    dependencies?: readonly import("../../../libs/display/src/types.js").DisplayPluginLock[];
    resources?: readonly import("../../../libs/display/src/types.js").DisplayResource[];
    builders?: readonly import("../../../libs/display/src/types.js").DisplayBuilderDescriptor[];
}>;
