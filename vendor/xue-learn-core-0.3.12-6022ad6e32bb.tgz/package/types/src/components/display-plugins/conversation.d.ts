export type ConversationTurn = {
    id: string;
    speaker: string;
    text: string;
};
/** Keep every original code point; pages provide space rather than clipping a long dialogue. */
export declare function conversationPages(turns: readonly ConversationTurn[]): {
    text: string;
    part: number;
    parts: number;
    id: string;
    speaker: string;
}[][];
