import type { DisplayRenderer } from '../../display-runtime/index.js';
import type { DisplayPluginModule } from '../../../../libs/display/src/types.js';
declare const module: DisplayPluginModule<DisplayRenderer>;
export default module;
