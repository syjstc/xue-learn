import React from 'react';
import type { DisplayRendererProps } from '../../display-runtime/index.js';
import { type LessonMotion } from '../film/lesson-motion.js';
import type { RemotionLessonComponent, RemotionLessonSceneV1 } from '../film/types.js';
import type { CompiledVideoTimelineV1 } from '../film/timeline.js';
type Context<T extends RemotionLessonComponent['type']> = {
    component: Extract<RemotionLessonComponent, {
        type: T;
    }>;
    motion: LessonMotion;
    scene: RemotionLessonSceneV1;
    timeline: CompiledVideoTimelineV1;
    tick: number;
};
/** Shared clock adapter; each domain imports only the boards it implements. */
export declare function createAnimatedDisplay<T extends RemotionLessonComponent['type']>(type: T, render: (context: Context<T>) => React.ReactNode): ({ node, clock, timeline: displayTimeline, resources }: DisplayRendererProps) => React.JSX.Element;
export {};
