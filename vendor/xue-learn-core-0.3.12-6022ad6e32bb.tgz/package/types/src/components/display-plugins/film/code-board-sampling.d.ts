import type { ClassroomCodeScrollSample } from '../../course-display/course-code.js';
import type { RemotionCodeComponent } from "./types.js";
export declare const CODE_BOARD_COLUMNS = 68;
export declare const CODE_BOARD_VISIBLE_ROWS = 13;
export declare const CODE_BOARD_ROW_HEIGHT = 41;
export type CodeBoardRow = Readonly<{
    number: number;
    text: string;
    continuation: boolean;
}>;
export type CodeBoardHighlight = Readonly<{
    id: string;
    label: string;
    startLine: number;
    endLine: number;
}>;
/** Partition the exact accepted source, including repeated lines and gaps.
 * Overlapping legacy ranges share host-derived atoms while their public IDs
 * remain the narration targets. No substring search can select the wrong copy. */
export declare function classroomCodeBoardAdapter(props: RemotionCodeComponent['props']): {
    block: Readonly<{
        [key: string]: unknown;
        type: string;
    }>;
    parts: Readonly<{
        id?: string;
        text: string;
    }>[];
    targets: (ids: readonly string[]) => string[];
};
/** Reuse the classroom's measured source rows and centered short-range fit.
 * A range taller than the viewport is traversed within its accepted narration,
 * with inspection holds at both ends. Every output is a function of the tick. */
export declare function sampleClassroomCodeViewport(sample: ClassroomCodeScrollSample, elapsedTicks: number, durationTicks: number): number;
/** Source-only layout: cues never change glyphs, wrapping, or row heights. */
export declare function layoutCodeBoardRows(code: string): readonly CodeBoardRow[];
/** Align the actual first wrapped row, then traverse an oversized range within its beat. */
export declare function sampleCodeBoardViewport(rows: readonly CodeBoardRow[], highlight: CodeBoardHighlight | undefined, elapsedTicks: number, durationTicks: number, visibleRows?: number): {
    firstRow: number;
    lastRow: number;
    scrollRow: number;
    offsetY: number;
    firstSourceLine: number;
    lastSourceLine: number;
};
