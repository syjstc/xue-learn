import { type DerivationDocumentV1 } from "../../../../libs/formal-derivation/src/index.js";
import type { SubjectRef } from "../../../../libs/formal-expression-core/src/index.js";
import type { DerivationStepV1, MaterializedDerivationStateV1 } from "../../../../libs/formal-derivation/src/index.js";
import { formulaHighlights } from "./formal-derivation-view.js";
export declare function classroomDisplayedFormulaId(state: MaterializedDerivationStateV1): string | undefined;
/** Scene bounds are one-based ordinals; zero is the initial board. */
export declare function classroomDerivationFrame(document: DerivationDocumentV1, ordinal: number): {
    state: MaterializedDerivationStateV1;
    step: DerivationStepV1;
};
/** Keep authored reference formulas alongside every formula taught by this step. */
export declare function classroomDisplayedFormulaIds(state: MaterializedDerivationStateV1, step?: DerivationStepV1): string[];
export declare function classroomFormulaEmphasis(state: MaterializedDerivationStateV1, formulaId: string): {
    selected: SubjectRef[];
    highlights: ReturnType<typeof formulaHighlights>;
};
