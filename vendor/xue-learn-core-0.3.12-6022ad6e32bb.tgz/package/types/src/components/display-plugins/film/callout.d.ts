import React from 'react';
import type { DisplayRendererProps } from '../../display-runtime/index.js';
import './callout.css';
/** Retains the film's fixed rows, Markdown, moving focus plate and sampled wipe. */
export declare function CalloutDisplay(props: DisplayRendererProps): React.JSX.Element;
