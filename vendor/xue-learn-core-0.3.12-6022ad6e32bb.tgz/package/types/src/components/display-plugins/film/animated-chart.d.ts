import React from 'react';
import type { RemotionAnimatedChartComponent } from "./types.js";
import type { LessonMotion } from './lesson-motion.js';
export declare const chartColors: string[];
export declare function chartBounds(series: RemotionAnimatedChartComponent['props']['series']): {
    min: number;
    max: number;
};
export declare function AnimatedChart({ props, motion }: {
    props: RemotionAnimatedChartComponent['props'];
    motion: LessonMotion;
}): React.JSX.Element;
