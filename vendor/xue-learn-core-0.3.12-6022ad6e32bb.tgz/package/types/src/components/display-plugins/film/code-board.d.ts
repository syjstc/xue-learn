import React from 'react';
import type { RemotionCodeComponent } from "./types.js";
import type { LessonMotion } from './lesson-motion.js';
import './code-base.css';
import './code-board.css';
/** Remotion supplies its accepted narration clock to the existing classroom
 * renderer. Source partitions, syntax, board math and source-row measurement
 * share that renderer; video only owns the shell and sampled camera movement. */
export declare function CodeBoard({ props, motion }: {
    props: RemotionCodeComponent['props'];
    motion: LessonMotion;
}): React.JSX.Element;
