import type { DisplayDocument, DisplayNode } from '../../../libs/display/src/types.js';
import type { MaterialTeachingCueInterval, MusicPlaybackState } from '../../../libs/domain/src/index.js';
export type MaterialDisplayOptions = Readonly<{
    id?: string;
    activeTargetIds?: readonly string[];
    previousActiveTargetIds?: readonly string[];
    revealedTargetIds?: readonly string[];
    previousRevealedTargetIds?: readonly string[];
    progress?: number;
    teachingTimeline?: {
        intervals: readonly MaterialTeachingCueInterval[];
        tick: number;
    };
    music?: MusicPlaybackState;
}>;
declare const teachingKind: (templateId: unknown) => "math:teaching" | "music:teaching" | "physics:teaching" | "general:teaching";
export { teachingKind as builtinTeachingKind };
/** Historical accepted data is projected without rewriting saved learner content. Unknown content remains an explicit missing-plugin node. */
export declare function materialDisplayNode(input: unknown, options?: MaterialDisplayOptions): DisplayNode;
export declare function displayDocumentForNode(root: DisplayNode, id?: string): DisplayDocument;
export declare function materialDisplayDocument(block: unknown, options?: MaterialDisplayOptions): DisplayDocument;
export declare function derivationDisplayDocument(input: {
    document: unknown;
    derived?: unknown;
    id?: string;
    focused?: boolean;
    fromStep?: number;
    toStep?: number;
    cueId?: string;
    progress?: number;
    layoutProgress?: number;
    visualProgress?: number;
    contextProgress?: number;
    visualTimeline?: unknown;
}): DisplayDocument;
export declare const legacyMaterialToDisplayDocument: typeof materialDisplayDocument;
export declare const legacyDerivationToDisplayDocument: typeof derivationDisplayDocument;
/** A learner advances a cue while every preceding animation stage stays
 * completed. The authored tree and the course's saved timeline remain intact. */
export declare function projectDisplayFocusTimeline(document: DisplayDocument, activeTargets: readonly string[], cueId?: string, startSeconds?: number, transitionSeconds?: number): DisplayDocument;
