import type { DisplayResource } from "../../../libs/display/src/types.js";
export type BrowserDisplayResource = Readonly<{
    uri: string;
    width?: number;
    height?: number;
    duration?: number;
    family?: string;
    data?: unknown;
}>;
export type BrowserDisplayResourceResolver = ((resource: DisplayResource) => Promise<BrowserDisplayResource>) & {
    dispose: () => void;
};
/** Create one resolver per runtime. Verified bytes are retained as blob URLs until disposal. */
export declare function createBrowserDisplayResourceResolver(options?: {
    resolveUri?: (resource: DisplayResource) => string | Promise<string>;
    timeoutMs?: number;
}): BrowserDisplayResourceResolver;
