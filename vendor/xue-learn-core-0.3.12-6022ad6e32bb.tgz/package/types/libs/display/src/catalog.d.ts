import type { DisplayComponentManifest, DisplayPluginLock, DisplayPluginManifest } from "./types.js";
export declare const displayComponentKey: (kind: string, version: number) => string;
export declare const displayPluginKey: (id: string, version: string) => string;
export type DisplayCatalogMatch = Readonly<{
    manifest: DisplayPluginManifest;
    component: DisplayComponentManifest;
}>;
/** One catalog per workspace. Registration is metadata-only and never loads code. */
export declare class DisplayCatalog {
    private readonly manifests;
    private readonly listeners;
    private revision;
    readonly subscribe: (listener: () => void) => (() => void);
    readonly getSnapshot: () => number;
    register(manifest: DisplayPluginManifest): () => void;
    get(id: string, version: string): DisplayPluginManifest | undefined;
    list(): readonly DisplayPluginManifest[];
    find(kind: string, version: number, locks?: readonly DisplayPluginLock[]): readonly DisplayCatalogMatch[];
    /** Model-facing discovery contains schemas/examples/builders, never executable modules. */
    describe(domains?: readonly string[]): readonly DisplayPluginManifest[];
    private changed;
}
export declare function createDisplayCatalog(manifests?: readonly DisplayPluginManifest[]): DisplayCatalog;
