import type { DisplayClock, DisplayTimelineCue } from "./types.js";
/** Frame sampling is deterministic, including backwards seeks and fractional frames. */
export declare function createDisplayClock(frame: number, fps?: number, options?: {
    ticksPerSecond?: number;
    playing?: boolean;
}): DisplayClock;
export declare function displayClockAtTick(tick: number, fps?: number, ticksPerSecond?: number, playing?: boolean): DisplayClock;
export declare function activeDisplayTargets(cues: readonly DisplayTimelineCue[], clock: DisplayClock): readonly string[];
