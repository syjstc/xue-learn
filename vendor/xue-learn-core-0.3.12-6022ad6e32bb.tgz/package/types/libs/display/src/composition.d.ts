import type { DisplayNode } from "./types.js";
/** Template ids are scoped by the caller. Slots preserve the authored child identities. */
export declare function expandDisplayComposition(node: DisplayNode, template: DisplayNode): DisplayNode;
