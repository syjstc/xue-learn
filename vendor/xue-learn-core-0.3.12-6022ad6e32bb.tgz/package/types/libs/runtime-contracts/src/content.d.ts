import { z } from "zod";
export declare const localPlanningModeSchema: z.ZodEnum<{
    fast: "fast";
    deep: "deep";
    docs_first: "docs_first";
}>;
export declare const localResearchScopeSchema: z.ZodEnum<{
    goal: "goal";
    module: "module";
}>;
export declare const localContentContextSchema: z.ZodObject<{
    planningMode: z.ZodEnum<{
        fast: "fast";
        deep: "deep";
        docs_first: "docs_first";
    }>;
    researchScope: z.ZodDefault<z.ZodEnum<{
        goal: "goal";
        module: "module";
    }>>;
    documentsAvailable: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strip>;
export type LocalContentContext = z.infer<typeof localContentContextSchema>;
export declare const localContentCapabilityRequestSchema: z.ZodObject<{
    planningMode: z.ZodEnum<{
        fast: "fast";
        deep: "deep";
        docs_first: "docs_first";
    }>;
    researchScope: z.ZodDefault<z.ZodEnum<{
        goal: "goal";
        module: "module";
    }>>;
    documentsAvailable: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strip>;
export declare const localContentCapabilityResultSchema: z.ZodObject<{
    planningMode: z.ZodEnum<{
        fast: "fast";
        deep: "deep";
        docs_first: "docs_first";
    }>;
    researchScope: z.ZodEnum<{
        goal: "goal";
        module: "module";
    }>;
    primaryResearchSource: z.ZodEnum<{
        none: "none";
        web: "web";
        documents: "documents";
    }>;
    webSearch: z.ZodObject<{
        status: z.ZodEnum<{
            available: "available";
            degraded: "degraded";
            blocked: "blocked";
        }>;
        reason: z.ZodNullable<z.ZodString>;
        providerId: z.ZodNullable<z.ZodEnum<{
            none: "none";
            doubao: "doubao";
            tavily: "tavily";
            anysearch: "anysearch";
        }>>;
    }, z.core.$strip>;
    image: z.ZodObject<{
        status: z.ZodEnum<{
            available: "available";
            degraded: "degraded";
            blocked: "blocked";
        }>;
        reason: z.ZodNullable<z.ZodString>;
        providerId: z.ZodNullable<z.ZodEnum<{
            none: "none";
            minimax: "minimax";
            doubao: "doubao";
            codex: "codex";
            apimart: "apimart";
            krill: "krill";
        }>>;
    }, z.core.$strip>;
    audio: z.ZodObject<{
        status: z.ZodEnum<{
            available: "available";
            degraded: "degraded";
            blocked: "blocked";
        }>;
        reason: z.ZodNullable<z.ZodString>;
        providerId: z.ZodNullable<z.ZodEnum<{
            none: "none";
            minimax: "minimax";
            doubao: "doubao";
            qwen: "qwen";
            cartesia: "cartesia";
        }>>;
    }, z.core.$strip>;
    svg: z.ZodObject<{
        status: z.ZodEnum<{
            available: "available";
            degraded: "degraded";
            blocked: "blocked";
        }>;
        providerId: z.ZodNullable<z.ZodString>;
        reason: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
}, z.core.$strip>;
export type LocalContentCapabilityResult = z.infer<typeof localContentCapabilityResultSchema>;
export declare const localContentSearchRequestSchema: z.ZodObject<{
    planningMode: z.ZodEnum<{
        fast: "fast";
        deep: "deep";
        docs_first: "docs_first";
    }>;
    researchScope: z.ZodDefault<z.ZodEnum<{
        goal: "goal";
        module: "module";
    }>>;
    documentsAvailable: z.ZodDefault<z.ZodBoolean>;
    query: z.ZodString;
    maxResults: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
export type LocalContentSearchRequest = z.infer<typeof localContentSearchRequestSchema>;
export declare const localContentSearchResultSchema: z.ZodObject<{
    status: z.ZodEnum<{
        ready: "ready";
        fallback: "fallback";
        skipped: "skipped";
    }>;
    providerId: z.ZodNullable<z.ZodEnum<{
        none: "none";
        doubao: "doubao";
        tavily: "tavily";
        anysearch: "anysearch";
    }>>;
    reason: z.ZodNullable<z.ZodString>;
    results: z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        url: z.ZodString;
        snippet: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type LocalContentSearchResult = z.infer<typeof localContentSearchResultSchema>;
export declare const localImageGenerationRequestSchema: z.ZodObject<{
    prompt: z.ZodString;
    aspectRatio: z.ZodDefault<z.ZodEnum<{
        "1:1": "1:1";
        "16:9": "16:9";
        "9:16": "9:16";
        "4:3": "4:3";
        "3:4": "3:4";
    }>>;
    altText: z.ZodString;
}, z.core.$strip>;
export type LocalImageGenerationRequest = z.infer<typeof localImageGenerationRequestSchema>;
export declare const localAudioGenerationRequestSchema: z.ZodObject<{
    text: z.ZodString;
    language: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type LocalAudioGenerationRequest = z.infer<typeof localAudioGenerationRequestSchema>;
export declare const localSvgGenerationRequestSchema: z.ZodObject<{
    prompt: z.ZodString;
    title: z.ZodString;
}, z.core.$strip>;
export type LocalSvgGenerationRequest = z.infer<typeof localSvgGenerationRequestSchema>;
export declare const localBinaryContentResultSchema: z.ZodObject<{
    status: z.ZodEnum<{
        ready: "ready";
        fallback: "fallback";
    }>;
    providerId: z.ZodNullable<z.ZodString>;
    reason: z.ZodNullable<z.ZodString>;
    mimeType: z.ZodNullable<z.ZodString>;
    dataBase64: z.ZodNullable<z.ZodString>;
    fallback: z.ZodNullable<z.ZodObject<{
        kind: z.ZodEnum<{
            text: "text";
            image_callout: "image_callout";
        }>;
        content: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type LocalBinaryContentResult = z.infer<typeof localBinaryContentResultSchema>;
export declare const localSvgGenerationResultSchema: z.ZodObject<{
    status: z.ZodEnum<{
        ready: "ready";
        fallback: "fallback";
    }>;
    providerId: z.ZodNullable<z.ZodString>;
    reason: z.ZodNullable<z.ZodString>;
    svg: z.ZodString;
}, z.core.$strip>;
export type LocalSvgGenerationResult = z.infer<typeof localSvgGenerationResultSchema>;
