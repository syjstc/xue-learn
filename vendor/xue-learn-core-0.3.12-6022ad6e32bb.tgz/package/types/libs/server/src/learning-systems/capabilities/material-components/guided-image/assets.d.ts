import { type GuidedImageAsset, type GuidedImageRegion } from "../../../../../../domain/src/guided-image.js";
export declare function imageSha256(data: Buffer): string;
export declare const GUIDED_IMAGE_OBSERVATION_VERSION = "classroom-light-matte-v1";
/** Model input uses the same light matte as guided-image.css. The immutable
 * source PNG, its alpha, dimensions and content hash remain authoritative. */
export declare function guidedImageObservationDataUrl(data: Buffer): Promise<string>;
export declare function normalizeGuidedImage(data: Buffer): Promise<{
    data: Buffer<ArrayBufferLike>;
    width: number;
    height: number;
    sha256: string;
}>;
/** The model supplies outlines; libvips rasterizes and applies them. This is
 * alpha compositing, not a handwritten segmentation/matting algorithm. */
export declare function cutGuidedImageRegion(data: Buffer, image: GuidedImageAsset, region: GuidedImageRegion): Promise<Buffer<ArrayBufferLike>>;
