import type { LearningSystemPersistenceClient } from "../persistence-client.js";
export { BASE_CAPABILITY_ID, BASE_CAPABILITY_VIEW_KEYS } from "../keys.js";
export declare function createBaseGenerationCapability(options?: {
    persistence?: LearningSystemPersistenceClient;
}): import("../types.js").LearningSystemCapability;
