import type { DisplayDocument, DisplayPluginManifest } from "../../../display/src/types.js";
declare let provider: (() => readonly DisplayPluginManifest[] | Promise<readonly DisplayPluginManifest[]>) | undefined;
export declare function configureDisplayPluginCatalog(next: typeof provider): void;
export declare function loadDisplayAuthoringCatalog(): Promise<readonly DisplayPluginManifest[]>;
export declare function displayCatalogInstruction(manifests: readonly DisplayPluginManifest[]): string;
export declare function authoredDisplayDocumentIssues(document: DisplayDocument, manifests: readonly DisplayPluginManifest[]): string[];
export {};
