import type { MaterialRegenerationRepository, UnitDeliveryReadRepository } from "../../../../../domain/src/index.js";
export declare function editComponentWithAi(repository: MaterialRegenerationRepository, unitRead: UnitDeliveryReadRepository, userId: string, unitId: string, blockIndex: number, instruction: string, onPartial?: (component: unknown) => void | Promise<void>): Promise<{
    component: {
        type: "heading";
        text: string;
        level?: 2 | 3;
        topicId?: string;
    } | {
        type: "paragraph";
        text: string;
        cue?: {
            target: string;
            timelineCueId?: string;
            music?: {
                figureId: string;
                clipId: string;
                repeat?: number;
            };
            targetIds?: string[];
            op?: "highlight" | "window";
            regionIds?: string[];
            figureId?: string;
        };
    } | {
        type: "code";
        code: string;
        id?: string;
        language?: string;
        parts?: {
            text: string;
            id?: string;
        }[];
        regions?: {
            id: string;
            match: string;
        }[];
    } | {
        type: "conversation";
        turns: {
            speaker: string;
            text: string;
        }[];
        id?: string;
        title?: string;
    } | {
        type: "callout";
        variant: "example" | "warning" | "definition" | "tip";
        body: string;
        id?: string;
        title?: string;
    } | {
        type: "accordion";
        title: string;
        body: string;
        id?: string;
    } | {
        type: "step_sort";
        title: string;
        correct_sequence: {
            id: string;
            content: string;
            order: number;
        }[];
        dependency_hint: string;
    } | {
        type: "graph";
        variant: "process_flow" | "concept_map";
        title: string;
        direction: "TB" | "LR" | "RADIAL";
        nodes: {
            id: string;
            label: string;
            kind: "start" | "end" | "process" | "io" | "outcome" | "source" | "decision" | "system" | "concept";
            emphasis: "primary" | "normal";
            description?: string;
            groupId?: string;
        }[];
        edges: {
            id: string;
            from: string;
            to: string;
            arrow: "none" | "forward" | "backward" | "both";
            label?: string;
        }[];
        groups?: {
            id: string;
            label: string;
            description?: string;
        }[];
        caption?: string;
    } | {
        type: "chart";
        title: string;
        chartType: "line" | "area" | "bar" | "pie" | "scatter";
        data: Record<string, string | number>[];
        series: {
            dataKey: string;
            name: string;
            color?: string;
            unit?: string;
        }[];
        showLegend: boolean;
        donut: boolean;
        summary: string;
        categoryKey?: string;
        xKey?: string;
        yKey?: string;
        xLabel?: string;
        yLabel?: string;
        unit?: string;
    } | {
        type: "math_scene";
        title: string;
        dimension: "2d" | "3d";
        coordinateSystem: "cartesian" | "polar";
        xRange: [number?, number?, ...unknown[]];
        yRange: [number?, number?, ...unknown[]];
        objects: ({
            kind: "point";
            id: string;
            position?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "vector";
            id: string;
            start?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            end?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            relation?: {
                operation: "sum" | "difference";
                operands: [string?, string?, ...unknown[]];
            } | {
                operation: "scale";
                operand: string;
                factor: number;
                factorParameter?: string;
            };
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "segment";
            id: string;
            from?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            to?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "function";
            expression: string;
            variable: "x";
            domain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "parametric";
            xExpression: string;
            yExpression: string;
            parameter: "t";
            domain: [number?, number?, ...unknown[]];
            id: string;
            zExpression?: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "polar_function";
            expression: string;
            variable: "theta";
            domain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "surface";
            expression: string;
            variables: ["x"?, "y"?, ...unknown[]];
            xDomain: [number?, number?, ...unknown[]];
            yDomain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        })[];
        showGrid: boolean;
        showAxes: boolean;
        summary: string;
        zRange?: [number?, number?, ...unknown[]];
        parameters?: {
            id: string;
            name: string;
            min: number;
            max: number;
            step: number;
            default: number;
        }[];
        camera?: {
            azimuth: number;
            elevation: number;
        };
    } | {
        type: "interactive_html";
        title: string;
        summary: string;
        html: string;
        visualKind?: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
        height?: number;
    } | {
        type: "svg";
        caption: string;
        alt: string;
        svg: string;
        title?: string;
        intent?: {
            visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
            setup: string;
            learningGoal: string;
            expectedInsight: string;
            composition?: string;
            elements?: string[];
            relationships?: string[];
            labels?: string[];
            avoid?: string[];
        };
    };
    contentRevision: number;
}>;
/** Delete one authored/generated block in the desktop development editor. */
export declare function deleteComponentBlock(repository: MaterialRegenerationRepository, unitRead: UnitDeliveryReadRepository, userId: string, unitId: string, blockIndex: number): Promise<{
    deleted: boolean;
    contentRevision: number;
}>;
