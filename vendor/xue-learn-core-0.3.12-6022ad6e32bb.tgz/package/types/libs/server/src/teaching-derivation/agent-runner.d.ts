import { type LearningSystemRuntime } from "../learning-systems/runtime.js";
import type { LlmMessageRecord } from "../agents/core/types.js";
import type { TeachingDerivationRunEventV1 } from "../learning-systems/capabilities/teaching-derivation/session.js";
export type RunTeachingDerivationAgentParams = {
    runId: string;
    /** Supplied by hosts that own derivations but do not run the learning database. */
    runtime?: LearningSystemRuntime;
    userId: string;
    title: string;
    locale: string;
    requirementText: string;
    assumptions?: string[];
    target?: string;
    traceId: string;
    signal?: AbortSignal;
    send: (event: TeachingDerivationRunEventV1) => Promise<void>;
    operation?: string;
    toolSet?: string;
    invocationPrompt?: string;
    finishToolName?: string;
    missingFinishMessage?: string;
    platformFunded?: boolean;
};
export declare const MAX_REPEATED_DERIVATION_TOOL_ERRORS = 5;
export declare function shouldCountRepeatedDerivationToolError(toolName: string, result: unknown): boolean;
export declare function shouldAbortInvalidDerivationToolSchema(attempts: number, limit?: number): boolean;
/** Keep the invocation in the user turn; the prepared system prompt is context/policy only. */
export declare function buildTeachingDerivationInitialMessages(systemPrompt: string, invocationPrompt: string): LlmMessageRecord[];
export declare function runTeachingDerivationAgent(params: RunTeachingDerivationAgentParams): Promise<void>;
