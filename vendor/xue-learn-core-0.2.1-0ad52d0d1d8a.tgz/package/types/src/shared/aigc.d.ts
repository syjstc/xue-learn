export declare const AIGC_IMAGE_CACHE_VERSION = "v1";
export declare function withAigcImageVersion(url: string): string;
