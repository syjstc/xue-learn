import type { CourseDisplayBlock } from "../../../libs/domain/src/index.js";
/** Only semantic focus facts are shared; hosts may attach their own narration clocks. */
export type CourseFocusBeat = Readonly<{
    teaching?: Readonly<{
        targetIds: readonly string[];
    }>;
    actions?: readonly Readonly<{
        id: string;
        targetId: string;
    }>[];
}>;
export declare function courseBuildBeatTargets(beat: CourseFocusBeat): readonly string[];
export declare function courseSceneBuildHistory(block: CourseDisplayBlock | undefined, beats: readonly CourseFocusBeat[], beatIndex: number): readonly string[] | undefined;
export declare function supportsCourseDetailBuild(block: CourseDisplayBlock | undefined): boolean;
/** Preserve whole-card visits separately from detail cues' parent lighting ids. */
export declare function courseBuildHistoryTargets(block: CourseDisplayBlock, targets: readonly string[]): readonly string[];
/** Automatic builds need explicit narration history; uncued old lessons stay complete. */
export declare function supportsCourseCardBuild(block: CourseDisplayBlock | undefined): boolean;
export declare function courseCardRevealedIndexes(block: CourseDisplayBlock, targets: readonly string[]): number[];
