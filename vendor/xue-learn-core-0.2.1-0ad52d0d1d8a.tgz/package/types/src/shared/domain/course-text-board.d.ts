type TextFigure = Readonly<{
    type?: string;
    variant?: unknown;
    title?: unknown;
    body?: unknown;
}>;
/** Only explicitly authored, bold Markdown labels form dimensions. Ordinary
 * prose, colons in code/math, and unequal dimensions are never guessed. */
export declare function courseTextDimensions(body: string): {
    label: string;
    text: string;
}[] | null;
/** A display-only projection. Original figure order, text and cue IDs survive. */
export declare function courseTextBoard(figures: readonly TextFigure[]): {
    columns: number[];
    notes: number[];
    rows: {
        label: string;
        cells: string[];
    }[];
};
export {};
