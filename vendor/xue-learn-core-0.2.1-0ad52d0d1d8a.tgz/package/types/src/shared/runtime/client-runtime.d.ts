import type { RuntimeDescriptor } from "../../../libs/runtime-contracts/src/index.js";
/** Configure once during a non-web renderer bootstrap, before React mounts. */
export declare function configureClientRuntime(runtime: RuntimeDescriptor): void;
export declare function getClientRuntime(): RuntimeDescriptor;
export declare function isDesktopLocalRuntime(): boolean;
/** Desktop-local keeps durable application state in SQLite, never Web Storage. */
export declare function canUseBrowserPersistentStorage(): boolean;
export declare function supportsAssistantSpaceOrganization(): boolean;
/**
 * The global assistant is a durable, tool-capable thread surface.  Local
 * runtimes must opt in only after their SQLite adapter implements the shared
 * create/read/send/resume/stream contract; omission keeps hosted compatibility.
 */
export declare function supportsGlobalAssistant(): boolean;
/** Local normal text threads may be bound to an owned goal or unit. */
export declare function supportsScopedAssistantTextThreads(): boolean;
export declare function supportsGoalOverviewGeneration(): boolean;
/** Instant micro-course generation requires the runtime's goal SSE authority. */
export declare function supportsGoalInstantMicroGeneration(): boolean;
export declare function supportsGoalWebResources(): boolean;
/** User-supplied URL documents use the shared extraction/index contract. */
export declare function supportsGoalDocumentUrls(): boolean;
export declare function supportsMaterialFollowUps(): boolean;
/** Per-block complex-component regeneration (hosted + desktop-local). */
export declare function supportsMaterialComponentRegeneration(): boolean;
/** Per-block authored-material illustration regeneration (hosted + desktop-local). */
export declare function supportsMaterialIllustrationRegeneration(): boolean;
export declare function supportsGoalPlanLegacyGeneration(): boolean;
export declare function supportsGoalMasteryTransition(): boolean;
export declare function supportsGoalKacomDetach(): boolean;
export declare function supportsGoalMapAuthoring(): boolean;
export declare function supportsGoalMapRefresh(): boolean;
export declare function supportsGoalTextbookExport(): boolean;
/** Development-only batch Survey/material generation requires hosted routes. */
export declare function supportsGoalBatchGeneration(): boolean;
/** Hosted goal icons are provider-generated; local SQLite uses GoalIcon's deterministic fallback. */
export declare function supportsGoalIconGeneration(): boolean;
/**
 * Hosted flashcards require the deck/card/source DTOs plus provider-backed
 * generation and FSRS review routes. Local SQLite only has its separate
 * bounded unit-review scheduler, so it opts out until those contracts share
 * one authority.
 */
export declare function supportsFlashcards(): boolean;
/** Agenda reminder preferences are actionable only when delivery is wired. */
export declare function supportsAgendaReminderDelivery(): boolean;
/** Section chat narration requires a durable asset catalog and byte route. */
export declare function supportsChatAudioGeneration(): boolean;
/** Hosted runtimes may use provider authoring; local uses the shared
 * server-owned deterministic fallback and persists the resulting scenes. */
export declare function supportsScenarioTheaterGeneration(): boolean;
/** Keep the shared theater activity visible only when it has an authority.
 * Local can still replay a prepared/ready definition from SQLite, but must not
 * advertise a generate action that would hit the unavailable authoring stream.
 */
export declare function isScenarioTheaterActivityAvailable(content: {
    status?: string;
    definition?: unknown;
} | null | undefined, isMicro: boolean): boolean;
export { isUnitLabActivityAvailable } from "../domain/unit-lab.js";
/** Keep development-only hosted panels hidden whenever their route is absent. */
export declare function shouldRenderGoalBatchGeneration(isDevelopment: boolean): boolean;
/** Goal snapshots/public links require the hosted sharing authority. */
export declare function supportsGoalSharing(): boolean;
