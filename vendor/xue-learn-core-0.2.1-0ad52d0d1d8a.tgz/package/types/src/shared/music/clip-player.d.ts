import { type MusicPerformancePlan as TimelineMusicInput } from "../../../libs/domain/src/index.js";
export declare function renderMusicBuffer(context: BaseAudioContext, plan: TimelineMusicInput): Promise<AudioBuffer>;
export declare class MusicClipPlayer {
    private context?;
    private generation;
    private source?;
    private raf;
    private notify?;
    private disposed;
    private prepared?;
    prepare(plan: TimelineMusicInput): Promise<AudioBuffer>;
    stop(): void;
    play(plan: TimelineMusicInput, offset: number, notify: (tick: number | null) => void): Promise<void>;
    dispose(): void;
}
