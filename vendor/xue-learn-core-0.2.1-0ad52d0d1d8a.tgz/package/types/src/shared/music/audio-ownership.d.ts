export declare function claimMusicAudio(owner: object, stop: () => void): void;
export declare function releaseMusicAudio(owner: object): void;
