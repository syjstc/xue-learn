import { type MusicInstrument, type MusicPlan, type MusicSelection } from "../../../libs/domain/src/index.js";
type Sample = {
    buffer: AudioBuffer;
    peak: number;
    offset: number;
    loopStart: number;
    loopEnd: number;
    rate: number;
    sustain: boolean;
};
export declare const MUSIC_LABELS: Record<MusicInstrument, string>;
export declare function loadMusicSample(context: BaseAudioContext, instrument: MusicInstrument, midi: number): Promise<Sample>;
export declare function scheduleMusicSample(context: BaseAudioContext, destination: AudioNode, sample: Sample, when: number, duration: number, velocity: number): () => void;
export type MusicPlayback = {
    beat: number;
    state: "paused" | "loading" | "playing" | "ended" | "error";
    error?: string;
};
/** One owned context per mounted player. Cancels decoding races, scheduled notes and RAF. */
export declare class MusicPlayer {
    private update;
    private context?;
    private generation;
    private stops;
    private frame;
    private beat;
    private disposed;
    constructor(update: (state: MusicPlayback) => void);
    pause(): void;
    private ready;
    play(plan: MusicPlan, selection: MusicSelection, speed: number, fromBeat: number, loop: boolean): Promise<void>;
    audition(midi: number, instrument: MusicInstrument): Promise<void>;
    dispose(): void;
}
export {};
