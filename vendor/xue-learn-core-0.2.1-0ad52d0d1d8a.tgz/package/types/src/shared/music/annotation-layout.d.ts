type Annotation = {
    id: string;
    center: number;
    width: number;
    height: number;
};
/** Pack measured captions in pitch order. Reserve every caption, even when its cue is hidden. */
export declare function layoutMusicAnnotations(annotations: readonly Annotation[], availableWidth: number, gap?: number): {
    boxes: Map<string, {
        x: number;
        y: number;
        width: number;
        height: number;
    }>;
    height: number;
};
/** Route a leader through the gaps of lower caption rows, never through their copy. */
export declare function routeMusicAnnotation(start: {
    x: number;
    y: number;
}, target: {
    x: number;
    y: number;
}, obstacles: readonly {
    x: number;
    y: number;
    width: number;
    height: number;
}[]): string;
export {};
