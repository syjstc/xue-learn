/** Extract source bodies from fenced markdown code blocks, in document order. */
export declare function extractMarkdownCodeBlocks(markdown: string): string[];
export declare function markdownCodeBlockTargets(blockKey: string, markdown: string): Array<{
    key: string;
    text: string;
}>;
