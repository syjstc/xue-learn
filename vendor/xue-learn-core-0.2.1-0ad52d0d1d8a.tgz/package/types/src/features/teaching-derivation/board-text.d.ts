/** Tiny text/math renderer: no markdown layout/chrome or unsafe HTML on stage. */
export declare function BoardText({ text }: {
    text: string;
}): import("react").JSX.Element;
