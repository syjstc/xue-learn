import { type ReactNode } from "react";
import type { TextHighlightSpan } from "../../shared/domain/material-highlight.js";
export type TextIndexState = {
    index: number;
};
export declare function highlightMarkClassName(active: boolean): string;
export type CharHighlightLookup = Map<number, TextHighlightSpan>;
/** Expand start/end spans into a per-character index map for underline rendering. */
export declare function charHighlightLookup(spans: TextHighlightSpan[]): CharHighlightLookup;
/** Walk rendered markdown nodes and wrap each highlighted character. */
export declare function applyTextHighlights(node: ReactNode, spans: TextHighlightSpan[], onSpanClick: ((aid: string, threadId?: string) => void) | undefined, state: TextIndexState, lookup?: CharHighlightLookup): ReactNode;
