import type { TextHighlightSpan } from "../../shared/domain/material-highlight.js";
import { type MaterialCodePart } from "../../../libs/domain/src/index.js";
export declare function CodeBlockShell({ code, language, className, contentKey, spans, onSpanClick, parts, activeTargetIds, figureId, presentation, }: {
    code: string;
    language?: string;
    className?: string;
    /** Follow-up highlight + selection region key, e.g. block:0:code:0 */
    contentKey?: string;
    spans?: TextHighlightSpan[];
    onSpanClick?: (aid: string, threadId?: string) => void;
    parts?: readonly MaterialCodePart[];
    activeTargetIds?: readonly string[];
    figureId?: string;
    presentation?: "default" | "chat";
}): import("react").JSX.Element;
