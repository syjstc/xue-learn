import type { ReactNode } from "react";
export type CourseCalloutVariant = "definition" | "example" | "warning" | "tip";
/** The host supplies selectable or projected text; meaning determines shape. */
export declare function CourseCallout({ variant, label, title, body, compact, presentation, }: {
    variant: CourseCalloutVariant;
    label: string;
    title?: ReactNode;
    body: ReactNode;
    compact?: boolean;
    presentation?: "film";
}): import("react").JSX.Element;
