import type { CodeBlockShell } from "../markdown/code-block-shell.js";
import type { InteractiveBlock } from "../../shared/llm/schemas.js";
import { type ClassroomCodeLineBox, type CourseDisplayBlock, type MaterialCodePart } from "../../../libs/domain/src/index.js";
import { type ComponentProps, type ReactNode } from "react";
export type ClassroomCodeScrollSample = Readonly<{
    layout: MeasuredClassroomCodeLayout;
    focus?: Readonly<{
        startLine: number;
        endLine: number;
    }>;
    previousFocus?: Readonly<{
        startLine: number;
        endLine: number;
    }>;
}>;
export type CourseCodeDisplayProps = {
    surface: "classroom";
    block: CourseDisplayBlock;
    activeTargetIds?: readonly string[];
    previousActiveTargetIds?: readonly string[];
    clocked?: boolean;
    beatEnter?: number;
    /** Host-proven source partition; bypass authoring caps only when exact. */
    sourceParts?: readonly MaterialCodePart[];
    sampleClockedScroll?: (sample: ClassroomCodeScrollSample) => number;
} | {
    surface: "responsive";
    block: Extract<InteractiveBlock, {
        type: "code";
    }>;
    activeTargetIds?: readonly string[];
    renderCode: (props: ComponentProps<typeof CodeBlockShell>) => ReactNode;
};
/** Both surfaces consume the same code identity and cue targets, without a player dependency. */
export declare function CourseCodeDisplay(props: CourseCodeDisplayProps): string | number | bigint | boolean | import("react").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<ReactNode>>;
type MeasuredClassroomCodeLayout = Readonly<{
    viewportHeight: number;
    contentHeight: number;
    rowHeight: number;
    lineBoxes: readonly ClassroomCodeLineBox[];
}>;
/**
 * Text boards are authored as small, independently addressable source parts.
 * Keep the source untouched at the React boundary, but give the markdown
 * renderer a trimmed display copy so partition newlines do not become empty
 * paragraphs or shift the visual spacing between parts.
 */
export declare function textBoardDisplaySource(sourceText: string): string;
export {};
