import type { MaterialTeachingCueInterval } from "../../../libs/domain/src/index.js";
import { type ReactNode } from "react";
import { type CourseDisplayBlock } from "../../../libs/domain/src/index.js";
import type { CourseDisplayScene } from "../../../libs/domain/src/index.js";
type BoardOptions = {
    calloutPresentation?: "film";
    teachingTimeline?: {
        intervals: readonly MaterialTeachingCueInterval[];
        tick: number;
    };
    revealedTargetIds?: readonly string[];
    previousRevealedTargetIds?: readonly string[];
    animate?: boolean;
    mode?: "classroom" | "chat";
    contentSize?: {
        width: number;
        height: number;
    };
    renderCode?: (block: CourseDisplayBlock, options?: {
        contentSized: boolean;
    }) => ReactNode;
    renderMedia?: (block: CourseDisplayBlock) => ReactNode;
};
export declare function CourseBoardContent(props: BoardOptions & {
    scene: Pick<CourseDisplayScene, "templateId" | "slots" | "title">;
    mediaBlock?: CourseDisplayBlock;
    activeTargetIds?: readonly string[];
    previousActiveTargetIds?: readonly string[];
    clocked?: boolean;
    beatEnter?: number;
}): import("react").JSX.Element;
/** Inline classroom copy: keep `$...$` for HTML KaTeX. */
export declare function ClassroomInlineCopy({ content, className, }: {
    content: string;
    className?: string;
}): import("react").JSX.Element;
export declare function CourseConversationScene(props: {
    title: string;
    mediaBlock?: CourseDisplayBlock;
}): import("react").JSX.Element;
export {};
