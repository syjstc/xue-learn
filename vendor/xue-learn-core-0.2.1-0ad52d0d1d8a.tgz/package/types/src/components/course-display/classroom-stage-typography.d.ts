import { type MaterialStageLayoutPlan, type MaterialStageRect } from "../../../libs/domain/src/index.js";
/** Ordinary lesson figures needed by deterministic stage text fitting. */
export type ClassroomCopyFigure = Readonly<{
    type?: string;
    title?: unknown;
    caption?: unknown;
    body?: unknown;
    summary?: unknown;
    alt?: unknown;
    svg?: unknown;
    imageUrl?: unknown;
    left?: unknown;
    right?: unknown;
    [key: string]: unknown;
}>;
/**
 * Deterministic type fitting for text panes on a composed classroom stage.
 *
 * A stage pane is an absolute box whose size follows the layout plan. The
 * projected copy inside it (callout / paragraph cards, nested compare sides)
 * must fill that box legibly instead of sitting as a small caption in one
 * corner, and it must grow with the pane when a cue promotes it. Nothing here
 * measures the DOM: the estimate is a fixed character-advance model so HTML
 * preview, hidden export windows, and the Canvas painter agree frame by frame.
 *
 * All sizes are 1920×1080 design pixels (`CLASSROOM_EM` = 18px).
 */
export declare const CLASSROOM_STAGE_TYPE_MIN: number;
/**
 * Comfortable ceiling for body copy. The fit maximises size inside the pane,
 * so without this cap a two-line callout on a half-stage pane balloons into
 * poster type; ~1.3em keeps card copy clearly subordinate to the title row.
 */
export declare const CLASSROOM_STAGE_TYPE_MAX: number;
/** A cued pane may run past the shared cap so its copy visibly gains weight. */
export declare const CLASSROOM_STAGE_TYPE_FOCUS_BONUS: number;
/** Font size (px) used when a pane does not carry fitted copy (code, visuals). */
export declare const CLASSROOM_STAGE_TYPE_BASE: number;
/** Card metrics as multiples of the fitted body font size. */
export declare const CLASSROOM_STAGE_CARD: Readonly<{
    padX: 1.25;
    padY: 1.05;
    /** Icon chip column plus its gap in the header row. */
    headerLead: 2.55;
    titleScale: 1.22;
    titleLeading: 1.24;
    /** Accent rule plus the gaps above and below it. */
    ruleBlock: 0.95;
    /** Marker column plus gap before each body row when there are several rows. */
    rowLead: 1.15;
    bodyLeading: 1.52;
    rowGap: 0.36;
}>;
export type ClassroomStageCopy = Readonly<{
    title: string;
    lines: readonly string[];
}>;
/** Estimated advance of one line in em at font size 1. */
export declare function estimateLineAdvanceEm(text: string): number;
/** Keep paired `$...$` for HTML KaTeX; drop a leftover closer after `$12$ ℃$`. */
export declare function classroomBoardDisplayText(text: string): string;
/** Canvas has no KaTeX pass, so unwrap delimiters after the same repair. */
export declare function classroomBoardPaintText(text: string): string;
/** Split body copy into the rows the card paints (blank lines are dropped). */
export declare function classroomStageBodyLines(body: string): string[];
/** Copy painted on a text pane, or `null` for visuals / code that fit themselves. */
export declare function classroomStageCopy(figure: ClassroomCopyFigure): ClassroomStageCopy | null;
/** Estimated painted height (px) of `copy` at font size `size` inside `width`. */
export declare function estimateClassroomStageCopyHeight(copy: ClassroomStageCopy, size: number, width: number, compareSide?: boolean): number;
/** Largest body font size (px) in `[min, max]` whose estimated copy fits `rect`. */
export declare function fitClassroomStageType(copy: ClassroomStageCopy, rect: MaterialStageRect, content: Readonly<{
    width: number;
    height: number;
}>, options?: Readonly<{
    compareSide?: boolean;
    slotPad?: number;
    max?: number;
}>): number;
/** Compile joins compare points with ` · `; paint them back as separate rows. */
export declare function classroomCompareSlotLines(slot: string | undefined): string[];
/** Geometry of the standalone `content.compare` board (mirrors the CSS grid). */
export declare const CLASSROOM_COMPARE_BOARD: Readonly<{
    /** `min(100%, 61em)` at the 18px stage em. */
    maxWidth: number;
    /** Centre pillar (3.8em) plus two 0.75em gaps, in em of the fitted size. */
    pillarEm: number;
    /** Each side card keeps `min-height: 17em` of the fitted size. */
    minSideHeightEm: 17;
}>;
/**
 * Fitted body font size for a standalone compare board. The two side cards
 * share the 61em row, so the longer side drives the fit exactly like a
 * nested compare pane.
 */
export declare function fitClassroomCompareBoard(slots: Readonly<{
    leftLabel?: string;
    left?: string;
    rightLabel?: string;
    right?: string;
}>, content: Readonly<{
    width: number;
    height: number;
}>): number;
export type ClassroomStageTypography = readonly (number | null)[];
/**
 * Per-pane body font size (design px) for the current frame. Both endpoints
 * are fitted on settled plans, then lerped on the shared classroom ease so a
 * word-wrap flip in the estimate cannot pop the type mid-transition.
 */
export declare function classroomStageTypography(params: {
    previousPlan: MaterialStageLayoutPlan;
    currentPlan: MaterialStageLayoutPlan;
    figures: readonly ClassroomCopyFigure[];
    content: Readonly<{
        width: number;
        height: number;
    }>;
    progress: number;
}): ClassroomStageTypography;
/** CSS variable applied on a stage slot; `null` keeps the stylesheet default. */
export declare function classroomStageTypeStyle(size: number | null): Readonly<Record<string, string>>;
/** Presentation type follows the shared slots and stays fixed across cue changes.
 * Long historical copy keeps a readable floor; the reader can expand naturally. */
export declare function classroomPresentationTypography(params: {
    plan: MaterialStageLayoutPlan;
    figures: readonly ClassroomCopyFigure[];
    content: Readonly<{
        width: number;
        height: number;
    }>;
}): ClassroomStageTypography;
/** Finite visual labels share the classroom's fixed design coordinate system. */
export declare function classroomVisualTypography(content?: {
    width: number;
    height: number;
}): number;
