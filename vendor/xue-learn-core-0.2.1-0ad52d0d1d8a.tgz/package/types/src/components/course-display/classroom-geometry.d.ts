/** Design-pixel geometry mirrored from `lesson-performance.css` (18px em). */
export declare const CLASSROOM_EM = 18;
export declare const CLASSROOM_WIDTH = 1920;
export declare const CLASSROOM_HEIGHT = 1080;
export declare const CLASSROOM_INSET_LEFT: number;
export declare const CLASSROOM_INSET_RIGHT: number;
export declare const CLASSROOM_CONTENT_TOP: number;
export declare const CLASSROOM_CONTENT_BOTTOM: number;
export declare const CLASSROOM_OPENING_TOP: number;
export declare const CLASSROOM_OPENING_RIGHT: number;
export declare const CLASSROOM_OPENING_BOTTOM: number;
export declare const CLASSROOM_TOPIC_TOP: number;
export declare const CLASSROOM_TOPIC_SIZE: number;
export declare const CLASSROOM_BRAND_TOP: number;
export declare const CLASSROOM_BRAND_HEIGHT: number;
export declare const CLASSROOM_CARD_MAX_WIDTH: number;
export declare const CLASSROOM_CONTENT_SHIFT: number;
export declare const CLASSROOM_TOPIC_SHIFT: number;
/** Subtitle padding-inline is 3.5% of the design canvas, then 0.25em on the line. */
export declare const CLASSROOM_CAPTION_PAD: number;
export declare const CLASSROOM_CAPTION_LINE_PAD: number;
export declare const CLASSROOM_CAPTION_FONT: number;
export declare const CLASSROOM_CAPTION_LETTER: number;
export declare const CLASSROOM_CAPTION_LINE_HEIGHT = 1.3;
export declare const CLASSROOM_CAPTION_BOTTOM: number;
export declare const CLASSROOM_CAPTION_BOTTOM_OPENING: number;
export declare function classroomContentRect(kind: string): {
    x: number;
    y: number;
    width: number;
    height: number;
};
export declare function classroomCaptionBox(kind: string): {
    x: number;
    width: number;
    bottom: number;
};
