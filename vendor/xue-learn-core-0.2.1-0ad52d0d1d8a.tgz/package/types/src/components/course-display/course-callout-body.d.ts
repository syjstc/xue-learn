import { type CourseDisplayBlock } from "../../../libs/domain/src/index.js";
/** Explicit detail cues animate the existing Markdown; no narration matching,
 * inferred teaching order, content replacement or additional model call. */
export declare function CourseCalloutBody(props: {
    figure: CourseDisplayBlock;
    body: string;
    activeTargetIds: readonly string[];
    previousActiveTargetIds: readonly string[];
    revealedTargetIds?: readonly string[];
    previousRevealedTargetIds?: readonly string[];
    clocked: boolean;
    animate: boolean;
    /** Classroom/export reserve every row, including unspoken detail copy. */
    reserveSpace?: boolean;
    progress?: number;
    presentation?: "film";
}): import("react").JSX.Element;
