import { type CourseDisplayBlock } from "../../../libs/domain/src/index.js";
import type { CourseDisplayScene } from "../../../libs/domain/src/index.js";
/**
 * Text boards are authored as small, independently addressable source parts.
 * Keep the source untouched at the React boundary, but give the markdown
 * renderer a trimmed display copy so partition newlines do not become empty
 * paragraphs or shift the visual spacing between parts.
 */
export declare function textBoardDisplaySource(sourceText: string): string;
export declare function staticSvgMarkup(block: CourseDisplayBlock | undefined): string | null;
export declare function staticIllustrationUrl(block: CourseDisplayBlock | undefined): string | null;
/** Let CSS own the 16:9 board; authored px width/height overflow the stage. */
export declare function prepareStageSvgMarkup(svg: string): string;
export declare function StageStaticSvg({ markup, className, alt, stage, }: {
    markup: string;
    className?: string;
    alt?: string;
    stage?: boolean;
}): import("react").JSX.Element;
export declare function CourseBoardImage({ src, alt, className, loading, }: {
    src: string;
    alt: string;
    className?: string;
    loading?: "lazy" | "eager";
}): import("react").JSX.Element;
export declare function StageCodeBoard({ block, activeTargetIds, previousActiveTargetIds, clocked, beatEnter, contentSized, }: {
    block: CourseDisplayBlock;
    activeTargetIds?: readonly string[];
    previousActiveTargetIds?: readonly string[];
    clocked?: boolean;
    beatEnter?: number;
    contentSized?: boolean;
}): import("react").JSX.Element;
export declare function CourseMediaScene(props: {
    scene: Pick<CourseDisplayScene, "slots">;
    mediaBlock?: CourseDisplayBlock;
    activeTargetIds?: readonly string[];
    previousActiveTargetIds?: readonly string[];
    clocked?: boolean;
    beatEnter?: number;
    /**
     * Nested stage panes already expose the figure's cue node on
     * `.lp-composed-figure`. A leftover `data-lp-target="media"` would be
     * treated as unlit and dim the focused picture.
     */
    nested?: boolean;
    interactive?: boolean;
}): import("react").JSX.Element;
