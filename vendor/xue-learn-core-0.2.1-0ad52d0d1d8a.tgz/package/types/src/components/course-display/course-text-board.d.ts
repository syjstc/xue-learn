import { type CourseDisplayBlock, type MaterialStageLayoutPlan } from "../../../libs/domain/src/index.js";
import { courseTextBoard } from "../../shared/domain/course-text-board.js";
type TextBoard = NonNullable<ReturnType<typeof courseTextBoard>>;
export declare function CourseTextBoard({ board, figures, plan, labels, }: {
    board: TextBoard;
    figures: readonly CourseDisplayBlock[];
    plan: MaterialStageLayoutPlan;
    labels: Readonly<Record<string, string>>;
}): import("react").JSX.Element;
export {};
