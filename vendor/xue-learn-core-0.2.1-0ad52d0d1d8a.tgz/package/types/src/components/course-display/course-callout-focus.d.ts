/** Measure the uncued, reserved rows once per layout. Only the independent light
 * plate moves; glyph positions and wrapping never depend on a narration cue. */
export declare function CourseCalloutFocus({ layoutKey, items }: {
    layoutKey: string;
    items: readonly {
        emphasis: number;
    }[];
}): import("react").JSX.Element;
