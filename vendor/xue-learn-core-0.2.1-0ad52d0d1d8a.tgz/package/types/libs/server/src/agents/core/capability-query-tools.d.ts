import type { LearningSystemActivationResolver } from "../../learning-systems/activation.js";
import { LearningSystemRegistry } from "../../learning-systems/registry.js";
import { CapabilityQueryToolGateway } from "../../learning-systems/tool-gateway.js";
import type { BoundToolSubject, ContextEnvelope } from "../../learning-systems/types.js";
import { type GenerationContextMode } from "../../generation/kernel.js";
import type { AgentToolDef } from "./types.js";
export type CapabilityAgentQueryTools = {
    tools: AgentToolDef[];
    gateway: CapabilityQueryToolGateway;
    unavailableToolKeys: string[];
    resolvedToolKeys: string[];
    mode: GenerationContextMode;
    parityError?: string;
};
export type CreateCapabilityAgentQueryToolsOptions = {
    registry: LearningSystemRegistry;
    activationResolver: LearningSystemActivationResolver;
    operation: string;
    subject: BoundToolSubject;
    signal?: AbortSignal;
    selectedToolKeys?: readonly string[];
    presentationAdapters?: Readonly<Record<string, Pick<AgentToolDef, "renderUi">>>;
};
export type AgentCapabilityQueryResult = {
    data: unknown;
    authority: ContextEnvelope["authority"];
    scope: ContextEnvelope["scope"];
    freshness: ContextEnvelope["freshness"];
    provenance: {
        capabilityId: string;
        capabilityVersion: string;
        schemaVersion: number;
    };
};
/**
 * Bridges operation-allowlisted capability query tools into the existing agent
 * runtime without exposing the registry, capability identities, or write plane
 * to the model.
 *
 * The returned gateway is intentionally shared by every generated tool
 * handler. Its per-tool call limits and total lazy-context token budget
 * therefore apply to the complete agent run rather than to individual calls.
 */
export declare function createCapabilityAgentQueryTools({ registry, activationResolver, operation, subject, signal, selectedToolKeys, presentationAdapters, }: CreateCapabilityAgentQueryToolsOptions): Promise<CapabilityAgentQueryTools>;
export declare function resolveOperationMaxToolRounds(operation: string, fallback: number): number;
