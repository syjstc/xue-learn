import type { AgentConversationRepository } from "../../../../domain/src/index.js";
import type { AgentRegistry } from "./agent-registry.js";
import type { LlmMessageRecord } from "./types.js";
export declare function configureAgentCheckpointPersistence(repository: AgentConversationRepository | undefined): void;
export declare function requireAgentConversationPersistence(): AgentConversationRepository;
export type ThreadCheckpoint = {
    llmMessages: LlmMessageRecord[];
    /** LLM trace id for the in-flight agent task; cleared when the task completes. */
    activeTraceId?: string;
    pendingInterrupt?: {
        toolCallId: string;
        toolName: string;
        uiKind: string;
        args: Record<string, unknown>;
    } | null;
    agentRegistry?: AgentRegistry;
    goalCreationActive?: boolean;
    goalCreationPaused?: boolean;
    goalCreationMessages?: LlmMessageRecord[];
    goalCreationPausedInterrupt?: ThreadCheckpoint["pendingInterrupt"];
    goalState?: Record<string, unknown>;
    mainMessages?: LlmMessageRecord[];
    [key: string]: unknown;
};
export declare function loadCheckpoint(threadId: string): Promise<ThreadCheckpoint>;
export declare function saveCheckpoint(threadId: string, checkpoint: ThreadCheckpoint): Promise<void>;
export declare function appendAgentMessage(threadId: string, message: {
    role: string;
    content?: string;
    toolCalls?: unknown[];
    toolCallId?: string;
    uiPayload?: Record<string, unknown>;
    metadata?: Record<string, unknown>;
}): Promise<Readonly<{
    id: string;
    threadId: string;
    role: string;
    content: string;
    toolCalls: string;
    toolCallId: string | null;
    uiPayload: string;
    metadataJson: string;
    createdAt: Date;
}>>;
export declare function loadThreadMessages(threadId: string): Promise<readonly Readonly<{
    id: string;
    threadId: string;
    role: string;
    content: string;
    toolCalls: string;
    toolCallId: string | null;
    uiPayload: string;
    metadataJson: string;
    createdAt: Date;
}>[]>;
