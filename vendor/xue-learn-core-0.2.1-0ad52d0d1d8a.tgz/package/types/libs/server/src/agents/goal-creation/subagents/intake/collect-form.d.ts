import { type ThreadCheckpoint } from "../../../core/checkpoint.js";
import type { RunSubagentResult } from "../../../core/runtime.js";
import type { AgentRunContext } from "../../../core/types.js";
import { type CollectFormField, type GoalCreationState, type GoalSpaceSuggestion } from "../../state.js";
export declare function normalizeCollectFormFieldValue(field: "level" | "contentLanguage", value: unknown): string | undefined;
export declare function needsCollectFormInterrupt(state: GoalCreationState): boolean;
export declare function collectFormFieldsForState(state: GoalCreationState): CollectFormField[];
export declare function inferFormDefaultsFromState(state: GoalCreationState): Record<string, unknown>;
export declare function collectFormDefaultsForState(state: GoalCreationState, overrides?: Record<string, unknown>): Record<string, unknown>;
/** Normalize collect_form UI args so mandatory fields always reach the client. */
export declare function enrichCollectFormUiArgs(state: GoalCreationState, args?: Record<string, unknown>): Record<string, unknown>;
export declare function interruptForCollectForm(ctx: AgentRunContext, checkpoint: ThreadCheckpoint, embedded: boolean): Promise<RunSubagentResult>;
export declare function interruptForConfirmation(ctx: AgentRunContext, checkpoint: ThreadCheckpoint, embedded: boolean): Promise<RunSubagentResult>;
export declare function interruptForGoalSpaceSuggestion(ctx: AgentRunContext, checkpoint: ThreadCheckpoint, embedded: boolean, suggestion: GoalSpaceSuggestion): Promise<RunSubagentResult>;
