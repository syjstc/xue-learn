import { z } from "zod";
import type { PlanningMode } from "../../../../domain/src/index.js";
import type { GoalCreationState } from "./state.js";
export declare const goalCreationExecutionModes: readonly ["guided", "agentic"];
export type GoalCreationExecutionMode = (typeof goalCreationExecutionModes)[number];
export declare const goalTeachingIntentSchema: z.ZodObject<{
    targetLevel: z.ZodString;
    observableOutcomes: z.ZodArray<z.ZodString>;
    includedScope: z.ZodArray<z.ZodString>;
    excludedScope: z.ZodArray<z.ZodString>;
    prerequisiteBridges: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export type GoalTeachingIntent = z.infer<typeof goalTeachingIntentSchema>;
export declare const goalCreationContractSchema: z.ZodObject<{
    schemaVersion: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
    teachingIntent: z.ZodOptional<z.ZodObject<{
        targetLevel: z.ZodString;
        observableOutcomes: z.ZodArray<z.ZodString>;
        includedScope: z.ZodArray<z.ZodString>;
        excludedScope: z.ZodArray<z.ZodString>;
        prerequisiteBridges: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>;
    originalRequest: z.ZodString;
    interpretedOutcome: z.ZodString;
    includedScope: z.ZodArray<z.ZodString>;
    excludedScope: z.ZodArray<z.ZodString>;
    level: z.ZodEnum<{
        zero: "zero";
        basic: "basic";
        advanced: "advanced";
    }>;
    learningMode: z.ZodEnum<{
        exploration: "exploration";
        mastery: "mastery";
    }>;
    planningMode: z.ZodEnum<{
        fast: "fast";
        deep: "deep";
        docs_first: "docs_first";
    }>;
    contentLanguage: z.ZodString;
    constraints: z.ZodArray<z.ZodString>;
    sourceReferences: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            web: "web";
            planned_goal: "planned_goal";
            upload: "upload";
            rag: "rag";
            profile: "profile";
        }>;
        label: z.ZodString;
        contentHash: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    discoveryAnswers: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionText: z.ZodOptional<z.ZodString>;
        answer: z.ZodUnion<readonly [z.ZodString, z.ZodArray<z.ZodString>]>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type GoalCreationContract = z.infer<typeof goalCreationContractSchema>;
export declare function canonicalizeGoalCreationContract(value: unknown): GoalCreationContract;
export declare function formatDeterministicPromptValue(value: unknown): string;
export declare function goalCreationContractJson(contract: GoalCreationContract): string;
export declare function formatGoalCreationContractPrompt(contractJson: string): string;
export declare function goalCreationContractHash(contract: GoalCreationContract): string;
export declare function compileGoalCreationContract(state: GoalCreationState): GoalCreationContract;
export declare function resolveGoalCreationExecutionMode(input: {
    isSmallCourse: boolean;
    isPlannedGoalActivation: boolean;
    autoApproveWithoutQuestions: boolean;
}): GoalCreationExecutionMode;
/** Full placeholder activations without uploads still use deep research. */
export declare function resolvePlannedGoalActivationPlanningMode(input: {
    isSmallCourse: boolean;
    hasDocuments: boolean;
    suggestedPlanningMode?: PlanningMode;
}): PlanningMode;
/** Planned placeholders already carry intake authority; only confirmation remains. */
export declare function shouldConfirmPlannedGoalWithoutIntake(state: Pick<GoalCreationState, "isPlannedGoalActivation" | "goalId" | "currentPhase">): boolean;
export declare function isAgenticGoalCreation(state: Pick<GoalCreationState, "isSmallCourse" | "isPlannedGoalActivation" | "autoApproveWithoutQuestions">): boolean;
