/** One trace id per agent task (user turn + follow-up resumes), not per thread. */
export declare function resolveAgentTraceId(threadId: string, options?: {
    continueTask?: boolean;
}): Promise<string>;
export declare function clearAgentTraceId(threadId: string): Promise<void>;
export declare function agentTaskStillOpen(threadId: string): Promise<boolean>;
