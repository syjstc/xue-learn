import { type GoalMapPlan, type GoalMapSummary } from "../../llm/schemas.js";
import type { AgentRunContext } from "../core/types.js";
import type { LegacyMapReplacementRepository } from "../../../../domain/src/index.js";
import type { OverviewCoursePublicationRepository } from "../../../../domain/src/index.js";
import type { LearningGoalPlanRepository } from "../../../../domain/src/index.js";
import type { ModuleStructureDraftRepository } from "../../../../domain/src/index.js";
import type { ModuleStructureQueueRepository } from "../../../../domain/src/index.js";
import type { SequentialCurriculumApprovalRepository } from "../../../../domain/src/index.js";
import type { CognitiveModelInvalidationRepository } from "../../../../domain/src/index.js";
import type { GoalCreationState } from "./state.js";
import type { LearningSpaceGoalCreationApplication } from "../../learning-spaces/orm-application-service.js";
type GoalPlanGenerationOptions = Readonly<{
    adjustment?: string;
    learningGoalPlan?: LearningGoalPlanRepository;
}>;
type GoalPlanApprovalOptions = Readonly<{
    learningGoalPlan?: LearningGoalPlanRepository;
    sequentialCurriculumApproval?: SequentialCurriculumApprovalRepository;
    moduleStructureQueue?: ModuleStructureQueueRepository;
    moduleStructureDraft?: ModuleStructureDraftRepository;
    sessionId?: string;
    structureQueueMode?: "direct" | "draft";
}>;
export declare function createGoalRecord(userId: string, state: GoalCreationState, options?: {
    threadId?: string;
    onStatus?: (message: string) => void | Promise<void>;
    learningSpaceApplication?: LearningSpaceGoalCreationApplication;
}): Promise<{
    goalId: string;
}>;
export declare function generatePlanForGoal(userId: string, state: GoalCreationState, ctx: Pick<AgentRunContext, "send" | "signal" | "threadId" | "traceId">, options?: GoalPlanGenerationOptions): Promise<GoalMapPlan>;
export declare function generateSummaryForGoal(userId: string, state: GoalCreationState, ctx: Pick<AgentRunContext, "send" | "signal" | "threadId">, options?: {
    adjustment?: string;
}): Promise<GoalMapSummary>;
export declare function patchGoalPlan(userId: string, goalId: string, patch: {
    topicOverview?: string;
    whatYouWillLearn?: string[];
    majorAreas?: GoalMapPlan["majorAreas"];
    outOfScope?: string[];
    prerequisitesAssumed?: string[];
}): Promise<GoalMapPlan>;
export declare function approveGoalPlan(userId: string, goalId: string, options?: GoalPlanApprovalOptions): Promise<void>;
export declare function approveGoalSummary(userId: string, goalId: string, fallbackSummary?: GoalMapSummary | null): Promise<void>;
export declare function decomposeGoalMap(userId: string, state: GoalCreationState, ctx: AgentRunContext, options?: {
    legacyMapReplacement?: LegacyMapReplacementRepository;
    cognitiveModelInvalidation?: CognitiveModelInvalidationRepository;
}): Promise<{
    goalId: string;
    unitCount: number;
    complete: boolean;
    modulesNeedingExpansion?: Array<{
        id: string;
        title: string;
    }>;
}>;
export declare function generateOverviewCourseForGoal(userId: string, state: GoalCreationState, ctx: AgentRunContext, options?: {
    overviewCoursePublication?: OverviewCoursePublicationRepository;
}): Promise<{
    navigateTo: string;
    overviewCourseStatus: string;
}>;
export declare function formatLanguageLabel(code: string): string;
export {};
