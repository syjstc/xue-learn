/**
 * Resolve the title shown on the confirmation card without starting another
 * model call during the persistence step.
 */
export declare function resolveConfirmedGoalTitle(input: {
    topic: string;
    refinedTitle: string;
    isSmallCourse: boolean;
}): string;
