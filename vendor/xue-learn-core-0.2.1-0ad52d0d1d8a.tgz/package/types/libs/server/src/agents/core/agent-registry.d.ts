import type { GoalCreationState } from "../goal-creation/state.js";
import type { ThreadCheckpoint } from "./checkpoint.js";
import type { AgentPhase, AgentSubagent, LlmMessageRecord } from "./types.js";
export type AgentId = "global" | "goal_creation";
export type AgentStatus = "idle" | "active" | "paused" | "waiting_user";
export type HandoffReason = "out_of_scope" | "user_global_request" | "explicit_handoff" | "resume_goal_creation" | "user_resume_request" | "user_exit";
export type LiveAgentStructuredContext = {
    topic?: string;
    goalId?: string;
    goalTitle?: string;
    mapPlanStatus?: string;
    collectedFields?: string[];
    pendingTool?: string;
};
export type LiveAgentCard = {
    agentId: AgentId;
    displayName: string;
    status: AgentStatus;
    subagent?: AgentSubagent;
    phase?: AgentPhase;
    latestMessage: string;
    latestMessageRole: "user" | "assistant";
    lastActiveAt: string;
    summary: string;
    structuredContext: LiveAgentStructuredContext;
    handoffReason?: string;
};
export type HandoffSnapshot = Pick<LiveAgentCard, "summary" | "structuredContext" | "latestMessage" | "subagent" | "phase">;
export type HandoffPacket = {
    from: AgentId;
    to: AgentId;
    question: string;
    reason: HandoffReason;
    at: string;
    fromSnapshot: HandoffSnapshot;
};
export type AgentRegistry = {
    activeAgentId: AgentId;
    agents: Partial<Record<AgentId, LiveAgentCard>>;
    /** @deprecated Prefer `handoffHistory`; kept for checkpoint migration. */
    lastHandoff?: HandoffPacket;
    handoffHistory?: HandoffPacket[];
};
export declare function createDefaultAgentCard(agentId: AgentId): LiveAgentCard;
export declare function createInitialRegistry(): AgentRegistry;
export declare function normalizeHandoffHistory(registry: AgentRegistry): HandoffPacket[];
export declare function normalizeRegistry(registry: AgentRegistry): AgentRegistry;
export declare function registryFromCheckpoint(checkpoint: ThreadCheckpoint): AgentRegistry;
export declare function deriveRegistryFromLegacy(checkpoint: ThreadCheckpoint): AgentRegistry;
export declare function initRegistry(checkpoint: ThreadCheckpoint): ThreadCheckpoint;
export declare function syncLegacyFlagsFromRegistry(checkpoint: ThreadCheckpoint): ThreadCheckpoint;
export declare function syncRegistryToCheckpoint(checkpoint: ThreadCheckpoint, registry: AgentRegistry): ThreadCheckpoint;
export declare function getActiveAgent(registry: AgentRegistry): AgentId;
export declare function snapshotCard(registry: AgentRegistry, agentId: AgentId): HandoffSnapshot;
export declare function updateAgentCard(registry: AgentRegistry, agentId: AgentId, patch: Partial<LiveAgentCard>): AgentRegistry;
export declare function appendHandoffHistory(registry: AgentRegistry, packet: Omit<HandoffPacket, "at" | "fromSnapshot"> & {
    fromSnapshot?: HandoffSnapshot;
}): AgentRegistry;
export declare function performHandoff(registry: AgentRegistry, packet: Omit<HandoffPacket, "at" | "fromSnapshot"> & {
    fromSnapshot?: HandoffSnapshot;
}): AgentRegistry;
export declare function setActiveAgent(registry: AgentRegistry, agentId: AgentId): AgentRegistry;
export declare function buildProgressSummary(goalState: GoalCreationState, pendingTool?: string): string;
export declare function buildStructuredContextFromGoalState(goalState: GoalCreationState, pendingTool?: string): LiveAgentStructuredContext;
export declare function extractLatestMessage(messages: LlmMessageRecord[]): {
    content: string;
    role: "user" | "assistant";
};
export declare function syncGoalCreationCard(registry: AgentRegistry, checkpoint: ThreadCheckpoint, statusOverride?: AgentStatus): AgentRegistry;
export declare function syncGlobalCard(registry: AgentRegistry, checkpoint: ThreadCheckpoint, statusOverride?: AgentStatus): AgentRegistry;
export declare function syncRegistryFromCheckpoint(checkpoint: ThreadCheckpoint): AgentRegistry;
export declare function applyRegistryToCheckpoint(checkpoint: ThreadCheckpoint, registry: AgentRegistry): ThreadCheckpoint;
export declare function buildHandoffHistoryPrompt(registry: AgentRegistry): string;
export declare function buildAgentAwarenessPrompt(registry: AgentRegistry, selfAgentId: AgentId): string;
export declare function buildResumeContextPrompt(registry: AgentRegistry): string;
export declare function updateRegistryAfterAgentTurn(checkpoint: ThreadCheckpoint, agentId: AgentId, messages?: LlmMessageRecord[]): ThreadCheckpoint;
export declare function handoffGoalCreationToGlobal(checkpoint: ThreadCheckpoint, question: string, reason: HandoffReason, explicitReason?: string): ThreadCheckpoint;
