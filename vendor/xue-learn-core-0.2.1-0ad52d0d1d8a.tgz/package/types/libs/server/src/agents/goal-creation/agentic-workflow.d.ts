import type { AgentRunContext } from "../core/types.js";
import type { ThreadCheckpoint } from "../core/checkpoint.js";
import type { GoalCreationRunOptions } from "./embedded.js";
export declare function runAgenticPostApproval(ctx: AgentRunContext, userId: string, _checkpoint: ThreadCheckpoint, options: GoalCreationRunOptions, sessionId: string): Promise<ThreadCheckpoint>;
export declare function shouldRunAgenticPostApproval(checkpoint: ThreadCheckpoint): boolean;
