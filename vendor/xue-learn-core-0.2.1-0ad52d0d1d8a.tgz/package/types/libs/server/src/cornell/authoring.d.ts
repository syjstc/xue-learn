import { z } from "zod";
import { type CornellJitItem } from "../llm/jit-structured-items.js";
export type PrepareCornellAuthoringInput = {
    unitTitle: string;
    goalBlock: string;
    difficultyBlock: string;
    timeBudgetBlock: string;
    styleBlock: string;
    languageBlock: string;
    optionsBlock?: string;
    sqJson: string;
    materialJson: string;
    context?: string;
};
export declare function cornellItemsFromCommitArgs(value: unknown): unknown;
/** Compact continuation when Survey/material already live in authoring history. */
export declare function buildCornellHistoryContinuationPrompt(input: {
    unitTitle: string;
    languageBlock: string;
    styleBlock?: string;
    optionsBlock?: string;
    context?: string;
}): string;
export declare function cornellHistoryResultSchema(): z.ZodPreprocess<z.ZodPipe<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"note">;
    text: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"cue">;
    text: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"summary">;
    text: z.ZodString;
}, z.core.$strip>], "kind">>, z.ZodTransform<{
    notes: string;
    cues: string;
    summary: string;
}, ({
    kind: "note";
    text: string;
} | {
    kind: "cue";
    text: string;
} | {
    kind: "summary";
    text: string;
})[]>>>;
/** Provider-independent Cornell-note contract shared by hosted and local. */
export declare function prepareCornellAuthoring(input: PrepareCornellAuthoringInput): {
    operation: "unit.cornell";
    prompt: string;
    contextInvocation: {
        optionsBlock: string;
        context: string;
        unitTitle: string;
        goalBlock: string;
        difficultyBlock: string;
        timeBudgetBlock: string;
        styleBlock: string;
        languageBlock: string;
        sqJson: string;
        materialJson: string;
    };
    itemSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"note">;
        text: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"cue">;
        text: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"summary">;
        text: z.ZodString;
    }, z.core.$strip>], "kind">;
    itemsSchema: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"note">;
        text: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"cue">;
        text: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"summary">;
        text: z.ZodString;
    }, z.core.$strip>], "kind">>;
    resultSchema: z.ZodPipe<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"note">;
        text: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"cue">;
        text: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"summary">;
        text: z.ZodString;
    }, z.core.$strip>], "kind">>, z.ZodTransform<{
        notes: string;
        cues: string;
        summary: string;
    }, ({
        kind: "note";
        text: string;
    } | {
        kind: "cue";
        text: string;
    } | {
        kind: "summary";
        text: string;
    })[]>>;
    parseProviderOutput(content: string): {
        notes: string;
        cues: string;
        summary: string;
    };
};
export type { CornellJitItem };
