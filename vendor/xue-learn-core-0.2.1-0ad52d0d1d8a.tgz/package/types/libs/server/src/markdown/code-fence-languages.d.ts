/**
 * highlight.js language ids we prompt for and repair toward.
 * Keep in sync with web/mobile highlight registration (minus markdown).
 */
export declare const HIGHLIGHT_CODE_LANGUAGE_IDS: readonly ["rust", "python", "javascript", "typescript", "java", "go", "bash", "sql", "json", "yaml", "cpp", "csharp", "kotlin", "swift", "php", "ruby", "c", "css", "xml", "diff", "dockerfile", "graphql", "ini", "lua", "makefile", "objectivec", "perl", "powershell", "r", "scala", "scss", "vbnet", "wasm"];
export type HighlightCodeLanguageId = (typeof HIGHLIGHT_CODE_LANGUAGE_IDS)[number];
/** Non-code fence info strings that must never be overwritten by repair. */
export declare const RESERVED_FENCE_LANGUAGE_IDS: readonly ["math", "latex", "tex", "flowchart", "mermaid", "graph"];
/** LLM placeholder tags — treat like a missing language. */
export declare const PLACEHOLDER_FENCE_LANGUAGE_IDS: readonly ["xxx", "code", "lang", "language", "plaintext", "plain", "text", "txt", "example", "snippet", "source", "output", "console"];
/** Prompt-facing comma list of highlight.js ids. */
export declare function formatHighlightCodeLanguagePromptList(): string;
/** Canonical highlight id, or undefined if unknown. */
export declare function resolveHighlightCodeLanguage(language?: string | null): HighlightCodeLanguageId | undefined;
export declare function isReservedFenceLanguage(language?: string | null): boolean;
export declare function isPlaceholderFenceLanguage(language?: string | null): boolean;
/**
 * True when the fence opener should keep its info string as-is
 * (known highlight id, reserved math/graph tag, or non-placeholder unknown).
 */
export declare function shouldKeepFenceLanguage(language?: string | null): boolean;
