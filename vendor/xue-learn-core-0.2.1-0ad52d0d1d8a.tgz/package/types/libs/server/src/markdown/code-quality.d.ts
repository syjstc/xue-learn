import type { InteractiveBlock } from "../llm/schemas.js";
import { type RepairCodeFencesOptions } from "./repair-code-fences.js";
import { type HighlightCodeLanguageId } from "./code-fence-languages.js";
export type InvalidGeneratedCode = {
    source: string;
    language: HighlightCodeLanguageId;
    error: Error;
};
export type ImproveCodeOptions = RepairCodeFencesOptions & {
    /** Repair one invalid source value without regenerating its surrounding material. */
    repairInvalidCode?: (request: InvalidGeneratedCode) => Promise<string>;
    /** Keep the lesson publishable if the localized repair also fails. */
    preserveInvalidCodeAsText?: boolean;
    onInvalidCodeFallback?: (request: InvalidGeneratedCode) => void | Promise<void>;
};
/**
 * Repairs legacy fence shapes, rejects syntactically invalid supported code,
 * and formats valid code using a language-native formatter when available.
 * Heavy runtimes and individual grammars are loaded only when a generated
 * material block actually contains a supported code fence.
 */
export declare function improveMarkdownCodeFences(markdown: string, options?: ImproveCodeOptions): Promise<string>;
export declare function improveLearningMaterialCode(material: {
    introduction: string;
    blocks: InteractiveBlock[];
    keyTakeaways: string[];
}, options?: ImproveCodeOptions): Promise<typeof material>;
