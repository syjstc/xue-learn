import type { CognitiveModelPublicationRepository } from "../../../domain/src/index.js";
export declare const COGNITIVE_MODEL_PUBLICATION_REPOSITORY: unique symbol;
export type CognitiveModelPublicationPort = CognitiveModelPublicationRepository;
