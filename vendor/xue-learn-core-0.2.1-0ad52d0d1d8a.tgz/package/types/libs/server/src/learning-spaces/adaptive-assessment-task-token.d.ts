export declare const ADAPTIVE_ASSESSMENT_TASK_REPOSITORY: unique symbol;
