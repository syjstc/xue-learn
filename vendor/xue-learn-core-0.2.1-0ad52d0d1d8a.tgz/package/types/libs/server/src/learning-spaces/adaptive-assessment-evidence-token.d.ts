export declare const ADAPTIVE_ASSESSMENT_EVIDENCE_REPOSITORY: unique symbol;
