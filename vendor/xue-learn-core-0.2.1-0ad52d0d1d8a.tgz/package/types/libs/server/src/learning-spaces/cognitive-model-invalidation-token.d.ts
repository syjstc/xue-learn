export declare const COGNITIVE_MODEL_INVALIDATION_REPOSITORY: unique symbol;
