/** Nest composition token for post-completion learned-knowledge source reads. */
export declare const COMPLETED_UNIT_KNOWLEDGE_READ_REPOSITORY: unique symbol;
