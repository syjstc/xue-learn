import type { CognitiveModelGenerationRunRepository } from "../../../domain/src/index.js";
/** Nest token for the owner-scoped unit cognitive-generation run lifecycle. */
export declare const COGNITIVE_MODEL_GENERATION_RUN_REPOSITORY: unique symbol;
export type CognitiveModelGenerationRunPort = CognitiveModelGenerationRunRepository;
