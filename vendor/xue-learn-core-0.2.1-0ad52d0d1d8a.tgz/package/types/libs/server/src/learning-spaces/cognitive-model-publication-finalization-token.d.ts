import type { CognitiveModelPublicationFinalizationRepository } from "../../../domain/src/index.js";
export declare const COGNITIVE_MODEL_PUBLICATION_FINALIZATION_REPOSITORY: unique symbol;
export type CognitiveModelPublicationFinalizationPort = CognitiveModelPublicationFinalizationRepository;
