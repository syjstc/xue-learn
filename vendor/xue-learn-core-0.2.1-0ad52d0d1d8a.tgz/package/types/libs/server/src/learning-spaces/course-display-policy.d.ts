import type { LearningSpaceItemRepository, LearningSpaceRepository } from "../../../domain/src/index.js";
type PolicyPersistence = {
    spaces: Pick<LearningSpaceRepository, "listByUserId">;
    items: Pick<LearningSpaceItemRepository, "findByGoalId">;
};
export declare function configureCourseDisplayPolicyPersistence(value?: PolicyPersistence): void;
/** Resolve actual membership for each generation, including existing goals and moved courses. */
export declare function isGeneralEducationCourse(userId: string, goalId: string): Promise<boolean>;
export {};
