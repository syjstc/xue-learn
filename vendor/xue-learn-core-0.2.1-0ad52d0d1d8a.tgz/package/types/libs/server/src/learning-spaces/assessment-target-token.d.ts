export declare const ASSESSMENT_TARGET_REPOSITORY: unique symbol;
