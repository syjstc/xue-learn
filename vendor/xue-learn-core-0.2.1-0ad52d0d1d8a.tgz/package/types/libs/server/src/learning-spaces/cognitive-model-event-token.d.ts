export declare const COGNITIVE_MODEL_EVENT_REPOSITORY: unique symbol;
