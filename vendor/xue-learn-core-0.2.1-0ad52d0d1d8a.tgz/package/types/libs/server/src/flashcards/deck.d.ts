import type { FlashcardExperienceRepository } from "../../../domain/src/index.js";
import type { StreamTokenHandler } from "../llm/chat-stream.js";
export declare function generateFlashcardDeckForUnit(repository: FlashcardExperienceRepository, unitId: string, userId: string, options?: {
    onToken?: StreamTokenHandler;
    signal?: AbortSignal;
}): Promise<{
    deckId: string;
    cardCount: number;
    sourceHash: string;
}>;
export declare function getUnitFlashcardDeck(repository: FlashcardExperienceRepository, unitId: string, userId: string): Promise<{
    id: string;
    unitId: string;
    cardCount: number;
    generatedAt: string;
    sourceHash: string;
    stale: boolean;
    stats: {
        due: number;
        new: number;
        learning: number;
        total: number;
    };
}>;
