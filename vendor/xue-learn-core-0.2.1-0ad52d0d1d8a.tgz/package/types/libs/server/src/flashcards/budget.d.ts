export declare const MAX_GENERATED_FLASHCARDS = 15;
/**
 * Preserve coverage first, then target minimums, then optional extra cards,
 * without ever exceeding the authoritative deck limit.
 */
export declare function boundFlashcardBudgets(budgets: ReadonlyArray<{
    min: number;
    max: number;
}>, limit?: number): Array<{
    min: number;
    max: number;
}>;
