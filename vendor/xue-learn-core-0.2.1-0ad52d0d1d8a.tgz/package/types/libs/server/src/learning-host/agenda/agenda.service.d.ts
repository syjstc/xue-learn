import { LearningSpaceOrmProvider } from "../../learning-spaces/learning-space-orm.provider.js";
export declare class AgendaService {
    private readonly learningSpaceOrm;
    constructor(learningSpaceOrm: LearningSpaceOrmProvider);
    getAgenda(userId: string, goalId?: string, spaceId?: string): Promise<import("../../agenda/queries.js").AgendaResponse>;
    getSettings(userId: string): Promise<import("../../agenda/settings.js").PlanningSettings>;
    patchSettings(userId: string, body: unknown): Promise<import("../../agenda/settings.js").PlanningSettings>;
    patchTodayCapacity(userId: string, body: unknown): Promise<import("../../agenda/settings.js").PlanningSettings>;
    refresh(userId: string, body: unknown): Promise<import("../../agenda/refresh.js").RefreshAgendaResult>;
    getItemExplanation(userId: string, id: string): Promise<{
        id: string;
        explanation: string;
        explanationCode: string;
        itemType: string;
        plannedDate: string;
        priority: number;
    }>;
}
