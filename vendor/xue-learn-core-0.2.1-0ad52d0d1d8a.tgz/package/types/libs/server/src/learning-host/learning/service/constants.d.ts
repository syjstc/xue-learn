export declare const KACOM_ASSESSMENT_ACTIONS: Set<string>;
