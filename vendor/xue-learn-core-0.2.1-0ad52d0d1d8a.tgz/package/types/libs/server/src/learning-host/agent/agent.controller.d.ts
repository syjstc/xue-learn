import type { AgentPageContext, DocumentGoalSeed, GoalCreationDraft } from "../../agents/index.js";
import type { Response } from "express";
import { AgentService, type AgentUploadFile } from "./agent.service.js";
import { GoalCreationSessionService } from "./goal-creation-session.service.js";
export declare class AgentController {
    private readonly agent;
    private readonly goalCreationSessions;
    constructor(agent: AgentService, goalCreationSessions: GoalCreationSessionService);
    createGoalCreationSession(userId: string): Promise<{
        created: boolean;
        session: {
            id: string;
            threadId: string;
            goalId: string;
            status: string;
            phase: string;
            flowMode: string;
            version: number;
            currentRunId: string;
            firstUnitId: string;
            lastError: string;
            pendingInteraction: {
                toolCallId: string;
                toolName: string;
                uiKind: string;
                args: Record<string, unknown>;
            };
            progress: {
                preparedModuleCount: number;
                publishedModuleCount: number;
                failedModuleCount: number;
                auditStatus: string;
                modules: {
                    id: string;
                    title: string;
                    status: string;
                }[];
                moduleCount: number;
                readyModuleCount: number;
                unitCount: number;
                readyUnitCount: number;
                firstReadyUnitId: string;
                firstReadyUnitTitle: string;
                learningMode: string;
            };
            resources: {
                id: string;
                kind: string;
                filename: string;
                status: string;
                warning: string;
                error: string;
            }[];
            actions: {
                canRetry: boolean;
                canStop: boolean;
                canDelete: boolean;
            };
            createdAt: string;
            updatedAt: string;
            stoppedAt: string;
            completedAt: string;
        };
    }>;
    createFoundationGoal(userId: string, parentGoalId: string, body: {
        prerequisiteItems?: string[];
        learningMode?: "exploration" | "mastery";
    }): Promise<{
        created: boolean;
        activeCreationExists: boolean;
        session: any;
    }>;
    getActiveGoalCreationSession(userId: string): Promise<{
        created: boolean;
        session: {
            id: string;
            threadId: string;
            goalId: string;
            status: string;
            phase: string;
            flowMode: string;
            version: number;
            currentRunId: string;
            firstUnitId: string;
            lastError: string;
            pendingInteraction: {
                toolCallId: string;
                toolName: string;
                uiKind: string;
                args: Record<string, unknown>;
            };
            progress: {
                preparedModuleCount: number;
                publishedModuleCount: number;
                failedModuleCount: number;
                auditStatus: string;
                modules: {
                    id: string;
                    title: string;
                    status: string;
                }[];
                moduleCount: number;
                readyModuleCount: number;
                unitCount: number;
                readyUnitCount: number;
                firstReadyUnitId: string;
                firstReadyUnitTitle: string;
                learningMode: string;
            };
            resources: {
                id: string;
                kind: string;
                filename: string;
                status: string;
                warning: string;
                error: string;
            }[];
            actions: {
                canRetry: boolean;
                canStop: boolean;
                canDelete: boolean;
            };
            createdAt: string;
            updatedAt: string;
            stoppedAt: string;
            completedAt: string;
        };
    } | {
        session: any;
    }>;
    getGoalCreationSessionByGoal(userId: string, goalId: string): Promise<{
        created: boolean;
        session: {
            id: string;
            threadId: string;
            goalId: string;
            status: string;
            phase: string;
            flowMode: string;
            version: number;
            currentRunId: string;
            firstUnitId: string;
            lastError: string;
            pendingInteraction: {
                toolCallId: string;
                toolName: string;
                uiKind: string;
                args: Record<string, unknown>;
            };
            progress: {
                preparedModuleCount: number;
                publishedModuleCount: number;
                failedModuleCount: number;
                auditStatus: string;
                modules: {
                    id: string;
                    title: string;
                    status: string;
                }[];
                moduleCount: number;
                readyModuleCount: number;
                unitCount: number;
                readyUnitCount: number;
                firstReadyUnitId: string;
                firstReadyUnitTitle: string;
                learningMode: string;
            };
            resources: {
                id: string;
                kind: string;
                filename: string;
                status: string;
                warning: string;
                error: string;
            }[];
            actions: {
                canRetry: boolean;
                canStop: boolean;
                canDelete: boolean;
            };
            createdAt: string;
            updatedAt: string;
            stoppedAt: string;
            completedAt: string;
        };
    } | {
        session: any;
    }>;
    getGoalCreationSession(userId: string, sessionId: string): Promise<{
        created: boolean;
        session: {
            id: string;
            threadId: string;
            goalId: string;
            status: string;
            phase: string;
            flowMode: string;
            version: number;
            currentRunId: string;
            firstUnitId: string;
            lastError: string;
            pendingInteraction: {
                toolCallId: string;
                toolName: string;
                uiKind: string;
                args: Record<string, unknown>;
            };
            progress: {
                preparedModuleCount: number;
                publishedModuleCount: number;
                failedModuleCount: number;
                auditStatus: string;
                modules: {
                    id: string;
                    title: string;
                    status: string;
                }[];
                moduleCount: number;
                readyModuleCount: number;
                unitCount: number;
                readyUnitCount: number;
                firstReadyUnitId: string;
                firstReadyUnitTitle: string;
                learningMode: string;
            };
            resources: {
                id: string;
                kind: string;
                filename: string;
                status: string;
                warning: string;
                error: string;
            }[];
            actions: {
                canRetry: boolean;
                canStop: boolean;
                canDelete: boolean;
            };
            createdAt: string;
            updatedAt: string;
            stoppedAt: string;
            completedAt: string;
        };
    }>;
    getGoalCreationSessionEvents(userId: string, sessionId: string, after?: string): Promise<{
        events: {
            sequence: number;
            type: string;
            payload: unknown;
            createdAt: string;
        }[];
        cursor: number;
    }>;
    streamGoalCreationSessionEvents(userId: string, sessionId: string, res: Response, after?: string): Promise<void>;
    retryGoalCreationSession(userId: string, sessionId: string): Promise<{
        created: boolean;
        session: {
            id: string;
            threadId: string;
            goalId: string;
            status: string;
            phase: string;
            flowMode: string;
            version: number;
            currentRunId: string;
            firstUnitId: string;
            lastError: string;
            pendingInteraction: {
                toolCallId: string;
                toolName: string;
                uiKind: string;
                args: Record<string, unknown>;
            };
            progress: {
                preparedModuleCount: number;
                publishedModuleCount: number;
                failedModuleCount: number;
                auditStatus: string;
                modules: {
                    id: string;
                    title: string;
                    status: string;
                }[];
                moduleCount: number;
                readyModuleCount: number;
                unitCount: number;
                readyUnitCount: number;
                firstReadyUnitId: string;
                firstReadyUnitTitle: string;
                learningMode: string;
            };
            resources: {
                id: string;
                kind: string;
                filename: string;
                status: string;
                warning: string;
                error: string;
            }[];
            actions: {
                canRetry: boolean;
                canStop: boolean;
                canDelete: boolean;
            };
            createdAt: string;
            updatedAt: string;
            stoppedAt: string;
            completedAt: string;
        };
    }>;
    stopGoalCreationSession(userId: string, sessionId: string): Promise<{
        created: boolean;
        session: {
            id: string;
            threadId: string;
            goalId: string;
            status: string;
            phase: string;
            flowMode: string;
            version: number;
            currentRunId: string;
            firstUnitId: string;
            lastError: string;
            pendingInteraction: {
                toolCallId: string;
                toolName: string;
                uiKind: string;
                args: Record<string, unknown>;
            };
            progress: {
                preparedModuleCount: number;
                publishedModuleCount: number;
                failedModuleCount: number;
                auditStatus: string;
                modules: {
                    id: string;
                    title: string;
                    status: string;
                }[];
                moduleCount: number;
                readyModuleCount: number;
                unitCount: number;
                readyUnitCount: number;
                firstReadyUnitId: string;
                firstReadyUnitTitle: string;
                learningMode: string;
            };
            resources: {
                id: string;
                kind: string;
                filename: string;
                status: string;
                warning: string;
                error: string;
            }[];
            actions: {
                canRetry: boolean;
                canStop: boolean;
                canDelete: boolean;
            };
            createdAt: string;
            updatedAt: string;
            stoppedAt: string;
            completedAt: string;
        };
    }>;
    sendGoalCreationSessionMessage(userId: string, res: Response, sessionId: string, body: {
        message: string;
        pageContext?: AgentPageContext;
        clientAction?: string;
        seedTopic?: string;
        documentSeed?: DocumentGoalSeed;
        isSmallCourse?: boolean;
        goalDraft?: GoalCreationDraft;
    }): Promise<void>;
    resumeGoalCreationSessionInteraction(userId: string, res: Response, sessionId: string, body: {
        toolCallId: string;
        result: unknown;
    }): Promise<void>;
    storeGoalCreationSessionDocuments(userId: string, sessionId: string, uploads: {
        files?: AgentUploadFile[];
        file?: AgentUploadFile[];
    }): Promise<{
        fileCount: number;
    }>;
    analyzeGoalCreationSessionDocuments(userId: string, sessionId: string): Promise<DocumentGoalSeed>;
    storeGoalCreationSessionUrls(userId: string, sessionId: string, body: {
        urls?: string[];
    }): Promise<{
        results: ({
            status: "error";
            url: string;
            error: string;
        } | {
            status: "success";
            url: string;
            title: string;
            sourceType: "article";
            provider: "web";
            warning: string;
        })[];
    }>;
    deleteGoalCreationSession(userId: string, sessionId: string, body: {
        confirm?: string;
    }): Promise<{
        ok: boolean;
        deletedGoalId: string;
    }>;
    createThread(userId: string, body: {
        scope: string;
        scopeId?: string;
        fresh?: boolean;
        conversationContext?: import("../../agents/core/types.js").AssistantConversationContext;
    }): Promise<{
        threadId: string;
        scope: string;
    }>;
    listThreads(userId: string, scope?: string): Promise<{
        threads: {
            id: string;
            scope: string;
            scopeId: string;
            status: string;
            conversationContext: import("../../agents/index.js").AssistantConversationContext;
            latestMessage: {
                role: string;
                content: string;
                createdAt: string;
            };
            createdAt: string;
            updatedAt: string;
        }[];
    }>;
    globalBriefing(userId: string): Promise<Readonly<{
        dueCount: number;
        flashcardDueCount: number;
        activeGoalCount: number;
    }>>;
    getTime(timezone?: string): {
        utc: string;
        timezone: string;
        local: string;
        weekday: string;
        calendarDate: string;
        year: string;
        unixMs: number;
    };
    searchGoals(userId: string, since?: string, until?: string, dateField?: "updated" | "created", status?: "active" | "all", query?: string, limit?: string): Promise<{
        dateField: string;
        count: number;
        goals: {
            id: string;
            title: string;
            status: string;
            createdAt: string;
            updatedAt: string;
            unitCount: number;
            completedCount: number;
        }[];
    }>;
    recentActivity(userId: string, limit?: string): Promise<{
        goals: {
            id: string;
            title: string;
            status: string;
            lastTouchedAt: string;
            kind: "goal";
        }[];
        units: {
            id: string;
            title: string;
            status: string;
            goalId: string;
            goalTitle: string;
            currentStep: string;
            structuredSubStep: string;
            lastTouchedAt: string;
            kind: "unit";
        }[];
    }>;
    getThread(userId: string, id: string, limit?: string, before?: string): Promise<{
        thread: {
            id: string;
            scope: string;
            scopeId: string;
            status: string;
            conversationContext: import("../../agents/index.js").AssistantConversationContext;
            stateJson: string;
            createdAt: string;
            updatedAt: string;
        };
        messages: {
            id: string;
            role: string;
            content: string;
            toolCalls: any;
            toolCallId: string;
            uiPayload: any;
            metadata: {
                contextReset?: unknown;
            };
            createdAt: string;
        }[];
        page: {
            limit: number;
            hasMore: boolean;
            oldestCursor: string;
            messageCount: number;
        };
        activeRun: {
            active: true;
            events: import("../../agents/index.js").AgentSseEvent[];
        };
    }>;
    sendMessage(userId: string, res: Response, id: string, body: {
        message: string;
        pageContext?: AgentPageContext;
        clientAction?: string;
        seedTopic?: string;
        documentSeed?: DocumentGoalSeed;
        isSmallCourse?: boolean;
        goalDraft?: GoalCreationDraft;
    }): Promise<void>;
    analyzePendingDocuments(userId: string, id: string): Promise<DocumentGoalSeed>;
    storePendingUrls(userId: string, id: string, body: {
        urls?: string[];
    }): Promise<{
        results: ({
            status: "error";
            url: string;
            error: string;
        } | {
            status: "success";
            url: string;
            title: string;
            sourceType: "article";
            provider: "web";
            warning: string;
        })[];
    }>;
    storePendingDocuments(userId: string, id: string, uploads: {
        files?: AgentUploadFile[];
        file?: AgentUploadFile[];
    }): Promise<{
        fileCount: number;
    }>;
    resume(userId: string, res: Response, id: string, body: {
        toolCallId: string;
        result: unknown;
    }): Promise<void>;
    cancel(userId: string, id: string): {
        ok: boolean;
    };
    clear(userId: string, id: string): Promise<{
        ok: boolean;
    }>;
    clearContext(userId: string, id: string): Promise<{
        ok: boolean;
    }>;
    remove(userId: string, id: string): Promise<{
        ok: boolean;
    }>;
}
