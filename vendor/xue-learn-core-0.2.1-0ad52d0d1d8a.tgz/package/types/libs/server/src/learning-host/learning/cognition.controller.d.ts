import { LearningService } from "./learning.service.js";
export declare class CognitionController {
    private readonly learning;
    constructor(learning: LearningService);
    getState(userId: string, entityId: string): Promise<import("../../cognition/index.js").LearnerEntityStateDto>;
    getEvidence(userId: string, entityId: string): Promise<Readonly<{
        claims: readonly import("../../../../domain/src/index.js").CognitiveEntityEvidenceClaimRecord[];
    }>>;
}
