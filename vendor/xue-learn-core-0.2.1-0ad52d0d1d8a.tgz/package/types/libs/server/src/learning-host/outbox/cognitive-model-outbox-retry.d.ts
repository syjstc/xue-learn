export declare const COGNITIVE_MODEL_OUTBOX_MAX_ATTEMPTS = 4;
export declare const COGNITIVE_MODEL_OUTBOX_RETRY_DELAY_MS = 5000;
export declare const COGNITIVE_MODEL_OUTBOX_MAX_RETRY_DELAY_MS = 60000;
export declare const COGNITIVE_MODEL_OUTBOX_ERROR_MAX_LENGTH = 2000;
export declare function cognitiveModelOutboxErrorMessage(error: unknown): string;
/**
 * Fail closed: validation, parsing, and invariant failures are deterministic
 * unless the error carries explicit retry metadata or a known transport signal.
 */
export declare function isTransientCognitiveModelOutboxError(error: unknown): boolean;
export type CognitiveModelOutboxFailureDecision = {
    terminal: boolean;
    attemptCount: number;
    data: {
        attemptCount: number;
        nextAttemptAt: Date | null;
        lastError: string;
        deadLetteredAt: Date | null;
    };
};
export declare function cognitiveModelOutboxRetryDelayMs(attemptCount: number): number;
export declare function decideCognitiveModelOutboxFailure(params: {
    error: unknown;
    previousAttemptCount: number;
    now?: Date;
}): CognitiveModelOutboxFailureDecision;
