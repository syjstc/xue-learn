import type { CognitiveEntityEvidenceReadRepository, LearnerStateProjectionReadRepository } from "../../../../../domain/src/index.js";
export declare function getCognitiveEntityState(userId: string, entityId: string, stateRead: LearnerStateProjectionReadRepository): Promise<import("../../../cognition/index.js").LearnerEntityStateDto>;
export declare function getCognitiveEntityEvidence(userId: string, entityId: string, evidenceRead: CognitiveEntityEvidenceReadRepository): Promise<Readonly<{
    claims: readonly import("../../../../../domain/src/index.js").CognitiveEntityEvidenceClaimRecord[];
}>>;
