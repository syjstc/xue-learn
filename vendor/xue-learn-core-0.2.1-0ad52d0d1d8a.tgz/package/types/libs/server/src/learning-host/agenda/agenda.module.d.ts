export declare class AgendaModule {
}
