import { searchGoals as queryGoals } from "../../assistant/index.js";
import type { AgentPageContext, AgentSseEvent, AssistantConversationContext } from "../../agents/core/types.js";
import type { DocumentGoalSeed, GoalCreationDraft } from "../../agents/index.js";
import { GoalCreationSessionService } from "./goal-creation-session.service.js";
import { LearningSpaceOrmProvider } from "../../learning-spaces/learning-space-orm.provider.js";
import type { LearningSpaceGoalCreationApplication } from "../../learning-spaces/orm-application-service.js";
type AgentRunOptions = {
    clientAction?: string;
    seedTopic?: string;
    documentSeed?: DocumentGoalSeed;
    isSmallCourse?: boolean;
    goalDraft?: GoalCreationDraft;
    learningSpaceApplication?: LearningSpaceGoalCreationApplication;
    microUnitPublication?: LearningSpaceGoalCreationApplication["microUnitPublication"];
};
export type AgentUploadFile = Readonly<{
    originalname: string;
    buffer: Buffer;
}>;
export declare class AgentService {
    private readonly goalCreationSessions;
    private readonly learningSpaceOrm;
    constructor(goalCreationSessions: GoalCreationSessionService, learningSpaceOrm: LearningSpaceOrmProvider);
    createThread(userId: string, body: {
        scope: string;
        scopeId?: string;
        fresh?: boolean;
        conversationContext?: AssistantConversationContext;
    }): Promise<{
        threadId: string;
        scope: string;
    }>;
    storePendingGoalUrls(userId: string, threadId: string, urls: string[]): Promise<{
        results: ({
            status: "error";
            url: string;
            error: string;
        } | {
            status: "success";
            url: string;
            title: string;
            sourceType: "article";
            provider: "web";
            warning: string;
        })[];
    }>;
    listThreads(userId: string, scope?: string): Promise<{
        threads: {
            id: string;
            scope: string;
            scopeId: string;
            status: string;
            conversationContext: AssistantConversationContext;
            latestMessage: {
                role: string;
                content: string;
                createdAt: string;
            };
            createdAt: string;
            updatedAt: string;
        }[];
    }>;
    getThread(userId: string, threadId: string, options?: {
        limit?: number;
        before?: string;
    }): Promise<{
        thread: {
            id: string;
            scope: string;
            scopeId: string;
            status: string;
            conversationContext: AssistantConversationContext;
            stateJson: string;
            createdAt: string;
            updatedAt: string;
        };
        messages: {
            id: string;
            role: string;
            content: string;
            toolCalls: any;
            toolCallId: string;
            uiPayload: any;
            metadata: {
                contextReset?: unknown;
            };
            createdAt: string;
        }[];
        page: {
            limit: number;
            hasMore: boolean;
            oldestCursor: string;
            messageCount: number;
        };
        activeRun: {
            active: true;
            events: AgentSseEvent[];
        };
    }>;
    getGlobalBriefing(userId: string): Promise<Readonly<{
        dueCount: number;
        flashcardDueCount: number;
        activeGoalCount: number;
    }>>;
    getCurrentTime(timezone?: string): {
        utc: string;
        timezone: string;
        local: string;
        weekday: string;
        calendarDate: string;
        year: string;
        unixMs: number;
    };
    searchGoals(userId: string, input: Parameters<typeof queryGoals>[1]): Promise<{
        dateField: string;
        count: number;
        goals: {
            id: string;
            title: string;
            status: string;
            createdAt: string;
            updatedAt: string;
            unitCount: number;
            completedCount: number;
        }[];
    }>;
    getRecentActivity(userId: string, limit?: number): Promise<{
        goals: {
            id: string;
            title: string;
            status: string;
            lastTouchedAt: string;
            kind: "goal";
        }[];
        units: {
            id: string;
            title: string;
            status: string;
            goalId: string;
            goalTitle: string;
            currentStep: string;
            structuredSubStep: string;
            lastTouchedAt: string;
            kind: "unit";
        }[];
    }>;
    streamMessage(userId: string, threadId: string, message: string, res: import("express").Response, pageContext?: AgentPageContext, options?: AgentRunOptions): Promise<void>;
    startGoalCreationInBackground(userId: string, threadId: string): {
        started: boolean;
    };
    private routeGoalCreationMessage;
    private hasLegacyGoalCreationProgress;
    private runGlobalAssistantInterruption;
    streamResume(userId: string, threadId: string, toolCallId: string, result: unknown, res: import("express").Response): Promise<void>;
    private bindThreadPageContext;
    private writeSse;
    cancel(userId: string, threadId: string): {
        ok: boolean;
    };
    isThreadRunning(threadId: string): boolean;
    abortThreadRun(threadId: string): boolean;
    storePendingGoalDocuments(userId: string, threadId: string, files: readonly AgentUploadFile[]): Promise<{
        fileCount: number;
    }>;
    analyzePendingGoalDocuments(userId: string, threadId: string): Promise<DocumentGoalSeed>;
    clearThread(userId: string, threadId: string): Promise<{
        ok: boolean;
    }>;
    clearThreadContext(userId: string, threadId: string): Promise<{
        ok: boolean;
    }>;
    deleteThread(userId: string, threadId: string): Promise<{
        ok: boolean;
    }>;
    private buildCtx;
    private requireThread;
}
export {};
