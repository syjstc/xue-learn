import type { CognitiveModelPresentationReadRepository, CognitiveModelGenerationRunRepository, CognitiveModelPublicationFinalizationRepository, LearnerStateMemoryInvalidationRepository } from "../../../../../../domain/src/index.js";
import { type LearningAccess } from "../../../../cognitive-model/index.js";
export declare function getUnitLearningAccess(unit: {
    id: string;
    goalId?: string;
    userId?: string;
    cognitiveModelStatus: string;
    cognitiveModelBuildInputHash: string | null;
    goal: {
        goalKind: string;
        learningMode: string;
        cognitiveModelStatus: string;
        cognitiveModelInputHash: string;
        cognitiveModelPublishedHash: string | null;
    };
    module?: {
        unlockStatus: string | null;
        generationStatus: string | null;
    } | null;
    canonicalTargetCount: number;
    hasCanonicalContent: boolean;
}, generationRun?: CognitiveModelGenerationRunRepository, publicationFinalization?: CognitiveModelPublicationFinalizationRepository, learnerStateMemoryInvalidation?: LearnerStateMemoryInvalidationRepository, presentationRead?: CognitiveModelPresentationReadRepository): Promise<LearningAccess>;
export declare function assertUnitAssessmentReady(unitId: string, generationRun?: CognitiveModelGenerationRunRepository, publicationFinalization?: CognitiveModelPublicationFinalizationRepository, learnerStateMemoryInvalidation?: LearnerStateMemoryInvalidationRepository, presentationRead?: CognitiveModelPresentationReadRepository): Promise<void>;
