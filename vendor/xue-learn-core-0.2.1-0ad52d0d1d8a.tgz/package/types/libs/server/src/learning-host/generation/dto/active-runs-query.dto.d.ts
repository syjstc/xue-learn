import type { GenerationScope } from "../../../../../contracts/src/index.js";
export declare class ActiveRunsQueryDto {
    scope: GenerationScope;
    scopeId: string;
}
