import type { Response } from "express";
import { LearningService } from "./learning.service.js";
export declare class AdaptiveAssessmentController {
    private readonly learning;
    constructor(learning: LearningService);
    submit(userId: string, taskId: string, body: Record<string, unknown>, res: Response): Promise<void>;
}
