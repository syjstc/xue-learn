export declare class AgentModule {
}
