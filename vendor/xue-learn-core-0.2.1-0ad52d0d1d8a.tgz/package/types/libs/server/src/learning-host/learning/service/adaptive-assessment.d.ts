import type { LearnerStateMemoryInvalidationRepository, TaskAttemptRepository, PrerequisiteBridgeRepository, VerifiedAssessmentCompletionRepository } from "../../../../../domain/src/index.js";
import { type AssistanceLevel } from "../../../cognition/index.js";
export type AdaptiveAssessmentSubmitBody = {
    response?: unknown;
    durationMs?: unknown;
    idempotencyKey?: unknown;
    assistanceTrace?: unknown;
};
export declare function assertAdaptiveAssessmentSubmitBody(body: Record<string, unknown>): {
    response: Record<string, unknown>;
    durationMs: number;
    idempotencyKey: string;
    assistance: {
        trace: Record<string, unknown>[];
        level: AssistanceLevel;
        hintCount: number;
        answerRevealed: boolean;
    };
};
export declare function submitAdaptiveAssessmentStream(compatibilityClient: unknown, userId: string, taskId: string, rawBody: Record<string, unknown>, verifiedAssessmentCompletion?: VerifiedAssessmentCompletionRepository, learnerStateMemoryInvalidation?: LearnerStateMemoryInvalidationRepository, taskAttempt?: TaskAttemptRepository, prerequisiteBridge?: PrerequisiteBridgeRepository): Promise<Response>;
