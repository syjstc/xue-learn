import { LearningSpaceOrmProvider } from "../../learning-spaces/learning-space-orm.provider.js";
import { type BackendErrorListParams } from "../../observability/index.js";
export declare class BackendErrorsService {
    private readonly learningSpaceOrm;
    constructor(learningSpaceOrm: LearningSpaceOrmProvider);
    list(params: BackendErrorListParams): Promise<{
        items: import("../../../../domain/src/index.js").BackendErrorGroupRecord[];
        nextCursor: string;
        windowHours: number;
    }>;
    detail(id: string): Promise<{
        group: import("../../../../domain/src/index.js").BackendErrorGroupRecord;
        recentApiOccurrences: import("../../../../domain/src/index.js").ApiErrorOccurrenceRecord[];
    }>;
}
