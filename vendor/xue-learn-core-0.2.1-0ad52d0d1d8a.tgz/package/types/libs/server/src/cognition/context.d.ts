import type { LearnerStateProjectionReadRepository } from "../../../domain/src/index.js";
/** Install the process-local projection reader from the active ORM composition. */
export declare function configureLearnerStateProjectionRead(projectionRead: LearnerStateProjectionReadRepository | undefined): void;
/** Compact inferred learner-state context. Definitions remain objective and immutable. */
export declare function formatCognitiveStatePromptBlock(userId: string, goalId?: string, projectionRead?: LearnerStateProjectionReadRepository): Promise<string>;
