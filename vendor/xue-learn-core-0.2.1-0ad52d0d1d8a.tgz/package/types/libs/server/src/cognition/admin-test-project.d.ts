import type { PersistenceClient } from "../persistence/persistence-compat.js";
import { type ProjectBlueprint } from "./projects.js";
export declare const ADMIN_TEST_PROJECT_STABLE_KEY: "project:admin-test:v1";
export declare const ADMIN_TEST_SKILL_STABLE_KEY: "admin_test:skill:execute";
export declare const ADMIN_TEST_COMPETENCY_STABLE_KEY: "admin_test:competency:adapt";
export type AdminTestProjectMode = "fixture" | "from_model";
export type AdminTestProjectResult = {
    status: "published";
    mode: AdminTestProjectMode;
    goalId: string;
    rootTaskId: string;
    milestoneTaskIds: string[];
    blueprintHash: string;
    title: string;
    entitySource: "existing" | "admin_test";
} | {
    status: "not_ready" | "not_applicable";
    mode: "from_model";
    goalId: string;
    reason?: string;
};
export declare function buildAdminTestBlueprint(goalId: string, skill: {
    id: string;
    definitionVersion: number;
}, competency: {
    id: string;
    definitionVersion: number;
}): ProjectBlueprint;
/**
 * Admin-only helper to create a learner-visible 项目实战 project for testing.
 * `fixture` always publishes a deterministic three-milestone blueprint.
 * `from_model` runs the production capstone projection and may return
 * not_ready / not_applicable without inventing a synthetic project.
 */
export declare function createAdminTestProject(persistence: PersistenceClient, input: {
    goalId: string;
    mode?: AdminTestProjectMode;
}): Promise<AdminTestProjectResult>;
