import type { LearningTargetAssessment } from "./target.js";
import type { CognitiveDimension, CombinationGapKind } from "./types.js";
export declare const COMBINATION_GAP_REASON_CODES: readonly ["component_unobserved", "component_dimension_unobserved", "component_insufficient_evidence", "component_revalidation_required", "component_below_threshold", "integration_unobserved", "integration_dimension_unobserved", "integration_insufficient_evidence", "integration_revalidation_required", "integration_dimension_below_threshold", "integration_overall_below_threshold"];
export type CombinationGapReasonCode = (typeof COMBINATION_GAP_REASON_CODES)[number];
export type CombinationGapReason = {
    code: CombinationGapReasonCode;
    targetId: string;
    dimension?: CognitiveDimension;
};
export type CombinationGapClassification = {
    kind: CombinationGapKind;
    affectedTargetIds: readonly string[];
    dimensions: readonly CognitiveDimension[];
    reasons: readonly CombinationGapReason[];
};
/**
 * Components are evaluated before their integrated target. This separates
 * "does not know a part" from "knows the parts but cannot coordinate them".
 */
export declare function classifyCombinationGap(components: readonly LearningTargetAssessment[], integration: LearningTargetAssessment): CombinationGapClassification;
