import { type CapacityBreakdown, type DeterministicAgenda } from "./types.js";
import type { NewLearningCandidate, ReviewCandidate } from "./candidates.js";
export type AllocateParams = {
    planningDate: string;
    timezone: string;
    capacityMinutes: number;
    capacityByDate?: Record<string, number>;
    capacity: CapacityBreakdown;
    reviews: ReviewCandidate[];
    newLearning: NewLearningCandidate[];
    locale?: string;
    now?: Date;
};
/**
 * Allocate one capacity budget per day across the rolling window.
 * Overdue/due reviews first; remaining capacity → new learning.
 * Missed work is rebuilt into current capacity (no unbounded backlog).
 */
export declare function allocateAgenda(params: AllocateParams): DeterministicAgenda;
/** Exported for tests: ensure window length helpers stay aligned. */
export declare function agendaWindowEndDateKey(planningDate: string): string;
