import { type CapacityBreakdown } from "./types.js";
export type CapacityInput = {
    /** Learner-owned global daily capacity target. */
    statedTargetMinutes: number;
    /** Manual override from settings. */
    overrideMinutes?: number | null;
    /** Recent same-goal (or cross-goal) average session length in minutes. */
    observedAvgSessionMinutes?: number | null;
    /** Recent daily active study minutes average. */
    observedDailyActiveMinutes?: number | null;
    /** Previous day's planned capacity for clamping. */
    previousCapacityMinutes?: number | null;
};
/**
 * Adaptive daily capacity in minutes.
 * The global target is the baseline; observed behavior adjusts execution capacity.
 */
export declare function calculateDailyCapacity(input: CapacityInput): CapacityBreakdown;
