import type { ExplanationCode } from "./types.js";
export type UnitCandidateRow = {
    id: string;
    goalId: string;
    title: string;
    status: string;
    unitKind: string;
    parentUnitId: string | null;
    orderIndex: number;
    prerequisites: string;
    completedAt?: Date | string | null;
    completionMethod?: string | null;
    module?: {
        unlockStatus: string;
    } | null;
    remediationSourceUnitId?: string | null;
    supportKind?: string | null;
    sections?: Array<{
        id: string;
        title: string;
        orderIndex: number;
        baseEstimatedMinutes: number;
        progress: Array<{
            status: string;
            activeSeconds: number;
            completedAt: Date | null;
        }>;
    }>;
};
export type ReviewCandidateRow = {
    reviewCardId: string | null;
    cognitiveEntityIds: string[];
    unitId: string;
    goalId: string;
    unitTitle: string;
    goalTitle: string;
    durationMin: number;
    nextReviewAt: Date;
    status: string;
    prerequisitePriority?: number;
    explanationCode?: ExplanationCode;
    targetState?: Record<string, unknown>;
    expectedEvidence?: Record<string, unknown>;
};
export type NewLearningCandidate = {
    unitId: string;
    sectionId: string | null;
    sectionTitle: string | null;
    goalId: string;
    unitTitle: string;
    goalTitle: string;
    estimatedMinutes: number;
    status: string;
    inProgress: boolean;
    mapOrder: number;
    goalPriority: number;
    recentEngagementScore: number;
    remediation: boolean;
    targetState?: Record<string, unknown>;
    expectedEvidence?: Record<string, unknown>;
};
export type ReviewCandidate = {
    reviewCardId: string | null;
    cognitiveEntityIds: string[];
    unitId: string;
    goalId: string;
    unitTitle: string;
    goalTitle: string;
    estimatedMinutes: number;
    nextReviewAt: Date;
    overdueMs: number;
    goalPriority: number;
    prerequisitePriority: number;
    explanationCode?: ExplanationCode;
    targetState?: Record<string, unknown>;
    expectedEvidence?: Record<string, unknown>;
};
export declare function collectNewLearningCandidates(params: {
    unitsByGoal: Map<string, UnitCandidateRow[]>;
    goalTitles: Map<string, string>;
    goalPriorities: Map<string, number>;
    engagementByGoal: Map<string, number>;
    now?: Date;
}): NewLearningCandidate[];
export declare function collectReviewCandidates(params: {
    reviews: ReviewCandidateRow[];
    goalPriorities: Map<string, number>;
    now: Date;
    windowEnd: Date;
}): ReviewCandidate[];
