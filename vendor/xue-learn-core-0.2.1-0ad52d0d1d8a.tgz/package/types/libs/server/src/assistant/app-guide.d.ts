export type LearningAppGuideTopic = "overview" | "methods" | "workflow" | "features";
export declare function getLearningAppGuide(topic?: LearningAppGuideTopic): {
    sections: {
        title: string;
        summary: string;
        points: string[];
    }[];
};
