import type { CognitiveDimension, CognitiveEntityKind, ContextDistance } from "../cognition/index.js";
export declare const ADAPTIVE_ASSESSMENT_POLICY_VERSION = 2;
export type AssessmentScope = "unit" | "module" | "goal";
export type AssessmentDemandTier = "basic" | "standard" | "advanced";
export type AssessmentItemKind = "selected_response" | "constructed_response" | "performance_case" | "integrated_challenge" | "synthesis_challenge" | "delayed_retention";
export type AdaptiveAssessmentRequirement = {
    cognitiveEntityId: string;
    entityKind: CognitiveEntityKind;
    dimension: CognitiveDimension;
    required: boolean;
    gate: boolean;
    weight: number;
    threshold: number;
};
export type AdaptiveAssessmentTarget = {
    id: string;
    localRef: string;
    title: string;
    importance: "core" | "supporting" | "enrichment";
    importanceWeight: number;
    difficulty: "easy" | "medium" | "hard";
    targetCognitiveLevel: "remember" | "understand" | "apply" | "analyze" | "evaluate" | "create";
    assessmentCriteria: ReadonlyArray<{
        ref: string;
        text: string;
    }>;
    requirements: readonly AdaptiveAssessmentRequirement[];
};
export type ExistingRequirementEvidence = {
    claimCount: number;
    contextCount?: number;
    independentClaimCount?: number;
    constructedResponseCount?: number;
    hasFarContext?: boolean;
    timeSpanDays?: number;
};
export type AssessmentEvidenceKey = `${string}:${string}:${CognitiveDimension}`;
export declare function assessmentEvidenceKey(learningTargetId: string, cognitiveEntityId: string, dimension: CognitiveDimension): AssessmentEvidenceKey;
export type AssessmentEvidenceSlot = {
    id: string;
    learningTargetId: string;
    localLearningTargetRef: string;
    cognitiveEntityId: string;
    entityKind: CognitiveEntityKind;
    dimension: CognitiveDimension;
    criterionRef: string;
    tier: AssessmentDemandTier;
    itemKind: AssessmentItemKind;
    contextDistance: ContextDistance;
    estimatedMinutes: number;
    required: boolean;
    gate: boolean;
    minimumTimeSpanDays: number;
    purpose: string;
};
export type AssessmentBlueprint = {
    policyVersion: typeof ADAPTIVE_ASSESSMENT_POLICY_VERSION;
    scope: AssessmentScope;
    timeBudgetMinutes: number;
    estimatedMinutes: number;
    slots: AssessmentEvidenceSlot[];
    deferredSlots: AssessmentEvidenceSlot[];
};
export declare function assessmentDemandTier(target: AdaptiveAssessmentTarget, requirement: AdaptiveAssessmentRequirement): AssessmentDemandTier;
export declare function requiredEvidenceCount(dimension: CognitiveDimension, tier: AssessmentDemandTier): number;
export declare function defaultAssessmentTimeBudget(scope: AssessmentScope): number;
export declare function planAdaptiveAssessment(params: {
    scope: AssessmentScope;
    targets: readonly AdaptiveAssessmentTarget[];
    existingEvidence?: ReadonlyMap<AssessmentEvidenceKey, ExistingRequirementEvidence>;
    timeBudgetMinutes?: number;
}): AssessmentBlueprint;
