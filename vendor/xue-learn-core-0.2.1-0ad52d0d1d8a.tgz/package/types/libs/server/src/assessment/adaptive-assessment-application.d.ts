import { type AdaptiveAssessmentTarget, type AssessmentBlueprint, type AssessmentEvidenceKey, type AssessmentScope, type ExistingRequirementEvidence } from "./adaptive-blueprint.js";
export type AdaptiveAssessmentPurpose = "mastery" | "readiness";
export type PreparedAdaptiveAssessmentItem = {
    id: string;
    taskId: null;
    type: "selected_response" | "constructed_response" | "performance_case" | "integrated_challenge" | "synthesis_challenge" | "delayed_retention";
    primaryLearningTargetId: string;
    relatedLearningTargetIds: string[];
    primaryCognitiveEntityId: string;
    evidenceDimension: string;
    criterionRef: string;
    evidencePurpose: string;
    estimatedMinutes: number;
    responseType: "selected" | "text" | "structured";
    prompt: string;
    sections?: Array<"decision" | "output" | "verification" | "reflection">;
    generationRequired?: boolean;
    availableNow: boolean;
};
export type PreparedAdaptiveAssessmentPlan = {
    purpose: AdaptiveAssessmentPurpose;
    blueprint: AssessmentBlueprint;
    items: PreparedAdaptiveAssessmentItem[];
    nextEvidenceAction: {
        itemKind: string;
        purpose: string;
        learningTargetId: string;
        cognitiveEntityId: string;
        dimension: string;
    } | null;
};
/**
 * Provider- and persistence-independent adaptive assessment read model.
 * Callers remain responsible for loading authoritative targets/evidence and for
 * binding writable items to immutable server-owned tasks.
 */
export declare function prepareAdaptiveAssessmentPlan(params: {
    scope: AssessmentScope;
    purpose?: AdaptiveAssessmentPurpose;
    targets: readonly AdaptiveAssessmentTarget[];
    existingEvidence?: ReadonlyMap<AssessmentEvidenceKey, ExistingRequirementEvidence>;
    timeBudgetMinutes?: number;
}): PreparedAdaptiveAssessmentPlan;
