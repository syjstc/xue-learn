import type { PersistenceClient } from "../persistence/persistence-compat.js";
import type { AssessmentTargetRepository, AdaptiveAssessmentEvidenceRepository, AdaptiveAssessmentTaskRepository } from "../../../domain/src/index.js";
import { type AssessmentBlueprint, type AssessmentScope } from "./adaptive-blueprint.js";
export type AdaptiveAssessmentRolloutMode = "off" | "shadow" | "internal" | "production";
export type AdaptiveAssessmentPlan = {
    purpose: "mastery" | "readiness";
    rolloutMode: AdaptiveAssessmentRolloutMode;
    evidenceWritesEnabled: boolean;
    blueprint: AssessmentBlueprint;
    items: AdaptiveAssessmentItem[];
    nextEvidenceAction: {
        itemKind: string;
        purpose: string;
        learningTargetId: string;
        cognitiveEntityId: string;
        dimension: string;
    } | null;
};
export type AdaptiveAssessmentItem = {
    id: string;
    taskId: string | null;
    type: "selected_response" | "constructed_response" | "performance_case" | "integrated_challenge" | "synthesis_challenge" | "delayed_retention";
    primaryLearningTargetId: string;
    relatedLearningTargetIds: string[];
    primaryCognitiveEntityId: string;
    evidenceDimension: string;
    criterionRef: string;
    evidencePurpose: string;
    estimatedMinutes: number;
    responseType: "selected" | "text" | "structured";
    prompt: string;
    sections?: Array<"decision" | "output" | "verification" | "reflection">;
    generationRequired?: boolean;
    availableNow: boolean;
};
type ScopeIds = {
    goalId: string;
    moduleId?: string;
    unitId?: string;
};
export declare function adaptiveAssessmentRolloutMode(): AdaptiveAssessmentRolloutMode;
export declare function adaptiveAssessmentEvidenceWritesEnabled(): boolean;
export declare function getAdaptiveAssessmentPlan(persistence: PersistenceClient | undefined, userId: string, scope: AssessmentScope, ids: ScopeIds, options?: {
    purpose?: "mastery" | "readiness";
    targetRepository?: AssessmentTargetRepository;
    evidenceRepository?: AdaptiveAssessmentEvidenceRepository;
    taskRepository?: AdaptiveAssessmentTaskRepository;
}): Promise<AdaptiveAssessmentPlan>;
export {};
