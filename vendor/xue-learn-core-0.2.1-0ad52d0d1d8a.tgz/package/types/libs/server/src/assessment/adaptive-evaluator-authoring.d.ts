import { z } from "zod";
/** The provider-facing structured result, before immutable binding checks. */
export declare const adaptiveEvaluatorOutputSchema: z.ZodObject<{
    requirementId: z.ZodString;
    cognitiveEntityId: z.ZodString;
    learningTargetId: z.ZodString;
    dimension: z.ZodEnum<{
        transfer: "transfer";
        memory: "memory";
        understanding: "understanding";
        application: "application";
        fluency: "fluency";
        stability: "stability";
        independence: "independence";
    }>;
    criterionRef: z.ZodString;
    score: z.ZodNumber;
    contextNoveltyVerified: z.ZodBoolean;
    rationale: z.ZodString;
}, z.core.$strip>;
export type AdaptiveEvaluatorOutput = z.infer<typeof adaptiveEvaluatorOutputSchema>;
export type AdaptiveEvaluatorInvocation = Readonly<{
    goalTitle: string;
    task: Readonly<{
        title: string;
        instructions: string;
        rubric: Record<string, unknown>;
    }>;
    requirement: Readonly<{
        id: string;
        learningTargetId: string;
        cognitiveEntityId: string;
        dimension: string;
    }>;
    criterionRef: string;
    response: Record<string, unknown>;
}>;
export type AdaptiveEvaluatorBinding = Readonly<{
    requirementId: string;
    learningTargetId: string;
    cognitiveEntityId: string;
    dimension: string;
    criterionRef: string;
}>;
export type PreparedAdaptiveEvaluator = Readonly<{
    operation: "assessment.adaptive.evaluate";
    invocation: AdaptiveEvaluatorInvocation;
    prompt: string;
    parseProviderOutput: (content: string) => AdaptiveEvaluatorOutput;
}>;
/** Prepare the same capability-owned prompt and structured output contract used by hosted evaluation. */
export declare function prepareAdaptiveEvaluator(invocation: AdaptiveEvaluatorInvocation): PreparedAdaptiveEvaluator;
/** Fail closed when a provider changes any server-owned evidence binding. */
export declare function assertAdaptiveEvaluatorBinding(output: AdaptiveEvaluatorOutput, binding: AdaptiveEvaluatorBinding): AdaptiveEvaluatorOutput;
export declare function normalizeAdaptiveEvaluatorContextDistance(declared: "same" | "near" | "far", contextNoveltyVerified: boolean): "same" | "near" | "far";
