import type { PersistenceClient } from "../persistence/persistence-compat.js";
import type { MaterialCheckCompletionRepository, MaterialCheckTaskDefinition, ModuleDiagnosticCompletionItem, ModuleDiagnosticTaskDefinition, UnitDiagnosticCompletionItem, UnitDiagnosticTaskDefinition, LearnerStateProjectionReadRepository, QuizSubmissionItem } from "../../../domain/src/index.js";
import { type CognitiveDimension, type CognitiveEntityKind, type EvidenceSource } from "../cognition/index.js";
import type { QuizGradeItem } from "../graph/grade-quiz.js";
import type { QuizQuestion } from "../llm/schemas.js";
export declare function isQuizEvidenceDimension(dimension: CognitiveDimension): dimension is "memory" | "understanding";
export type AssessmentCriterion = {
    ref: string;
    text: string;
};
export type UnitAssessmentRequirement = {
    cognitiveEntityId: string;
    entityKind: CognitiveEntityKind;
    entityDefinitionVersion: number;
    dimension: CognitiveDimension;
    required: boolean;
    gate: boolean;
    weight: number;
    threshold: number;
};
export type UnitAssessmentTarget = {
    id: string;
    localRef: string;
    title: string;
    description: string;
    learningObjective: string;
    assessmentCriteria: readonly AssessmentCriterion[];
    required: boolean;
    weight: number;
    role: string;
    isEntry: boolean;
    isExit: boolean;
    importance: "core" | "supporting" | "enrichment";
    importanceWeight: number;
    difficulty: "easy" | "medium" | "hard";
    targetCognitiveLevel: "remember" | "understand" | "apply" | "analyze" | "evaluate" | "create";
    estimatedMinutes: number;
    requirements: readonly UnitAssessmentRequirement[];
};
export type PerLearningTargetPerformance = {
    learningTargetId: string;
    localRef: string;
    title: string;
    score: number;
    correctCount: number;
    partialCount: number;
    incorrectCount: number;
    questionCount: number;
    required: boolean;
    passed: boolean;
};
export type LearningTargetCognitiveAssessment = {
    learningTargetId: string;
    localRef: string;
    title: string;
    estimate: number | null;
    evidenceSufficiency: number;
    status: "unobserved" | "forming" | "demonstrated" | "robust" | "revalidate";
    passed: boolean;
    failures: Array<{
        cognitiveEntityId: string;
        dimension: CognitiveDimension;
        reason: "unobserved" | "insufficient_evidence" | "below_threshold" | "revalidate";
    }>;
};
export type PublishedMaterialCheckDefinition = {
    checkId: string;
    blockIndex: number;
    itemIndex: number;
    question: string;
    questionType: "mcq" | "mcq_multi" | "true_false";
    correctIndex?: number;
    correctIndices?: number[];
    correctAnswer?: boolean;
    explanation: string;
    primaryLearningTargetId: string;
    targetCognitiveEntityId?: string;
    evidenceDimension: "memory" | "understanding";
    criterionRef: string;
    contextDistance: "same" | "near" | "far";
    assessmentFormat: "mcq" | "mcq_multi" | "true_false";
};
export type MaterialCheckResult = {
    checkId: string;
    blockIndex: number;
    itemIndex: number;
    selectedAnswer: number | number[] | boolean;
    correct: boolean;
    outcome?: "correct" | "partial" | "incorrect";
    score?: number;
    explanation: string;
    submittedAt: string;
    firstSubmission: boolean;
};
/**
 * Stable for every retry of one persisted unit-session quiz, but rotates when
 * the session row changes for a newly generated/selected attempt.
 */
export declare function buildQuizEvidenceSubmissionId(input: {
    userId: string;
    unitId: string;
    quizSetId: string;
    sessionId: string;
    sessionUpdatedAt: string;
}): string;
/**
 * Extract only published, server-verifiable inline checks. Placeholders and
 * legacy checks without a stable checkId deliberately remain non-evidentiary.
 */
export declare function publishedMaterialCheckDefinitions(material: {
    blocks: readonly unknown[];
}): PublishedMaterialCheckDefinition[];
export declare function loadUnitAssessmentTargets(persistence: PersistenceClient, unitId: string, userId?: string): Promise<UnitAssessmentTarget[]>;
export declare function loadModuleAssessmentTargets(persistence: PersistenceClient, moduleId: string, userId?: string, options?: {
    role?: "entry" | "exit";
}): Promise<UnitAssessmentTarget[]>;
export declare function loadGoalAssessmentTargets(persistence: PersistenceClient, goalId: string, userId?: string): Promise<UnitAssessmentTarget[]>;
export declare function isCriticalLearningTarget(target: UnitAssessmentTarget): boolean;
export declare function isQuizAssessableLearningTarget(target: UnitAssessmentTarget): boolean;
/**
 * Pick the still-unresolved targets that a closed-book diagnostic can assess.
 *
 * A LearningTarget may also require application, transfer, fluency, stability,
 * or independence evidence. Those requirements must remain authoritative, but
 * they must not prevent the diagnostic from collecting its valid
 * memory/understanding evidence. Full target completion is decided after the
 * attempt from the combined direct learner state.
 */
export declare function selectQuizAssessableDiagnosticTargets(targets: readonly UnitAssessmentTarget[], priorAssessments: readonly LearningTargetCognitiveAssessment[]): UnitAssessmentTarget[];
/**
 * Legacy units may have published core/supporting targets with only
 * application/transfer requirements. Selected-response quizzes cannot write
 * those dimensions, so deterministically add a complementary memory or
 * understanding requirement on an existing entity before quiz generation.
 */
export declare function ensureUnitQuizAssessableRequirements(persistence: PersistenceClient, unitId: string, userId?: string): Promise<UnitAssessmentTarget[]>;
export declare function ensureModuleQuizAssessableRequirements(persistence: PersistenceClient, moduleId: string, userId?: string): Promise<UnitAssessmentTarget[]>;
/** Quiz-eligible dimensions declared on a LearningTarget (memory / understanding). */
export declare function quizEligibleEvidenceDimensions(target: UnitAssessmentTarget): Array<"memory" | "understanding">;
/**
 * Deterministically clamp model-authored quiz evidence fields to the published
 * LearningTarget contract. Keeps a valid requested dimension; otherwise picks a
 * declared quiz-eligible dimension (and a declared criterion when needed).
 */
export declare function alignQuizQuestionsToDeclaredEvidence(questions: readonly QuizQuestion[], targets: readonly UnitAssessmentTarget[]): QuizQuestion[];
export declare function learningTargetSummativeQuestionCount(target: UnitAssessmentTarget): number;
export declare function learningTargetCompetencyBlock(targets: readonly UnitAssessmentTarget[]): string;
export declare function scoreQuizByLearningTarget(params: {
    questions: readonly QuizQuestion[];
    results: readonly QuizGradeItem[];
    targets: readonly UnitAssessmentTarget[];
}): {
    perLearningTarget: PerLearningTargetPerformance[];
};
type QuizTaskEvidenceDeclarationInput = {
    source: "quiz" | "diagnostic" | "review_quiz";
    questions: readonly QuizQuestion[];
    results: readonly QuizGradeItem[];
    targets: readonly UnitAssessmentTarget[];
};
type QuizQuestionEvidenceDeclarationInput = Omit<QuizTaskEvidenceDeclarationInput, "results">;
type InvalidQuestionPolicy = "reject" | "skip";
/**
 * Compile a graded active-recall batch into the transaction-neutral items
 * consumed by the ORM quiz-submission boundary. The stable declarations and
 * evaluator facts intentionally match recordQuizTaskEvidence.
 */
export declare function buildQuizSubmissionItems(params: {
    unitId: string;
    activityAttemptId: string;
    source: "quiz" | "review_quiz";
    questions: readonly QuizQuestion[];
    results: readonly QuizGradeItem[];
    answers: Readonly<Record<string, string | number | boolean | number[]>>;
    targets: readonly UnitAssessmentTarget[];
    invalidQuestionPolicy?: InvalidQuestionPolicy;
}): {
    items: readonly QuizSubmissionItem[];
    skippedQuestionCount: number;
};
export type UnitDiagnosticEvidenceBatch = Readonly<{
    tasks: readonly UnitDiagnosticTaskDefinition[];
    completions: readonly UnitDiagnosticCompletionItem[];
    entityIds: readonly string[];
}>;
/**
 * Compiles the already-graded diagnostic into the transaction-neutral task and
 * evidence declarations used by the ORM completion port. The same stable keys
 * and evaluator facts are retained by the Persistence fallback below.
 */
export declare function buildUnitDiagnosticEvidenceBatch(params: {
    goalId: string;
    unitId: string;
    activityAttemptId: string;
    questions: readonly QuizQuestion[];
    results: readonly QuizGradeItem[];
    answers: Readonly<Record<string, string | number | boolean | number[]>>;
    targets: readonly UnitAssessmentTarget[];
    submittedAt: Date;
}): UnitDiagnosticEvidenceBatch;
export type ModuleDiagnosticEvidenceBatch = Readonly<{
    tasks: readonly ModuleDiagnosticTaskDefinition[];
    completions: readonly ModuleDiagnosticCompletionItem[];
    entityIds: readonly string[];
}>;
/**
 * Compiles module diagnostic answers into question-level task declarations and
 * completion items. The completion port creates these evidence tasks and then
 * creates the separate evaluated attempt on the generated module task.
 */
export declare function buildModuleDiagnosticEvidenceBatch(params: {
    goalId: string;
    moduleId: string;
    activityAttemptId: string;
    questions: readonly QuizQuestion[];
    results: readonly QuizGradeItem[];
    answers: Readonly<Record<string, string | number | boolean | number[]>>;
    targets: readonly UnitAssessmentTarget[];
    submittedAt: Date;
}): ModuleDiagnosticEvidenceBatch;
/** Validate generated questions against the published LearningTarget contract. */
export declare function validateQuizQuestionEvidenceDeclaration(params: QuizQuestionEvidenceDeclarationInput): void;
/**
 * A target-level count is insufficient when the target binds several
 * cognitive entities. Require the adaptive quota for each exact
 * entity × dimension pair before publishing a generated diagnostic.
 */
export declare function validateAdaptiveQuizRequirementCoverage(params: {
    questions: readonly QuizQuestion[];
    targets: readonly UnitAssessmentTarget[];
}): void;
/**
 * Validate the complete evaluator declaration before the first task, attempt,
 * observation, or claim is persisted. This makes an overreaching later item an
 * all-or-nothing rejection rather than a partially accepted quiz.
 */
export declare function validateQuizTaskEvidenceDeclaration(params: QuizTaskEvidenceDeclarationInput): void;
export declare function recordQuizTaskEvidence(params: {
    persistence: PersistenceClient;
    userId: string;
    goalId: string;
    unitId?: string;
    moduleId?: string;
    activityAttemptId: string;
    source: "quiz" | "diagnostic" | "review_quiz";
    questions: readonly QuizQuestion[];
    results: readonly QuizGradeItem[];
    answers: Record<string, string | number | boolean | number[]>;
    targets: readonly UnitAssessmentTarget[];
    invalidQuestionPolicy?: InvalidQuestionPolicy;
}): Promise<{
    observationCount: number;
    skippedQuestionCount: number;
}>;
export declare function assessLearningTargetsFromDirectState(params: {
    persistence?: PersistenceClient;
    userId: string;
    targets: readonly UnitAssessmentTarget[];
    stateRead?: LearnerStateProjectionReadRepository;
}): Promise<LearningTargetCognitiveAssessment[]>;
/** Persistence-independent target assessment over authoritative entity state. */
export type AssessmentLearnerEntityState = Readonly<{
    overallEstimate: number | null;
    evidenceSufficiency: number;
    status: "unobserved" | "forming" | "demonstrated" | "robust" | "revalidate";
    inferencePolicyVersion: number;
    stateRevision: number;
    evidenceCutoffAt: string | null;
    lifecycleCutoffAt: string | null;
    dimensions: readonly Readonly<{
        dimension: CognitiveDimension;
        estimate: number | null;
        evidenceSufficiency: number;
        evidenceSufficiencyReasons: readonly string[];
        status: "unobserved" | "forming" | "demonstrated" | "robust" | "revalidate";
        effectiveEvidenceWeight: number;
        lastObservedAt: string | null;
    }>[];
}>;
export declare function assessLearningTargetsFromState(params: {
    targets: readonly UnitAssessmentTarget[];
    stateFor: (entityId: string) => Promise<AssessmentLearnerEntityState>;
}): Promise<LearningTargetCognitiveAssessment[]>;
export type FeynmanCriterionScore = {
    learningTargetId: string;
    criterionRef: string;
    score: number;
    rationale: string;
};
/** Rejects rubric-scoped LLM overreach before any workflow or evidence write. */
export declare function validateFeynmanRubricResult(params: {
    targets: readonly UnitAssessmentTarget[];
    observations: readonly FeynmanCriterionScore[];
    passed: boolean;
}): void;
export declare function recordFeynmanTaskEvidence(params: {
    persistence: PersistenceClient;
    userId: string;
    goalId: string;
    unitId: string;
    feynmanSessionId: string;
    userText: string;
    observations: readonly FeynmanCriterionScore[];
    targets: readonly UnitAssessmentTarget[];
}): Promise<{
    observationCount: number;
}>;
export declare function recordSocraticTaskEvidence(params: {
    persistence: PersistenceClient;
    userId: string;
    goalId: string;
    unitId: string;
    threadId: string;
    turn: number;
    localLearningTargetRef: string;
    criterionRef: string;
    answer: string;
    resolved: boolean;
    terminatedByLimit: boolean;
    targets: readonly UnitAssessmentTarget[];
}): Promise<{
    observationCount: number;
    skippedReason?: "unknown_learning_target" | "undeclared_criterion" | "undeclared_understanding";
}>;
export declare function recordVerifiedMaterialCheckEvidence(params: {
    persistence?: PersistenceClient;
    userId: string;
    goalId: string;
    unitId: string;
    blockKey: string;
    localLearningTargetRef: string;
    criterionRef: string;
    dimension: "understanding" | "application";
    contextDistance: "same" | "near";
    correct: boolean;
    response: unknown;
    targets: readonly UnitAssessmentTarget[];
    materialCheckCompletion?: MaterialCheckCompletionRepository;
}): Promise<void>;
export declare function buildMaterialCheckTaskDeclarations(params: {
    persistence?: PersistenceClient;
    userId: string;
    goalId: string;
    unitId: string;
    material: {
        blocks: readonly unknown[];
    };
    targets?: readonly UnitAssessmentTarget[];
}): Promise<MaterialCheckTaskDefinition[]>;
/**
 * Publish immutable inline-check task definitions alongside learning material.
 * Call this inside the same transaction as the LearningMaterial write.
 */
export declare function publishMaterialCheckTasks(params: {
    persistence: PersistenceClient;
    userId: string;
    goalId: string;
    unitId: string;
    material: {
        blocks: readonly unknown[];
    };
    targets?: readonly UnitAssessmentTarget[];
}): Promise<{
    publishedCheckIds: string[];
    deprecatedCount: number;
}>;
export declare function listMaterialCheckResults(params: {
    persistence?: PersistenceClient;
    userId: string;
    unitId: string;
    checkIds?: readonly string[];
    attempts?: readonly Readonly<{
        response: unknown;
        submittedAt: Date | null;
    }>[];
    materialCheckCompletion?: MaterialCheckCompletionRepository;
}): Promise<MaterialCheckResult[]>;
export declare function submitSectionMiniTestAnswers(params: {
    persistence?: PersistenceClient;
    userId: string;
    goalId: string;
    unitId: string;
    sectionId?: string;
    expectedUnitRevision?: number;
    expectedSectionRevision?: number;
    definitions: PublishedMaterialCheckDefinition[];
    answers: Record<string, number | number[] | boolean>;
    material: {
        blocks: readonly unknown[];
    };
    targets?: readonly UnitAssessmentTarget[];
    materialCheckCompletion?: MaterialCheckCompletionRepository;
}): Promise<{
    score: number;
    results: MaterialCheckResult[];
}>;
export declare function submitPublishedMaterialCheck(params: {
    persistence?: PersistenceClient;
    userId: string;
    goalId: string;
    unitId: string;
    definition: PublishedMaterialCheckDefinition;
    selectedAnswer: number | number[] | boolean;
    material?: {
        blocks: readonly unknown[];
    };
    targets?: readonly UnitAssessmentTarget[];
    materialCheckCompletion?: MaterialCheckCompletionRepository;
}): Promise<MaterialCheckResult>;
export declare function evidenceSourceForQuizPurpose(purpose: "learning" | "review"): Extract<EvidenceSource, "quiz" | "review_quiz">;
export {};
