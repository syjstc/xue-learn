import type { GoalMapPlan } from "../../llm/schemas.js";
import type { ContentLanguageCode } from "../../llm/content-language.js";
export declare function curriculumModuleMatchesContentLanguage(module: NonNullable<GoalMapPlan["modules"]>[number], contentLanguage: ContentLanguageCode): boolean;
/**
 * Canonicalize the contract so every major area can own exactly one map root.
 * The validated module/area list is the authoritative top-level count.
 */
export declare function normalizeGoalMapPlan(plan: GoalMapPlan): GoalMapPlan;
export declare function hydrateCurriculumModule(raw: unknown): unknown;
/** Coerce raw LLM JSON before schema validation (clamp counts, trim arrays). */
export declare function preprocessGoalMapPlanPayload(data: unknown): unknown;
