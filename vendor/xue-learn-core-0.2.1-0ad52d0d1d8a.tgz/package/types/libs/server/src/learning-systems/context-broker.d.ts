import { type LearningSystemActivationResolver } from "./activation.js";
import { LearningSystemRegistry } from "./registry.js";
import { type GenerationContextProfile, type LearningSystemSubject, type ResolvedGenerationContext } from "./types.js";
export type ContextResolutionRequest = {
    operation?: string;
    profile: GenerationContextProfile;
    subject: LearningSystemSubject;
    query?: string;
    invocation?: unknown;
    signal?: AbortSignal;
};
export type ContextBrokerOptions = {
    activationResolver?: LearningSystemActivationResolver;
    estimateTokens?: (data: unknown) => number;
};
export declare class ContextResolutionError extends Error {
    readonly result: ResolvedGenerationContext;
    constructor(message: string, result: ResolvedGenerationContext);
}
/**
 * Resolves operation-declared eager context. It selects complete envelopes
 * rather than truncating structured capability payloads, leaving schema-aware
 * compaction to the owning capability.
 */
export declare class ContextBroker {
    private readonly registry;
    private readonly activationResolver;
    private readonly estimateTokens;
    constructor(registry: LearningSystemRegistry, options?: ContextBrokerOptions);
    resolve(request: ContextResolutionRequest): Promise<ResolvedGenerationContext>;
    private resolveView;
    private assertProfile;
}
