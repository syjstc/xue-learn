import type { PlanContext } from "../../../llm/context/plan-context.js";
type CornellPromptPlan = {
    plan: PlanContext;
} | {
    goalBlock: string;
    difficultyBlock: string;
    timeBudgetBlock: string;
    styleBlock: string;
    languageBlock: string;
};
/** Root JSON-array successor to Cornell line DSL. */
export declare function buildCornellJsonPrompt(params: {
    unitTitle: string;
    optionsBlock: string;
    sqJson: string;
    materialJson: string;
    context: string;
} & CornellPromptPlan): string;
export {};
