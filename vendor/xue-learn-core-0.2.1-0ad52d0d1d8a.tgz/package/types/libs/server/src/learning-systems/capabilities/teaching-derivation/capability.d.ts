export { TEACHING_DERIVATION_CAPABILITY_ID, TEACHING_DERIVATION_CAPABILITY_VERSION, UNIT_TEACHING_DERIVATION_OPERATION, TEACHING_DERIVATION_PROMPT_VERSION, TEACHING_DERIVATION_TOOL_SET, TEACHING_DERIVATION_VIEW_KEYS, } from "./keys.js";
export { TEACHING_DERIVATION_AUTHORING_INSTRUCTION } from "./prompt.js";
export { configureTeachingDerivationPersistence } from "./persistence.js";
export declare function createTeachingDerivationCapability(): import("../../types.js").LearningSystemCapability;
