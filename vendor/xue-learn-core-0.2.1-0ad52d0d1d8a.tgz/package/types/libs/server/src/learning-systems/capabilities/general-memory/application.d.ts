import type { GeneralMemoryRepositoryPort } from "../../../../../domain/src/index.js";
import type { MemoryKind, MemoryScope } from "../../../../../memory/src/index.js";
import { GeneralMemoryRepository } from "./repository.js";
export declare class GeneralMemoryApplication {
    readonly repository: GeneralMemoryRepository;
    constructor(persistence?: GeneralMemoryRepositoryPort);
    getSettings(userId: string): Promise<{
        enabled: boolean;
    }>;
    setSettings(userId: string, enabled: boolean): Promise<{
        enabled: boolean;
    }>;
    list(input: {
        userId: string;
        status?: "active" | "archived";
        kind?: MemoryKind;
        scopeType?: MemoryScope["scopeType"];
        scopeId?: string | null;
        cursor?: string;
        limit?: number;
    }): Promise<{
        items: import("./schemas.js").MemoryItemDto[];
        nextCursor: string | null;
    }>;
    get(userId: string, memoryId: string): Promise<{
        id: string;
        kind: "personal_fact" | "preference" | "constraint" | "episode";
        summary: string;
        stableKey: string;
        authority: "learner_declared" | "conversation_derived" | "trusted_workflow";
        status: "active" | "superseded" | "archived";
        confidence: number;
        importance: number;
        scope: {
            productId: string;
            domain: string;
            scopeType: "goal" | "user" | "thread";
            scopeId?: string;
        };
        evidence: {
            id: string;
            sourceType: "message" | "manual" | "workflow";
            excerpt: string;
            occurredAt: string;
        }[];
        asOf: string;
        createdAt: string;
        updatedAt: string;
    }>;
    create(input: {
        userId: string;
        kind: Exclude<MemoryKind, "episode">;
        summary: string;
        stableKey?: string;
        importance: number;
        scopeType?: "user" | "goal" | "thread";
        scopeId?: string | null;
    }): Promise<{
        id: string;
        kind: "personal_fact" | "preference" | "constraint" | "episode";
        summary: string;
        stableKey: string;
        authority: "learner_declared" | "conversation_derived" | "trusted_workflow";
        status: "active" | "superseded" | "archived";
        confidence: number;
        importance: number;
        scope: {
            productId: string;
            domain: string;
            scopeType: "goal" | "user" | "thread";
            scopeId?: string;
        };
        evidence: {
            id: string;
            sourceType: "message" | "manual" | "workflow";
            excerpt: string;
            occurredAt: string;
        }[];
        asOf: string;
        createdAt: string;
        updatedAt: string;
    }>;
    correct(input: {
        userId: string;
        memoryId: string;
        summary: string;
        importance?: number;
    }): Promise<{
        id: string;
        kind: "personal_fact" | "preference" | "constraint" | "episode";
        summary: string;
        stableKey: string;
        authority: "learner_declared" | "conversation_derived" | "trusted_workflow";
        status: "active" | "superseded" | "archived";
        confidence: number;
        importance: number;
        scope: {
            productId: string;
            domain: string;
            scopeType: "goal" | "user" | "thread";
            scopeId?: string;
        };
        evidence: {
            id: string;
            sourceType: "message" | "manual" | "workflow";
            excerpt: string;
            occurredAt: string;
        }[];
        asOf: string;
        createdAt: string;
        updatedAt: string;
    }>;
    archive(userId: string, memoryId: string): Promise<{
        id: string;
        kind: "personal_fact" | "preference" | "constraint" | "episode";
        summary: string;
        stableKey: string;
        authority: "learner_declared" | "conversation_derived" | "trusted_workflow";
        status: "active" | "superseded" | "archived";
        confidence: number;
        importance: number;
        scope: {
            productId: string;
            domain: string;
            scopeType: "goal" | "user" | "thread";
            scopeId?: string;
        };
        evidence: {
            id: string;
            sourceType: "message" | "manual" | "workflow";
            excerpt: string;
            occurredAt: string;
        }[];
        asOf: string;
        createdAt: string;
        updatedAt: string;
    }>;
    delete(userId: string, memoryId: string): Promise<void>;
    listCandidates(userId: string): Promise<{
        id: string;
        kind: string;
        stableKey: string;
        summary: string;
        action: string;
        confidence: number;
        importance: number;
        createdAt: string;
    }[]>;
    resolveCandidate(input: {
        userId: string;
        candidateId: string;
        decision: "accept" | "reject";
    }): Promise<{
        status: "rejected";
        memory: any;
    } | {
        status: "activated";
        memory: {
            id: string;
            kind: "personal_fact" | "preference" | "constraint" | "episode";
            summary: string;
            stableKey: string;
            authority: "learner_declared" | "conversation_derived" | "trusted_workflow";
            status: "active" | "superseded" | "archived";
            confidence: number;
            importance: number;
            scope: {
                productId: string;
                domain: string;
                scopeType: "goal" | "user" | "thread";
                scopeId?: string;
            };
            evidence: {
                id: string;
                sourceType: "message" | "manual" | "workflow";
                excerpt: string;
                occurredAt: string;
            }[];
            asOf: string;
            createdAt: string;
            updatedAt: string;
        };
    }>;
    recordEpisode(input: {
        userId: string;
        threadId: string;
        summary: string;
        sourceRef: string;
    }): Promise<{
        id: string;
        kind: "personal_fact" | "preference" | "constraint" | "episode";
        summary: string;
        stableKey: string;
        authority: "learner_declared" | "conversation_derived" | "trusted_workflow";
        status: "active" | "superseded" | "archived";
        confidence: number;
        importance: number;
        scope: {
            productId: string;
            domain: string;
            scopeType: "goal" | "user" | "thread";
            scopeId?: string;
        };
        evidence: {
            id: string;
            sourceType: "message" | "manual" | "workflow";
            excerpt: string;
            occurredAt: string;
        }[];
        asOf: string;
        createdAt: string;
        updatedAt: string;
    }>;
}
export declare function createGeneralMemoryApplication(persistence?: GeneralMemoryRepositoryPort): GeneralMemoryApplication;
