import type { LearningSystemCapability } from "../types.js";
import type { RuntimeContextDependencies } from "./support/runtime.js";
export declare const AGENDA_GENERATION_VIEW_KEYS: Readonly<{
    refineInstructionContext: "instruction.agenda.refine.v1";
}>;
export type AgendaRefineInvocation = {
    capacityMinutes: number;
    planningDate: string;
    timezone: string;
    languageInstruction: string;
    shortlist: unknown;
};
export declare function buildAgendaRefineInvocationPrompt(input: AgendaRefineInvocation): string;
export declare function createAgendaCapability(deps: RuntimeContextDependencies): LearningSystemCapability;
