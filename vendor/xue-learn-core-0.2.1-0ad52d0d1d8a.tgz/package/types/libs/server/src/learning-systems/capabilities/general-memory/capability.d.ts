import type { LearningSystemCapability } from "../../types.js";
export declare function createGeneralMemoryCapability(): LearningSystemCapability;
