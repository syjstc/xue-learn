import type { LearningSystemPersistenceClient } from "../../persistence-client.js";
import type { CognitiveModelPresentationReadRepository, LearnerStateMemoryReadRepository, LearnerStateProjectionReadRepository } from "../../../../../domain/src/index.js";
import { z } from "zod";
import { getGoalCognitiveModel, getUnitLearningTargetsV2 } from "../../../cognitive-model/presentation.js";
import type { PersonaPromptLocale, TeachingPersonaPromptPart } from "../../../teaching-personas/index.js";
import { loadTeachingSkillPrompt } from "../../../teaching-skills/index.js";
import { upsertUserSettingsForUser } from "../../../user-settings.js";
import type { ContextAuthority, ContextEnvelope, LearningSystemSubject } from "../../types.js";
import type { LearningSpaceGoalCreationApplication, LearningSpacePortfolioReader } from "../../../learning-spaces/orm-application-service.js";
export declare const VERSION = "1.0.0";
export declare const SCHEMA_VERSION = 1;
export declare const BUILTIN_READ_VIEW_KEYS: {
    readonly goalIntent: "goal.intent.v1";
    readonly curriculumStructure: "curriculum.structure.v1";
    readonly curriculumModule: "curriculum.module.v1";
    readonly curriculumUnit: "curriculum.unit.v1";
    readonly sessionCurrent: "session.current.v1";
    readonly contentMaterial: "content.material.v1";
    readonly learnerRelevantMemory: "learner.relevant_memory.v2";
    readonly learnerProfile: "learner.profile.v1";
    readonly learnerCognitiveState: "learner.cognitive_state.v1";
    readonly learningObjectives: "learning.objectives.v1";
    readonly learningAssessmentAuthority: "learning.assessment_authority.v1";
    readonly teachingPersonaBase: "teaching.persona.base.v1";
    readonly teachingPersonaFull: "teaching.persona.full.v1";
    readonly teachingPersonaCourse: "teaching.persona.course.v1";
    readonly teachingPersonaAssessment: "teaching.persona.assessment.v1";
    readonly teachingPersonaFollowUp: "teaching.persona.follow_up.v1";
    readonly teachingDomainGuidance: "teaching.domain_guidance.v1";
};
export declare const BUILTIN_READ_QUERY_TOOL_KEYS: {
    readonly findRelevantMemory: "find_relevant_memory";
    readonly searchGoals: "search_goals";
    readonly searchUnits: "search_units";
    readonly getRecentActivity: "get_recent_activity";
    readonly getActiveGoalCreation: "get_active_goal_creation";
    readonly explainLearningApp: "explain_learning_app";
    readonly getCurrentLearningState: "get_current_learning_state";
    readonly getLearningObjectives: "get_current_learning_objectives";
    readonly getLearningPreferences: "get_effective_learning_preferences";
};
export type BuiltinReadCapabilityDependencies = {
    formatGlobalLearnerStateMemoryPrompt: (userId: string, client?: LearningSystemPersistenceClient, memoryRead?: LearnerStateMemoryReadRepository) => Promise<string>;
    formatCognitiveStatePromptBlock: (userId: string, goalId?: string, projectionRead?: LearnerStateProjectionReadRepository) => Promise<string>;
    formatTeachingPersonaPromptPartForUser: (userId: string, goalId: string | undefined, part: TeachingPersonaPromptPart, locale?: PersonaPromptLocale) => Promise<string>;
    formatTeachingPersonaPromptBlockForUser: (userId: string, goalId?: string, locale?: PersonaPromptLocale) => Promise<string>;
    getGoalCognitiveModel: (client: LearningSystemPersistenceClient, goalId: string, options?: any) => ReturnType<typeof getGoalCognitiveModel>;
    getUnitLearningTargetsV2: (client: LearningSystemPersistenceClient, unitId: string, options?: any) => ReturnType<typeof getUnitLearningTargetsV2>;
    upsertUserSettingsForUser: typeof upsertUserSettingsForUser;
    loadTeachingSkillPrompt: typeof loadTeachingSkillPrompt;
};
export type CreateBuiltinReadCapabilitiesOptions = {
    persistence?: LearningSystemPersistenceClient;
    /** Optional cache reader supplied by the active persistence composition. */
    learnerStateMemoryRead?: LearnerStateMemoryReadRepository;
    /** Optional projection reader supplied by the active persistence composition. */
    learnerStateProjectionRead?: LearnerStateProjectionReadRepository;
    cognitiveModelPresentationRead?: CognitiveModelPresentationReadRepository;
    /** Optional typed application supplied by the active persistence composition root. */
    learningSpaceApplication?: LearningSpaceGoalCreationApplication;
    /** Optional typed reader supplied by the active persistence composition root. */
    learningSpacePortfolio?: LearningSpacePortfolioReader;
    /**
     * Test seam for public read APIs whose current implementation uses the
     * process-local database client. Production callers should not override it.
     */
    dependencies?: Partial<BuiltinReadCapabilityDependencies>;
};
export declare const preferencesResultSchema: z.ZodObject<{
    learningViewMode: z.ZodEnum<{
        chat: "chat";
        reading: "reading";
    }>;
    chatAudioEnabled: z.ZodBoolean;
}, z.core.$strip>;
export declare const goalSearchResultSchema: z.ZodObject<{
    goals: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        status: z.ZodString;
        goalKind: z.ZodString;
        learningMode: z.ZodString;
        contentLanguage: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const unitSearchResultSchema: z.ZodObject<{
    units: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        goalId: z.ZodString;
        goalTitle: z.ZodString;
        title: z.ZodString;
        status: z.ZodString;
        unitKind: z.ZodString;
        orderIndex: z.ZodNumber;
        currentStep: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const recentActivityResultSchema: z.ZodObject<{
    goals: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        status: z.ZodString;
        lastTouchedAt: z.ZodString;
    }, z.core.$strip>>;
    units: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        status: z.ZodString;
        goalId: z.ZodString;
        goalTitle: z.ZodString;
        currentStep: z.ZodNullable<z.ZodString>;
        lastTouchedAt: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const activeGoalCreationResultSchema: z.ZodObject<{
    session: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        goalId: z.ZodNullable<z.ZodString>;
        title: z.ZodNullable<z.ZodString>;
        status: z.ZodString;
        phase: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const cognitiveStateResultSchema: z.ZodObject<{
    globalStatePrompt: z.ZodString;
    goalStatePrompt: z.ZodString;
    objectives: z.ZodArray<z.ZodUnknown>;
}, z.core.$strip>;
export declare const objectivesResultSchema: z.ZodObject<{
    goalId: z.ZodNullable<z.ZodString>;
    unitId: z.ZodNullable<z.ZodString>;
    status: z.ZodString;
    objectives: z.ZodArray<z.ZodUnknown>;
}, z.core.$strip>;
export declare function nowIso(): string;
export declare function iso(value: unknown): string;
export declare function abortIfNeeded(signal?: AbortSignal): void;
export declare function envelope<T>(params: {
    ownerCapabilityId: string;
    authority: ContextAuthority;
    scope: LearningSystemSubject;
    data: T;
    asOf?: string;
    stale?: boolean;
}): ContextEnvelope<T>;
export declare function parseJsonObject(raw: string | null | undefined): Record<string, unknown>;
export declare function parseJsonArray(raw: string | null | undefined): unknown[];
export declare function compactText(value: string | null | undefined, maxLength: number): string;
export declare function compactTakeaways(raw: string | null | undefined): string[];
export declare function compactSections(raw: string | null | undefined): {
    index: number;
    title: string;
    preview: string;
}[];
export declare function loadGoal(persistence: LearningSystemPersistenceClient, subject: LearningSystemSubject): Promise<any>;
export declare function loadCurriculum(persistence: LearningSystemPersistenceClient, subject: LearningSystemSubject): Promise<{
    goal: any;
    modules: any[];
    units: any[];
}>;
export declare function compactDurableGoal(goal: NonNullable<Awaited<ReturnType<typeof loadGoal>>>): {
    id: any;
    title: any;
    level: any;
    domainTag: any;
    topicCategory: any;
    contentLanguage: any;
    goalKind: any;
    learningMode: any;
    planningMode: any;
    curriculumVersion: any;
    topicOverview: string;
    generationOptions: any;
};
export declare function compactDurableCurriculum(curriculum: NonNullable<Awaited<ReturnType<typeof loadCurriculum>>>): {
    goal: {
        id: any;
        title: any;
        level: any;
        domainTag: any;
        topicCategory: any;
        contentLanguage: any;
        goalKind: any;
        learningMode: any;
        planningMode: any;
        curriculumVersion: any;
        topicOverview: string;
        generationOptions: any;
    };
    modules: {
        id: any;
        planRef: any;
        orderIndex: any;
        title: any;
        summary: string;
        objective: string;
    }[];
    units: {
        id: any;
        moduleId: any;
        parentUnitId: any;
        unitKind: any;
        title: any;
        orderIndex: any;
        difficulty: any;
        contentSummary: string;
    }[];
};
export declare function renderGoalIntentPrompt(goal: ReturnType<typeof compactDurableGoal>): string;
export declare function renderCurriculumStructurePrompt(curriculum: ReturnType<typeof compactDurableCurriculum>): string;
export declare function renderCurriculumModulePrompt(input: NonNullable<Awaited<ReturnType<typeof loadModule>>>, goalTitle?: string | null): string;
export declare function renderCurriculumUnitPrompt(unit: NonNullable<Awaited<ReturnType<typeof loadDurableUnit>>>): string;
export declare function loadModule(persistence: LearningSystemPersistenceClient, subject: LearningSystemSubject): Promise<{
    goalTitle: any;
    module: {
        id: any;
        planRef: any;
        orderIndex: any;
        title: any;
        summary: string;
        objective: string;
    };
    units: {
        id: any;
        parentUnitId: any;
        unitKind: any;
        title: any;
        orderIndex: any;
        difficulty: any;
        contentSummary: string;
    }[];
}>;
export declare function loadDurableUnit(persistence: LearningSystemPersistenceClient, subject: LearningSystemSubject): Promise<{
    priorTeachingContext: string;
    id: any;
    goalId: any;
    moduleId: any;
    title: any;
    unitKind: any;
    orderIndex: any;
    contentSummary: string;
}>;
export declare function loadCurrentUnit(persistence: LearningSystemPersistenceClient, subject: LearningSystemSubject): Promise<any>;
export declare function compactSession(unit: Awaited<ReturnType<typeof loadCurrentUnit>>): {
    unit: {
        id: any;
        goalId: any;
        goalTitle: any;
        moduleId: any;
        title: any;
        status: any;
        unitKind: any;
        orderIndex: any;
        contentSummary: string;
        learningMode: any;
        goalKind: any;
    };
    session: {
        currentStep: any;
        structuredSubStep: any;
        cumulativeActiveSeconds: any;
        updatedAt: string;
    };
};
export declare function compactMaterial(unit: Awaited<ReturnType<typeof loadCurrentUnit>>): {
    unitId: any;
    goalId: any;
    title: any;
    contentSummary: string;
    material: {
        introduction: string;
        sections: {
            index: number;
            title: string;
            preview: string;
        }[];
        keyTakeaways: string[];
        contextSources: unknown[];
        updatedAt: string;
    };
};
export declare function compactLearningTarget(target: unknown): unknown;
export declare function authorizeCognitiveSubject(persistence: LearningSystemPersistenceClient, subject: LearningSystemSubject): Promise<{
    goalId: any;
    unitId: any;
    goalKind: any;
    learningMode: any;
    goalCognitiveModelStatus: any;
    unitCognitiveModelStatus: any;
}>;
export declare function loadObjectives(persistence: LearningSystemPersistenceClient, deps: BuiltinReadCapabilityDependencies, subject: LearningSystemSubject): Promise<{
    goalId: any;
    unitId: any;
    status: any;
    objectives: unknown[];
}>;
export declare function loadCognitiveState(persistence: LearningSystemPersistenceClient, deps: BuiltinReadCapabilityDependencies, subject: LearningSystemSubject): Promise<{
    globalStatePrompt: string;
    goalStatePrompt: string;
    objectives: unknown[];
}>;
