import type { LearningSystemPersistenceClient } from "../persistence-client.js";
import type { LearningSystemCapability } from "../types.js";
export declare function createCurriculumSessionCapability(persistence: LearningSystemPersistenceClient): LearningSystemCapability;
