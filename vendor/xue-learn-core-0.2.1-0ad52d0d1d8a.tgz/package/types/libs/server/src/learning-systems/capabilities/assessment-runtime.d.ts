import type { LearningSystemPersistenceClient } from "../persistence-client.js";
import type { LearningSystemCapability } from "../types.js";
export declare function buildAssessmentInvocationPrompt(key: string, invocation: unknown): string | null;
export declare function createAssessmentRuntimeCapability(persistence: LearningSystemPersistenceClient): LearningSystemCapability;
