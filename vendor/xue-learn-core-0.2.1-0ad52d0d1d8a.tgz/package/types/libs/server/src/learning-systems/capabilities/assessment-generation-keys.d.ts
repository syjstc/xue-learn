export declare const ASSESSMENT_GENERATION_VIEW_KEYS: Readonly<{
    quizInstructionContext: "instruction.assessment.quiz.v1";
    feynmanInstructionContext: "instruction.assessment.feynman.v1";
    drillsInstructionContext: "instruction.assessment.drills.v1";
    diagnosticInstructionContext: "instruction.assessment.diagnostic.v1";
    adaptiveEvaluationInstructionContext: "instruction.assessment.adaptive_evaluation.v1";
}>;
