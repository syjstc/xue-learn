import type { AgentPageContext } from "../../../agents/core/types.js";
export declare const ASSISTANT_POLICY_CAPABILITY_ID: "assistant-policy";
export declare const ASSISTANT_POLICY_CAPABILITY_VERSION: "1.0.0";
export declare function buildGlobalAssistantInvocationPrompt(invocation?: {
    pageContext?: AgentPageContext;
    forcedWebContext?: string;
}, query?: string): string;
export declare function createAssistantPolicyCapability(): import("../../types.js").LearningSystemCapability;
