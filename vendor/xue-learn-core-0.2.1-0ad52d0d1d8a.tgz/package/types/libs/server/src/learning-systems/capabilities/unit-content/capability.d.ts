type SqAnswersInput = {
    unitTitle: string;
    goalBlock: string;
    languageBlock: string;
    styleBlock: string;
    optionsBlock?: string;
    numberedQuestions: string;
    materialJson: string;
    answerCount: number;
};
export declare function buildSqQuestionAnswersPrompt(input: SqAnswersInput): string;
export declare const SQ_ANSWERS_STABLE_INSTRUCTION = "Answer the unit's guiding questions only from the supplied published learning material, preserving the requested order and structured output contract. Write the answers in the active teaching persona's voice; if it specifies a roast cadence, keep that edge in these short answers without inventing material.";
export declare function buildUnitContentInvocationPrompt(key: string, invocation: unknown): string | null;
export declare function createUnitContentCapability(): import("../../types.js").LearningSystemCapability;
export {};
