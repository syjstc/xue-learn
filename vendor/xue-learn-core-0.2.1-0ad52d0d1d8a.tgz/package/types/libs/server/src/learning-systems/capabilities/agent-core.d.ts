export declare const AGENT_CORE_CAPABILITY_ID: "agent-core";
export declare const AGENT_CORE_CAPABILITY_VERSION: "1.0.0";
export declare function createAgentCoreCapability(): import("../types.js").LearningSystemCapability;
