import { type ContentLanguageCode } from "../../llm/content-language.js";
import { z } from "zod";
import type { StreamTokenHandler } from "../../llm/chat-stream.js";
import { type ObjectRepairSlot } from "../../llm/validated-structured-generation.js";
import { type GoalCurriculumIdentity, type GoalMapPlan } from "../../llm/schemas.js";
export declare function sequentialModuleRepairTarget(params: {
    validCount: number;
    droppedCount: number;
    packedSingle: boolean;
}): number;
export declare const PLAN_SCHEMA_SHAPE = "{\n  \"schemaVersion\": 2,\n  \"refinedTitle\": \"clear, accurate learning goal title (fix typos/grammar; keep language & scope)\",\n  \"domainAnalysis\": {\n    \"field\": \"broad discipline (e.g. language learning, computer science)\",\n    \"subdomain\": \"specific slice within the field\",\n    \"learningMode\": \"skill_practice\",\n    \"domainTag\": \"humanities\",\n    \"topicCategory\": \"language\",\n    \"modeClarification\": \"2-3 sentences: which learning tradition this is and why (e.g. learning English for communication vs studying linguistics)\",\n    \"alternateInterpretations\": [{ \"label\": \"other reading of the goal\", \"whyNotChosen\": \"why we did not pick it\" }]\n  },\n  \"topicOverview\": \"2-4 short paragraphs AFTER domain is clear \u2014 journey, motivation, how units will feel\",\n  \"whatYouWillLearn\": [\"...\", \"...\"],\n  \"prerequisitesAssumed\": [\"...\"],\n  \"modules\": [{\n    \"title\": \"first observable milestone\",\n    \"summary\": \"what changes for the learner in this module\",\n    \"objective\": \"observable capability achieved at exit\",\n    \"dependsOnPrevious\": \"for module 1, state the entry foundation\"\n  }, {\n    \"title\": \"next dependent milestone\",\n    \"summary\": \"the next capability that requires the previous module\",\n    \"objective\": \"observable capability achieved at this later exit\",\n    \"dependsOnPrevious\": \"how this builds on the prior milestone\"\n  }]\n}";
export declare const IDENTITY_SCHEMA_SHAPE = "{\n  \"schemaVersion\": 2,\n  \"refinedTitle\": \"clear, accurate learning goal title (fix typos/grammar; keep language & scope)\",\n  \"domainAnalysis\": {\n    \"field\": \"broad discipline (e.g. language learning, computer science)\",\n    \"subdomain\": \"specific slice within the field\",\n    \"learningMode\": \"skill_practice\",\n    \"domainTag\": \"humanities\",\n    \"topicCategory\": \"language\",\n    \"modeClarification\": \"2-3 sentences: which learning tradition this is and why\",\n    \"alternateInterpretations\": [{ \"label\": \"other reading of the goal\", \"whyNotChosen\": \"why we did not pick it\" }]\n  },\n  \"topicOverview\": \"2-4 short paragraphs AFTER domain is clear \u2014 journey, motivation, how units will feel\",\n  \"whatYouWillLearn\": [\"...\", \"...\"],\n  \"prerequisitesAssumed\": [\"assumed foundation given the confirmed level\"]\n}";
export declare const JOURNEY_SCHEMA_SHAPE = "{\n  \"modules\": [{\n    \"title\": \"first observable milestone\",\n    \"summary\": \"what changes for the learner in this module\",\n    \"objective\": \"observable capability achieved at exit\",\n    \"dependsOnPrevious\": \"for module 1, state the entry foundation\"\n  }]\n}";
export declare function buildGoalMapPlanPrompt(params: {
    title: string;
    level: string;
    context?: string;
    pathSource: "rag" | "search" | "generic";
    contentLanguage: ContentLanguageCode;
    generationOptions?: string;
    teachingSkillBlock?: string;
}): string;
export declare function buildGoalIdentityPrompt(params: Parameters<typeof buildGoalMapPlanPrompt>[0]): string;
export declare function buildGoalJourneyPrompt(params: Parameters<typeof buildGoalMapPlanPrompt>[0], identity: GoalCurriculumIdentity): string;
export declare const CURRICULUM_PLANNING_CAPABILITY_ID: "curriculum-planning";
export declare const CURRICULUM_PLANNING_CAPABILITY_VERSION: "1.3.0";
export declare const CURRICULUM_PLANNING_INSTRUCTION = "Create the requested XueLearn curriculum artifact from the invocation input.\n- Treat the learner's confirmed goal, level, scope, language, and approved map as authoritative.\n- Match module count to that confirmed scope. A narrow goal (one named theorem, identity, proof, formula, or skill) is one module. Do not expand a small request into a textbook, chapter sequence, or survey course.\n- Allowed range is 1\u20138 modules. Never pad toward 3\u20136. Use extra modules only for genuine capability milestones the learner asked for.\n- Keep assumed foundations in prerequisitesAssumed; do not open modules that only review them.\n- If the teaching persona specifies first-principles or non-textbook sequencing, order modules for the fastest path to understanding. Do not copy a syllabus or textbook table of contents. Still cover the confirmed goal and teach genuinely blocking prerequisites first.\n- Follow the invocation's complete planning rules and declared structured-output contract.\n- Do not invent learner constraints, credentials, exams, or outcomes that the supplied goal contract does not support.";
export type GoalCurriculumPlanningMode = "fast" | "deep" | "docs_first";
export type PrepareGoalCurriculumPlanAuthoringInput = {
    title: string;
    level: string;
    context?: string;
    pathSource: "rag" | "search" | "generic";
    contentLanguage: ContentLanguageCode;
    generationOptions?: string;
    teachingSkillBlock?: string;
    planningMode?: GoalCurriculumPlanningMode;
    operation?: "goal.curriculum.plan" | "goal.curriculum.replan" | "goal.curriculum.plan.deep_blueprint" | "goal.curriculum.plan.deep_draft" | "goal.curriculum.plan.deep_synthesis";
};
/** Shared authoring boundary after mode-specific context gathering. */
export declare function prepareGoalCurriculumPlanAuthoring(input: PrepareGoalCurriculumPlanAuthoringInput): {
    operation: "goal.curriculum.plan" | "goal.curriculum.replan" | "goal.curriculum.plan.deep_blueprint" | "goal.curriculum.plan.deep_draft" | "goal.curriculum.plan.deep_synthesis";
    prompt: string;
    standalonePrompt: string;
    contextInvocation: {
        title: string;
        level: string;
        context: string;
        pathSource: "search" | "rag" | "generic";
        contentLanguage: "zh-Hans" | "zh-Hant" | "en" | "ja" | "ko" | "es" | "fr" | "de" | "other";
        generationOptions: string;
        teachingSkillBlock: string;
    };
    schema: z.ZodPreprocess<z.ZodObject<{
        schemaVersion: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>>;
        refinedTitle: z.ZodOptional<z.ZodString>;
        domainAnalysis: z.ZodObject<{
            field: z.ZodString;
            subdomain: z.ZodString;
            learningMode: z.ZodEnum<{
                skill_practice: "skill_practice";
                conceptual_understanding: "conceptual_understanding";
                research_scholarship: "research_scholarship";
                professional_applied: "professional_applied";
                creative_expression: "creative_expression";
                mixed: "mixed";
            }>;
            domainTag: z.ZodEnum<{
                humanities: "humanities";
                general: "general";
                stem: "stem";
            }>;
            topicCategory: z.ZodEnum<{
                music: "music";
                language: "language";
                mathematics: "mathematics";
                natural_science: "natural_science";
                computer_science: "computer_science";
                engineering: "engineering";
                humanities: "humanities";
                social_science: "social_science";
                arts: "arts";
                business: "business";
                health_medicine: "health_medicine";
                professional: "professional";
                general: "general";
            }>;
            modeClarification: z.ZodString;
            alternateInterpretations: z.ZodDefault<z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                whyNotChosen: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>;
        topicOverview: z.ZodString;
        whatYouWillLearn: z.ZodArray<z.ZodString>;
        majorAreas: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            description: z.ZodString;
            mapRole: z.ZodDefault<z.ZodEnum<{
                branch: "branch";
                leaf: "leaf";
            }>>;
            estimatedChildCount: z.ZodOptional<z.ZodNumber>;
            groupingAxis: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        modules: z.ZodOptional<z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            summary: z.ZodString;
            objective: z.ZodString;
            dependsOnPrevious: z.ZodString;
            plannedOutcomes: z.ZodArray<z.ZodString>;
            entryFoundationBriefs: z.ZodDefault<z.ZodArray<z.ZodObject<{
                ref: z.ZodString;
                title: z.ZodString;
                rationale: z.ZodString;
                criticality: z.ZodEnum<{
                    critical: "critical";
                    recommended: "recommended";
                }>;
                verificationDimensions: z.ZodArray<z.ZodEnum<{
                    memory: "memory";
                    understanding: "understanding";
                    application: "application";
                }>>;
            }, z.core.$strip>>>;
            exitCapabilityBriefs: z.ZodArray<z.ZodString>;
            estimatedUnitCount: z.ZodNumber;
            unitPlanningBrief: z.ZodDefault<z.ZodObject<{
                scopeSize: z.ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                    large: "large";
                }>;
                rationale: z.ZodString;
                progression: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
        }, z.core.$strip>>>;
        mapStructure: z.ZodObject<{
            recommendedDepth: z.ZodNumber;
            estimatedLeafUnits: z.ZodNumber;
            layeringStrategy: z.ZodString;
            nestingRationale: z.ZodString;
        }, z.core.$strip>;
        outOfScope: z.ZodDefault<z.ZodArray<z.ZodString>>;
        prerequisitesAssumed: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>>;
    bindingSchema: z.ZodObject<{
        schemaVersion: z.ZodLiteral<2>;
        refinedTitle: z.ZodOptional<z.ZodString>;
        domainAnalysis: z.ZodObject<{
            field: z.ZodString;
            subdomain: z.ZodString;
            learningMode: z.ZodEnum<{
                skill_practice: "skill_practice";
                conceptual_understanding: "conceptual_understanding";
                research_scholarship: "research_scholarship";
                professional_applied: "professional_applied";
                creative_expression: "creative_expression";
                mixed: "mixed";
            }>;
            domainTag: z.ZodEnum<{
                humanities: "humanities";
                general: "general";
                stem: "stem";
            }>;
            topicCategory: z.ZodEnum<{
                music: "music";
                language: "language";
                mathematics: "mathematics";
                natural_science: "natural_science";
                computer_science: "computer_science";
                engineering: "engineering";
                humanities: "humanities";
                social_science: "social_science";
                arts: "arts";
                business: "business";
                health_medicine: "health_medicine";
                professional: "professional";
                general: "general";
            }>;
            modeClarification: z.ZodString;
            alternateInterpretations: z.ZodDefault<z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                whyNotChosen: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>;
        topicOverview: z.ZodString;
        whatYouWillLearn: z.ZodArray<z.ZodString>;
        prerequisitesAssumed: z.ZodDefault<z.ZodArray<z.ZodString>>;
        modules: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            summary: z.ZodString;
            objective: z.ZodString;
            dependsOnPrevious: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    schemaShape: string;
    recoveryPolicy: {
        sourceSchema: z.ZodUnknown;
        normalize: (candidate: unknown) => {
            value: unknown;
            normalizedCount: number;
            droppedCount: number;
        };
        repairSlots: ({ candidate }: {
            candidate: unknown;
            error: z.ZodError;
        }) => ObjectRepairSlot[];
    };
    parseResult: (candidate: unknown) => {
        schemaVersion: 1 | 2;
        domainAnalysis: {
            field: string;
            subdomain: string;
            learningMode: "skill_practice" | "conceptual_understanding" | "research_scholarship" | "professional_applied" | "creative_expression" | "mixed";
            domainTag: "humanities" | "general" | "stem";
            topicCategory: "music" | "language" | "mathematics" | "natural_science" | "computer_science" | "engineering" | "humanities" | "social_science" | "arts" | "business" | "health_medicine" | "professional" | "general";
            modeClarification: string;
            alternateInterpretations: {
                label: string;
                whyNotChosen: string;
            }[];
        };
        topicOverview: string;
        whatYouWillLearn: string[];
        majorAreas: {
            title: string;
            description: string;
            mapRole: "branch" | "leaf";
            estimatedChildCount?: number;
            groupingAxis?: string;
        }[];
        mapStructure: {
            recommendedDepth: number;
            estimatedLeafUnits: number;
            layeringStrategy: string;
            nestingRationale: string;
        };
        outOfScope: string[];
        prerequisitesAssumed: string[];
        refinedTitle?: string;
        modules?: {
            title: string;
            summary: string;
            objective: string;
            dependsOnPrevious: string;
            plannedOutcomes: string[];
            entryFoundationBriefs: {
                ref: string;
                title: string;
                rationale: string;
                criticality: "critical" | "recommended";
                verificationDimensions: ("memory" | "understanding" | "application")[];
            }[];
            exitCapabilityBriefs: string[];
            estimatedUnitCount: number;
            unitPlanningBrief: {
                scopeSize: "standard" | "compact" | "large";
                rationale: string;
                progression: string[];
            };
        }[];
    };
    parseProviderOutput: (content: string) => {
        schemaVersion: 1 | 2;
        domainAnalysis: {
            field: string;
            subdomain: string;
            learningMode: "skill_practice" | "conceptual_understanding" | "research_scholarship" | "professional_applied" | "creative_expression" | "mixed";
            domainTag: "humanities" | "general" | "stem";
            topicCategory: "music" | "language" | "mathematics" | "natural_science" | "computer_science" | "engineering" | "humanities" | "social_science" | "arts" | "business" | "health_medicine" | "professional" | "general";
            modeClarification: string;
            alternateInterpretations: {
                label: string;
                whyNotChosen: string;
            }[];
        };
        topicOverview: string;
        whatYouWillLearn: string[];
        majorAreas: {
            title: string;
            description: string;
            mapRole: "branch" | "leaf";
            estimatedChildCount?: number;
            groupingAxis?: string;
        }[];
        mapStructure: {
            recommendedDepth: number;
            estimatedLeafUnits: number;
            layeringStrategy: string;
            nestingRationale: string;
        };
        outOfScope: string[];
        prerequisitesAssumed: string[];
        refinedTitle?: string;
        modules?: {
            title: string;
            summary: string;
            objective: string;
            dependsOnPrevious: string;
            plannedOutcomes: string[];
            entryFoundationBriefs: {
                ref: string;
                title: string;
                rationale: string;
                criticality: "critical" | "recommended";
                verificationDimensions: ("memory" | "understanding" | "application")[];
            }[];
            exitCapabilityBriefs: string[];
            estimatedUnitCount: number;
            unitPlanningBrief: {
                scopeSize: "standard" | "compact" | "large";
                rationale: string;
                progression: string[];
            };
        }[];
    };
};
export declare function prepareGoalCurriculumIdentityAuthoring(input: PrepareGoalCurriculumPlanAuthoringInput): {
    prompt: string;
    standalonePrompt: string;
    bindingSchema: z.ZodObject<{
        schemaVersion: z.ZodLiteral<2>;
        refinedTitle: z.ZodOptional<z.ZodString>;
        domainAnalysis: z.ZodObject<{
            field: z.ZodString;
            subdomain: z.ZodString;
            learningMode: z.ZodEnum<{
                skill_practice: "skill_practice";
                conceptual_understanding: "conceptual_understanding";
                research_scholarship: "research_scholarship";
                professional_applied: "professional_applied";
                creative_expression: "creative_expression";
                mixed: "mixed";
            }>;
            domainTag: z.ZodEnum<{
                humanities: "humanities";
                general: "general";
                stem: "stem";
            }>;
            topicCategory: z.ZodEnum<{
                music: "music";
                language: "language";
                mathematics: "mathematics";
                natural_science: "natural_science";
                computer_science: "computer_science";
                engineering: "engineering";
                humanities: "humanities";
                social_science: "social_science";
                arts: "arts";
                business: "business";
                health_medicine: "health_medicine";
                professional: "professional";
                general: "general";
            }>;
            modeClarification: z.ZodString;
            alternateInterpretations: z.ZodDefault<z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                whyNotChosen: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>;
        topicOverview: z.ZodString;
        whatYouWillLearn: z.ZodArray<z.ZodString>;
        prerequisitesAssumed: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>;
    schemaShape: string;
    recoveryPolicy: {
        sourceSchema: z.ZodUnknown;
        normalize: (candidate: unknown) => {
            value: unknown;
            normalizedCount: number;
            droppedCount: number;
        };
        repairSlots: ({ candidate, error, }: {
            candidate: unknown;
            error: z.ZodError;
        }) => ObjectRepairSlot[];
    };
    parseResult: (candidate: unknown) => {
        schemaVersion: 2;
        domainAnalysis: {
            field: string;
            subdomain: string;
            learningMode: "skill_practice" | "conceptual_understanding" | "research_scholarship" | "professional_applied" | "creative_expression" | "mixed";
            domainTag: "humanities" | "general" | "stem";
            topicCategory: "music" | "language" | "mathematics" | "natural_science" | "computer_science" | "engineering" | "humanities" | "social_science" | "arts" | "business" | "health_medicine" | "professional" | "general";
            modeClarification: string;
            alternateInterpretations: {
                label: string;
                whyNotChosen: string;
            }[];
        };
        topicOverview: string;
        whatYouWillLearn: string[];
        prerequisitesAssumed: string[];
        refinedTitle?: string;
    };
    operation: "goal.curriculum.plan" | "goal.curriculum.replan" | "goal.curriculum.plan.deep_blueprint" | "goal.curriculum.plan.deep_draft" | "goal.curriculum.plan.deep_synthesis";
    contextInvocation: {
        title: string;
        level: string;
        context: string;
        pathSource: "search" | "rag" | "generic";
        contentLanguage: "zh-Hans" | "zh-Hant" | "en" | "ja" | "ko" | "es" | "fr" | "de" | "other";
        generationOptions: string;
        teachingSkillBlock: string;
    };
    schema: z.ZodPreprocess<z.ZodObject<{
        schemaVersion: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>>;
        refinedTitle: z.ZodOptional<z.ZodString>;
        domainAnalysis: z.ZodObject<{
            field: z.ZodString;
            subdomain: z.ZodString;
            learningMode: z.ZodEnum<{
                skill_practice: "skill_practice";
                conceptual_understanding: "conceptual_understanding";
                research_scholarship: "research_scholarship";
                professional_applied: "professional_applied";
                creative_expression: "creative_expression";
                mixed: "mixed";
            }>;
            domainTag: z.ZodEnum<{
                humanities: "humanities";
                general: "general";
                stem: "stem";
            }>;
            topicCategory: z.ZodEnum<{
                music: "music";
                language: "language";
                mathematics: "mathematics";
                natural_science: "natural_science";
                computer_science: "computer_science";
                engineering: "engineering";
                humanities: "humanities";
                social_science: "social_science";
                arts: "arts";
                business: "business";
                health_medicine: "health_medicine";
                professional: "professional";
                general: "general";
            }>;
            modeClarification: z.ZodString;
            alternateInterpretations: z.ZodDefault<z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                whyNotChosen: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>;
        topicOverview: z.ZodString;
        whatYouWillLearn: z.ZodArray<z.ZodString>;
        majorAreas: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            description: z.ZodString;
            mapRole: z.ZodDefault<z.ZodEnum<{
                branch: "branch";
                leaf: "leaf";
            }>>;
            estimatedChildCount: z.ZodOptional<z.ZodNumber>;
            groupingAxis: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        modules: z.ZodOptional<z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            summary: z.ZodString;
            objective: z.ZodString;
            dependsOnPrevious: z.ZodString;
            plannedOutcomes: z.ZodArray<z.ZodString>;
            entryFoundationBriefs: z.ZodDefault<z.ZodArray<z.ZodObject<{
                ref: z.ZodString;
                title: z.ZodString;
                rationale: z.ZodString;
                criticality: z.ZodEnum<{
                    critical: "critical";
                    recommended: "recommended";
                }>;
                verificationDimensions: z.ZodArray<z.ZodEnum<{
                    memory: "memory";
                    understanding: "understanding";
                    application: "application";
                }>>;
            }, z.core.$strip>>>;
            exitCapabilityBriefs: z.ZodArray<z.ZodString>;
            estimatedUnitCount: z.ZodNumber;
            unitPlanningBrief: z.ZodDefault<z.ZodObject<{
                scopeSize: z.ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                    large: "large";
                }>;
                rationale: z.ZodString;
                progression: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
        }, z.core.$strip>>>;
        mapStructure: z.ZodObject<{
            recommendedDepth: z.ZodNumber;
            estimatedLeafUnits: z.ZodNumber;
            layeringStrategy: z.ZodString;
            nestingRationale: z.ZodString;
        }, z.core.$strip>;
        outOfScope: z.ZodDefault<z.ZodArray<z.ZodString>>;
        prerequisitesAssumed: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>>;
    parseProviderOutput: (content: string) => {
        schemaVersion: 1 | 2;
        domainAnalysis: {
            field: string;
            subdomain: string;
            learningMode: "skill_practice" | "conceptual_understanding" | "research_scholarship" | "professional_applied" | "creative_expression" | "mixed";
            domainTag: "humanities" | "general" | "stem";
            topicCategory: "music" | "language" | "mathematics" | "natural_science" | "computer_science" | "engineering" | "humanities" | "social_science" | "arts" | "business" | "health_medicine" | "professional" | "general";
            modeClarification: string;
            alternateInterpretations: {
                label: string;
                whyNotChosen: string;
            }[];
        };
        topicOverview: string;
        whatYouWillLearn: string[];
        majorAreas: {
            title: string;
            description: string;
            mapRole: "branch" | "leaf";
            estimatedChildCount?: number;
            groupingAxis?: string;
        }[];
        mapStructure: {
            recommendedDepth: number;
            estimatedLeafUnits: number;
            layeringStrategy: string;
            nestingRationale: string;
        };
        outOfScope: string[];
        prerequisitesAssumed: string[];
        refinedTitle?: string;
        modules?: {
            title: string;
            summary: string;
            objective: string;
            dependsOnPrevious: string;
            plannedOutcomes: string[];
            entryFoundationBriefs: {
                ref: string;
                title: string;
                rationale: string;
                criticality: "critical" | "recommended";
                verificationDimensions: ("memory" | "understanding" | "application")[];
            }[];
            exitCapabilityBriefs: string[];
            estimatedUnitCount: number;
            unitPlanningBrief: {
                scopeSize: "standard" | "compact" | "large";
                rationale: string;
                progression: string[];
            };
        }[];
    };
};
export declare function prepareGoalCurriculumJourneyAuthoring(input: PrepareGoalCurriculumPlanAuthoringInput & {
    identity: GoalCurriculumIdentity;
}): {
    prompt: string;
    standalonePrompt: string;
    bindingSchema: z.ZodObject<{
        modules: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            summary: z.ZodString;
            objective: z.ZodString;
            dependsOnPrevious: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    schemaShape: string;
    recoveryPolicy: {
        sourceSchema: z.ZodUnknown;
        normalize: (candidate: unknown) => {
            value: unknown;
            normalizedCount: number;
            droppedCount: number;
        };
        repairSlots: ({ candidate, error, }: {
            candidate: unknown;
            error: z.ZodError;
        }) => ObjectRepairSlot[];
    };
    parseResult: (candidate: unknown) => {
        modules: {
            title: string;
            summary: string;
            objective: string;
            dependsOnPrevious: string;
        }[];
    };
    operation: "goal.curriculum.plan" | "goal.curriculum.replan" | "goal.curriculum.plan.deep_blueprint" | "goal.curriculum.plan.deep_draft" | "goal.curriculum.plan.deep_synthesis";
    contextInvocation: {
        title: string;
        level: string;
        context: string;
        pathSource: "search" | "rag" | "generic";
        contentLanguage: "zh-Hans" | "zh-Hant" | "en" | "ja" | "ko" | "es" | "fr" | "de" | "other";
        generationOptions: string;
        teachingSkillBlock: string;
    };
    schema: z.ZodPreprocess<z.ZodObject<{
        schemaVersion: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>>;
        refinedTitle: z.ZodOptional<z.ZodString>;
        domainAnalysis: z.ZodObject<{
            field: z.ZodString;
            subdomain: z.ZodString;
            learningMode: z.ZodEnum<{
                skill_practice: "skill_practice";
                conceptual_understanding: "conceptual_understanding";
                research_scholarship: "research_scholarship";
                professional_applied: "professional_applied";
                creative_expression: "creative_expression";
                mixed: "mixed";
            }>;
            domainTag: z.ZodEnum<{
                humanities: "humanities";
                general: "general";
                stem: "stem";
            }>;
            topicCategory: z.ZodEnum<{
                music: "music";
                language: "language";
                mathematics: "mathematics";
                natural_science: "natural_science";
                computer_science: "computer_science";
                engineering: "engineering";
                humanities: "humanities";
                social_science: "social_science";
                arts: "arts";
                business: "business";
                health_medicine: "health_medicine";
                professional: "professional";
                general: "general";
            }>;
            modeClarification: z.ZodString;
            alternateInterpretations: z.ZodDefault<z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                whyNotChosen: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>;
        topicOverview: z.ZodString;
        whatYouWillLearn: z.ZodArray<z.ZodString>;
        majorAreas: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            description: z.ZodString;
            mapRole: z.ZodDefault<z.ZodEnum<{
                branch: "branch";
                leaf: "leaf";
            }>>;
            estimatedChildCount: z.ZodOptional<z.ZodNumber>;
            groupingAxis: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        modules: z.ZodOptional<z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            summary: z.ZodString;
            objective: z.ZodString;
            dependsOnPrevious: z.ZodString;
            plannedOutcomes: z.ZodArray<z.ZodString>;
            entryFoundationBriefs: z.ZodDefault<z.ZodArray<z.ZodObject<{
                ref: z.ZodString;
                title: z.ZodString;
                rationale: z.ZodString;
                criticality: z.ZodEnum<{
                    critical: "critical";
                    recommended: "recommended";
                }>;
                verificationDimensions: z.ZodArray<z.ZodEnum<{
                    memory: "memory";
                    understanding: "understanding";
                    application: "application";
                }>>;
            }, z.core.$strip>>>;
            exitCapabilityBriefs: z.ZodArray<z.ZodString>;
            estimatedUnitCount: z.ZodNumber;
            unitPlanningBrief: z.ZodDefault<z.ZodObject<{
                scopeSize: z.ZodEnum<{
                    standard: "standard";
                    compact: "compact";
                    large: "large";
                }>;
                rationale: z.ZodString;
                progression: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>;
        }, z.core.$strip>>>;
        mapStructure: z.ZodObject<{
            recommendedDepth: z.ZodNumber;
            estimatedLeafUnits: z.ZodNumber;
            layeringStrategy: z.ZodString;
            nestingRationale: z.ZodString;
        }, z.core.$strip>;
        outOfScope: z.ZodDefault<z.ZodArray<z.ZodString>>;
        prerequisitesAssumed: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>>;
    parseProviderOutput: (content: string) => {
        schemaVersion: 1 | 2;
        domainAnalysis: {
            field: string;
            subdomain: string;
            learningMode: "skill_practice" | "conceptual_understanding" | "research_scholarship" | "professional_applied" | "creative_expression" | "mixed";
            domainTag: "humanities" | "general" | "stem";
            topicCategory: "music" | "language" | "mathematics" | "natural_science" | "computer_science" | "engineering" | "humanities" | "social_science" | "arts" | "business" | "health_medicine" | "professional" | "general";
            modeClarification: string;
            alternateInterpretations: {
                label: string;
                whyNotChosen: string;
            }[];
        };
        topicOverview: string;
        whatYouWillLearn: string[];
        majorAreas: {
            title: string;
            description: string;
            mapRole: "branch" | "leaf";
            estimatedChildCount?: number;
            groupingAxis?: string;
        }[];
        mapStructure: {
            recommendedDepth: number;
            estimatedLeafUnits: number;
            layeringStrategy: string;
            nestingRationale: string;
        };
        outOfScope: string[];
        prerequisitesAssumed: string[];
        refinedTitle?: string;
        modules?: {
            title: string;
            summary: string;
            objective: string;
            dependsOnPrevious: string;
            plannedOutcomes: string[];
            entryFoundationBriefs: {
                ref: string;
                title: string;
                rationale: string;
                criticality: "critical" | "recommended";
                verificationDimensions: ("memory" | "understanding" | "application")[];
            }[];
            exitCapabilityBriefs: string[];
            estimatedUnitCount: number;
            unitPlanningBrief: {
                scopeSize: "standard" | "compact" | "large";
                rationale: string;
                progression: string[];
            };
        }[];
    };
};
export declare function createCurriculumPlanningCapability(): import("../types.js").LearningSystemCapability;
export declare function planGoalMapStream(params: {
    title: string;
    level: string;
    context?: string;
    pathSource: "rag" | "search" | "generic";
    contentLanguage: ContentLanguageCode;
    generationOptions?: string;
    teachingSkillBlock?: string;
    onToken?: StreamTokenHandler;
    signal?: AbortSignal;
    operation?: "goal.curriculum.plan" | "goal.curriculum.replan" | "goal.curriculum.plan.deep_blueprint" | "goal.curriculum.plan.deep_draft" | "goal.curriculum.plan.deep_synthesis";
    authoringAgent?: {
        userId: string;
        goalId: string;
    };
    onIdentity?: (identity: GoalCurriculumIdentity) => void | Promise<void>;
    wrapIdentity?: <T>(run: () => Promise<T>) => Promise<T>;
    wrapJourney?: <T>(run: () => Promise<T>) => Promise<T>;
}): Promise<GoalMapPlan>;
export declare function planGoalMapFromCurrentMapStream(params: {
    title: string;
    level: string;
    currentMap: string;
    context?: string;
    pathSource: "rag" | "search" | "generic";
    contentLanguage: ContentLanguageCode;
    generationOptions?: string;
    teachingSkillBlock?: string;
    onToken?: StreamTokenHandler;
    signal?: AbortSignal;
}): Promise<GoalMapPlan>;
export declare function planGoalMap(params: {
    title: string;
    level: string;
    context?: string;
    pathSource: "rag" | "search" | "generic";
    contentLanguage: ContentLanguageCode;
    generationOptions?: string;
}): Promise<GoalMapPlan>;
