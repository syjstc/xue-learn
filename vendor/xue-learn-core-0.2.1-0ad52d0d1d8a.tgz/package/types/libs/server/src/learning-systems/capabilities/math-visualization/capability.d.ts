export declare const MATH_VISUALIZATION_CAPABILITY_ID: "math-visualization";
export declare const MATH_VISUALIZATION_CAPABILITY_VERSION: "1.0.0";
export declare const MATH_VISUALIZATION_TOOL_SET: "math.visualization";
export declare function createMathVisualizationCapability(): import("../../types.js").LearningSystemCapability;
