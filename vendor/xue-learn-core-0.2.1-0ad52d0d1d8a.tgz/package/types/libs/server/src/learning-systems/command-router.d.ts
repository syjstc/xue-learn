import { LearningSystemRegistry } from "./registry.js";
import type { SystemCommand, SystemCommandResult, TransactionContext } from "./types.js";
export declare class SystemCommandRoutingError extends Error {
    constructor(message: string);
}
/**
 * Routes typed intent to the single registered owner. The router never derives
 * capability state and deliberately exposes no untyped repository access.
 */
export declare class SystemCommandRouter {
    private readonly registry;
    constructor(registry: LearningSystemRegistry);
    execute(command: SystemCommand, transaction?: TransactionContext): Promise<SystemCommandResult>;
}
