export declare const SVG_VISUALIZATION_CAPABILITY_ID: "svg-visualization";
export declare const SVG_VISUALIZATION_CAPABILITY_VERSION: "1.0.0";
export declare const SVG_VISUALIZATION_TOOL_SET: "svg.visualization";
export declare function createSvgVisualizationCapability(): import("../../types.js").LearningSystemCapability;
