import type { LearningSystemActivationRequest, LearningSystemActivationResolver, LearningSystemSubjectResolver, LearningSystemViewRequirementRequest } from "./activation.js";
import type { LearningSystemSubject } from "./types.js";
import type { LearningSystemPersistenceClient } from "./persistence-client.js";
type GoalPolicyRow = {
    id: string;
    userId: string | null;
    goalKind: string;
    learningMode: string;
};
export type LearningSystemActivationStore = Pick<LearningSystemPersistenceClient, "learningSystemAvailability" | "goalLearningSystemBinding" | "learningGoal" | "learningUnit" | "learningModule">;
export declare class LearningSystemSubjectAuthorizationError extends Error {
    constructor(message?: string);
}
export declare function goalRequiresKacom(goal: GoalPolicyRow | null): boolean;
/**
 * Hydrates trusted internal goal/unit jobs with their learner owner. If a
 * caller already supplies an authenticated learner, ownership is included in
 * the lookup itself so foreign goal existence and policy cannot be observed.
 */
export declare class DatabaseLearningSystemSubjectResolver implements LearningSystemSubjectResolver {
    private readonly store;
    constructor(store: LearningSystemActivationStore);
    resolve(subject: LearningSystemSubject): Promise<LearningSystemSubject>;
}
/**
 * Resolves product policy before optional bindings. Every goal/binding lookup
 * includes the authenticated owner, so another learner's goal cannot disclose
 * its mode, binding, or even whether a capability is enabled for it.
 */
export declare class DatabaseLearningSystemActivationResolver implements LearningSystemActivationResolver {
    private readonly store;
    constructor(store: LearningSystemActivationStore);
    isActive({ capability, subject, }: LearningSystemActivationRequest): Promise<boolean>;
    isViewRequired({ capability, subject, profile, }: LearningSystemViewRequirementRequest): Promise<boolean>;
}
export {};
