import { type GuidedImageAsset, type GuidedImageRegion } from "../../../../../../domain/src/guided-image.js";
export declare function imageSha256(data: Buffer): string;
export declare function normalizeGuidedImage(data: Buffer): Promise<{
    data: Buffer<ArrayBufferLike>;
    width: number;
    height: number;
    sha256: string;
}>;
/** The model supplies outlines; libvips rasterizes and applies them. This is
 * alpha compositing, not a handwritten segmentation/matting algorithm. */
export declare function cutGuidedImageRegion(data: Buffer, image: GuidedImageAsset, region: GuidedImageRegion): Promise<Buffer<ArrayBufferLike>>;
