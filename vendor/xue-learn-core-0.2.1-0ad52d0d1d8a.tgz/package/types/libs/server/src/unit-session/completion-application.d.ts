export type UnitCompletionQuality = "strong" | "adequate" | "needs_reinforcement";
export type UnitCompletionStatus = "completed" | "completed_needs_reinforcement";
export type UnitCompletionTransition = Readonly<{
    completionMethod: "learned";
    completionQuality: UnitCompletionQuality;
    status: UnitCompletionStatus;
    completedAt: Date;
}>;
export type UnitCompletionRollup = Readonly<{
    moduleCompleted: boolean;
    goalCompleted: boolean;
}>;
export type UnitCompletionCommitResult<TNextReviewAt = Date> = Readonly<{
    transitioned: boolean;
    status: UnitCompletionStatus;
    completionQuality: UnitCompletionQuality;
    nextReviewAt: TNextReviewAt | null;
    rollup: UnitCompletionRollup;
}>;
export type UnitCompletionPersistencePort<TNextReviewAt = Date> = Readonly<{
    /**
     * Atomically commits the unit/session transition and module/goal rollup.
     * Repeated calls must return the canonical stored outcome without demoting or
     * re-timestamping an already completed unit.
     */
    commitAndRollup(input: {
        userId: string;
        unitId: string;
        transition: UnitCompletionTransition;
        idempotencyKey: string;
    }): Promise<UnitCompletionCommitResult<TNextReviewAt>>;
}>;
export type UnitCompletionReviewPort = Readonly<{
    /** Must be idempotent for the supplied key so a retry can repair a crash gap. */
    ensureScheduled(input: {
        userId: string;
        unitId: string;
        idempotencyKey: string;
    }): Promise<void>;
}>;
export type UnitCompletionAgendaPort = Readonly<{
    /** Must be idempotent for the supplied key so a retry can repair a crash gap. */
    applyCompletion(input: {
        userId: string;
        unitId: string;
        idempotencyKey: string;
    }): Promise<void>;
}>;
export type UnitCompletionApplicationPort<TNextReviewAt = Date> = Readonly<{
    persistence: UnitCompletionPersistencePort<TNextReviewAt>;
    reviews: UnitCompletionReviewPort;
    agenda: UnitCompletionAgendaPort;
}>;
export declare function planUnitCompletion(input: {
    score: number;
    feynmanPassed: boolean;
    completedAt?: Date;
}): UnitCompletionTransition;
/**
 * Portable completion orchestration. Storage adapters own their atomic unit +
 * hierarchy transaction. Review and agenda adapters are independently
 * idempotent and run on every invocation, allowing a retry to heal a process
 * crash after the primary commit.
 */
export declare function completeUnitLearning<TNextReviewAt = Date>(port: UnitCompletionApplicationPort<TNextReviewAt>, input: {
    userId: string;
    unitId: string;
    score: number;
    feynmanPassed: boolean;
    completedAt?: Date;
}): Promise<UnitCompletionCommitResult<TNextReviewAt>>;
