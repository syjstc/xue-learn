export type MaterialReadingGate = {
    requiredSectionIds: string[];
    completedSectionIds: string[];
    hasMaterial: boolean;
    missingCheckIds: string[];
    scenarioTheaterOffered: boolean;
};
export type UnitSessionApplicationPort = {
    loadMaterialReadingGate(input: {
        userId: string;
        unitId: string;
    }): Promise<MaterialReadingGate>;
    setStructuredSubStep(input: {
        userId: string;
        unitId: string;
        structuredSubStep: "questions";
    }): Promise<void>;
};
export type SessionSectionStatus = "available" | "in_progress" | "completed" | "skipped";
export type SessionSectionProjection = {
    id: string;
    status: SessionSectionStatus;
};
/**
 * Stable, persistence-independent fields shared by GET /session adapters.
 *
 * Hosted PostgreSQL and desktop-local SQLite intentionally keep their
 * database-specific envelopes (quiz attempts, persona context, memory
 * palace, etc.) outside this projection.  The learner shell only needs this
 * deterministic progression spine to render the same navigation state.
 */
export type UnitSessionProgressProjection<TSection extends SessionSectionProjection = SessionSectionProjection> = {
    currentStep: string;
    structuredSubStep: string;
    unitStatus: string;
    isLearningDone: boolean;
    contentRevision: number;
    sections: TSection[];
    currentSectionId: string | null;
};
export declare function projectUnitSessionProgress<TSection extends SessionSectionProjection>(input: {
    currentStep: string;
    structuredSubStep: string;
    unitStatus: string;
    isLearningDone: boolean;
    contentRevision: number;
    sections: readonly TSection[];
}): UnitSessionProgressProjection<TSection>;
/**
 * Normalize the optional `revision` query used by both unit content routes.
 * Invalid/empty query values retain the hosted controller's compatibility
 * behavior: they mean "read the latest" rather than inventing a revision.
 */
export declare function normalizeUnitContentRevision(value: unknown): number | undefined;
/**
 * Database-independent revision guard shared by hosted PostgreSQL and local
 * SQLite content adapters.  HTTP adapters keep ownership of localized error
 * messages and status codes; this helper only answers the authoritative
 * version question.
 */
export declare function unitContentRevisionMatches(input: {
    requestedRevision?: number;
    contentRevision: number;
}): boolean;
/** Resolve the current navigation step used by the shared unit page. */
export declare function resolveUnitPageCurrentStep(input: {
    unitStatus: string;
    persistedCurrentStep?: unknown;
}): string;
export type UnitSessionStreamCommand = {
    action: string;
    payload: Record<string, unknown>;
    runId?: string;
};
/**
 * Normalize the transport envelope shared by hosted and local session SSE.
 * Capability-specific action allowlists remain in each adapter; this helper
 * only makes malformed/legacy envelopes deterministic and keeps top-level
 * payload compatibility identical across transports.
 */
export declare function normalizeUnitSessionStreamCommand(body: Record<string, unknown>): UnitSessionStreamCommand;
export type UnitSessionLearningAccess = {
    modelPhase: "pending" | "building" | "targets_ready" | "ready" | "failed" | "stale";
    contentMode: "none" | "draft" | "canonical";
    assessmentMode: "locked" | "ready";
    lockReason?: "model_building" | "model_failed" | "model_stale";
    activeRunId?: string;
    inputHash?: string;
    prefixHash?: string;
};
/** Keep reconnectable stream access events tied to the durable generation run. */
export declare function withUnitSessionActiveRun(access: UnitSessionLearningAccess, runId?: string): UnitSessionLearningAccess;
export type SessionTouchPayload = {
    tab?: string;
    slideIndex?: number;
    hasCompletedSlides?: boolean;
    sectionSteps?: Record<string, number>;
    activeSeconds?: number;
    sectionId?: string;
    sectionContentRevision?: number;
    sectionCursor?: number;
    timeFlush?: boolean;
};
export type SectionMiniTestAnswer = number | number[] | boolean;
export type SectionMiniTestAnswers = Record<string, SectionMiniTestAnswer>;
export type UnitSessionProgressionPort<TSession = unknown, TSection extends SessionSectionProjection = SessionSectionProjection, TMiniTestResult = unknown> = {
    openSession(input: {
        userId: string;
        unitId: string;
    }): Promise<TSession>;
    touchActivity(input: {
        userId: string;
        unitId: string;
        payload: SessionTouchPayload;
    }): Promise<{
        totalActiveSeconds: number;
        acceptedActiveSeconds: number;
    }>;
    completeSection(input: {
        userId: string;
        unitId: string;
        sectionId: string;
        skip: boolean;
    }): Promise<void>;
    listSections(input: {
        userId: string;
        unitId: string;
    }): Promise<TSection[]>;
    setStep(input: {
        userId: string;
        unitId: string;
        step: string;
        structuredSubStep?: "done";
    }): Promise<void>;
    submitSectionMiniTest(input: {
        userId: string;
        unitId: string;
        sectionId: string;
        answers: SectionMiniTestAnswers;
    }): Promise<TMiniTestResult>;
};
export type UnitSessionProgressionErrorCode = "section_id_required" | "unit_learning_required" | "invalid_step" | "feynman_unavailable" | "section_quiz_invalid" | "section_quiz_answers_only" | "all_answers_required" | "invalid_answer_format";
export type FeynmanEligibility = "available" | "feature_disabled" | "exploration_unsupported";
/**
 * Shared policy boundary for the optional Feynman evidence step.  Hosted and
 * local adapters map their own goal-kind enums into the boolean input, while
 * this function keeps feature gating and exploration exclusion identical.
 */
export declare function feynmanEligibility(input: {
    featureEnabled: boolean;
    exploration: boolean;
}): FeynmanEligibility;
export declare class UnitSessionProgressionError extends Error {
    readonly code: UnitSessionProgressionErrorCode;
    constructor(code: UnitSessionProgressionErrorCode);
}
export type UnitSessionProgressionCommand = {
    action: "open";
} | {
    action: "touch_activity";
    payload?: Record<string, unknown>;
} | {
    action: "complete_section" | "skip_section";
    payload?: Record<string, unknown>;
} | {
    action: "set_step";
    payload?: Record<string, unknown>;
    gate: {
        isLearningDone: boolean;
        feynmanEnabled?: boolean;
    };
} | {
    action: "submit_section_mini_test";
    payload?: Record<string, unknown>;
};
export declare function openUnitSession<TSession>(port: Pick<UnitSessionProgressionPort<TSession>, "openSession">, input: {
    userId: string;
    unitId: string;
}): Promise<TSession>;
export declare function normalizeSessionTouchPayload(payload?: Record<string, unknown>): SessionTouchPayload;
export declare function parseSectionMiniTestSubmission(payload?: Record<string, unknown>): {
    sectionId: string;
    answers: SectionMiniTestAnswers;
};
/**
 * Portable dispatcher for deterministic, already-authored unit-session
 * progression. Authoring/generation remains outside this boundary; database
 * adapters own persistence while this function owns payload and transition
 * semantics.
 */
export declare function dispatchUnitSessionProgressionCommand<TSession, TSection extends SessionSectionProjection, TMiniTestResult>(port: UnitSessionProgressionPort<TSession, TSection, TMiniTestResult>, input: {
    userId: string;
    unitId: string;
}, command: UnitSessionProgressionCommand): Promise<TSession | {
    ok: true;
    totalActiveSeconds: number;
    acceptedActiveSeconds: number;
} | {
    sections: TSection[];
    currentSectionId: string | null;
} | {
    currentStep: string;
} | TMiniTestResult>;
export type MaterialReadingConflict = "unit_sections_required" | "material_required" | "material_checks_required";
export declare class MaterialReadingTransitionError extends Error {
    readonly code: MaterialReadingConflict;
    readonly details: {
        missingCheckIds?: string[];
    };
    constructor(code: MaterialReadingConflict, details?: {
        missingCheckIds?: string[];
    });
}
export type UnitSessionAssessmentGateOptions = {
    /**
     * Standalone micro/exploration lessons do not use the hosted sequential
     * section-completion gate.  Callers still pass the same facts so the
     * material/check policy remains shared.
     */
    requireSections?: boolean;
    requireMaterial?: boolean;
    requireChecks?: boolean;
};
/**
 * Validate the material-readiness facts required before an assessment can
 * start.  The hosted session POST and the local SQLite compatibility
 * controller both gather these facts from their database adapter; this
 * function owns the order and conflict codes so a different database cannot
 * accidentally make active recall available early.
 *
 * A nullable error is returned instead of throwing so HTTP adapters can keep
 * their existing localized status/message mapping.  `finishMaterialReading`
 * below throws the same error directly for its transition boundary.
 */
export declare function validateUnitSessionAssessmentGate(gate: Pick<MaterialReadingGate, "requiredSectionIds" | "completedSectionIds" | "hasMaterial" | "missingCheckIds">, options?: UnitSessionAssessmentGateOptions): MaterialReadingTransitionError | null;
export declare function assertUnitSessionAssessmentReady(gate: Pick<MaterialReadingGate, "requiredSectionIds" | "completedSectionIds" | "hasMaterial" | "missingCheckIds">, options?: UnitSessionAssessmentGateOptions): void;
/**
 * Authoritative transition from lesson material to the guiding-question phase.
 * Persistence adapters supply facts and commit the state change; both hosted
 * PostgreSQL and desktop-local SQLite must execute this same rule.
 */
export declare function finishMaterialReading(port: UnitSessionApplicationPort, input: {
    userId: string;
    unitId: string;
}): Promise<{
    structuredSubStep: "questions";
    scenarioTheaterOffered: boolean;
}>;
