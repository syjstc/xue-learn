import type { LlmMessageRecord } from "../agents/core/types.js";
import type { FormalDerivationRunEventV1 } from "../../../formal-derivation/src/index.js";
export type RunFormalDerivationAgentParams = {
    runId: string;
    userId: string;
    title: string;
    locale: string;
    requirementText: string;
    assumptions?: string[];
    target?: string;
    traceId: string;
    signal?: AbortSignal;
    send: (event: FormalDerivationRunEventV1) => Promise<void>;
    operation?: string;
    toolSet?: string;
    invocationPrompt?: string;
    finishToolName?: string;
    missingFinishMessage?: string;
    platformFunded?: boolean;
};
export declare const MAX_REPEATED_DERIVATION_TOOL_ERRORS = 5;
export declare function shouldCountRepeatedDerivationToolError(toolName: string, result: unknown): boolean;
export declare function shouldAbortInvalidDerivationToolSchema(attempts: number, limit?: number): boolean;
/** Keep the invocation in the user turn; the prepared system prompt is context/policy only. */
export declare function buildFormalDerivationInitialMessages(systemPrompt: string, invocationPrompt: string): LlmMessageRecord[];
export declare function runFormalDerivationAgent(params: RunFormalDerivationAgentParams): Promise<void>;
