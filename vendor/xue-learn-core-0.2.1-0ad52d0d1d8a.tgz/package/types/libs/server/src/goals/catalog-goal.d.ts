/** Heuristic: goal title implies an itemized catalog (numbered anthology, word list, etc.). */
export declare function isItemizedCatalogGoal(title: string): boolean;
export declare function catalogSearchQuery(title: string): string;
