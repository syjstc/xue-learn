export type ContinueLearningUnit = {
    id: string;
    title: string;
    status: string;
};
type UnitCandidate = ContinueLearningUnit & {
    unitKind: string;
    parentUnitId: string | null;
    orderIndex: number;
};
/** Picks the exact lesson the home-page continue action should open. */
export declare function resolveContinueLearningUnit(units: UnitCandidate[], lastLearnedUnitId?: string | null): ContinueLearningUnit | null;
export {};
