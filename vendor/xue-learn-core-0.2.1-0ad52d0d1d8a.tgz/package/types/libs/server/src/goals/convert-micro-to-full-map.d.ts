import type { StreamTokenHandler } from "../llm/chat-stream.js";
import type { MapDslPartial } from "../llm/map-dsl.js";
import type { CognitiveModelInvalidationRepository, LearningGoalPlanRepository, LegacyMapReplacementRepository, OwnedMicroGoalConversionContext } from "../../../domain/src/index.js";
export type ExpandMicroGoalProgress = (message: string) => void;
export type ExpandMicroGoalStreamOptions = {
    onToken?: StreamTokenHandler;
    onPartialMap?: (partial: MapDslPartial) => void | Promise<void>;
    signal?: AbortSignal;
};
export type ExpandMicroGoalToFullMapResult = {
    unitCount: number;
    children: {
        id: string;
        title: string;
    }[];
};
export declare function buildMicroConvertMapHint(params: {
    lessonTitle: string;
    lessonSummary: string;
}): string;
/** Replace a micro goal with a full top-level learning map for the broadened topic. */
export declare function expandMicroGoalToFullMap(source: OwnedMicroGoalConversionContext, params: {
    broadenedTitle: string;
    topicOverview?: string | null;
    adjustment?: string;
    cognitiveModelInvalidation: CognitiveModelInvalidationRepository;
    learningGoalPlan: LearningGoalPlanRepository;
    legacyMapReplacement: LegacyMapReplacementRepository;
    onProgress?: ExpandMicroGoalProgress;
    streamOptions?: ExpandMicroGoalStreamOptions;
}): Promise<ExpandMicroGoalToFullMapResult>;
