import type { AgentRunContext } from "../agents/core/types.js";
import type { MicroUnitPublicationRepository } from "../../../domain/src/index.js";
export type CreateMicroUnitResult = {
    goalId: string;
    unitId: string;
    isOverview: boolean;
};
export declare function createMicroUnitForGoal(userId: string, goalId: string, ctx: Pick<AgentRunContext, "send" | "signal">, options?: {
    hasDocuments?: boolean;
    autoSurvey?: boolean;
    autoContent?: boolean;
    microUnitPublication?: MicroUnitPublicationRepository;
}): Promise<CreateMicroUnitResult>;
