import type { AgentRunContext } from "../agents/core/types.js";
import type { MicroUnitPublicationRepository } from "../../../domain/src/index.js";
import type { LearningSpaceGoalCreationApplication } from "../learning-spaces/orm-application-service.js";
export type CreateMicroCourseFromTopicResult = {
    goalId: string;
    unitId: string;
    title: string;
    isOverview: boolean;
    navigateTo: string;
};
export declare function createMicroCourseFromTopic(userId: string, topic: string, ctx: Pick<AgentRunContext, "send" | "signal" | "threadId" | "traceId">, options?: {
    contentLanguage?: string;
    learningSpaceApplication?: LearningSpaceGoalCreationApplication;
    microUnitPublication?: MicroUnitPublicationRepository;
}): Promise<CreateMicroCourseFromTopicResult>;
