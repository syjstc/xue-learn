import type { RequestMetricsRepository } from "../../../domain/src/index.js";
import { type RequestMetricsSnapshot } from "./request-metrics.js";
import { type SystemMetricsSnapshot } from "./system-metrics.js";
export type AlertSeverity = "warning" | "critical";
export type PerformanceAlert = {
    id: string;
    severity: AlertSeverity;
    title: string;
    message: string;
    value: number;
    threshold: number;
};
export type MonitoringSnapshot = {
    system: SystemMetricsSnapshot;
    requests: RequestMetricsSnapshot;
    alerts: PerformanceAlert[];
};
export type AlertCheckResult = {
    snapshot: MonitoringSnapshot;
    fired: PerformanceAlert[];
    skippedCooldown: string[];
    webhookDelivered: boolean;
};
export declare function resetAlertCooldownState(): void;
export declare function evaluatePerformanceAlerts(input: {
    system: SystemMetricsSnapshot;
    requests: RequestMetricsSnapshot;
}): PerformanceAlert[];
export declare function collectMonitoringSnapshot(repository?: RequestMetricsRepository): Promise<MonitoringSnapshot>;
export declare function deliverAlertWebhook(alerts: PerformanceAlert[], snapshot: MonitoringSnapshot): Promise<boolean>;
export declare function runPerformanceAlertCheck(repository?: RequestMetricsRepository): Promise<AlertCheckResult>;
