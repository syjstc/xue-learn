import type { ObservabilityRepository } from "../../../domain/src/index.js";
import type { BackendErrorSource } from "./backend-error-log.js";
export type BackendErrorStatusFilter = number | "5xx";
export type BackendErrorListParams = {
    limit?: number;
    cursor?: string;
    hours?: number;
    source?: BackendErrorSource;
    service?: string;
    status?: BackendErrorStatusFilter;
    search?: string;
};
export declare function queryBackendErrorGroups(params?: BackendErrorListParams, repository?: ObservabilityRepository): Promise<{
    items: import("../../../domain/src/index.js").BackendErrorGroupRecord[];
    nextCursor: string;
    windowHours: number;
}>;
export declare function queryBackendErrorGroupDetail(id: string, repository?: ObservabilityRepository): Promise<{
    group: import("../../../domain/src/index.js").BackendErrorGroupRecord;
    recentApiOccurrences: import("../../../domain/src/index.js").ApiErrorOccurrenceRecord[];
}>;
