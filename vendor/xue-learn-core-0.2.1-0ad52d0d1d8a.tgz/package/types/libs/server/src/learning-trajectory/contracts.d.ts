import { z } from "zod";
export declare const learningPositionSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    unitId: z.ZodString;
    sectionId: z.ZodOptional<z.ZodString>;
    topicId: z.ZodOptional<z.ZodString>;
    topicTitle: z.ZodOptional<z.ZodString>;
    blockIdentity: z.ZodOptional<z.ZodString>;
    blockIndex: z.ZodOptional<z.ZodNumber>;
    contentRevision: z.ZodOptional<z.ZodNumber>;
    anchorText: z.ZodOptional<z.ZodString>;
    scrollOffset: z.ZodOptional<z.ZodNumber>;
    mode: z.ZodEnum<{
        classroom: "classroom";
        reading: "reading";
    }>;
    readingPage: z.ZodOptional<z.ZodObject<{
        renderer: z.ZodLiteral<"godot">;
        identity: z.ZodString;
    }, z.core.$strict>>;
    classroom: z.ZodOptional<z.ZodObject<{
        projectId: z.ZodString;
        sourceHash: z.ZodString;
        sceneId: z.ZodString;
        beatId: z.ZodOptional<z.ZodString>;
        tick: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const learningSupplementDraftSchema: z.ZodObject<{
    purpose: z.ZodEnum<{
        foundation: "foundation";
        clarification: "clarification";
        interest: "interest";
    }>;
    kind: z.ZodEnum<{
        section: "section";
        topic: "topic";
    }>;
    title: z.ZodString;
    reason: z.ZodString;
    returnGoal: z.ZodString;
    topics: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export type LearningSupplementDraft = z.infer<typeof learningSupplementDraftSchema>;
export type LearningGuidanceTurn = {
    userId: string;
    unitId: string;
    threadId?: string;
    eventId: string;
    position: import("../../../domain/src/index.js").LearningPosition;
    activeVisitId?: string;
    sourceText: string;
    performedAction?: boolean;
    responseOnly?: boolean;
};
