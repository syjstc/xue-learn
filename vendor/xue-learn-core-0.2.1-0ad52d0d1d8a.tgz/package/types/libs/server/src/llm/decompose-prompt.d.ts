import { type ContentLanguageCode } from "./content-language.js";
type DecomposeMapPlan = {
    majorAreas: Array<unknown>;
    mapStructure: {
        estimatedLeafUnits: number;
        recommendedDepth: number;
        layeringStrategy: string;
    };
    domainAnalysis: {
        domainTag: string;
    };
};
type DecomposeMapSummary = {
    topicOverview: string;
    assumptions: string[];
};
export declare const DECOMPOSE_SCHEMA_SHAPE = "{\n  \"domainTag\": \"stem\",\n  \"units\": [\n    {\n      \"title\": \"Unit title\",\n      \"contentSummary\": \"2-3 sentences on what the learner will study in this unit.\",\n      \"parentTitle\": \"Exact top-level parent title for a child, otherwise null\",\n      \"difficulty\": \"medium\",\n      \"prerequisiteTitles\": [],\n      \"scope\": \"session\"\n    }\n  ]\n}";
export declare function buildDecomposePrompt(params: {
    title: string;
    level: string;
    context?: string;
    pathSource: "rag" | "search" | "generic";
    contentLanguage: ContentLanguageCode;
    mapPlan?: DecomposeMapPlan;
    mapSummary?: DecomposeMapSummary;
    generationOptions?: string;
    rootsOnly?: boolean;
}): string;
export {};
