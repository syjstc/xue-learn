import { z } from "zod";
export declare const compactLearningMaterialBindingSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodUnknown>;
}, z.core.$strip>;
export declare function resolveCompactBindingSchema(operation: string): z.ZodType | undefined;
