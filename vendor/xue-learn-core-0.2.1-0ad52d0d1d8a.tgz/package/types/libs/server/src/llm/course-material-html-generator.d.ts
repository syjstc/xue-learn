import { type InteractiveBlock } from "./schemas.js";
import { type CourseSvgIntent } from "./course-svg-intent.js";
export declare function prepareCourseHtmlGeneration(params: {
    intent: CourseSvgIntent;
    unitTitle: string;
    language: string;
    context: string;
}): {
    operation: "unit.learning_material.html_generate";
    invocation: {
        unitTitle: string;
        language: string;
        context: string;
        intent: {
            visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
            setup: string;
            learningGoal: string;
            expectedInsight: string;
            composition?: string;
            elements?: string[];
            relationships?: string[];
            labels?: string[];
            avoid?: string[];
        };
    };
    prompt: string;
    standalonePrompt: string;
    bindingSchema: import("zod").ZodObject<{
        type: import("zod").ZodLiteral<"interactive_html">;
        title: import("zod").ZodString;
        summary: import("zod").ZodString;
        html: import("zod").ZodString;
        visualKind: import("zod").ZodOptional<import("zod").ZodEnum<{
            simple_structure: "simple_structure";
            spatial_relationship: "spatial_relationship";
            state_comparison: "state_comparison";
            step_derivation: "step_derivation";
        }>>;
        height: import("zod").ZodOptional<import("zod").ZodNumber>;
    }, import("zod/v4/core").$strip>;
    resultSchema: import("zod").ZodObject<{
        type: import("zod").ZodLiteral<"interactive_html">;
        title: import("zod").ZodString;
        summary: import("zod").ZodString;
        html: import("zod").ZodString;
        visualKind: import("zod").ZodOptional<import("zod").ZodEnum<{
            simple_structure: "simple_structure";
            spatial_relationship: "spatial_relationship";
            state_comparison: "state_comparison";
            step_derivation: "step_derivation";
        }>>;
        height: import("zod").ZodOptional<import("zod").ZodNumber>;
    }, import("zod/v4/core").$strip>;
    intentIssue: string;
    parseProviderOutput(content: string): {
        type: "interactive_html";
        title: string;
        summary: string;
        html: string;
        visualKind?: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
        height?: number;
    };
};
export declare function generateCourseInteractiveHtml(params: {
    intent: CourseSvgIntent;
    unitTitle: string;
    language: string;
    context: string;
    signal?: AbortSignal;
    meta?: Record<string, unknown>;
    onPartial?: (block: InteractiveBlock) => void | Promise<void>;
}): Promise<InteractiveBlock | null>;
