export declare const CURRICULUM_PLANNING_VIEW_KEYS: Readonly<{
    journeyInstructionContext: "instruction.goal.curriculum.plan.v1";
    detailInstructionContext: "instruction.goal.plan.detail.v1";
}>;
