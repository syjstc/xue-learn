import { z } from "zod";
export declare const COURSE_SVG_VISUAL_KINDS: readonly ["simple_structure", "spatial_relationship", "state_comparison", "step_derivation"];
export type CourseSvgVisualKind = (typeof COURSE_SVG_VISUAL_KINDS)[number];
export declare const STATIC_COURSE_SVG_VISUAL_KINDS: readonly ["simple_structure", "spatial_relationship", "state_comparison"];
export declare function isAnimatedCourseSvgVisualKind(visualKind: CourseSvgVisualKind): boolean;
export declare const courseSvgBriefItemSchema: z.ZodString;
export declare const courseSvgBriefListSchema: z.ZodArray<z.ZodString>;
export declare const courseSvgIntentSchema: z.ZodObject<{
    visualKind: z.ZodEnum<{
        simple_structure: "simple_structure";
        spatial_relationship: "spatial_relationship";
        state_comparison: "state_comparison";
        step_derivation: "step_derivation";
    }>;
    setup: z.ZodString;
    learningGoal: z.ZodString;
    expectedInsight: z.ZodString;
    composition: z.ZodOptional<z.ZodString>;
    elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
    relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
    labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
    avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
/** New material authoring must freeze a picture-level brief for stable redraws. */
export declare const courseSvgAuthoringIntentSchema: z.ZodObject<{
    visualKind: z.ZodEnum<{
        simple_structure: "simple_structure";
        spatial_relationship: "spatial_relationship";
        state_comparison: "state_comparison";
        step_derivation: "step_derivation";
    }>;
    setup: z.ZodString;
    learningGoal: z.ZodString;
    expectedInsight: z.ZodString;
    composition: z.ZodString;
    elements: z.ZodArray<z.ZodString>;
    relationships: z.ZodArray<z.ZodString>;
    labels: z.ZodArray<z.ZodString>;
    avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export type CourseSvgIntent = z.infer<typeof courseSvgIntentSchema>;
export declare const COURSE_SVG_SLOT_INTENT_CONTRACT = "{\"type\":\"svg_slot\",\"intent\":{\"visualKind\":\"simple_structure\",\"setup\":\"what this picture depicts\",\"learningGoal\":\"the precise concept it should explain\",\"expectedInsight\":\"what the learner should notice\",\"composition\":\"how the picture is arranged: reading order, what sits left/right/above/below/center, how groups are clustered, and arrow or flow direction\",\"elements\":[\"required shape or object and where it sits\"],\"relationships\":[\"how objects connect or compare, including direction\"],\"labels\":[\"short visible label and its placement\"],\"avoid\":[\"misconception or unsupported detail\"]}}";
/**
 * Stable, human-readable serialization shared by the material and SVG calls.
 * Keep this brief deterministic so providers can reuse the same prefix while
 * the SVG request remains focused on the slot's semantic requirements.
 */
export declare function formatCourseSvgIntent(intent: CourseSvgIntent): string;
/** Rebuild a compiler brief from a stored placeholder or formatted intent. */
export declare function parseCourseSvgIntentFromDescription(description: string, fallback: CourseSvgIntent): CourseSvgIntent;
/** Keep realistic and organic subjects out even if authoring misclassifies them. */
export declare function courseSvgIntentIssue(intent: CourseSvgIntent): string | null;
export declare function attachCourseSvgIntent<T extends {
    type: string;
}>(block: T | null, intent: CourseSvgIntent): (T & {
    intent?: CourseSvgIntent;
}) | null;
