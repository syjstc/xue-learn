import { type InteractiveBlock } from "./schemas.js";
import { type ContentLanguageCode } from "./content-language.js";
/**
 * Block types a single-block AI edit may target. Text blocks, markup diagrams,
 * and model-authored structured visuals are editable; server-owned assessment
 * (`check`), image assets (`illustration`), loading `placeholder`s, and the
 * deterministic sandbox engines are not.
 */
declare const AI_EDITABLE_BLOCK_TYPES: readonly ["heading", "paragraph", "code", "conversation", "callout", "accordion", "svg", "chart", "math_scene", "graph", "step_sort", "interactive_html"];
export type AiEditableBlockType = (typeof AI_EDITABLE_BLOCK_TYPES)[number];
export declare function isAiEditableBlockType(type: string): type is AiEditableBlockType;
/**
 * Edit one existing course-material block with the learner's routed chat
 * model. The edited block must validate against the authoritative block
 * schema AND keep the original block type; anything else fails closed.
 */
export declare function editCourseMaterialBlockWithAi(params: {
    unitTitle: string;
    language: ContentLanguageCode;
    instruction: string;
    block: InteractiveBlock;
    introduction?: string;
    surroundingBlocks?: InteractiveBlock[];
    meta?: Record<string, unknown>;
    signal?: AbortSignal;
    onPartial?: (block: InteractiveBlock) => void | Promise<void>;
}): Promise<InteractiveBlock | null>;
export {};
