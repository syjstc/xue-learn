import { ToolMessage } from "@langchain/core/messages";
import { z } from "zod";
import { type InteractiveBlock } from "./schemas.js";
import { type CourseSvgIntent } from "./course-svg-intent.js";
export { progressiveCourseSvgMarkup } from "../../../contracts/src/index.js";
export { normalizeGeneratedCourseSvg } from "./safe-svg.js";
export { COURSE_SVG_VISUAL_KINDS, STATIC_COURSE_SVG_VISUAL_KINDS, courseSvgIntentIssue, isAnimatedCourseSvgVisualKind, type CourseSvgIntent, type CourseSvgVisualKind, } from "./course-svg-intent.js";
/** Provider binding: one SVG markup string, not a JSON scene graph. */
export declare const courseSvgGenerationBindingSchema: z.ZodObject<{
    type: z.ZodLiteral<"svg">;
    title: z.ZodString;
    caption: z.ZodString;
    alt: z.ZodString;
    svg: z.ZodString;
}, z.core.$strip>;
export declare const courseSvgWireSchema: z.ZodObject<{
    type: z.ZodLiteral<"svg">;
    title: z.ZodOptional<z.ZodString>;
    caption: z.ZodString;
    alt: z.ZodString;
    svg: z.ZodString;
}, z.core.$strip>;
export declare const courseSvgBlockSchema: z.ZodObject<{
    type: z.ZodLiteral<"svg">;
    title: z.ZodString;
    caption: z.ZodString;
    alt: z.ZodString;
    svg: z.ZodString;
}, z.core.$strip>;
export declare const courseSvgEditSchema: z.ZodObject<{
    reviewSummary: z.ZodString;
    edits: z.ZodArray<z.ZodObject<{
        oldText: z.ZodString;
        newText: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare function applyCourseSvgEdits(current: CourseSvgBlock, input: z.infer<typeof courseSvgEditSchema>): CourseSvgBlock;
type CourseSvgBlock = z.infer<typeof courseSvgBlockSchema>;
/** Stable forced tool for generate + visual-audit repair (prefix-cache friendly). */
export declare const COURSE_SVG_TOOL_NAME = "emit_course_svg";
export declare const COURSE_SVG_EDIT_TOOL_NAME = "edit_course_svg";
/** Max emit/edit submissions before publishing the last diagram. */
export declare const COURSE_SVG_MAX_AUDIT_ROUNDS = 3;
/**
 * Default tool_choice for DeepSeek/MiniMax prefix-cache stability.
 * Doubao/OpenAI/Codex resolve to a named force via {@link resolveCourseSvgToolChoice}.
 */
export declare const COURSE_SVG_TOOL_CHOICE: "required";
export type CourseSvgToolChoice = typeof COURSE_SVG_TOOL_CHOICE | "auto" | {
    type: "function";
    function: {
        name: typeof COURSE_SVG_TOOL_NAME;
    };
};
/**
 * First emit uses a named force on Doubao/OpenAI/Codex. Repair rounds keep bare
 * `required` so the model may choose `edit_course_svg` or `emit_course_svg`.
 * Qwen thinking mode rejects both `required` and named function objects.
 */
export declare function resolveCourseSvgToolChoice(providerId?: string, options?: {
    allowEdit?: boolean;
    model?: string;
}): CourseSvgToolChoice;
/**
 * Doubao/OpenAI `function.strict` requires an OpenAI constrained-decoding
 * subset (`additionalProperties: false`, every property required). Sending the
 * raw projected schema with `strict: true` often yields content JSON instead of
 * a tool call — then the SVG round fails with "must call exactly one …".
 */
export declare function courseSvgToolParameters(providerId?: string): Record<string, unknown>;
export declare function buildCourseSvgToolDefinitions(options?: {
    providerId?: string;
    allowEdit?: boolean;
}): {
    type: "function";
    function: {
        name: string;
        description: string;
        parameters: Record<string, unknown>;
        strict: boolean;
    };
}[];
/** Recover when a provider returns the SVG object (or raw markup) in content. */
export declare function recoverCourseSvgToolCallFromText(text: string, intent: CourseSvgIntent): {
    id: string;
    name: typeof COURSE_SVG_TOOL_NAME;
    args: Record<string, unknown>;
} | null;
/** Append-only visual-audit rejection into the gen-model transcript. */
export declare function svgVisualAuditRepairContinuation(params: {
    toolCallId: string;
    reason: string;
}): ToolMessage;
export declare function progressiveCourseSvgBlock(candidate: unknown, intent: CourseSvgIntent): InteractiveBlock | null;
/** Provider-independent prepared contract shared by hosted and local adapters. */
export declare function prepareCourseSvgGeneration(params: {
    intent: CourseSvgIntent;
    unitTitle: string;
    language: string;
    context: string;
    revision?: {
        originalSvg: string;
        feedback: string;
    };
}): {
    operation: "unit.learning_material.svg_generate";
    invocation: {
        revision?: {
            originalSvg: string;
            feedback: string;
        };
        unitTitle: string;
        language: string;
        context: string;
        intent: {
            visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
            setup: string;
            learningGoal: string;
            expectedInsight: string;
            composition?: string;
            elements?: string[];
            relationships?: string[];
            labels?: string[];
            avoid?: string[];
        };
    };
    prompt: string;
    standalonePrompt: string;
    bindingSchema: z.ZodObject<{
        type: z.ZodLiteral<"svg">;
        title: z.ZodString;
        caption: z.ZodString;
        alt: z.ZodString;
        svg: z.ZodString;
    }, z.core.$strip>;
    resultSchema: z.ZodObject<{
        type: z.ZodLiteral<"svg">;
        title: z.ZodString;
        caption: z.ZodString;
        alt: z.ZodString;
        svg: z.ZodString;
    }, z.core.$strip>;
    intentIssue: string;
    parseProviderOutput(content: string): {
        type: "svg";
        title: string;
        caption: string;
        alt: string;
        svg: string;
    };
};
type CourseSvgGenerateParams = {
    intent: CourseSvgIntent;
    unitTitle: string;
    language: string;
    context: string;
    /** Cold standalone repair (no prior generate turn in this process). */
    revision?: {
        originalSvg: string;
        feedback: string;
    };
    signal?: AbortSignal;
    meta?: Record<string, unknown>;
    authoringScope?: {
        userId: string;
        goalId: string;
        unitId: string;
    };
    onPartial?: (block: InteractiveBlock) => void | Promise<void>;
};
export declare function courseSvgRepairRetryDirective(params: {
    validationError: string;
    currentSvg: string;
    forceFullEmit: boolean;
}): string;
export declare function generateCourseSvg(params: CourseSvgGenerateParams): Promise<InteractiveBlock | null>;
/** In-lesson diagrams compile to raw SVG markup. HTML playgrounds are lab-only. */
export declare function compileTeachingDiagram(params: CourseSvgGenerateParams): Promise<InteractiveBlock | null>;
