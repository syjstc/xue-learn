import type { TopicCategory } from "../../../common/src/index.js";
import { type ResolvedStructuredContract, type StructuredOutputLimits } from "./structured-contract.js";
import type { LearningSystemSubject } from "../learning-systems/types.js";
export type StreamTokenHandler = (delta: string) => void | Promise<void>;
export type StreamThinkingHandler = () => void | Promise<void>;
/** Stream chat tokens; returns full assembled text. */
export declare function streamChat(prompt: string, options: {
    operation: string;
    meta?: Record<string, unknown>;
    topicCategory?: TopicCategory | null;
    onToken?: StreamTokenHandler;
    onThinking?: StreamThinkingHandler;
    /** Internal streaming activity, without exposing hidden reasoning text. */
    onProgress?: () => void;
    signal?: AbortSignal;
    structuredContract?: ResolvedStructuredContract;
    outputLimits?: StructuredOutputLimits;
    outputMode?: string;
    contextSubject?: LearningSystemSubject;
    contextQuery?: string;
    contextInvocation?: unknown;
}): Promise<string>;
