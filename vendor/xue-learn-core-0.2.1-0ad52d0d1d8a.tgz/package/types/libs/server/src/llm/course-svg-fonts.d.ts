/**
 * resvg must not inherit the host's font set: a browser and the packaged
 * sidecar otherwise choose different CJK fallback glyphs and text metrics.
 */
export declare function resolveCourseSvgFontFiles(): string[];
