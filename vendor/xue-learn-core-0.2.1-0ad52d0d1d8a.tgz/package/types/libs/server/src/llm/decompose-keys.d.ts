export declare const GOAL_MAP_VIEW_KEYS: Readonly<{
    instructionContext: "instruction.goal.map.v1";
}>;
