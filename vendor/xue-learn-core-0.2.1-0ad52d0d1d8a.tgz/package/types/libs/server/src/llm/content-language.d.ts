export declare const CONTENT_LANGUAGES: readonly ["zh-Hans", "zh-Hant", "en", "ja", "ko", "es", "fr", "de", "other"];
export type ContentLanguageCode = (typeof CONTENT_LANGUAGES)[number];
export declare const GOAL_CONTENT_LANGUAGE_SETTINGS: readonly ["auto", "zh-Hans", "zh-Hant", "en", "ja", "ko", "es", "fr", "de", "other"];
export type GoalContentLanguageSetting = (typeof GOAL_CONTENT_LANGUAGE_SETTINGS)[number];
export declare function isGoalContentLanguageSetting(value: string | null | undefined): value is GoalContentLanguageSetting;
export declare function detectChineseVariant(text: string): "zh-Hans" | "zh-Hant";
export declare function isChineseContentLanguage(code: ContentLanguageCode | string | null | undefined): boolean;
/** Detect dominant language from goal title / free text. */
export declare function detectContentLanguage(text: string): ContentLanguageCode;
/**
 * Detect the language being studied from a language-learning goal title/topic.
 * This is not the authoring contentLanguage (explanations may be in Chinese
 * while the target is Japanese).
 */
export declare function detectLanguageLearningTarget(text: string | null | undefined): ContentLanguageCode | null;
export declare function getContentLanguageLabel(code: ContentLanguageCode): string;
export declare function getLanguagePromptInstruction(code: ContentLanguageCode): string;
/**
 * Per-topic lock appended after prompt compaction. Later commit_topic_material
 * turns otherwise drop the language block because it already appeared in the
 * transcript, and models then follow the English tool schema.
 */
export declare function topicMaterialLanguageLock(languageBlock: string, topicId: string): string;
/** Appended to image-provider prompts so on-image labels match lesson language. */
export declare function getImageLabelLanguageInstruction(code: ContentLanguageCode): string;
export declare function getPromptLanguageLabel(code: ContentLanguageCode): string;
export declare function resolveGoalContentLanguage(stored: string | null | undefined, goalTitle: string, appLocale?: string | null): ContentLanguageCode;
