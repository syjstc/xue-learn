import type { StreamTokenHandler } from "./chat-stream.js";
import { z } from "zod";
import { assembleMaterialItems, type MaterialGenerationJitItem } from "./jit-structured-items.js";
import { type InlineCheckContext } from "./course-material-inline-checks.js";
import { type MaterialGenerationPolicy } from "./component-dsl-registry.js";
import type { LearningSystemSubject } from "../learning-systems/types.js";
export declare function normalizedCheckQuestion(question: string): string;
/** Normalize authored prose while preserving significant code whitespace. */
export declare function normalizeMaterialGeneratedJsonValue(value: unknown): unknown;
/**
 * Streams a flat provider-facing root array. Every preview block
 * has passed its item schema. Parsed component_slot / svg_slot items emit a
 * loading placeholder immediately and start their compiler without waiting
 * for the remaining authored blocks. Inline checks stay server-owned and are
 * still appended after authoring completes.
 */
export declare function streamCourseMaterialItems(prompt: string, options: {
    onToken?: StreamTokenHandler;
    onMaterialUpdate?: (partial: {
        material: ReturnType<typeof assembleMaterialItems>["material"];
        completeBlockCount: number;
        placeholderBlockCount: number;
    }) => void | Promise<void>;
    signal?: AbortSignal;
    operation?: string;
    meta?: Record<string, unknown>;
    contextSubject?: LearningSystemSubject;
    contextQuery?: string;
    contextInvocation?: unknown;
    generationPolicy?: MaterialGenerationPolicy;
    componentContext: {
        unitTitle: string;
        language: string;
        context: string;
        authoringScope?: {
            userId: string;
            goalId: string;
            unitId: string;
        };
    };
    inlineCheckContext?: InlineCheckContext;
    authorItems?: (input: {
        prompt: string;
        resultSchema: z.ZodType<MaterialGenerationJitItem[]>;
        onToken?: StreamTokenHandler;
        onPartial: (items: MaterialGenerationJitItem[]) => void | Promise<void>;
        signal?: AbortSignal;
    }) => Promise<MaterialGenerationJitItem[]>;
}): Promise<{
    items: MaterialGenerationJitItem[];
    material: ReturnType<typeof assembleMaterialItems>["material"];
}>;
