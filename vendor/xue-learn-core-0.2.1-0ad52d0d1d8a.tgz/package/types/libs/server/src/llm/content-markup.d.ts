import { type ContentMarkupProfile, type TopicCategory } from "../../../common/src/index.js";
import { type ContentLanguageCode } from "./content-language.js";
/** Marker checked by {@link appendContentMarkupRules} to avoid duplicate injection. */
export declare const CONTENT_MARKUP_MARKER = "Unified special-content markup (mandatory)";
/** All language ruby/IPA rules (fallback when the studied language is unknown). */
export declare const LANGUAGE_CONTENT_MARKUP_RULES: string;
export declare const STEM_CONTENT_MARKUP_RULES = "Math/science:\n- Wrap every on-screen math fragment in TeX delimiters: identifiers, sub/superscripts, operators, equalities, and implications. Inline: $f \\circ g_1 = f \\circ g_2 \\implies g_1 = g_2$ and $C^{\\mathrm{op}}$. Never leave those as plain/Unicode text (f \u25E6 g1, C^op, a \u2192 b, g1).\n- Inline math: $E=mc^2$. Use a math fence for long/display math:\n     ```math\n     \\int_0^1 x^2 \\, dx\n     ```\n- Chemistry: always mhchem inside math delimiters, e.g. $\\ce{H2O}$ or $\\ce{SO4^2- + Ba^2+ -> BaSO4 v}$.\n- Units: keep the full value/unit in one $\\pu{\u2026}$, e.g. $\\pu{0.5 kg}$ or $\\pu{9.8 m/s^2}$.";
export declare const CODE_CONTENT_MARKUP_RULES: string;
export type LanguageMarkupScript = "chinese_pinyin" | "chinese_bopomofo" | "japanese_furigana" | "korean_hanja" | "ipa";
export type ContentMarkupOptions = {
    topicCategory?: TopicCategory | null;
    /**
     * Language being studied (language goals only). Prefer this over inferring
     * from {@link goalTitle}. Not the authoring contentLanguage.
     */
    targetLanguage?: ContentLanguageCode | string | null;
    /** Goal/topic text used to infer {@link targetLanguage} when unset. */
    goalTitle?: string | null;
    /** Override category-derived profiles when callers need explicit control. */
    profiles?: ContentMarkupProfile[];
};
/** Resolve which language markup scripts apply for a studied language. */
export declare function languageMarkupScriptsForTarget(target: ContentLanguageCode | string | null | undefined): LanguageMarkupScript[];
/** Resolve studied language for language-topic markup selection. */
export declare function resolveLanguageMarkupTarget(options?: Pick<ContentMarkupOptions, "targetLanguage" | "goalTitle">): ContentLanguageCode | null;
/** Build markup options from generation meta + optional topic override. */
export declare function contentMarkupOptionsFromMeta(meta: Record<string, unknown> | undefined, topicCategory?: TopicCategory | null): ContentMarkupOptions;
/** Build markup rules for the given topic category (or explicit profiles). */
export declare function buildContentMarkupRules(options?: ContentMarkupOptions): string;
/**
 * Global rules for pronunciation, math, and other typed inline/block markup.
 * Language ruby/IPA is included only for language-related topic categories,
 * and narrowed to the studied language when known (e.g. Japanese → furigana).
 * Math/chem/unit markup is included for every prompt so mixed-topic content
 * still renders formulas consistently.
 */
export declare const CONTENT_MARKUP_RULES: string;
/** Append content markup rules once per prompt. */
export declare function appendContentMarkupRules(prompt: string, options?: ContentMarkupOptions): string;
/** Prompt block for PlanContext and explicit prompt builders. */
export declare function getContentMarkupPromptBlock(options?: ContentMarkupOptions): string;
