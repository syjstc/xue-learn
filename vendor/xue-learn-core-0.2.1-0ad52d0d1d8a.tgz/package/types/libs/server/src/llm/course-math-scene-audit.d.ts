import { z } from "zod";
import type { MathScene } from "../../../domain/src/index.js";
export declare const COURSE_MATH_SCENE_AUDIT_MODEL = "deepseek-flash";
export declare const courseMathSceneAuditSchema: z.ZodObject<{
    result: z.ZodBoolean;
    reason: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type CourseMathSceneAudit = z.infer<typeof courseMathSceneAuditSchema>;
/**
 * This prefix is deliberately invariant. Lesson facts and scene JSON are
 * appended below it so repeated audits can reuse the provider prefix cache.
 */
export declare const COURSE_MATH_SCENE_AUDIT_PROMPT = "You are a rigorous mathematical teaching-scene auditor. Audit an already compiled declarative math scene; do not author a replacement scene.\n\nCheck semantic truth before presentation:\n1. Derive the important mathematical claims from the teaching requirement, title, labels, and summary. Verify that the actual expressions, coordinates, domains, parameters, vector relations, and plotted limits support those claims.\n2. Check intersections, roots, extrema, monotonicity, asymptotes and limits, signs, ordering, geometry, vector arithmetic, parameter behavior, and dimensional or coordinate-system consistency whenever relevant. Inspect the whole declared domain and meaningful parameter range, not just one convenient sample.\n3. Text is not evidence. A correct title, label, reference line, or summary cannot compensate for a curve or object that depicts a contradictory relationship.\n4. Distinguish an exact finite equality from asymptotic convergence. Do not accept curves that merely cross once when the requirement says they approach and remain at a common equilibrium.\n5. Check that every visible label identifies the correct object and that the chosen ranges do not hide a contradiction or materially clip the teaching relationship.\n6. Do not reject a mathematically correct scene for optional style changes.\n\nReturn {\"result\":true} with no reason only when the complete scene is mathematically consistent with the teaching requirement and its own learner-visible claims. Otherwise return result=false and a concise repair contract in reason. The contract must state: (a) the false claim, (b) the scene fields or expressions causing it, (c) the required mathematical relationship, and (d) an objectively testable acceptance condition. Preserve correct parts explicitly when useful.";
export declare function buildCourseMathSceneAuditPrompt(params: {
    scene: MathScene;
    teachingBrief: string;
}): string;
export declare function auditCourseMathSceneIfConfigured(params: {
    scene: MathScene;
    teachingBrief: string;
    signal?: AbortSignal;
}): Promise<CourseMathSceneAudit | null>;
