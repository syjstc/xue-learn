import type { BaseChatModel } from "@langchain/core/language_models/chat_models";
import { z } from "zod";
import { type ComplexInteractiveBlockType, type InteractiveBlock } from "./schemas.js";
export type ComponentIntent = {
    type: ComplexInteractiveBlockType;
    description: string;
};
type CheckBlock = Extract<InteractiveBlock, {
    type: "check";
}>;
export declare const checkBlockSchema: z.ZodObject<{
    type: z.ZodLiteral<"check">;
    checkId: z.ZodOptional<z.ZodString>;
    question: z.ZodString;
    options: z.ZodArray<z.ZodString>;
    correctIndex: z.ZodNumber;
    explanation: z.ZodString;
    primaryLearningTargetId: z.ZodOptional<z.ZodString>;
    learningTargetIds: z.ZodArray<z.ZodString>;
    targetCognitiveEntityId: z.ZodOptional<z.ZodString>;
    evidenceDimension: z.ZodEnum<{
        memory: "memory";
        understanding: "understanding";
        application: "application";
    }>;
    criterionRef: z.ZodString;
    contextDistance: z.ZodEnum<{
        same: "same";
        near: "near";
    }>;
}, z.core.$strip>;
export declare function parseComponentIntentLine(line: string): ComponentIntent | null;
export declare function componentDslLine(block: InteractiveBlock): string;
export declare function checkDslLine(block: CheckBlock): string;
/**
 * Models often flatten the block onto tool-call args (or stringify it) instead
 * of nesting under `component`. Recover those shapes before Zod validation.
 */
export declare function normalizeComponentToolArgs(args: Record<string, unknown> | undefined, expectedType?: ComplexInteractiveBlockType): Record<string, unknown> | undefined;
/** Recover a component payload from assistant text when tool args are empty. */
export declare function recoverComponentArgsFromText(text: string, expectedType?: ComplexInteractiveBlockType): Record<string, unknown> | undefined;
/** Provider-independent prepared contract shared by hosted and local adapters. */
export declare function prepareComponentIntentCompilation(params: {
    intent: ComponentIntent;
    unitTitle: string;
    language: string;
    context: string;
}): {
    operation: "unit.learning_material.component_compile";
    invocation: {
        intentType: "step_sort" | "graph" | "chart" | "math_scene" | "mechanics_sandbox" | "circuit_sandbox" | "chemistry_lab";
        intentDescription: string;
        unitTitle: string;
        language: string;
        context: string;
        toolName: string;
        transport: "structured";
    };
    prompt: string;
    standalonePrompt: string;
    bindingSchema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
    resultSchema: z.ZodType<{
        templateId: "general-question";
        content: {
            objects: [string?, string?, ...unknown[]];
            glyphs: [("object" | "question" | "paper" | "boat" | "read" | "recall")?, ("object" | "question" | "paper" | "boat" | "read" | "recall")?, ...unknown[]];
            observations: [string?, string?, ...unknown[]];
            question: string;
            goal: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-layers";
        content: {
            layers: {
                title: string;
                detail: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-flow";
        content: {
            nodes: string[];
            caption: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-compare";
        content: {
            names: [string?, string?, ...unknown[]];
            metrics: {
                label: string;
                unit: string;
                values: [number?, number?, ...unknown[]];
                max: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-summary";
        content: {
            concepts: [string?, string?, string?, ...unknown[]];
            center: string;
            transfer: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-pythagoras";
        content: {
            a: number;
            b: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-tangent";
        content: {
            coefficient: number;
            at: number;
            startDx: number;
            xmax: number;
            power?: 2 | 3;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-integral";
        content: {
            coefficient: number;
            end: number;
            power?: 1 | 2;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-probability";
        content: {
            total: number;
            condition: number;
            intersection: number;
            outsideTarget: number;
            conditionName: string;
            targetName: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "physics-forces";
        content: {
            mass: number;
            drive: number;
            resistance: number;
            duration: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "physics-waves";
        content: {
            amplitude1: number;
            amplitude2: number;
            cycles1: number;
            cycles2: number;
            phase2: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "physics-circuit";
        content: {
            voltage: number;
            resistance1: number;
            resistance2: number;
            topology: "series" | "parallel";
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "chemistry-reaction";
        content: {
            reactants: {
                label: string;
                atoms: {
                    id: string;
                    element: string;
                }[];
                bonds: {
                    from: string;
                    to: string;
                    order?: 1 | 2 | 3;
                }[];
            }[];
            products: {
                label: string;
                atoms: {
                    id: string;
                    element: string;
                }[];
                bonds: {
                    from: string;
                    to: string;
                    order?: 1 | 2 | 3;
                }[];
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "chemistry-titration";
        content: {
            acidMl: number;
            acidMolarity: number;
            baseMolarity: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "biology-mitosis";
        content: {
            chromosomeCount?: 2 | 4;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "biology-enzyme";
        content: {
            enzyme: string;
            substrate: string;
            products: [string?, string?, ...unknown[]];
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "geography-water";
        content: {
            title: string;
            nodes: [{
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, ...unknown[]];
            transitions: [string?, string?, string?, string?, string?, ...unknown[]];
            stages: [string?, string?, string?, ...unknown[]];
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "history-timeline";
        content: {
            range: [number?, number?, ...unknown[]];
            events: [{
                year: number;
                label: string;
                evidence: string;
                kind: "type" | "block" | "moon" | "telescope" | "event";
                approximate?: boolean;
            }?, {
                year: number;
                label: string;
                evidence: string;
                kind: "type" | "block" | "moon" | "telescope" | "event";
                approximate?: boolean;
            }?, ...unknown[]];
            caution: string;
            conclusion: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "language-syntax";
        content: {
            subject: string;
            verb: string;
            object: string;
            question: string;
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "language-perspective";
        content: {
            object: "door" | "book";
            firstPerson: string;
            observer: string;
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "cs-sorting";
        content: {
            values: number[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "cs-recursion";
        content: {
            operation: "product" | "sum";
            start: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "music-score";
        type: "teaching";
        version: 1;
        id: string;
        title: string;
        content?: {
            source: "accepted-v2";
            block: {
                type: "music";
                version: 2;
                id: string;
                title: string;
                layout: "row" | "column" | "grid";
                notes: {
                    id: string;
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
                views: {
                    id: string;
                    kind: "staff" | "keyboard";
                    label: string;
                    notes: string[];
                    clef?: "treble" | "bass";
                    range?: string[];
                }[];
                marks?: {
                    id: string;
                    kind: "label" | "link" | "bracket" | "arrow";
                    label: string;
                    anchors: {
                        viewId: string;
                        noteId?: string;
                    }[];
                }[];
                clips?: {
                    id: string;
                    label: string;
                    tempo: number;
                    events: {
                        notes: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                    instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            };
            clipId?: string;
            repeat?: number;
        } | {
            id: string;
            title: string;
            groups: string[][];
            labels: string[];
            range: [string?, string?, ...unknown[]];
            beats?: 1 | 2;
            tempo?: number;
        };
    } | {
        templateId: "music-harmony";
        type: "teaching";
        version: 1;
        id: string;
        title: string;
        content?: {
            source: "accepted-v2";
            block: {
                type: "music";
                version: 2;
                id: string;
                title: string;
                layout: "row" | "column" | "grid";
                notes: {
                    id: string;
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
                views: {
                    id: string;
                    kind: "staff" | "keyboard";
                    label: string;
                    notes: string[];
                    clef?: "treble" | "bass";
                    range?: string[];
                }[];
                marks?: {
                    id: string;
                    kind: "label" | "link" | "bracket" | "arrow";
                    label: string;
                    anchors: {
                        viewId: string;
                        noteId?: string;
                    }[];
                }[];
                clips?: {
                    id: string;
                    label: string;
                    tempo: number;
                    events: {
                        notes: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                    instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            };
            clipId?: string;
            repeat?: number;
        } | {
            id: string;
            title: string;
            groups: string[][];
            labels: string[];
            range: [string?, string?, ...unknown[]];
            beats?: 1 | 2;
            tempo?: number;
        };
    } | {
        templateId: "economics-equilibrium";
        content: {
            demandIntercept: number;
            supplyIntercept: number;
            demandSlope: number;
            supplySlope: number;
            demandShift: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-timeline";
        content: {
            unit: string;
            events: {
                at: number;
                label: string;
                detail: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-cycle";
        content: {
            center: string;
            nodes: {
                label: string;
                process: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-decision";
        content: {
            question: string;
            branches: {
                condition: string;
                outcome: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-funnel";
        content: {
            unit: string;
            stages: {
                label: string;
                value: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-balance";
        content: {
            unit: string;
            left: {
                label: string;
                items: {
                    label: string;
                    value: number;
                }[];
            };
            right: {
                label: string;
                items: {
                    label: string;
                    value: number;
                }[];
            };
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-matrix";
        content: {
            columns: string[];
            rows: {
                label: string;
                values: number[];
            }[];
            unit: string;
            max: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-proportion";
        content: {
            whole: string;
            unit: string;
            parts: {
                label: string;
                value: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-network";
        content: {
            nodes: {
                id: string;
                label: string;
            }[];
            links: {
                from: string;
                to: string;
                label: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-counter";
        content: {
            label: string;
            unit: string;
            from: number;
            to: number;
            context: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-interval";
        content: {
            label: string;
            unit: string;
            min: number;
            max: number;
            low: number;
            high: number;
            points: {
                label: string;
                value: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-hierarchy";
        content: {
            root: string;
            groups: {
                label: string;
                members: string[];
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-ranking";
        content: {
            unit: string;
            before: string;
            after: string;
            items: {
                label: string;
                before: number;
                after: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        type: "music";
        version: 1;
        title: string;
        key: "C";
        meter: "2/4" | "3/4" | "4/4";
        tempo: number;
        keyboard: boolean;
        parts: {
            id: string;
            label: string;
            clef: "treble" | "bass";
            bars: {
                notes: {
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
            }[];
            instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
        }[];
        steps: {
            bars: number[];
            parts: string[];
            id: string;
            label: string;
            instruments?: {
                part: string;
                instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
            }[];
            focus?: string[];
            compare?: {
                bars: number[];
                parts: string[];
                label: string;
                instruments?: {
                    part: string;
                    instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            };
        }[];
        id?: string;
        notation?: "staff" | "both" | "jianpu";
    } | {
        type: "music";
        version: 2;
        id: string;
        title: string;
        layout: "row" | "column" | "grid";
        notes: {
            id: string;
            pitches: string[];
            beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
        }[];
        views: {
            id: string;
            kind: "staff" | "keyboard";
            label: string;
            notes: string[];
            clef?: "treble" | "bass";
            range?: string[];
        }[];
        marks?: {
            id: string;
            kind: "label" | "link" | "bracket" | "arrow";
            label: string;
            anchors: {
                viewId: string;
                noteId?: string;
            }[];
        }[];
        clips?: {
            id: string;
            label: string;
            tempo: number;
            events: {
                notes: string[];
                beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
            }[];
            instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
        }[];
    } | {
        type: "visual";
        kind: "process" | "cycle" | "layers" | "bars";
        title: string;
        items: {
            id: string;
            label: string;
            detail?: string;
            value?: number;
        }[];
        id?: string;
        unit?: string;
    } | {
        type: "heading";
        text: string;
        level?: 2 | 3;
        topicId?: string;
    } | {
        type: "paragraph";
        text: string;
        cue?: {
            target: string;
            music?: {
                figureId: string;
                clipId: string;
                repeat?: number;
            };
            targetIds?: string[];
            op?: "highlight" | "window";
            regionIds?: string[];
            figureId?: string;
        };
    } | {
        type: "code";
        code: string;
        id?: string;
        language?: string;
        parts?: {
            text: string;
            id?: string;
        }[];
        regions?: {
            id: string;
            match: string;
        }[];
    } | {
        type: "conversation";
        turns: {
            speaker: string;
            text: string;
        }[];
        id?: string;
        title?: string;
    } | {
        type: "callout";
        variant: "example" | "warning" | "definition" | "tip";
        body: string;
        id?: string;
        title?: string;
    } | {
        type: "accordion";
        title: string;
        body: string;
        id?: string;
    } | {
        type: "check";
        question: string;
        explanation: string;
        learningTargetIds: string[];
        evidenceDimension: "memory" | "understanding" | "application";
        criterionRef: string;
        contextDistance: "same" | "near";
        checkId?: string;
        questionType?: "mcq" | "mcq_multi" | "true_false";
        options?: string[];
        correctIndex?: number;
        correctIndices?: number[];
        correctAnswer?: boolean;
        primaryLearningTargetId?: string;
        targetCognitiveEntityId?: string;
    } | {
        type: "compare";
        left: {
            label: string;
            points: string[];
            id?: string;
        };
        right: {
            label: string;
            points: string[];
            id?: string;
        };
        id?: string;
        sides?: {
            label: string;
            points: string[];
            id?: string;
        }[];
    } | {
        type: "step_sort";
        title: string;
        correct_sequence: {
            id: string;
            content: string;
            order: number;
        }[];
        dependency_hint: string;
    } | {
        type: "graph";
        variant: "process_flow" | "concept_map";
        title: string;
        direction: "TB" | "LR" | "RADIAL";
        nodes: {
            id: string;
            label: string;
            kind: "start" | "end" | "process" | "io" | "outcome" | "source" | "decision" | "system" | "concept";
            emphasis: "primary" | "normal";
            description?: string;
            groupId?: string;
        }[];
        edges: {
            id: string;
            from: string;
            to: string;
            arrow: "none" | "forward" | "backward" | "both";
            label?: string;
        }[];
        groups?: {
            id: string;
            label: string;
            description?: string;
        }[];
        caption?: string;
    } | {
        type: "chart";
        title: string;
        chartType: "area" | "line" | "bar" | "pie" | "scatter";
        data: Record<string, string | number>[];
        series: {
            dataKey: string;
            name: string;
            color?: string;
            unit?: string;
        }[];
        showLegend: boolean;
        donut: boolean;
        summary: string;
        categoryKey?: string;
        xKey?: string;
        yKey?: string;
        xLabel?: string;
        yLabel?: string;
        unit?: string;
    } | {
        type: "math_scene";
        title: string;
        dimension: "2d" | "3d";
        coordinateSystem: "cartesian" | "polar";
        xRange: [number?, number?, ...unknown[]];
        yRange: [number?, number?, ...unknown[]];
        objects: ({
            kind: "point";
            id: string;
            position?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "vector";
            id: string;
            start?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            end?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            relation?: {
                operation: "sum" | "difference";
                operands: [string?, string?, ...unknown[]];
            } | {
                operation: "scale";
                operand: string;
                factor: number;
                factorParameter?: string;
            };
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "segment";
            id: string;
            from?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            to?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "function";
            expression: string;
            variable: "x";
            domain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "parametric";
            xExpression: string;
            yExpression: string;
            parameter: "t";
            domain: [number?, number?, ...unknown[]];
            id: string;
            zExpression?: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "polar_function";
            expression: string;
            variable: "theta";
            domain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "surface";
            expression: string;
            variables: ["x"?, "y"?, ...unknown[]];
            xDomain: [number?, number?, ...unknown[]];
            yDomain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        })[];
        showGrid: boolean;
        showAxes: boolean;
        summary: string;
        zRange?: [number?, number?, ...unknown[]];
        parameters?: {
            id: string;
            name: string;
            min: number;
            max: number;
            step: number;
            default: number;
        }[];
        camera?: {
            azimuth: number;
            elevation: number;
        };
    } | {
        type: "interactive_html";
        title: string;
        summary: string;
        html: string;
        visualKind?: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
        height?: number;
    } | {
        type: "mechanics_sandbox";
        title: string;
        summary: string;
        sandboxType: "collision_1d" | "inclined_plane" | "pendulum" | "spring_oscillator";
        objects: {
            id: string;
            name: string;
            mass: number;
            color?: string;
            radius?: number;
            width?: number;
            height?: number;
            initialPosition?: number;
            initialVelocity?: number;
        }[];
        showVectors: boolean;
        showEnergyChart: boolean;
        parameters?: {
            id: string;
            name: string;
            unit: string;
            min: number;
            max: number;
            step: number;
            default: number;
        }[];
        targetObservation?: string;
    } | {
        type: "circuit_sandbox";
        title: string;
        summary: string;
        circuit?: {
            id: string;
            kind: "battery" | "resistor" | "rheostat" | "switch" | "bulb" | "ammeter" | "voltmeter";
            label?: string;
            v?: number;
            ohm?: number;
            min?: number;
            max?: number;
            closed?: boolean;
            ratedV?: number;
            ratedW?: number;
        } | {
            series: unknown[];
        } | {
            parallel: unknown[];
        };
        components?: {
            id: string;
            kind: "battery" | "resistor" | "rheostat" | "switch" | "bulb" | "ammeter" | "voltmeter" | "voltage_source" | "potentiometer" | "lightbulb";
            nodeA: string;
            nodeB: string;
            label?: string;
            value?: number;
            minValue?: number;
            maxValue?: number;
            closed?: boolean;
            ratedVoltage?: number;
            ratedPower?: number;
            position?: [number?, number?, ...unknown[]];
        }[];
        wires?: {
            id: string;
            from: string;
            to: string;
            points?: [number?, number?, ...unknown[]][];
        }[];
        groundNode?: string;
        targetObservation?: string;
    } | {
        type: "chemistry_lab";
        title: string;
        summary: string;
        experimentId: "acid_base_indicator" | "acid_base_titration" | "precipitation_reaction" | "mass_conservation";
        experimentVersion: 1;
        stage: "middle_school" | "high_school" | "undergraduate";
        renderMode: "2d" | "3d";
        parameters: Record<string, number>;
        targetObservation?: string;
        controls?: string[];
        observations?: {
            id: string;
            label: string;
            value?: string | number;
            unit?: string;
            kind?: "text" | "state" | "scalar";
        }[];
    } | {
        type: "illustration";
        caption: string;
        prompt: string;
        style: "process" | "diagram" | "concept" | "comparison";
        id?: string;
        aspectRatio?: "1:1" | "16:9" | "9:16" | "4:3" | "3:4" | "3:2" | "2:3";
        imageId?: string;
        imageUrl?: string;
        guidedImage?: {
            type: "guided_image";
            schemaVersion: 1;
            id: string;
            intent: {
                id: string;
                title: string;
                language: string;
                learningGoal: string;
                assumedKnowledge: string;
                composition: string;
                parts: {
                    id: string;
                    label: string;
                    visualDescription: string;
                    teachingPoints: string[];
                    required: boolean;
                }[];
                relationships: {
                    from: string;
                    to: string;
                    meaning: string;
                }[];
            };
            image: {
                src: string;
                sha256: string;
                width: number;
                height: number;
            };
            segmentation: {
                regions: {
                    id: string;
                    partId: string;
                    label: string;
                    observedDescription: string;
                    polygons: {
                        outer: {
                            x: number;
                            y: number;
                        }[];
                        holes: {
                            x: number;
                            y: number;
                        }[][];
                    }[];
                }[];
                missingPartIds: string[];
                imageIssues: string[];
                geometryVersion?: "simple-shapes-v1";
            };
            cutouts: {
                regionId: string;
                src: string;
            }[];
            beats: {
                id: string;
                text: string;
                regionIds: string[];
                partIds: string[];
            }[];
            persona: {
                ref: string;
                name: string;
                avatarCode: string;
            };
            sourceFingerprint: string;
        };
    } | {
        type: "svg";
        caption: string;
        alt: string;
        svg: string;
        title?: string;
        intent?: {
            visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
            setup: string;
            learningGoal: string;
            expectedInsight: string;
            composition?: string;
            elements?: string[];
            relationships?: string[];
            labels?: string[];
            avoid?: string[];
        };
    } | {
        type: "placeholder";
        reason: string;
        componentType?: "check" | "step_sort" | "graph" | "chart" | "math_scene" | "interactive_html" | "mechanics_sandbox" | "circuit_sandbox" | "chemistry_lab" | "svg";
        description?: string;
        fallbackBody?: string;
        primaryLearningTargetId?: string;
        targetCognitiveEntityId?: string;
        evidenceDimension?: "memory" | "understanding";
        criterionRef?: string;
        contextDistance?: "same";
    } | {
        type: "svg_slot";
        intent: {
            visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
            setup: string;
            learningGoal: string;
            expectedInsight: string;
            composition?: string;
            elements?: string[];
            relationships?: string[];
            labels?: string[];
            avoid?: string[];
        };
        id?: string;
    } | {
        type: "stage";
        layout: "split-h" | "split-v" | "main+rail" | "stack";
        figures: any[];
        id?: string;
        presentation?: "compare" | "steps" | "focus";
    }, unknown, z.core.$ZodTypeInternals<{
        templateId: "general-question";
        content: {
            objects: [string?, string?, ...unknown[]];
            glyphs: [("object" | "question" | "paper" | "boat" | "read" | "recall")?, ("object" | "question" | "paper" | "boat" | "read" | "recall")?, ...unknown[]];
            observations: [string?, string?, ...unknown[]];
            question: string;
            goal: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-layers";
        content: {
            layers: {
                title: string;
                detail: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-flow";
        content: {
            nodes: string[];
            caption: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-compare";
        content: {
            names: [string?, string?, ...unknown[]];
            metrics: {
                label: string;
                unit: string;
                values: [number?, number?, ...unknown[]];
                max: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-summary";
        content: {
            concepts: [string?, string?, string?, ...unknown[]];
            center: string;
            transfer: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-pythagoras";
        content: {
            a: number;
            b: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-tangent";
        content: {
            coefficient: number;
            at: number;
            startDx: number;
            xmax: number;
            power?: 2 | 3;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-integral";
        content: {
            coefficient: number;
            end: number;
            power?: 1 | 2;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-probability";
        content: {
            total: number;
            condition: number;
            intersection: number;
            outsideTarget: number;
            conditionName: string;
            targetName: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "physics-forces";
        content: {
            mass: number;
            drive: number;
            resistance: number;
            duration: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "physics-waves";
        content: {
            amplitude1: number;
            amplitude2: number;
            cycles1: number;
            cycles2: number;
            phase2: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "physics-circuit";
        content: {
            voltage: number;
            resistance1: number;
            resistance2: number;
            topology: "series" | "parallel";
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "chemistry-reaction";
        content: {
            reactants: {
                label: string;
                atoms: {
                    id: string;
                    element: string;
                }[];
                bonds: {
                    from: string;
                    to: string;
                    order?: 1 | 2 | 3;
                }[];
            }[];
            products: {
                label: string;
                atoms: {
                    id: string;
                    element: string;
                }[];
                bonds: {
                    from: string;
                    to: string;
                    order?: 1 | 2 | 3;
                }[];
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "chemistry-titration";
        content: {
            acidMl: number;
            acidMolarity: number;
            baseMolarity: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "biology-mitosis";
        content: {
            chromosomeCount?: 2 | 4;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "biology-enzyme";
        content: {
            enzyme: string;
            substrate: string;
            products: [string?, string?, ...unknown[]];
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "geography-water";
        content: {
            title: string;
            nodes: [{
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, ...unknown[]];
            transitions: [string?, string?, string?, string?, string?, ...unknown[]];
            stages: [string?, string?, string?, ...unknown[]];
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "history-timeline";
        content: {
            range: [number?, number?, ...unknown[]];
            events: [{
                year: number;
                label: string;
                evidence: string;
                kind: "type" | "block" | "moon" | "telescope" | "event";
                approximate?: boolean;
            }?, {
                year: number;
                label: string;
                evidence: string;
                kind: "type" | "block" | "moon" | "telescope" | "event";
                approximate?: boolean;
            }?, ...unknown[]];
            caution: string;
            conclusion: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "language-syntax";
        content: {
            subject: string;
            verb: string;
            object: string;
            question: string;
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "language-perspective";
        content: {
            object: "door" | "book";
            firstPerson: string;
            observer: string;
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "cs-sorting";
        content: {
            values: number[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "cs-recursion";
        content: {
            operation: "product" | "sum";
            start: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "music-score";
        type: "teaching";
        version: 1;
        id: string;
        title: string;
        content?: {
            source: "accepted-v2";
            block: {
                type: "music";
                version: 2;
                id: string;
                title: string;
                layout: "row" | "column" | "grid";
                notes: {
                    id: string;
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
                views: {
                    id: string;
                    kind: "staff" | "keyboard";
                    label: string;
                    notes: string[];
                    clef?: "treble" | "bass";
                    range?: string[];
                }[];
                marks?: {
                    id: string;
                    kind: "label" | "link" | "bracket" | "arrow";
                    label: string;
                    anchors: {
                        viewId: string;
                        noteId?: string;
                    }[];
                }[];
                clips?: {
                    id: string;
                    label: string;
                    tempo: number;
                    events: {
                        notes: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                    instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            };
            clipId?: string;
            repeat?: number;
        } | {
            id: string;
            title: string;
            groups: string[][];
            labels: string[];
            range: [string?, string?, ...unknown[]];
            beats?: 1 | 2;
            tempo?: number;
        };
    } | {
        templateId: "music-harmony";
        type: "teaching";
        version: 1;
        id: string;
        title: string;
        content?: {
            source: "accepted-v2";
            block: {
                type: "music";
                version: 2;
                id: string;
                title: string;
                layout: "row" | "column" | "grid";
                notes: {
                    id: string;
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
                views: {
                    id: string;
                    kind: "staff" | "keyboard";
                    label: string;
                    notes: string[];
                    clef?: "treble" | "bass";
                    range?: string[];
                }[];
                marks?: {
                    id: string;
                    kind: "label" | "link" | "bracket" | "arrow";
                    label: string;
                    anchors: {
                        viewId: string;
                        noteId?: string;
                    }[];
                }[];
                clips?: {
                    id: string;
                    label: string;
                    tempo: number;
                    events: {
                        notes: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                    instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            };
            clipId?: string;
            repeat?: number;
        } | {
            id: string;
            title: string;
            groups: string[][];
            labels: string[];
            range: [string?, string?, ...unknown[]];
            beats?: 1 | 2;
            tempo?: number;
        };
    } | {
        templateId: "economics-equilibrium";
        content: {
            demandIntercept: number;
            supplyIntercept: number;
            demandSlope: number;
            supplySlope: number;
            demandShift: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-timeline";
        content: {
            unit: string;
            events: {
                at: number;
                label: string;
                detail: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-cycle";
        content: {
            center: string;
            nodes: {
                label: string;
                process: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-decision";
        content: {
            question: string;
            branches: {
                condition: string;
                outcome: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-funnel";
        content: {
            unit: string;
            stages: {
                label: string;
                value: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-balance";
        content: {
            unit: string;
            left: {
                label: string;
                items: {
                    label: string;
                    value: number;
                }[];
            };
            right: {
                label: string;
                items: {
                    label: string;
                    value: number;
                }[];
            };
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-matrix";
        content: {
            columns: string[];
            rows: {
                label: string;
                values: number[];
            }[];
            unit: string;
            max: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-proportion";
        content: {
            whole: string;
            unit: string;
            parts: {
                label: string;
                value: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-network";
        content: {
            nodes: {
                id: string;
                label: string;
            }[];
            links: {
                from: string;
                to: string;
                label: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-counter";
        content: {
            label: string;
            unit: string;
            from: number;
            to: number;
            context: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-interval";
        content: {
            label: string;
            unit: string;
            min: number;
            max: number;
            low: number;
            high: number;
            points: {
                label: string;
                value: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-hierarchy";
        content: {
            root: string;
            groups: {
                label: string;
                members: string[];
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-ranking";
        content: {
            unit: string;
            before: string;
            after: string;
            items: {
                label: string;
                before: number;
                after: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        type: "music";
        version: 1;
        title: string;
        key: "C";
        meter: "2/4" | "3/4" | "4/4";
        tempo: number;
        keyboard: boolean;
        parts: {
            id: string;
            label: string;
            clef: "treble" | "bass";
            bars: {
                notes: {
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
            }[];
            instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
        }[];
        steps: {
            bars: number[];
            parts: string[];
            id: string;
            label: string;
            instruments?: {
                part: string;
                instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
            }[];
            focus?: string[];
            compare?: {
                bars: number[];
                parts: string[];
                label: string;
                instruments?: {
                    part: string;
                    instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            };
        }[];
        id?: string;
        notation?: "staff" | "both" | "jianpu";
    } | {
        type: "music";
        version: 2;
        id: string;
        title: string;
        layout: "row" | "column" | "grid";
        notes: {
            id: string;
            pitches: string[];
            beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
        }[];
        views: {
            id: string;
            kind: "staff" | "keyboard";
            label: string;
            notes: string[];
            clef?: "treble" | "bass";
            range?: string[];
        }[];
        marks?: {
            id: string;
            kind: "label" | "link" | "bracket" | "arrow";
            label: string;
            anchors: {
                viewId: string;
                noteId?: string;
            }[];
        }[];
        clips?: {
            id: string;
            label: string;
            tempo: number;
            events: {
                notes: string[];
                beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
            }[];
            instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
        }[];
    } | {
        type: "visual";
        kind: "process" | "cycle" | "layers" | "bars";
        title: string;
        items: {
            id: string;
            label: string;
            detail?: string;
            value?: number;
        }[];
        id?: string;
        unit?: string;
    } | {
        type: "heading";
        text: string;
        level?: 2 | 3;
        topicId?: string;
    } | {
        type: "paragraph";
        text: string;
        cue?: {
            target: string;
            music?: {
                figureId: string;
                clipId: string;
                repeat?: number;
            };
            targetIds?: string[];
            op?: "highlight" | "window";
            regionIds?: string[];
            figureId?: string;
        };
    } | {
        type: "code";
        code: string;
        id?: string;
        language?: string;
        parts?: {
            text: string;
            id?: string;
        }[];
        regions?: {
            id: string;
            match: string;
        }[];
    } | {
        type: "conversation";
        turns: {
            speaker: string;
            text: string;
        }[];
        id?: string;
        title?: string;
    } | {
        type: "callout";
        variant: "example" | "warning" | "definition" | "tip";
        body: string;
        id?: string;
        title?: string;
    } | {
        type: "accordion";
        title: string;
        body: string;
        id?: string;
    } | {
        type: "check";
        question: string;
        explanation: string;
        learningTargetIds: string[];
        evidenceDimension: "memory" | "understanding" | "application";
        criterionRef: string;
        contextDistance: "same" | "near";
        checkId?: string;
        questionType?: "mcq" | "mcq_multi" | "true_false";
        options?: string[];
        correctIndex?: number;
        correctIndices?: number[];
        correctAnswer?: boolean;
        primaryLearningTargetId?: string;
        targetCognitiveEntityId?: string;
    } | {
        type: "compare";
        left: {
            label: string;
            points: string[];
            id?: string;
        };
        right: {
            label: string;
            points: string[];
            id?: string;
        };
        id?: string;
        sides?: {
            label: string;
            points: string[];
            id?: string;
        }[];
    } | {
        type: "step_sort";
        title: string;
        correct_sequence: {
            id: string;
            content: string;
            order: number;
        }[];
        dependency_hint: string;
    } | {
        type: "graph";
        variant: "process_flow" | "concept_map";
        title: string;
        direction: "TB" | "LR" | "RADIAL";
        nodes: {
            id: string;
            label: string;
            kind: "start" | "end" | "process" | "io" | "outcome" | "source" | "decision" | "system" | "concept";
            emphasis: "primary" | "normal";
            description?: string;
            groupId?: string;
        }[];
        edges: {
            id: string;
            from: string;
            to: string;
            arrow: "none" | "forward" | "backward" | "both";
            label?: string;
        }[];
        groups?: {
            id: string;
            label: string;
            description?: string;
        }[];
        caption?: string;
    } | {
        type: "chart";
        title: string;
        chartType: "area" | "line" | "bar" | "pie" | "scatter";
        data: Record<string, string | number>[];
        series: {
            dataKey: string;
            name: string;
            color?: string;
            unit?: string;
        }[];
        showLegend: boolean;
        donut: boolean;
        summary: string;
        categoryKey?: string;
        xKey?: string;
        yKey?: string;
        xLabel?: string;
        yLabel?: string;
        unit?: string;
    } | {
        type: "math_scene";
        title: string;
        dimension: "2d" | "3d";
        coordinateSystem: "cartesian" | "polar";
        xRange: [number?, number?, ...unknown[]];
        yRange: [number?, number?, ...unknown[]];
        objects: ({
            kind: "point";
            id: string;
            position?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "vector";
            id: string;
            start?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            end?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            relation?: {
                operation: "sum" | "difference";
                operands: [string?, string?, ...unknown[]];
            } | {
                operation: "scale";
                operand: string;
                factor: number;
                factorParameter?: string;
            };
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "segment";
            id: string;
            from?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            to?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "function";
            expression: string;
            variable: "x";
            domain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "parametric";
            xExpression: string;
            yExpression: string;
            parameter: "t";
            domain: [number?, number?, ...unknown[]];
            id: string;
            zExpression?: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "polar_function";
            expression: string;
            variable: "theta";
            domain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "surface";
            expression: string;
            variables: ["x"?, "y"?, ...unknown[]];
            xDomain: [number?, number?, ...unknown[]];
            yDomain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        })[];
        showGrid: boolean;
        showAxes: boolean;
        summary: string;
        zRange?: [number?, number?, ...unknown[]];
        parameters?: {
            id: string;
            name: string;
            min: number;
            max: number;
            step: number;
            default: number;
        }[];
        camera?: {
            azimuth: number;
            elevation: number;
        };
    } | {
        type: "interactive_html";
        title: string;
        summary: string;
        html: string;
        visualKind?: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
        height?: number;
    } | {
        type: "mechanics_sandbox";
        title: string;
        summary: string;
        sandboxType: "collision_1d" | "inclined_plane" | "pendulum" | "spring_oscillator";
        objects: {
            id: string;
            name: string;
            mass: number;
            color?: string;
            radius?: number;
            width?: number;
            height?: number;
            initialPosition?: number;
            initialVelocity?: number;
        }[];
        showVectors: boolean;
        showEnergyChart: boolean;
        parameters?: {
            id: string;
            name: string;
            unit: string;
            min: number;
            max: number;
            step: number;
            default: number;
        }[];
        targetObservation?: string;
    } | {
        type: "circuit_sandbox";
        title: string;
        summary: string;
        circuit?: {
            id: string;
            kind: "battery" | "resistor" | "rheostat" | "switch" | "bulb" | "ammeter" | "voltmeter";
            label?: string;
            v?: number;
            ohm?: number;
            min?: number;
            max?: number;
            closed?: boolean;
            ratedV?: number;
            ratedW?: number;
        } | {
            series: unknown[];
        } | {
            parallel: unknown[];
        };
        components?: {
            id: string;
            kind: "battery" | "resistor" | "rheostat" | "switch" | "bulb" | "ammeter" | "voltmeter" | "voltage_source" | "potentiometer" | "lightbulb";
            nodeA: string;
            nodeB: string;
            label?: string;
            value?: number;
            minValue?: number;
            maxValue?: number;
            closed?: boolean;
            ratedVoltage?: number;
            ratedPower?: number;
            position?: [number?, number?, ...unknown[]];
        }[];
        wires?: {
            id: string;
            from: string;
            to: string;
            points?: [number?, number?, ...unknown[]][];
        }[];
        groundNode?: string;
        targetObservation?: string;
    } | {
        type: "chemistry_lab";
        title: string;
        summary: string;
        experimentId: "acid_base_indicator" | "acid_base_titration" | "precipitation_reaction" | "mass_conservation";
        experimentVersion: 1;
        stage: "middle_school" | "high_school" | "undergraduate";
        renderMode: "2d" | "3d";
        parameters: Record<string, number>;
        targetObservation?: string;
        controls?: string[];
        observations?: {
            id: string;
            label: string;
            value?: string | number;
            unit?: string;
            kind?: "text" | "state" | "scalar";
        }[];
    } | {
        type: "illustration";
        caption: string;
        prompt: string;
        style: "process" | "diagram" | "concept" | "comparison";
        id?: string;
        aspectRatio?: "1:1" | "16:9" | "9:16" | "4:3" | "3:4" | "3:2" | "2:3";
        imageId?: string;
        imageUrl?: string;
        guidedImage?: {
            type: "guided_image";
            schemaVersion: 1;
            id: string;
            intent: {
                id: string;
                title: string;
                language: string;
                learningGoal: string;
                assumedKnowledge: string;
                composition: string;
                parts: {
                    id: string;
                    label: string;
                    visualDescription: string;
                    teachingPoints: string[];
                    required: boolean;
                }[];
                relationships: {
                    from: string;
                    to: string;
                    meaning: string;
                }[];
            };
            image: {
                src: string;
                sha256: string;
                width: number;
                height: number;
            };
            segmentation: {
                regions: {
                    id: string;
                    partId: string;
                    label: string;
                    observedDescription: string;
                    polygons: {
                        outer: {
                            x: number;
                            y: number;
                        }[];
                        holes: {
                            x: number;
                            y: number;
                        }[][];
                    }[];
                }[];
                missingPartIds: string[];
                imageIssues: string[];
                geometryVersion?: "simple-shapes-v1";
            };
            cutouts: {
                regionId: string;
                src: string;
            }[];
            beats: {
                id: string;
                text: string;
                regionIds: string[];
                partIds: string[];
            }[];
            persona: {
                ref: string;
                name: string;
                avatarCode: string;
            };
            sourceFingerprint: string;
        };
    } | {
        type: "svg";
        caption: string;
        alt: string;
        svg: string;
        title?: string;
        intent?: {
            visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
            setup: string;
            learningGoal: string;
            expectedInsight: string;
            composition?: string;
            elements?: string[];
            relationships?: string[];
            labels?: string[];
            avoid?: string[];
        };
    } | {
        type: "placeholder";
        reason: string;
        componentType?: "check" | "step_sort" | "graph" | "chart" | "math_scene" | "interactive_html" | "mechanics_sandbox" | "circuit_sandbox" | "chemistry_lab" | "svg";
        description?: string;
        fallbackBody?: string;
        primaryLearningTargetId?: string;
        targetCognitiveEntityId?: string;
        evidenceDimension?: "memory" | "understanding";
        criterionRef?: string;
        contextDistance?: "same";
    } | {
        type: "svg_slot";
        intent: {
            visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
            setup: string;
            learningGoal: string;
            expectedInsight: string;
            composition?: string;
            elements?: string[];
            relationships?: string[];
            labels?: string[];
            avoid?: string[];
        };
        id?: string;
    } | {
        type: "stage";
        layout: "split-h" | "split-v" | "main+rail" | "stack";
        figures: any[];
        id?: string;
        presentation?: "compare" | "steps" | "focus";
    }, unknown>>;
    parseProviderOutput(content: string): {
        templateId: "general-question";
        content: {
            objects: [string?, string?, ...unknown[]];
            glyphs: [("object" | "question" | "paper" | "boat" | "read" | "recall")?, ("object" | "question" | "paper" | "boat" | "read" | "recall")?, ...unknown[]];
            observations: [string?, string?, ...unknown[]];
            question: string;
            goal: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-layers";
        content: {
            layers: {
                title: string;
                detail: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-flow";
        content: {
            nodes: string[];
            caption: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-compare";
        content: {
            names: [string?, string?, ...unknown[]];
            metrics: {
                label: string;
                unit: string;
                values: [number?, number?, ...unknown[]];
                max: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "general-summary";
        content: {
            concepts: [string?, string?, string?, ...unknown[]];
            center: string;
            transfer: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-pythagoras";
        content: {
            a: number;
            b: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-tangent";
        content: {
            coefficient: number;
            at: number;
            startDx: number;
            xmax: number;
            power?: 2 | 3;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-integral";
        content: {
            coefficient: number;
            end: number;
            power?: 1 | 2;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "math-probability";
        content: {
            total: number;
            condition: number;
            intersection: number;
            outsideTarget: number;
            conditionName: string;
            targetName: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "physics-forces";
        content: {
            mass: number;
            drive: number;
            resistance: number;
            duration: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "physics-waves";
        content: {
            amplitude1: number;
            amplitude2: number;
            cycles1: number;
            cycles2: number;
            phase2: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "physics-circuit";
        content: {
            voltage: number;
            resistance1: number;
            resistance2: number;
            topology: "series" | "parallel";
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "chemistry-reaction";
        content: {
            reactants: {
                label: string;
                atoms: {
                    id: string;
                    element: string;
                }[];
                bonds: {
                    from: string;
                    to: string;
                    order?: 1 | 2 | 3;
                }[];
            }[];
            products: {
                label: string;
                atoms: {
                    id: string;
                    element: string;
                }[];
                bonds: {
                    from: string;
                    to: string;
                    order?: 1 | 2 | 3;
                }[];
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "chemistry-titration";
        content: {
            acidMl: number;
            acidMolarity: number;
            baseMolarity: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "biology-mitosis";
        content: {
            chromosomeCount?: 2 | 4;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "biology-enzyme";
        content: {
            enzyme: string;
            substrate: string;
            products: [string?, string?, ...unknown[]];
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "geography-water";
        content: {
            title: string;
            nodes: [{
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, {
                label: string;
                glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
            }?, ...unknown[]];
            transitions: [string?, string?, string?, string?, string?, ...unknown[]];
            stages: [string?, string?, string?, ...unknown[]];
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "history-timeline";
        content: {
            range: [number?, number?, ...unknown[]];
            events: [{
                year: number;
                label: string;
                evidence: string;
                kind: "type" | "block" | "moon" | "telescope" | "event";
                approximate?: boolean;
            }?, {
                year: number;
                label: string;
                evidence: string;
                kind: "type" | "block" | "moon" | "telescope" | "event";
                approximate?: boolean;
            }?, ...unknown[]];
            caution: string;
            conclusion: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "language-syntax";
        content: {
            subject: string;
            verb: string;
            object: string;
            question: string;
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "language-perspective";
        content: {
            object: "door" | "book";
            firstPerson: string;
            observer: string;
            note: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "cs-sorting";
        content: {
            values: number[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "cs-recursion";
        content: {
            operation: "product" | "sum";
            start: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "music-score";
        type: "teaching";
        version: 1;
        id: string;
        title: string;
        content?: {
            source: "accepted-v2";
            block: {
                type: "music";
                version: 2;
                id: string;
                title: string;
                layout: "row" | "column" | "grid";
                notes: {
                    id: string;
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
                views: {
                    id: string;
                    kind: "staff" | "keyboard";
                    label: string;
                    notes: string[];
                    clef?: "treble" | "bass";
                    range?: string[];
                }[];
                marks?: {
                    id: string;
                    kind: "label" | "link" | "bracket" | "arrow";
                    label: string;
                    anchors: {
                        viewId: string;
                        noteId?: string;
                    }[];
                }[];
                clips?: {
                    id: string;
                    label: string;
                    tempo: number;
                    events: {
                        notes: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                    instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            };
            clipId?: string;
            repeat?: number;
        } | {
            id: string;
            title: string;
            groups: string[][];
            labels: string[];
            range: [string?, string?, ...unknown[]];
            beats?: 1 | 2;
            tempo?: number;
        };
    } | {
        templateId: "music-harmony";
        type: "teaching";
        version: 1;
        id: string;
        title: string;
        content?: {
            source: "accepted-v2";
            block: {
                type: "music";
                version: 2;
                id: string;
                title: string;
                layout: "row" | "column" | "grid";
                notes: {
                    id: string;
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
                views: {
                    id: string;
                    kind: "staff" | "keyboard";
                    label: string;
                    notes: string[];
                    clef?: "treble" | "bass";
                    range?: string[];
                }[];
                marks?: {
                    id: string;
                    kind: "label" | "link" | "bracket" | "arrow";
                    label: string;
                    anchors: {
                        viewId: string;
                        noteId?: string;
                    }[];
                }[];
                clips?: {
                    id: string;
                    label: string;
                    tempo: number;
                    events: {
                        notes: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                    instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            };
            clipId?: string;
            repeat?: number;
        } | {
            id: string;
            title: string;
            groups: string[][];
            labels: string[];
            range: [string?, string?, ...unknown[]];
            beats?: 1 | 2;
            tempo?: number;
        };
    } | {
        templateId: "economics-equilibrium";
        content: {
            demandIntercept: number;
            supplyIntercept: number;
            demandSlope: number;
            supplySlope: number;
            demandShift: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-timeline";
        content: {
            unit: string;
            events: {
                at: number;
                label: string;
                detail: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-cycle";
        content: {
            center: string;
            nodes: {
                label: string;
                process: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-decision";
        content: {
            question: string;
            branches: {
                condition: string;
                outcome: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-funnel";
        content: {
            unit: string;
            stages: {
                label: string;
                value: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-balance";
        content: {
            unit: string;
            left: {
                label: string;
                items: {
                    label: string;
                    value: number;
                }[];
            };
            right: {
                label: string;
                items: {
                    label: string;
                    value: number;
                }[];
            };
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-matrix";
        content: {
            columns: string[];
            rows: {
                label: string;
                values: number[];
            }[];
            unit: string;
            max: number;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-proportion";
        content: {
            whole: string;
            unit: string;
            parts: {
                label: string;
                value: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-network";
        content: {
            nodes: {
                id: string;
                label: string;
            }[];
            links: {
                from: string;
                to: string;
                label: string;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-counter";
        content: {
            label: string;
            unit: string;
            from: number;
            to: number;
            context: string;
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-interval";
        content: {
            label: string;
            unit: string;
            min: number;
            max: number;
            low: number;
            high: number;
            points: {
                label: string;
                value: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-hierarchy";
        content: {
            root: string;
            groups: {
                label: string;
                members: string[];
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        templateId: "visual-ranking";
        content: {
            unit: string;
            before: string;
            after: string;
            items: {
                label: string;
                before: number;
                after: number;
            }[];
        };
        type: "teaching";
        version: 1;
        id: string;
        title: string;
    } | {
        type: "music";
        version: 1;
        title: string;
        key: "C";
        meter: "2/4" | "3/4" | "4/4";
        tempo: number;
        keyboard: boolean;
        parts: {
            id: string;
            label: string;
            clef: "treble" | "bass";
            bars: {
                notes: {
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
            }[];
            instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
        }[];
        steps: {
            bars: number[];
            parts: string[];
            id: string;
            label: string;
            instruments?: {
                part: string;
                instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
            }[];
            focus?: string[];
            compare?: {
                bars: number[];
                parts: string[];
                label: string;
                instruments?: {
                    part: string;
                    instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            };
        }[];
        id?: string;
        notation?: "staff" | "both" | "jianpu";
    } | {
        type: "music";
        version: 2;
        id: string;
        title: string;
        layout: "row" | "column" | "grid";
        notes: {
            id: string;
            pitches: string[];
            beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
        }[];
        views: {
            id: string;
            kind: "staff" | "keyboard";
            label: string;
            notes: string[];
            clef?: "treble" | "bass";
            range?: string[];
        }[];
        marks?: {
            id: string;
            kind: "label" | "link" | "bracket" | "arrow";
            label: string;
            anchors: {
                viewId: string;
                noteId?: string;
            }[];
        }[];
        clips?: {
            id: string;
            label: string;
            tempo: number;
            events: {
                notes: string[];
                beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
            }[];
            instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
        }[];
    } | {
        type: "visual";
        kind: "process" | "cycle" | "layers" | "bars";
        title: string;
        items: {
            id: string;
            label: string;
            detail?: string;
            value?: number;
        }[];
        id?: string;
        unit?: string;
    } | {
        type: "heading";
        text: string;
        level?: 2 | 3;
        topicId?: string;
    } | {
        type: "paragraph";
        text: string;
        cue?: {
            target: string;
            music?: {
                figureId: string;
                clipId: string;
                repeat?: number;
            };
            targetIds?: string[];
            op?: "highlight" | "window";
            regionIds?: string[];
            figureId?: string;
        };
    } | {
        type: "code";
        code: string;
        id?: string;
        language?: string;
        parts?: {
            text: string;
            id?: string;
        }[];
        regions?: {
            id: string;
            match: string;
        }[];
    } | {
        type: "conversation";
        turns: {
            speaker: string;
            text: string;
        }[];
        id?: string;
        title?: string;
    } | {
        type: "callout";
        variant: "example" | "warning" | "definition" | "tip";
        body: string;
        id?: string;
        title?: string;
    } | {
        type: "accordion";
        title: string;
        body: string;
        id?: string;
    } | {
        type: "check";
        question: string;
        explanation: string;
        learningTargetIds: string[];
        evidenceDimension: "memory" | "understanding" | "application";
        criterionRef: string;
        contextDistance: "same" | "near";
        checkId?: string;
        questionType?: "mcq" | "mcq_multi" | "true_false";
        options?: string[];
        correctIndex?: number;
        correctIndices?: number[];
        correctAnswer?: boolean;
        primaryLearningTargetId?: string;
        targetCognitiveEntityId?: string;
    } | {
        type: "compare";
        left: {
            label: string;
            points: string[];
            id?: string;
        };
        right: {
            label: string;
            points: string[];
            id?: string;
        };
        id?: string;
        sides?: {
            label: string;
            points: string[];
            id?: string;
        }[];
    } | {
        type: "step_sort";
        title: string;
        correct_sequence: {
            id: string;
            content: string;
            order: number;
        }[];
        dependency_hint: string;
    } | {
        type: "graph";
        variant: "process_flow" | "concept_map";
        title: string;
        direction: "TB" | "LR" | "RADIAL";
        nodes: {
            id: string;
            label: string;
            kind: "start" | "end" | "process" | "io" | "outcome" | "source" | "decision" | "system" | "concept";
            emphasis: "primary" | "normal";
            description?: string;
            groupId?: string;
        }[];
        edges: {
            id: string;
            from: string;
            to: string;
            arrow: "none" | "forward" | "backward" | "both";
            label?: string;
        }[];
        groups?: {
            id: string;
            label: string;
            description?: string;
        }[];
        caption?: string;
    } | {
        type: "chart";
        title: string;
        chartType: "area" | "line" | "bar" | "pie" | "scatter";
        data: Record<string, string | number>[];
        series: {
            dataKey: string;
            name: string;
            color?: string;
            unit?: string;
        }[];
        showLegend: boolean;
        donut: boolean;
        summary: string;
        categoryKey?: string;
        xKey?: string;
        yKey?: string;
        xLabel?: string;
        yLabel?: string;
        unit?: string;
    } | {
        type: "math_scene";
        title: string;
        dimension: "2d" | "3d";
        coordinateSystem: "cartesian" | "polar";
        xRange: [number?, number?, ...unknown[]];
        yRange: [number?, number?, ...unknown[]];
        objects: ({
            kind: "point";
            id: string;
            position?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "vector";
            id: string;
            start?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            end?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            relation?: {
                operation: "sum" | "difference";
                operands: [string?, string?, ...unknown[]];
            } | {
                operation: "scale";
                operand: string;
                factor: number;
                factorParameter?: string;
            };
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "segment";
            id: string;
            from?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            to?: [number?, number?, ...unknown[]] | [number?, number?, number?, ...unknown[]];
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "function";
            expression: string;
            variable: "x";
            domain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "parametric";
            xExpression: string;
            yExpression: string;
            parameter: "t";
            domain: [number?, number?, ...unknown[]];
            id: string;
            zExpression?: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "polar_function";
            expression: string;
            variable: "theta";
            domain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        } | {
            kind: "surface";
            expression: string;
            variables: ["x"?, "y"?, ...unknown[]];
            xDomain: [number?, number?, ...unknown[]];
            yDomain: [number?, number?, ...unknown[]];
            id: string;
            label?: string;
            color?: string;
            dashed?: boolean;
            opacity?: number;
            draggable?: boolean;
        })[];
        showGrid: boolean;
        showAxes: boolean;
        summary: string;
        zRange?: [number?, number?, ...unknown[]];
        parameters?: {
            id: string;
            name: string;
            min: number;
            max: number;
            step: number;
            default: number;
        }[];
        camera?: {
            azimuth: number;
            elevation: number;
        };
    } | {
        type: "interactive_html";
        title: string;
        summary: string;
        html: string;
        visualKind?: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
        height?: number;
    } | {
        type: "mechanics_sandbox";
        title: string;
        summary: string;
        sandboxType: "collision_1d" | "inclined_plane" | "pendulum" | "spring_oscillator";
        objects: {
            id: string;
            name: string;
            mass: number;
            color?: string;
            radius?: number;
            width?: number;
            height?: number;
            initialPosition?: number;
            initialVelocity?: number;
        }[];
        showVectors: boolean;
        showEnergyChart: boolean;
        parameters?: {
            id: string;
            name: string;
            unit: string;
            min: number;
            max: number;
            step: number;
            default: number;
        }[];
        targetObservation?: string;
    } | {
        type: "circuit_sandbox";
        title: string;
        summary: string;
        circuit?: {
            id: string;
            kind: "battery" | "resistor" | "rheostat" | "switch" | "bulb" | "ammeter" | "voltmeter";
            label?: string;
            v?: number;
            ohm?: number;
            min?: number;
            max?: number;
            closed?: boolean;
            ratedV?: number;
            ratedW?: number;
        } | {
            series: unknown[];
        } | {
            parallel: unknown[];
        };
        components?: {
            id: string;
            kind: "battery" | "resistor" | "rheostat" | "switch" | "bulb" | "ammeter" | "voltmeter" | "voltage_source" | "potentiometer" | "lightbulb";
            nodeA: string;
            nodeB: string;
            label?: string;
            value?: number;
            minValue?: number;
            maxValue?: number;
            closed?: boolean;
            ratedVoltage?: number;
            ratedPower?: number;
            position?: [number?, number?, ...unknown[]];
        }[];
        wires?: {
            id: string;
            from: string;
            to: string;
            points?: [number?, number?, ...unknown[]][];
        }[];
        groundNode?: string;
        targetObservation?: string;
    } | {
        type: "chemistry_lab";
        title: string;
        summary: string;
        experimentId: "acid_base_indicator" | "acid_base_titration" | "precipitation_reaction" | "mass_conservation";
        experimentVersion: 1;
        stage: "middle_school" | "high_school" | "undergraduate";
        renderMode: "2d" | "3d";
        parameters: Record<string, number>;
        targetObservation?: string;
        controls?: string[];
        observations?: {
            id: string;
            label: string;
            value?: string | number;
            unit?: string;
            kind?: "text" | "state" | "scalar";
        }[];
    } | {
        type: "illustration";
        caption: string;
        prompt: string;
        style: "process" | "diagram" | "concept" | "comparison";
        id?: string;
        aspectRatio?: "1:1" | "16:9" | "9:16" | "4:3" | "3:4" | "3:2" | "2:3";
        imageId?: string;
        imageUrl?: string;
        guidedImage?: {
            type: "guided_image";
            schemaVersion: 1;
            id: string;
            intent: {
                id: string;
                title: string;
                language: string;
                learningGoal: string;
                assumedKnowledge: string;
                composition: string;
                parts: {
                    id: string;
                    label: string;
                    visualDescription: string;
                    teachingPoints: string[];
                    required: boolean;
                }[];
                relationships: {
                    from: string;
                    to: string;
                    meaning: string;
                }[];
            };
            image: {
                src: string;
                sha256: string;
                width: number;
                height: number;
            };
            segmentation: {
                regions: {
                    id: string;
                    partId: string;
                    label: string;
                    observedDescription: string;
                    polygons: {
                        outer: {
                            x: number;
                            y: number;
                        }[];
                        holes: {
                            x: number;
                            y: number;
                        }[][];
                    }[];
                }[];
                missingPartIds: string[];
                imageIssues: string[];
                geometryVersion?: "simple-shapes-v1";
            };
            cutouts: {
                regionId: string;
                src: string;
            }[];
            beats: {
                id: string;
                text: string;
                regionIds: string[];
                partIds: string[];
            }[];
            persona: {
                ref: string;
                name: string;
                avatarCode: string;
            };
            sourceFingerprint: string;
        };
    } | {
        type: "svg";
        caption: string;
        alt: string;
        svg: string;
        title?: string;
        intent?: {
            visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
            setup: string;
            learningGoal: string;
            expectedInsight: string;
            composition?: string;
            elements?: string[];
            relationships?: string[];
            labels?: string[];
            avoid?: string[];
        };
    } | {
        type: "placeholder";
        reason: string;
        componentType?: "check" | "step_sort" | "graph" | "chart" | "math_scene" | "interactive_html" | "mechanics_sandbox" | "circuit_sandbox" | "chemistry_lab" | "svg";
        description?: string;
        fallbackBody?: string;
        primaryLearningTargetId?: string;
        targetCognitiveEntityId?: string;
        evidenceDimension?: "memory" | "understanding";
        criterionRef?: string;
        contextDistance?: "same";
    } | {
        type: "svg_slot";
        intent: {
            visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
            setup: string;
            learningGoal: string;
            expectedInsight: string;
            composition?: string;
            elements?: string[];
            relationships?: string[];
            labels?: string[];
            avoid?: string[];
        };
        id?: string;
    } | {
        type: "stage";
        layout: "split-h" | "split-v" | "main+rail" | "stack";
        figures: any[];
        id?: string;
        presentation?: "compare" | "steps" | "focus";
    };
};
/**
 * Last-resort step_sort from numbered / arrow-separated intent text.
 * CI descriptions often already list the ordered steps.
 */
export declare function synthesizeStepSortFromIntent(description: string): Extract<InteractiveBlock, {
    type: "step_sort";
}> | null;
export declare function replaceComponentIntentLines(text: string, compiledByLine: ReadonlyMap<number, InteractiveBlock | null>): string;
declare function compileComponentIntentOnce(params: {
    intent: ComponentIntent;
    unitTitle: string;
    language: string;
    context: string;
    model?: BaseChatModel;
    signal?: AbortSignal;
    meta?: Record<string, unknown>;
    onPartial?: (block: InteractiveBlock) => void | Promise<void>;
    /** When set, compact the compile prompt against the durable unit authoring transcript. */
    authoringScope?: {
        userId: string;
        goalId: string;
        unitId: string;
    };
}): Promise<InteractiveBlock | null>;
/**
 * Compile a component and semantically audit math scenes. Repairs are fresh
 * bounded compiler turns: the stable capability instruction remains the same,
 * while the prior scene and audit contract stay in the volatile invocation.
 */
export declare function compileComponentIntent(params: Parameters<typeof compileComponentIntentOnce>[0]): Promise<InteractiveBlock | null>;
export {};
