import { z } from "zod";
import { type TopicCategory } from "../../../common/src/index.js";
import { generatableComplexInteractiveBlockTypeSchema, type ComplexInteractiveBlockType } from "./schemas.js";
export declare const componentCategoryIdSchema: z.ZodEnum<{
    chemistry_lab: "chemistry_lab";
    base: "base";
    math_visualization: "math_visualization";
    data_visualization: "data_visualization";
    mechanics_lab: "mechanics_lab";
    circuit_lab: "circuit_lab";
}>;
export type ComponentCategoryId = z.infer<typeof componentCategoryIdSchema>;
/**
 * Most course sections need only base teaching blocks. The base family already
 * includes svg_slot, so visual explanations do not need a default category.
 */
export declare const GENERAL_INTERACTIVE_CATEGORIES: readonly ComponentCategoryId[];
export declare const STANDARD_INTERACTIVE_CATEGORIES: readonly ("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[];
/** Optional category for genuine coordinate-based mathematical interaction. */
export declare const SPECIALIZED_INTERACTIVE_CATEGORIES: readonly ["math_visualization"];
export declare const componentCategorySelectionBaseSchema: z.ZodObject<{
    mainCategory: z.ZodEnum<{
        chemistry_lab: "chemistry_lab";
        base: "base";
        math_visualization: "math_visualization";
        data_visualization: "data_visualization";
        mechanics_lab: "mechanics_lab";
        circuit_lab: "circuit_lab";
    }>;
    enabledCategories: z.ZodPipe<z.ZodArray<z.ZodEnum<{
        chemistry_lab: "chemistry_lab";
        base: "base";
        math_visualization: "math_visualization";
        data_visualization: "data_visualization";
        mechanics_lab: "mechanics_lab";
        circuit_lab: "circuit_lab";
    }>>, z.ZodTransform<("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[], ("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[]>>;
    rationale: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const generatablePlannedComponentDraftSchema: z.ZodObject<{
    componentType: z.ZodEnum<{
        chart: "chart";
        math_scene: "math_scene";
        mechanics_sandbox: "mechanics_sandbox";
        circuit_sandbox: "circuit_sandbox";
        chemistry_lab: "chemistry_lab";
    }>;
    description: z.ZodString;
}, z.core.$strip>;
export type GeneratableMaterialComponentType = z.infer<typeof generatableComplexInteractiveBlockTypeSchema>;
export declare const generatableMaterialComponentTypes: ("chart" | "math_scene" | "mechanics_sandbox" | "circuit_sandbox" | "chemistry_lab")[];
/** Stored/read path for planned complex components. */
export declare const plannedComponentDraftSchema: z.ZodObject<{
    componentType: z.ZodEnum<{
        chart: "chart";
        math_scene: "math_scene";
        mechanics_sandbox: "mechanics_sandbox";
        circuit_sandbox: "circuit_sandbox";
        chemistry_lab: "chemistry_lab";
    }>;
    description: z.ZodString;
}, z.core.$strip>;
export declare const plannedComponentSchema: z.ZodObject<{
    componentType: z.ZodEnum<{
        chart: "chart";
        math_scene: "math_scene";
        mechanics_sandbox: "mechanics_sandbox";
        circuit_sandbox: "circuit_sandbox";
        chemistry_lab: "chemistry_lab";
    }>;
    description: z.ZodString;
    id: z.ZodString;
}, z.core.$strip>;
/** Provider-facing selection; stable component ids are injected by the server. */
export declare const componentCategorySelectionBindingSchema: z.ZodObject<{
    mainCategory: z.ZodEnum<{
        chemistry_lab: "chemistry_lab";
        base: "base";
        math_visualization: "math_visualization";
        data_visualization: "data_visualization";
        mechanics_lab: "mechanics_lab";
        circuit_lab: "circuit_lab";
    }>;
    enabledCategories: z.ZodPipe<z.ZodArray<z.ZodEnum<{
        chemistry_lab: "chemistry_lab";
        base: "base";
        math_visualization: "math_visualization";
        data_visualization: "data_visualization";
        mechanics_lab: "mechanics_lab";
        circuit_lab: "circuit_lab";
    }>>, z.ZodTransform<("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[], ("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[]>>;
    rationale: z.ZodOptional<z.ZodString>;
    plannedComponents: z.ZodOptional<z.ZodArray<z.ZodObject<{
        componentType: z.ZodEnum<{
            chart: "chart";
            math_scene: "math_scene";
            mechanics_sandbox: "mechanics_sandbox";
            circuit_sandbox: "circuit_sandbox";
            chemistry_lab: "chemistry_lab";
        }>;
        description: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip>;
/** Canonical selection stored on SqPreview. */
export declare const componentCategorySelectionSchema: z.ZodObject<{
    mainCategory: z.ZodEnum<{
        chemistry_lab: "chemistry_lab";
        base: "base";
        math_visualization: "math_visualization";
        data_visualization: "data_visualization";
        mechanics_lab: "mechanics_lab";
        circuit_lab: "circuit_lab";
    }>;
    enabledCategories: z.ZodPipe<z.ZodArray<z.ZodEnum<{
        chemistry_lab: "chemistry_lab";
        base: "base";
        math_visualization: "math_visualization";
        data_visualization: "data_visualization";
        mechanics_lab: "mechanics_lab";
        circuit_lab: "circuit_lab";
    }>>, z.ZodTransform<("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[], ("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[]>>;
    rationale: z.ZodOptional<z.ZodString>;
    plannedComponents: z.ZodOptional<z.ZodArray<z.ZodObject<{
        componentType: z.ZodEnum<{
            chart: "chart";
            math_scene: "math_scene";
            mechanics_sandbox: "mechanics_sandbox";
            circuit_sandbox: "circuit_sandbox";
            chemistry_lab: "chemistry_lab";
        }>;
        description: z.ZodString;
        id: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip>;
export type PlannedComponent = z.infer<typeof plannedComponentSchema>;
export type ComponentCategorySelection = z.infer<typeof componentCategorySelectionSchema>;
export type MaterialGenerationPolicy = {
    allowedComponentTypes: ComplexInteractiveBlockType[];
    maxComponentCount: number;
    allowIllustrations: boolean;
    minIllustrationCount?: 0 | 1;
    maxIllustrationCount?: number;
    /** Desktop-dev 锐语腹黑: compile leftover svg/math_scene as illustrations. */
    replaceInLessonVisualsWithIllustrations?: boolean;
    plannedComponents?: PlannedComponent[];
};
/**
 * In-lesson teaching visuals. Charts are legacy read/compile support only;
 * new course content uses svg_slot for static explanations and keeps
 * math_scene as the exceptional renderer for genuine coordinate interaction.
 */
export declare const IN_LESSON_VISUAL_COMPONENT_TYPES: Set<"step_sort" | "graph" | "chart" | "math_scene" | "mechanics_sandbox" | "circuit_sandbox" | "chemistry_lab">;
/** Safety cap only — prompts treat math scenes like SVG (no separate quota). */
export declare const MAX_IN_LESSON_VISUAL_COMPONENTS = 24;
/** Compiled interactives that belong in the optional unit lab, not the lesson. */
export declare const LAB_ACTIVITY_COMPONENT_TYPES: Set<"step_sort" | "graph" | "chart" | "math_scene" | "mechanics_sandbox" | "circuit_sandbox" | "chemistry_lab">;
/** @deprecated Use LAB_ACTIVITY_COMPONENT_TYPES; labs are no longer in-material sections. */
export declare const STANDALONE_SECTION_COMPONENT_TYPES: Set<"step_sort" | "graph" | "chart" | "math_scene" | "mechanics_sandbox" | "circuit_sandbox" | "chemistry_lab">;
export declare function isInLessonVisualComponentType(type: string): type is ComplexInteractiveBlockType;
export declare function isLabActivityComponentType(type: string): type is ComplexInteractiveBlockType;
export declare function plannedInLessonVisualComponents(planned: readonly PlannedComponent[] | undefined): PlannedComponent[];
type ComponentCategoryDefinition = {
    id: ComponentCategoryId;
    label: string;
    purpose: string;
    tags: string[];
    dslContract: string;
    topicCategories?: TopicCategory[];
    quantitativeOnly?: boolean;
};
/** Shared authoring/selection rule: match the display to the teaching object; types are peers. */
export declare const VISUAL_RENDERER_PRIORITY_RULE = "Visual renderer matching: display types are peers \u2014 pick the board whose job matches this topic, not a preferred default. Callout for a definition, example, tip, or warning. Compare for side-by-side contrast. Accordion for optional extra detail. Conversation for a spoken exchange. Code for source or other monospace text. svg_slot for a schematic picture the learner should see (process flows, concept maps, static examples, physical ray/path diagrams, simple geometry constructions, simple quantitative comparisons, explanatory schematics); begin with a static picture, and add lightweight native SVG animation or interaction only when it directly improves the explanation. math_scene when a genuine coordinate plot\u2014especially functions and vectors\u2014or changing a parameter / dragging a mathematical object is the teaching object. Do not use math_scene merely because a schematic contains straight lines, arrows, points, geometric-looking objects, or crossing paths. Illustration (when enabled) when visible appearance, spatial context, concrete scenes or changes within them carry the explanation, including people, anatomy, organic forms and physical processes. A picture can be the main teaching evidence even when simple shapes could approximate the subject; do not replace useful visual evidence with prose or labeled boxes. Never skip a needed diagram to stay on text, and never add a decorative picture. Course content has no chart component: do not emit chart data or a chart block. Interactive HTML playgrounds and domain sandboxes belong in the unit lab, not the lesson.";
export declare const COMPONENT_CATEGORY_REGISTRY: Record<ComponentCategoryId, ComponentCategoryDefinition>;
/**
 * MiniMax and other OpenAI-compatible endpoints often return catalog labels,
 * component type ids, or omit enabledCategories even when the tool schema is
 * present. Canonicalize those payloads before authoritative Zod validation.
 */
export declare function normalizeComponentCategorySelectionInput(value: unknown): unknown;
/** Compact model-response schema for unit.component_category_selection. */
export declare const componentCategorySelectionResponseSchema: z.ZodPreprocess<z.ZodObject<{
    mainCategory: z.ZodEnum<{
        chemistry_lab: "chemistry_lab";
        base: "base";
        math_visualization: "math_visualization";
        data_visualization: "data_visualization";
        mechanics_lab: "mechanics_lab";
        circuit_lab: "circuit_lab";
    }>;
    enabledCategories: z.ZodPipe<z.ZodArray<z.ZodEnum<{
        chemistry_lab: "chemistry_lab";
        base: "base";
        math_visualization: "math_visualization";
        data_visualization: "data_visualization";
        mechanics_lab: "mechanics_lab";
        circuit_lab: "circuit_lab";
    }>>, z.ZodTransform<("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[], ("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[]>>;
    rationale: z.ZodOptional<z.ZodString>;
}, z.core.$strip>>;
export declare const DEFAULT_COMPONENT_SELECTION: ComponentCategorySelection;
export declare function defaultComponentSelectionForTopic(topicCategory: TopicCategory): ComponentCategorySelection;
export declare function componentCategoryCatalogPrompt(topicCategory?: TopicCategory): string;
export declare function normalizeComponentSelection(value: unknown): ComponentCategorySelection;
export declare function normalizeComponentSelectionForTopic(value: unknown, topicCategory: TopicCategory): ComponentCategorySelection;
/** Removes admin-disabled types from new plans while preserving stored render support. */
export declare function applyMaterialComponentAvailability(selection: ComponentCategorySelection, disabledTypes: readonly string[]): ComponentCategorySelection;
export declare function hasStoredComponentSelection(sqJson: string): boolean;
export declare function hasStoredComponentPlan(sqJson: string): boolean;
export declare function componentDslContext(selection: ComponentCategorySelection): string;
/** Compact JSON-authoring guide. Omits legacy CI‖ DSL so material calls can attend to matching renderers. */
export declare function matchingRendererAuthoringGuide(selection: ComponentCategorySelection, allowedComponentTypes?: readonly ComplexInteractiveBlockType[]): string;
export declare function componentSelectionFromSqJson(sqJson: string, topicCategory?: TopicCategory): ComponentCategorySelection;
export declare function materialGenerationPolicyFromSelection(selection: ComponentCategorySelection, topicCategory: TopicCategory | undefined, allowIllustrations: boolean, disabledComponentTypes?: readonly string[], options?: {
    maxIllustrationCount?: number;
    minIllustrationCount?: 0 | 1;
    replaceInLessonVisualsWithIllustrations?: boolean;
}): MaterialGenerationPolicy;
export declare function materialGenerationPolicyFromSqJson(sqJson: string, topicCategory: TopicCategory | undefined, allowIllustrations: boolean): MaterialGenerationPolicy;
export declare function interactiveComponentGuidance(selection: ComponentCategorySelection, topicCategory?: TopicCategory): string;
export {};
