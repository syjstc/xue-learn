import { z } from "zod";
import { type InteractiveBlock } from "./schemas.js";
export type InlineCheckEvidenceDimension = "memory" | "understanding";
export type InlineCheckQuestionType = "mcq" | "mcq_multi" | "true_false";
export type InlineCheckPlan = {
    slotRef: string;
    questionType: InlineCheckQuestionType;
    primaryLearningTargetId: string;
    targetCognitiveEntityId: string;
    evidenceDimension: InlineCheckEvidenceDimension;
    criterionRef: string;
    contextDistance: "same";
    targetLabel: string;
    targetExplanation?: string;
    learningObjective?: string;
    assessmentCriterion: string;
    placementHint: string;
    /** Prompt hint when reusing the same target with a different question shape. */
    judgmentAngleHint?: string;
};
export type CompiledInlineCheck = Extract<InteractiveBlock, {
    type: "check";
}>;
export type InlineCheckContext = {
    /** Canonical, published SQ preview JSON. Draft targets must not be supplied. */
    sqJson: string;
    /** Server-authoritative evidence bindings loaded from published targets. */
    authorityBindings?: readonly InlineCheckAuthorityBinding[];
    /** Section order for deterministic two-question type rotation. */
    sectionOrderIndex?: number;
};
export type InlineCheckAuthorityBinding = {
    learningTargetId: string;
    targetCognitiveEntityId: string;
    evidenceDimension: InlineCheckEvidenceDimension;
    criterionRef: string;
    assessmentCriterion?: string;
};
export declare const generatedInlineCheckItemBindingSchema: z.ZodObject<{
    questionType: z.ZodEnum<{
        mcq: "mcq";
        mcq_multi: "mcq_multi";
        true_false: "true_false";
    }>;
    question: z.ZodString;
    options: z.ZodOptional<z.ZodArray<z.ZodString>>;
    correctIndex: z.ZodOptional<z.ZodNumber>;
    correctIndices: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
    correctAnswer: z.ZodOptional<z.ZodBoolean>;
    explanation: z.ZodString;
}, z.core.$strip>;
export declare const generatedInlineCheckItemSchema: z.ZodObject<{
    questionType: z.ZodEnum<{
        mcq: "mcq";
        mcq_multi: "mcq_multi";
        true_false: "true_false";
    }>;
    question: z.ZodString;
    options: z.ZodOptional<z.ZodArray<z.ZodString>>;
    correctIndex: z.ZodOptional<z.ZodNumber>;
    correctIndices: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
    correctAnswer: z.ZodOptional<z.ZodBoolean>;
    explanation: z.ZodString;
}, z.core.$strip>;
export declare function inlineCheckAuthorityBindingsFromTargets(targets: readonly {
    localRef: string;
    assessmentCriteria: readonly {
        ref: string;
        text: string;
    }[];
    requirements: readonly {
        cognitiveEntityId: string;
        dimension: string;
    }[];
}[]): InlineCheckAuthorityBinding[];
/**
 * Deterministically selects evidence-capable published targets for inline checks.
 * Targets without both an assessment criterion and a cognitive entity are skipped;
 * this makes empty/legacy SQ payloads safely produce zero checks.
 */
export declare function planCourseMaterialInlineChecks(context: InlineCheckContext): InlineCheckPlan[];
export declare function inlineCheckAnchorGuidance(plans: InlineCheckPlan[]): string;
/** Replaces streamed QREF anchors and optionally appends compiled omitted checks. */
export declare function replaceInlineCheckReferenceLines(params: {
    text: string;
    plans: InlineCheckPlan[];
    compiledBySlot: ReadonlyMap<string, CompiledInlineCheck | null>;
    includeOmitted?: boolean;
}): string;
export declare function compileInlineCheckContent(plan: InlineCheckPlan, content: {
    question: string;
    explanation: string;
    options?: string[];
    correctIndex?: number;
    correctIndices?: number[];
    correctAnswer?: boolean;
}): CompiledInlineCheck;
export type PrepareCourseMaterialInlineCheckArrayInput = {
    plans: readonly InlineCheckPlan[];
    unitTitle: string;
    language: string;
    context: string;
};
export type PreparedCourseMaterialInlineCheckArray = {
    operation: "unit.section_mini_test";
    prompt: string;
    questionCount: number;
    itemSchema: typeof generatedInlineCheckItemSchema;
    bindingItemSchema: typeof generatedInlineCheckItemBindingSchema;
    resultSchema: z.ZodType<z.infer<typeof generatedInlineCheckItemBindingSchema>[]>;
    parseProviderOutput(content: string): CompiledInlineCheck[];
};
/**
 * Prepares the provider-independent section mini-test authoring contract.
 *
 * The topology supplies only transport. Question type/order and all evidence
 * authority fields are rebound from the server-owned plans before publication.
 */
export declare function prepareCourseMaterialInlineCheckArray(input: PrepareCourseMaterialInlineCheckArrayInput): PreparedCourseMaterialInlineCheckArray;
/** Authors the complete test question array in one normal LLM request. */
export declare function compileCourseMaterialInlineCheckArray(params: {
    plans: readonly InlineCheckPlan[];
    unitTitle: string;
    language: string;
    context: string;
    onPartialChecks?: (partial: {
        checks: CompiledInlineCheck[];
        completeQuestionCount: number;
        placeholderQuestionCount: number;
    }) => void | Promise<void>;
    signal?: AbortSignal;
    operation?: string;
    meta?: Record<string, unknown>;
}): Promise<CompiledInlineCheck[]>;
/** Forced tool-call compiler. Only content comes from the model; evidence fields are injected. */
export declare function compileCourseMaterialInlineCheck(params: {
    plan: InlineCheckPlan;
    unitTitle: string;
    language: string;
    context: string;
    /** Questions already used by sibling checks and forbidden for this retry. */
    avoidQuestions?: readonly string[];
    signal?: AbortSignal;
    operation?: string;
    meta?: Record<string, unknown>;
}): Promise<CompiledInlineCheck | null>;
