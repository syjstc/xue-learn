import type { Embeddings } from "@langchain/core/embeddings";
import type { BaseChatModel } from "@langchain/core/language_models/chat_models";
export declare function getChatModel(options?: {
    maxTokens?: number;
    cachePrefix?: string;
    strictStructuredOutput?: boolean;
}): Promise<BaseChatModel>;
export declare function getEmbeddings(): Promise<Embeddings>;
