import { cornellSchema } from "./schemas.js";
import type { z } from "zod";
type CornellNotes = z.infer<typeof cornellSchema>;
export type CornellDslInvalidLine = {
    lineNumber: number;
    line: string;
    reason: string;
};
export declare function sanitizeCornellDslText(text: string): string;
export declare function parseCornellDslPreview(text: string): {
    cornell: CornellNotes;
    completeLineCount: number;
    validLineCount: number;
} | null;
export declare class CornellDslParseError extends Error {
    readonly invalidLines: CornellDslInvalidLine[];
    constructor(invalidLines: CornellDslInvalidLine[]);
}
export declare function getCornellDslInvalidLines(text: string): CornellDslInvalidLine[];
export declare function applyCornellDslLineReplacements(text: string, replacements: {
    lineNumber: number;
    line: string;
}[]): string;
export declare function parseCornellDsl(text: string): CornellNotes;
export type CornellDslPartial = {
    cornell: CornellNotes;
    completeLineCount: number;
};
export declare class CornellDslStreamAccumulator {
    private completeText;
    private pending;
    private lastValidLineCount;
    append(delta: string): CornellDslPartial | null;
}
export declare const CORNELL_DSL_CONTRACT = "Output ONLY CornellNotes DSL lines. No JSON, markdown fences, or commentary.\nUse \"\u2016\" (U+2016 DOUBLE VERTICAL LINE) as the field separator. Do not use \"|\".\nIf a text field must contain \"\u2016\", wrap that field as a JSON string.\nLaTeX \\| and $...$ inline math may contain pipes and other characters.\nLine types:\nN\u2016note paragraph or bullet (1+ lines; distilled study notes, not the full textbook)\nCU\u2016recall cue or keyword prompt (1+ lines)\nSM\u20162-4 sentence synthesis summary (exactly one required line, last)\nUntagged lines after a tagged line continue the previous field (lists, code fences, multi-paragraph notes).";
export {};
