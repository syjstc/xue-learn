import type { BaseMessage } from "@langchain/core/messages";
import type { TopicCategory } from "../../../common/src/index.js";
import type { LearningSystemSubject } from "../learning-systems/types.js";
export type ChatInvokeOptions = {
    operation: string;
    meta?: Record<string, unknown>;
    topicCategory?: TopicCategory | null;
    contextSubject?: LearningSystemSubject;
    contextQuery?: string;
};
/** Invoke chat model with full request/response logging. */
export declare function invokeChat(prompt: string, options: ChatInvokeOptions): Promise<BaseMessage>;
