import type { UnitContentRevisionRepository } from "../../../domain/src/index.js";
export declare function configureContentRevisionPersistence(next: UnitContentRevisionRepository | null): void;
export declare function requireContentRevisionPersistence(): UnitContentRevisionRepository;
