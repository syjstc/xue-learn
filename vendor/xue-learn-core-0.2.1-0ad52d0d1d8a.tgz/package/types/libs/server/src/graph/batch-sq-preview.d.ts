import type { BatchContentGenerationRepository, LearnerStateMemoryInvalidationRepository } from "../../../domain/src/index.js";
import type { TrackedWorkContext } from "../generation/tracked-sse.js";
export type BatchSqFailure = {
    unitId: string;
    title: string;
    error: string;
};
export type BatchSqResult = {
    totalLessons: number;
    processed: number;
    succeeded: number;
    skipped: number;
    failed: BatchSqFailure[];
    cancelled?: boolean;
};
export declare function runBatchSqPreview(ctx: TrackedWorkContext, goalId: string, repository: BatchContentGenerationRepository, options?: {
    skipExisting?: boolean;
    learnerStateMemoryInvalidation?: LearnerStateMemoryInvalidationRepository;
}): Promise<BatchSqResult>;
