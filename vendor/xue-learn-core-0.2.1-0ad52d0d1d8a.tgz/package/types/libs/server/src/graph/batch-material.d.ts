import type { BatchContentGenerationRepository, LearnerStateMemoryInvalidationRepository, MaterialEnrichmentRepository, MaterialReplacementRepository } from "../../../domain/src/index.js";
import type { TrackedWorkContext } from "../generation/tracked-sse.js";
export type BatchMaterialFailure = {
    unitId: string;
    title: string;
    error: string;
};
export type BatchMaterialResult = {
    selectedCount: number;
    processed: number;
    succeeded: number;
    skipped: number;
    failed: BatchMaterialFailure[];
    cancelled?: boolean;
};
export declare function runBatchMaterial(ctx: TrackedWorkContext, goalId: string, repository: BatchContentGenerationRepository, options: {
    unitIds: string[];
    skipExisting?: boolean;
}, materialReplacement: MaterialReplacementRepository, materialEnrichment: MaterialEnrichmentRepository, learnerStateMemoryInvalidation?: LearnerStateMemoryInvalidationRepository): Promise<BatchMaterialResult>;
