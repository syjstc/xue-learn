import type { SqPreview } from "../llm/schemas.js";
export type CanonicalSqlearningTarget = {
    id: string;
    localRef: string;
    title: string;
    description?: string;
    explanation?: string;
    learningObjective: string;
    assessmentCriteria: string[];
    requirements?: Array<{
        entityId: string;
    }>;
    importance: string;
    importanceWeight: number;
    difficulty: string;
    targetCognitiveLevel: string;
    rationale?: string;
    isEntry: boolean;
    isExit: boolean;
};
export declare function assertCanonicalLearningTargetsFitLesson(canonicalPoints: CanonicalSqlearningTarget[], params: {
    contentLanguage?: string | null;
    unitTitle: string;
    contentSummary?: string | null;
}): void;
export declare function normalizeSectionOutlineCheckpoints<T extends {
    checkpointAfter: boolean;
}>(items: T[]): T[];
/**
 * Overlay the durable learning-target spine on an SQ preview.
 *
 * The model may stream learning-target lines in a different order while it is composing the
 * survey. Learners must never observe that draft order: SQ owns the outline and
 * guiding questions, while the published model owns target identity, definition, and
 * order.
 */
export declare function applyCanonicalLearningTargetsToSq(sq: SqPreview, canonicalPoints: CanonicalSqlearningTarget[], lesson?: {
    contentLanguage?: string | null;
    unitTitle: string;
    contentSummary?: string | null;
}): SqPreview;
