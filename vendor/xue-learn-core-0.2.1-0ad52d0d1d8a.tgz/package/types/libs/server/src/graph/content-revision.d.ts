/**
 * Increment LearningUnit.contentRevision when stable generated content changes.
 * Call inside the same transaction as the content write when possible.
 */
export declare function bumpUnitContentRevision(unitId: string, _compatibilityClient?: unknown): Promise<number>;
export declare class StaleUnitContentRevisionError extends Error {
    readonly unitId: string;
    readonly expectedContentRevision: number;
    readonly currentContentRevision?: number;
    constructor(unitId: string, expectedContentRevision: number, currentContentRevision?: number);
}
/**
 * Persist a generated SQ preview only if the unit is still on the revision
 * from which generation started. The session write and revision claim share
 * one transaction, preventing a stale generator from adopting a concurrent
 * material writer's newer revision.
 */
export declare function commitSqPreviewAtRevision(params: {
    db?: unknown;
    unitId: string;
    expectedContentRevision: number;
    sq3rData: string;
}): Promise<number>;
