import { z } from "zod";
import { generatableComplexInteractiveBlockTypeSchema } from "../llm/schemas.js";
export declare const MIN_SECTION_MATERIAL_BLOCKS = 6;
export declare const MAX_SECTION_MATERIAL_BLOCKS = 120;
export declare const MAX_SECTION_MATERIAL_TAKEAWAYS = 10;
export declare const sectionMaterialIntentSchema: z.ZodObject<{
    setup: z.ZodString;
    learningGoal: z.ZodString;
    expectedInsight: z.ZodString;
}, z.core.$strip>;
export declare const sectionMaterialSvgIntentSchema: z.ZodObject<{
    visualKind: z.ZodEnum<{
        simple_structure: "simple_structure";
        spatial_relationship: "spatial_relationship";
        state_comparison: "state_comparison";
        step_derivation: "step_derivation";
    }>;
    setup: z.ZodString;
    learningGoal: z.ZodString;
    expectedInsight: z.ZodString;
    composition: z.ZodString;
    elements: z.ZodArray<z.ZodString>;
    relationships: z.ZodArray<z.ZodString>;
    labels: z.ZodArray<z.ZodString>;
    avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export declare const sectionMaterialComponentSlotSchema: z.ZodUnion<readonly [z.ZodObject<{
    type: z.ZodLiteral<"component_slot">;
    slotRef: z.ZodString;
    intent: z.ZodObject<{
        setup: z.ZodString;
        learningGoal: z.ZodString;
        expectedInsight: z.ZodString;
    }, z.core.$strip>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"component_slot">;
    componentType: z.ZodEnum<{
        chart: "chart";
        math_scene: "math_scene";
        mechanics_sandbox: "mechanics_sandbox";
        circuit_sandbox: "circuit_sandbox";
        chemistry_lab: "chemistry_lab";
    }>;
    intent: z.ZodObject<{
        setup: z.ZodString;
        learningGoal: z.ZodString;
        expectedInsight: z.ZodString;
    }, z.core.$strip>;
}, z.core.$strip>]>;
export declare const sectionMaterialSvgSlotSchema: z.ZodObject<{
    type: z.ZodLiteral<"svg_slot">;
    intent: z.ZodObject<{
        visualKind: z.ZodEnum<{
            simple_structure: "simple_structure";
            spatial_relationship: "spatial_relationship";
            state_comparison: "state_comparison";
            step_derivation: "step_derivation";
        }>;
        setup: z.ZodString;
        learningGoal: z.ZodString;
        expectedInsight: z.ZodString;
        composition: z.ZodString;
        elements: z.ZodArray<z.ZodString>;
        relationships: z.ZodArray<z.ZodString>;
        labels: z.ZodArray<z.ZodString>;
        avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const sectionMaterialAuthoredBlockSchema: z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"music">;
    id: z.ZodOptional<z.ZodString>;
    version: z.ZodLiteral<1>;
    title: z.ZodString;
    key: z.ZodLiteral<"C">;
    meter: z.ZodEnum<{
        "2/4": "2/4";
        "3/4": "3/4";
        "4/4": "4/4";
    }>;
    tempo: z.ZodNumber;
    keyboard: z.ZodBoolean;
    notation: z.ZodOptional<z.ZodEnum<{
        staff: "staff";
        both: "both";
        jianpu: "jianpu";
    }>>;
    parts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        clef: z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        bars: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodObject<{
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    steps: z.ZodArray<z.ZodObject<{
        bars: z.ZodArray<z.ZodNumber>;
        parts: z.ZodArray<z.ZodString>;
        instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
            part: z.ZodString;
            instrument: z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>;
        }, z.core.$strict>>>;
        id: z.ZodString;
        label: z.ZodString;
        focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
        compare: z.ZodOptional<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"music">;
    version: z.ZodLiteral<2>;
    id: z.ZodString;
    title: z.ZodString;
    layout: z.ZodEnum<{
        row: "row";
        column: "column";
        grid: "grid";
    }>;
    notes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        pitches: z.ZodArray<z.ZodString>;
        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
    }, z.core.$strict>>;
    views: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            staff: "staff";
            keyboard: "keyboard";
        }>;
        label: z.ZodString;
        notes: z.ZodArray<z.ZodString>;
        clef: z.ZodOptional<z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>>;
        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            label: "label";
            link: "link";
            bracket: "bracket";
            arrow: "arrow";
        }>;
        label: z.ZodString;
        anchors: z.ZodArray<z.ZodObject<{
            viewId: z.ZodString;
            noteId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        tempo: z.ZodNumber;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        events: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
    templateId: z.ZodLiteral<"general-question">;
    content: z.ZodObject<{
        objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        glyphs: z.ZodTuple<[z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>, z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>], null>;
        observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        question: z.ZodString;
        goal: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-layers">;
    content: z.ZodObject<{
        layers: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-flow">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodString>;
        caption: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-compare">;
    content: z.ZodObject<{
        names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        metrics: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            max: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-summary">;
    content: z.ZodObject<{
        concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        center: z.ZodString;
        transfer: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-pythagoras">;
    content: z.ZodObject<{
        a: z.ZodNumber;
        b: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-tangent">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
        at: z.ZodNumber;
        startDx: z.ZodNumber;
        xmax: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-integral">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        end: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-probability">;
    content: z.ZodObject<{
        total: z.ZodNumber;
        condition: z.ZodNumber;
        intersection: z.ZodNumber;
        outsideTarget: z.ZodNumber;
        conditionName: z.ZodString;
        targetName: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-forces">;
    content: z.ZodObject<{
        mass: z.ZodNumber;
        drive: z.ZodNumber;
        resistance: z.ZodNumber;
        duration: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-waves">;
    content: z.ZodObject<{
        amplitude1: z.ZodNumber;
        amplitude2: z.ZodNumber;
        cycles1: z.ZodNumber;
        cycles2: z.ZodNumber;
        phase2: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-circuit">;
    content: z.ZodObject<{
        voltage: z.ZodNumber;
        resistance1: z.ZodNumber;
        resistance2: z.ZodNumber;
        topology: z.ZodEnum<{
            series: "series";
            parallel: "parallel";
        }>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-reaction">;
    content: z.ZodObject<{
        reactants: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        products: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-titration">;
    content: z.ZodObject<{
        acidMl: z.ZodNumber;
        acidMolarity: z.ZodNumber;
        baseMolarity: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-mitosis">;
    content: z.ZodObject<{
        chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-enzyme">;
    content: z.ZodObject<{
        enzyme: z.ZodString;
        substrate: z.ZodString;
        products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"geography-water">;
    content: z.ZodObject<{
        title: z.ZodString;
        nodes: z.ZodTuple<[z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>], null>;
        transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
        stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"history-timeline">;
    content: z.ZodObject<{
        range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
        events: z.ZodTuple<[z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>], null>;
        caution: z.ZodString;
        conclusion: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-syntax">;
    content: z.ZodObject<{
        subject: z.ZodString;
        verb: z.ZodString;
        object: z.ZodString;
        question: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-perspective">;
    content: z.ZodObject<{
        object: z.ZodEnum<{
            door: "door";
            book: "book";
        }>;
        firstPerson: z.ZodString;
        observer: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-sorting">;
    content: z.ZodObject<{
        values: z.ZodArray<z.ZodNumber>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-recursion">;
    content: z.ZodObject<{
        operation: z.ZodEnum<{
            product: "product";
            sum: "sum";
        }>;
        start: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-score">;
    content: z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-harmony">;
    content: z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"economics-equilibrium">;
    content: z.ZodObject<{
        demandIntercept: z.ZodNumber;
        supplyIntercept: z.ZodNumber;
        demandSlope: z.ZodNumber;
        supplySlope: z.ZodNumber;
        demandShift: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-timeline">;
    content: z.ZodObject<{
        unit: z.ZodString;
        events: z.ZodArray<z.ZodObject<{
            at: z.ZodNumber;
            label: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-cycle">;
    content: z.ZodObject<{
        center: z.ZodString;
        nodes: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            process: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-decision">;
    content: z.ZodObject<{
        question: z.ZodString;
        branches: z.ZodArray<z.ZodObject<{
            condition: z.ZodString;
            outcome: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-funnel">;
    content: z.ZodObject<{
        unit: z.ZodString;
        stages: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-balance">;
    content: z.ZodObject<{
        unit: z.ZodString;
        left: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        right: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-matrix">;
    content: z.ZodObject<{
        columns: z.ZodArray<z.ZodString>;
        rows: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>>;
        unit: z.ZodString;
        max: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-proportion">;
    content: z.ZodObject<{
        whole: z.ZodString;
        unit: z.ZodString;
        parts: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-network">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
        links: z.ZodArray<z.ZodObject<{
            from: z.ZodString;
            to: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-counter">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        from: z.ZodNumber;
        to: z.ZodNumber;
        context: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-interval">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        min: z.ZodNumber;
        max: z.ZodNumber;
        low: z.ZodNumber;
        high: z.ZodNumber;
        points: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-hierarchy">;
    content: z.ZodObject<{
        root: z.ZodString;
        groups: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            members: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-ranking">;
    content: z.ZodObject<{
        unit: z.ZodString;
        before: z.ZodString;
        after: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            before: z.ZodNumber;
            after: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>], "templateId">, z.ZodObject<{
    type: z.ZodLiteral<"visual">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    kind: z.ZodEnum<{
        process: "process";
        cycle: "cycle";
        layers: "layers";
    }>;
    items: z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"visual">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    unit: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"bars">;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
        value: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
    templateId: z.ZodLiteral<"general-question">;
    content: z.ZodObject<{
        objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        glyphs: z.ZodTuple<[z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>, z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>], null>;
        observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        question: z.ZodString;
        goal: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-layers">;
    content: z.ZodObject<{
        layers: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-flow">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodString>;
        caption: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-compare">;
    content: z.ZodObject<{
        names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        metrics: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            max: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-summary">;
    content: z.ZodObject<{
        concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        center: z.ZodString;
        transfer: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-pythagoras">;
    content: z.ZodObject<{
        a: z.ZodNumber;
        b: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-tangent">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
        at: z.ZodNumber;
        startDx: z.ZodNumber;
        xmax: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-integral">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        end: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-probability">;
    content: z.ZodObject<{
        total: z.ZodNumber;
        condition: z.ZodNumber;
        intersection: z.ZodNumber;
        outsideTarget: z.ZodNumber;
        conditionName: z.ZodString;
        targetName: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-forces">;
    content: z.ZodObject<{
        mass: z.ZodNumber;
        drive: z.ZodNumber;
        resistance: z.ZodNumber;
        duration: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-waves">;
    content: z.ZodObject<{
        amplitude1: z.ZodNumber;
        amplitude2: z.ZodNumber;
        cycles1: z.ZodNumber;
        cycles2: z.ZodNumber;
        phase2: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-circuit">;
    content: z.ZodObject<{
        voltage: z.ZodNumber;
        resistance1: z.ZodNumber;
        resistance2: z.ZodNumber;
        topology: z.ZodEnum<{
            series: "series";
            parallel: "parallel";
        }>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-reaction">;
    content: z.ZodObject<{
        reactants: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        products: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-titration">;
    content: z.ZodObject<{
        acidMl: z.ZodNumber;
        acidMolarity: z.ZodNumber;
        baseMolarity: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-mitosis">;
    content: z.ZodObject<{
        chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-enzyme">;
    content: z.ZodObject<{
        enzyme: z.ZodString;
        substrate: z.ZodString;
        products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"geography-water">;
    content: z.ZodObject<{
        title: z.ZodString;
        nodes: z.ZodTuple<[z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>], null>;
        transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
        stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"history-timeline">;
    content: z.ZodObject<{
        range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
        events: z.ZodTuple<[z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>], null>;
        caution: z.ZodString;
        conclusion: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-syntax">;
    content: z.ZodObject<{
        subject: z.ZodString;
        verb: z.ZodString;
        object: z.ZodString;
        question: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-perspective">;
    content: z.ZodObject<{
        object: z.ZodEnum<{
            door: "door";
            book: "book";
        }>;
        firstPerson: z.ZodString;
        observer: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-sorting">;
    content: z.ZodObject<{
        values: z.ZodArray<z.ZodNumber>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-recursion">;
    content: z.ZodObject<{
        operation: z.ZodEnum<{
            product: "product";
            sum: "sum";
        }>;
        start: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-score">;
    content: z.ZodUnion<readonly [z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodObject<{
        source: z.ZodLiteral<"accepted-v2">;
        block: z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        clipId: z.ZodOptional<z.ZodString>;
        repeat: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>]>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-harmony">;
    content: z.ZodUnion<readonly [z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodObject<{
        source: z.ZodLiteral<"accepted-v2">;
        block: z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        clipId: z.ZodOptional<z.ZodString>;
        repeat: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>]>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"economics-equilibrium">;
    content: z.ZodObject<{
        demandIntercept: z.ZodNumber;
        supplyIntercept: z.ZodNumber;
        demandSlope: z.ZodNumber;
        supplySlope: z.ZodNumber;
        demandShift: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-timeline">;
    content: z.ZodObject<{
        unit: z.ZodString;
        events: z.ZodArray<z.ZodObject<{
            at: z.ZodNumber;
            label: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-cycle">;
    content: z.ZodObject<{
        center: z.ZodString;
        nodes: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            process: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-decision">;
    content: z.ZodObject<{
        question: z.ZodString;
        branches: z.ZodArray<z.ZodObject<{
            condition: z.ZodString;
            outcome: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-funnel">;
    content: z.ZodObject<{
        unit: z.ZodString;
        stages: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-balance">;
    content: z.ZodObject<{
        unit: z.ZodString;
        left: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        right: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-matrix">;
    content: z.ZodObject<{
        columns: z.ZodArray<z.ZodString>;
        rows: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>>;
        unit: z.ZodString;
        max: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-proportion">;
    content: z.ZodObject<{
        whole: z.ZodString;
        unit: z.ZodString;
        parts: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-network">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
        links: z.ZodArray<z.ZodObject<{
            from: z.ZodString;
            to: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-counter">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        from: z.ZodNumber;
        to: z.ZodNumber;
        context: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-interval">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        min: z.ZodNumber;
        max: z.ZodNumber;
        low: z.ZodNumber;
        high: z.ZodNumber;
        points: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-hierarchy">;
    content: z.ZodObject<{
        root: z.ZodString;
        groups: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            members: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-ranking">;
    content: z.ZodObject<{
        unit: z.ZodString;
        before: z.ZodString;
        after: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            before: z.ZodNumber;
            after: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>], "templateId"> | z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"music">;
    id: z.ZodOptional<z.ZodString>;
    version: z.ZodLiteral<1>;
    title: z.ZodString;
    key: z.ZodLiteral<"C">;
    meter: z.ZodEnum<{
        "2/4": "2/4";
        "3/4": "3/4";
        "4/4": "4/4";
    }>;
    tempo: z.ZodNumber;
    keyboard: z.ZodBoolean;
    notation: z.ZodOptional<z.ZodEnum<{
        staff: "staff";
        both: "both";
        jianpu: "jianpu";
    }>>;
    parts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        clef: z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        bars: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodObject<{
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    steps: z.ZodArray<z.ZodObject<{
        bars: z.ZodArray<z.ZodNumber>;
        parts: z.ZodArray<z.ZodString>;
        instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
            part: z.ZodString;
            instrument: z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>;
        }, z.core.$strict>>>;
        id: z.ZodString;
        label: z.ZodString;
        focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
        compare: z.ZodOptional<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"music">;
    version: z.ZodLiteral<2>;
    id: z.ZodString;
    title: z.ZodString;
    layout: z.ZodEnum<{
        row: "row";
        column: "column";
        grid: "grid";
    }>;
    notes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        pitches: z.ZodArray<z.ZodString>;
        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
    }, z.core.$strict>>;
    views: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            staff: "staff";
            keyboard: "keyboard";
        }>;
        label: z.ZodString;
        notes: z.ZodArray<z.ZodString>;
        clef: z.ZodOptional<z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>>;
        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            label: "label";
            link: "link";
            bracket: "bracket";
            arrow: "arrow";
        }>;
        label: z.ZodString;
        anchors: z.ZodArray<z.ZodObject<{
            viewId: z.ZodString;
            noteId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        tempo: z.ZodNumber;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        events: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strict>], "version"> | z.ZodObject<{
    type: z.ZodLiteral<"illustration">;
    id: z.ZodOptional<z.ZodString>;
    caption: z.ZodString;
    prompt: z.ZodString;
    style: z.ZodEnum<{
        process: "process";
        diagram: "diagram";
        concept: "concept";
        comparison: "comparison";
    }>;
    aspectRatio: z.ZodOptional<z.ZodEnum<{
        "1:1": "1:1";
        "16:9": "16:9";
        "9:16": "9:16";
        "4:3": "4:3";
        "3:4": "3:4";
        "3:2": "3:2";
        "2:3": "2:3";
    }>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"visual">;
    id: z.ZodOptional<z.ZodString>;
    kind: z.ZodEnum<{
        process: "process";
        cycle: "cycle";
        layers: "layers";
        bars: "bars";
    }>;
    title: z.ZodString;
    unit: z.ZodOptional<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
        value: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict> | z.ZodObject<{
    type: z.ZodLiteral<"code">;
    id: z.ZodOptional<z.ZodString>;
    code: z.ZodString;
    language: z.ZodOptional<z.ZodString>;
    parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        text: z.ZodString;
    }, z.core.$strip>>>;
    regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        match: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"conversation">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodOptional<z.ZodString>;
    turns: z.ZodArray<z.ZodObject<{
        speaker: z.ZodString;
        text: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"callout">;
    id: z.ZodOptional<z.ZodString>;
    variant: z.ZodEnum<{
        example: "example";
        warning: "warning";
        definition: "definition";
        tip: "tip";
    }>;
    title: z.ZodOptional<z.ZodString>;
    body: z.ZodString;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"accordion">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    body: z.ZodString;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"compare">;
    id: z.ZodOptional<z.ZodString>;
    left: z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    right: z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"stage">;
    id: z.ZodOptional<z.ZodString>;
    layout: z.ZodEnum<{
        "split-h": "split-h";
        "split-v": "split-v";
        "main+rail": "main+rail";
        stack: "stack";
    }>;
    presentation: z.ZodOptional<z.ZodEnum<{
        compare: "compare";
        steps: "steps";
        focus: "focus";
    }>>;
    figures: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"music">;
        id: z.ZodOptional<z.ZodString>;
        version: z.ZodLiteral<1>;
        title: z.ZodString;
        key: z.ZodLiteral<"C">;
        meter: z.ZodEnum<{
            "2/4": "2/4";
            "3/4": "3/4";
            "4/4": "4/4";
        }>;
        tempo: z.ZodNumber;
        keyboard: z.ZodBoolean;
        notation: z.ZodOptional<z.ZodEnum<{
            staff: "staff";
            both: "both";
            jianpu: "jianpu";
        }>>;
        parts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            clef: z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            bars: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodObject<{
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            id: z.ZodString;
            label: z.ZodString;
            focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
            compare: z.ZodOptional<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"music">;
        version: z.ZodLiteral<2>;
        id: z.ZodString;
        title: z.ZodString;
        layout: z.ZodEnum<{
            row: "row";
            column: "column";
            grid: "grid";
        }>;
        notes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            pitches: z.ZodArray<z.ZodString>;
            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
        }, z.core.$strict>>;
        views: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                staff: "staff";
                keyboard: "keyboard";
            }>;
            label: z.ZodString;
            notes: z.ZodArray<z.ZodString>;
            clef: z.ZodOptional<z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>>;
            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                label: "label";
                link: "link";
                bracket: "bracket";
                arrow: "arrow";
            }>;
            label: z.ZodString;
            anchors: z.ZodArray<z.ZodObject<{
                viewId: z.ZodString;
                noteId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            tempo: z.ZodNumber;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            events: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
        templateId: z.ZodLiteral<"general-question">;
        content: z.ZodObject<{
            objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            glyphs: z.ZodTuple<[z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>, z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>], null>;
            observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            question: z.ZodString;
            goal: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-layers">;
        content: z.ZodObject<{
            layers: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-flow">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodString>;
            caption: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-compare">;
        content: z.ZodObject<{
            names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            metrics: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                max: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-summary">;
        content: z.ZodObject<{
            concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            center: z.ZodString;
            transfer: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-pythagoras">;
        content: z.ZodObject<{
            a: z.ZodNumber;
            b: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-tangent">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            at: z.ZodNumber;
            startDx: z.ZodNumber;
            xmax: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-integral">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            end: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-probability">;
        content: z.ZodObject<{
            total: z.ZodNumber;
            condition: z.ZodNumber;
            intersection: z.ZodNumber;
            outsideTarget: z.ZodNumber;
            conditionName: z.ZodString;
            targetName: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-forces">;
        content: z.ZodObject<{
            mass: z.ZodNumber;
            drive: z.ZodNumber;
            resistance: z.ZodNumber;
            duration: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-waves">;
        content: z.ZodObject<{
            amplitude1: z.ZodNumber;
            amplitude2: z.ZodNumber;
            cycles1: z.ZodNumber;
            cycles2: z.ZodNumber;
            phase2: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-circuit">;
        content: z.ZodObject<{
            voltage: z.ZodNumber;
            resistance1: z.ZodNumber;
            resistance2: z.ZodNumber;
            topology: z.ZodEnum<{
                series: "series";
                parallel: "parallel";
            }>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-reaction">;
        content: z.ZodObject<{
            reactants: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            products: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-titration">;
        content: z.ZodObject<{
            acidMl: z.ZodNumber;
            acidMolarity: z.ZodNumber;
            baseMolarity: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-mitosis">;
        content: z.ZodObject<{
            chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-enzyme">;
        content: z.ZodObject<{
            enzyme: z.ZodString;
            substrate: z.ZodString;
            products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"geography-water">;
        content: z.ZodObject<{
            title: z.ZodString;
            nodes: z.ZodTuple<[z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>], null>;
            transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
            stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"history-timeline">;
        content: z.ZodObject<{
            range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            events: z.ZodTuple<[z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>], null>;
            caution: z.ZodString;
            conclusion: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-syntax">;
        content: z.ZodObject<{
            subject: z.ZodString;
            verb: z.ZodString;
            object: z.ZodString;
            question: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-perspective">;
        content: z.ZodObject<{
            object: z.ZodEnum<{
                door: "door";
                book: "book";
            }>;
            firstPerson: z.ZodString;
            observer: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-sorting">;
        content: z.ZodObject<{
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-recursion">;
        content: z.ZodObject<{
            operation: z.ZodEnum<{
                product: "product";
                sum: "sum";
            }>;
            start: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-score">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-harmony">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"economics-equilibrium">;
        content: z.ZodObject<{
            demandIntercept: z.ZodNumber;
            supplyIntercept: z.ZodNumber;
            demandSlope: z.ZodNumber;
            supplySlope: z.ZodNumber;
            demandShift: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-timeline">;
        content: z.ZodObject<{
            unit: z.ZodString;
            events: z.ZodArray<z.ZodObject<{
                at: z.ZodNumber;
                label: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-cycle">;
        content: z.ZodObject<{
            center: z.ZodString;
            nodes: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                process: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-decision">;
        content: z.ZodObject<{
            question: z.ZodString;
            branches: z.ZodArray<z.ZodObject<{
                condition: z.ZodString;
                outcome: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-funnel">;
        content: z.ZodObject<{
            unit: z.ZodString;
            stages: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-balance">;
        content: z.ZodObject<{
            unit: z.ZodString;
            left: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            right: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-matrix">;
        content: z.ZodObject<{
            columns: z.ZodArray<z.ZodString>;
            rows: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>>;
            unit: z.ZodString;
            max: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-proportion">;
        content: z.ZodObject<{
            whole: z.ZodString;
            unit: z.ZodString;
            parts: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-network">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
            links: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-counter">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            from: z.ZodNumber;
            to: z.ZodNumber;
            context: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-interval">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            min: z.ZodNumber;
            max: z.ZodNumber;
            low: z.ZodNumber;
            high: z.ZodNumber;
            points: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-hierarchy">;
        content: z.ZodObject<{
            root: z.ZodString;
            groups: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                members: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-ranking">;
        content: z.ZodObject<{
            unit: z.ZodString;
            before: z.ZodString;
            after: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>], "templateId">, z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        kind: z.ZodEnum<{
            process: "process";
            cycle: "cycle";
            layers: "layers";
            bars: "bars";
        }>;
        title: z.ZodString;
        unit: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            value: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"code">;
        id: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        language: z.ZodOptional<z.ZodString>;
        parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            text: z.ZodString;
        }, z.core.$strip>>>;
        regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            match: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"conversation">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        turns: z.ZodArray<z.ZodObject<{
            speaker: z.ZodString;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"callout">;
        id: z.ZodOptional<z.ZodString>;
        variant: z.ZodEnum<{
            example: "example";
            warning: "warning";
            definition: "definition";
            tip: "tip";
        }>;
        title: z.ZodOptional<z.ZodString>;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"accordion">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"illustration">;
        id: z.ZodOptional<z.ZodString>;
        caption: z.ZodString;
        prompt: z.ZodString;
        style: z.ZodEnum<{
            process: "process";
            diagram: "diagram";
            concept: "concept";
            comparison: "comparison";
        }>;
        aspectRatio: z.ZodOptional<z.ZodEnum<{
            "1:1": "1:1";
            "16:9": "16:9";
            "9:16": "9:16";
            "4:3": "4:3";
            "3:4": "3:4";
            "3:2": "3:2";
            "2:3": "2:3";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"svg_slot">;
        id: z.ZodOptional<z.ZodString>;
        intent: z.ZodObject<{
            visualKind: z.ZodEnum<{
                simple_structure: "simple_structure";
                spatial_relationship: "spatial_relationship";
                state_comparison: "state_comparison";
                step_derivation: "step_derivation";
            }>;
            setup: z.ZodString;
            learningGoal: z.ZodString;
            expectedInsight: z.ZodString;
            composition: z.ZodOptional<z.ZodString>;
            elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
            relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
            labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
            avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"compare">;
        id: z.ZodOptional<z.ZodString>;
        left: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        right: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>>;
    }, z.core.$strip>], "type">>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"heading">;
    level: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
    text: z.ZodString;
    topicId: z.ZodOptional<z.ZodString>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"paragraph">;
    text: z.ZodString;
    cue: z.ZodOptional<z.ZodObject<{
        music: z.ZodOptional<z.ZodObject<{
            figureId: z.ZodString;
            clipId: z.ZodString;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        target: z.ZodString;
        targetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        op: z.ZodOptional<z.ZodEnum<{
            highlight: "highlight";
            window: "window";
        }>>;
        regionIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        figureId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
    templateId: z.ZodLiteral<"general-question">;
    content: z.ZodObject<{
        objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        glyphs: z.ZodTuple<[z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>, z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>], null>;
        observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        question: z.ZodString;
        goal: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-layers">;
    content: z.ZodObject<{
        layers: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-flow">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodString>;
        caption: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-compare">;
    content: z.ZodObject<{
        names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        metrics: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            max: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-summary">;
    content: z.ZodObject<{
        concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        center: z.ZodString;
        transfer: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-pythagoras">;
    content: z.ZodObject<{
        a: z.ZodNumber;
        b: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-tangent">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
        at: z.ZodNumber;
        startDx: z.ZodNumber;
        xmax: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-integral">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        end: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-probability">;
    content: z.ZodObject<{
        total: z.ZodNumber;
        condition: z.ZodNumber;
        intersection: z.ZodNumber;
        outsideTarget: z.ZodNumber;
        conditionName: z.ZodString;
        targetName: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-forces">;
    content: z.ZodObject<{
        mass: z.ZodNumber;
        drive: z.ZodNumber;
        resistance: z.ZodNumber;
        duration: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-waves">;
    content: z.ZodObject<{
        amplitude1: z.ZodNumber;
        amplitude2: z.ZodNumber;
        cycles1: z.ZodNumber;
        cycles2: z.ZodNumber;
        phase2: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-circuit">;
    content: z.ZodObject<{
        voltage: z.ZodNumber;
        resistance1: z.ZodNumber;
        resistance2: z.ZodNumber;
        topology: z.ZodEnum<{
            series: "series";
            parallel: "parallel";
        }>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-reaction">;
    content: z.ZodObject<{
        reactants: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        products: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-titration">;
    content: z.ZodObject<{
        acidMl: z.ZodNumber;
        acidMolarity: z.ZodNumber;
        baseMolarity: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-mitosis">;
    content: z.ZodObject<{
        chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-enzyme">;
    content: z.ZodObject<{
        enzyme: z.ZodString;
        substrate: z.ZodString;
        products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"geography-water">;
    content: z.ZodObject<{
        title: z.ZodString;
        nodes: z.ZodTuple<[z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>], null>;
        transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
        stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"history-timeline">;
    content: z.ZodObject<{
        range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
        events: z.ZodTuple<[z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>], null>;
        caution: z.ZodString;
        conclusion: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-syntax">;
    content: z.ZodObject<{
        subject: z.ZodString;
        verb: z.ZodString;
        object: z.ZodString;
        question: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-perspective">;
    content: z.ZodObject<{
        object: z.ZodEnum<{
            door: "door";
            book: "book";
        }>;
        firstPerson: z.ZodString;
        observer: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-sorting">;
    content: z.ZodObject<{
        values: z.ZodArray<z.ZodNumber>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-recursion">;
    content: z.ZodObject<{
        operation: z.ZodEnum<{
            product: "product";
            sum: "sum";
        }>;
        start: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-score">;
    content: z.ZodUnion<readonly [z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodObject<{
        source: z.ZodLiteral<"accepted-v2">;
        block: z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        clipId: z.ZodOptional<z.ZodString>;
        repeat: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>]>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-harmony">;
    content: z.ZodUnion<readonly [z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodObject<{
        source: z.ZodLiteral<"accepted-v2">;
        block: z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        clipId: z.ZodOptional<z.ZodString>;
        repeat: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>]>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"economics-equilibrium">;
    content: z.ZodObject<{
        demandIntercept: z.ZodNumber;
        supplyIntercept: z.ZodNumber;
        demandSlope: z.ZodNumber;
        supplySlope: z.ZodNumber;
        demandShift: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-timeline">;
    content: z.ZodObject<{
        unit: z.ZodString;
        events: z.ZodArray<z.ZodObject<{
            at: z.ZodNumber;
            label: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-cycle">;
    content: z.ZodObject<{
        center: z.ZodString;
        nodes: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            process: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-decision">;
    content: z.ZodObject<{
        question: z.ZodString;
        branches: z.ZodArray<z.ZodObject<{
            condition: z.ZodString;
            outcome: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-funnel">;
    content: z.ZodObject<{
        unit: z.ZodString;
        stages: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-balance">;
    content: z.ZodObject<{
        unit: z.ZodString;
        left: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        right: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-matrix">;
    content: z.ZodObject<{
        columns: z.ZodArray<z.ZodString>;
        rows: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>>;
        unit: z.ZodString;
        max: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-proportion">;
    content: z.ZodObject<{
        whole: z.ZodString;
        unit: z.ZodString;
        parts: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-network">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
        links: z.ZodArray<z.ZodObject<{
            from: z.ZodString;
            to: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-counter">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        from: z.ZodNumber;
        to: z.ZodNumber;
        context: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-interval">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        min: z.ZodNumber;
        max: z.ZodNumber;
        low: z.ZodNumber;
        high: z.ZodNumber;
        points: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-hierarchy">;
    content: z.ZodObject<{
        root: z.ZodString;
        groups: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            members: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-ranking">;
    content: z.ZodObject<{
        unit: z.ZodString;
        before: z.ZodString;
        after: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            before: z.ZodNumber;
            after: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>], "templateId"> | z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"music">;
    id: z.ZodOptional<z.ZodString>;
    version: z.ZodLiteral<1>;
    title: z.ZodString;
    key: z.ZodLiteral<"C">;
    meter: z.ZodEnum<{
        "2/4": "2/4";
        "3/4": "3/4";
        "4/4": "4/4";
    }>;
    tempo: z.ZodNumber;
    keyboard: z.ZodBoolean;
    notation: z.ZodOptional<z.ZodEnum<{
        staff: "staff";
        both: "both";
        jianpu: "jianpu";
    }>>;
    parts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        clef: z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        bars: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodObject<{
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    steps: z.ZodArray<z.ZodObject<{
        bars: z.ZodArray<z.ZodNumber>;
        parts: z.ZodArray<z.ZodString>;
        instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
            part: z.ZodString;
            instrument: z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>;
        }, z.core.$strict>>>;
        id: z.ZodString;
        label: z.ZodString;
        focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
        compare: z.ZodOptional<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"music">;
    version: z.ZodLiteral<2>;
    id: z.ZodString;
    title: z.ZodString;
    layout: z.ZodEnum<{
        row: "row";
        column: "column";
        grid: "grid";
    }>;
    notes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        pitches: z.ZodArray<z.ZodString>;
        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
    }, z.core.$strict>>;
    views: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            staff: "staff";
            keyboard: "keyboard";
        }>;
        label: z.ZodString;
        notes: z.ZodArray<z.ZodString>;
        clef: z.ZodOptional<z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>>;
        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            label: "label";
            link: "link";
            bracket: "bracket";
            arrow: "arrow";
        }>;
        label: z.ZodString;
        anchors: z.ZodArray<z.ZodObject<{
            viewId: z.ZodString;
            noteId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        tempo: z.ZodNumber;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        events: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strict>], "version"> | z.ZodObject<{
    type: z.ZodLiteral<"illustration">;
    id: z.ZodOptional<z.ZodString>;
    caption: z.ZodString;
    prompt: z.ZodString;
    style: z.ZodEnum<{
        process: "process";
        diagram: "diagram";
        concept: "concept";
        comparison: "comparison";
    }>;
    aspectRatio: z.ZodOptional<z.ZodEnum<{
        "1:1": "1:1";
        "16:9": "16:9";
        "9:16": "9:16";
        "4:3": "4:3";
        "3:4": "3:4";
        "3:2": "3:2";
        "2:3": "2:3";
    }>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"visual">;
    id: z.ZodOptional<z.ZodString>;
    kind: z.ZodEnum<{
        process: "process";
        cycle: "cycle";
        layers: "layers";
        bars: "bars";
    }>;
    title: z.ZodString;
    unit: z.ZodOptional<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
        value: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict> | z.ZodObject<{
    type: z.ZodLiteral<"code">;
    id: z.ZodOptional<z.ZodString>;
    code: z.ZodString;
    language: z.ZodOptional<z.ZodString>;
    parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        text: z.ZodString;
    }, z.core.$strip>>>;
    regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        match: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"conversation">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodOptional<z.ZodString>;
    turns: z.ZodArray<z.ZodObject<{
        speaker: z.ZodString;
        text: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"callout">;
    id: z.ZodOptional<z.ZodString>;
    variant: z.ZodEnum<{
        example: "example";
        warning: "warning";
        definition: "definition";
        tip: "tip";
    }>;
    title: z.ZodOptional<z.ZodString>;
    body: z.ZodString;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"accordion">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    body: z.ZodString;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"compare">;
    id: z.ZodOptional<z.ZodString>;
    left: z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    right: z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"stage">;
    id: z.ZodOptional<z.ZodString>;
    layout: z.ZodEnum<{
        "split-h": "split-h";
        "split-v": "split-v";
        "main+rail": "main+rail";
        stack: "stack";
    }>;
    presentation: z.ZodOptional<z.ZodEnum<{
        compare: "compare";
        steps: "steps";
        focus: "focus";
    }>>;
    figures: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"music">;
        id: z.ZodOptional<z.ZodString>;
        version: z.ZodLiteral<1>;
        title: z.ZodString;
        key: z.ZodLiteral<"C">;
        meter: z.ZodEnum<{
            "2/4": "2/4";
            "3/4": "3/4";
            "4/4": "4/4";
        }>;
        tempo: z.ZodNumber;
        keyboard: z.ZodBoolean;
        notation: z.ZodOptional<z.ZodEnum<{
            staff: "staff";
            both: "both";
            jianpu: "jianpu";
        }>>;
        parts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            clef: z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            bars: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodObject<{
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            id: z.ZodString;
            label: z.ZodString;
            focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
            compare: z.ZodOptional<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"music">;
        version: z.ZodLiteral<2>;
        id: z.ZodString;
        title: z.ZodString;
        layout: z.ZodEnum<{
            row: "row";
            column: "column";
            grid: "grid";
        }>;
        notes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            pitches: z.ZodArray<z.ZodString>;
            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
        }, z.core.$strict>>;
        views: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                staff: "staff";
                keyboard: "keyboard";
            }>;
            label: z.ZodString;
            notes: z.ZodArray<z.ZodString>;
            clef: z.ZodOptional<z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>>;
            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                label: "label";
                link: "link";
                bracket: "bracket";
                arrow: "arrow";
            }>;
            label: z.ZodString;
            anchors: z.ZodArray<z.ZodObject<{
                viewId: z.ZodString;
                noteId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            tempo: z.ZodNumber;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            events: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
        templateId: z.ZodLiteral<"general-question">;
        content: z.ZodObject<{
            objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            glyphs: z.ZodTuple<[z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>, z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>], null>;
            observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            question: z.ZodString;
            goal: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-layers">;
        content: z.ZodObject<{
            layers: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-flow">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodString>;
            caption: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-compare">;
        content: z.ZodObject<{
            names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            metrics: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                max: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-summary">;
        content: z.ZodObject<{
            concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            center: z.ZodString;
            transfer: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-pythagoras">;
        content: z.ZodObject<{
            a: z.ZodNumber;
            b: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-tangent">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            at: z.ZodNumber;
            startDx: z.ZodNumber;
            xmax: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-integral">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            end: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-probability">;
        content: z.ZodObject<{
            total: z.ZodNumber;
            condition: z.ZodNumber;
            intersection: z.ZodNumber;
            outsideTarget: z.ZodNumber;
            conditionName: z.ZodString;
            targetName: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-forces">;
        content: z.ZodObject<{
            mass: z.ZodNumber;
            drive: z.ZodNumber;
            resistance: z.ZodNumber;
            duration: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-waves">;
        content: z.ZodObject<{
            amplitude1: z.ZodNumber;
            amplitude2: z.ZodNumber;
            cycles1: z.ZodNumber;
            cycles2: z.ZodNumber;
            phase2: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-circuit">;
        content: z.ZodObject<{
            voltage: z.ZodNumber;
            resistance1: z.ZodNumber;
            resistance2: z.ZodNumber;
            topology: z.ZodEnum<{
                series: "series";
                parallel: "parallel";
            }>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-reaction">;
        content: z.ZodObject<{
            reactants: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            products: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-titration">;
        content: z.ZodObject<{
            acidMl: z.ZodNumber;
            acidMolarity: z.ZodNumber;
            baseMolarity: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-mitosis">;
        content: z.ZodObject<{
            chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-enzyme">;
        content: z.ZodObject<{
            enzyme: z.ZodString;
            substrate: z.ZodString;
            products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"geography-water">;
        content: z.ZodObject<{
            title: z.ZodString;
            nodes: z.ZodTuple<[z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>], null>;
            transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
            stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"history-timeline">;
        content: z.ZodObject<{
            range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            events: z.ZodTuple<[z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>], null>;
            caution: z.ZodString;
            conclusion: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-syntax">;
        content: z.ZodObject<{
            subject: z.ZodString;
            verb: z.ZodString;
            object: z.ZodString;
            question: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-perspective">;
        content: z.ZodObject<{
            object: z.ZodEnum<{
                door: "door";
                book: "book";
            }>;
            firstPerson: z.ZodString;
            observer: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-sorting">;
        content: z.ZodObject<{
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-recursion">;
        content: z.ZodObject<{
            operation: z.ZodEnum<{
                product: "product";
                sum: "sum";
            }>;
            start: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-score">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-harmony">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"economics-equilibrium">;
        content: z.ZodObject<{
            demandIntercept: z.ZodNumber;
            supplyIntercept: z.ZodNumber;
            demandSlope: z.ZodNumber;
            supplySlope: z.ZodNumber;
            demandShift: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-timeline">;
        content: z.ZodObject<{
            unit: z.ZodString;
            events: z.ZodArray<z.ZodObject<{
                at: z.ZodNumber;
                label: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-cycle">;
        content: z.ZodObject<{
            center: z.ZodString;
            nodes: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                process: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-decision">;
        content: z.ZodObject<{
            question: z.ZodString;
            branches: z.ZodArray<z.ZodObject<{
                condition: z.ZodString;
                outcome: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-funnel">;
        content: z.ZodObject<{
            unit: z.ZodString;
            stages: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-balance">;
        content: z.ZodObject<{
            unit: z.ZodString;
            left: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            right: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-matrix">;
        content: z.ZodObject<{
            columns: z.ZodArray<z.ZodString>;
            rows: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>>;
            unit: z.ZodString;
            max: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-proportion">;
        content: z.ZodObject<{
            whole: z.ZodString;
            unit: z.ZodString;
            parts: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-network">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
            links: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-counter">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            from: z.ZodNumber;
            to: z.ZodNumber;
            context: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-interval">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            min: z.ZodNumber;
            max: z.ZodNumber;
            low: z.ZodNumber;
            high: z.ZodNumber;
            points: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-hierarchy">;
        content: z.ZodObject<{
            root: z.ZodString;
            groups: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                members: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-ranking">;
        content: z.ZodObject<{
            unit: z.ZodString;
            before: z.ZodString;
            after: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>], "templateId">, z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        kind: z.ZodEnum<{
            process: "process";
            cycle: "cycle";
            layers: "layers";
            bars: "bars";
        }>;
        title: z.ZodString;
        unit: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            value: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"code">;
        id: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        language: z.ZodOptional<z.ZodString>;
        parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            text: z.ZodString;
        }, z.core.$strip>>>;
        regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            match: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"conversation">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        turns: z.ZodArray<z.ZodObject<{
            speaker: z.ZodString;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"callout">;
        id: z.ZodOptional<z.ZodString>;
        variant: z.ZodEnum<{
            example: "example";
            warning: "warning";
            definition: "definition";
            tip: "tip";
        }>;
        title: z.ZodOptional<z.ZodString>;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"accordion">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"illustration">;
        id: z.ZodOptional<z.ZodString>;
        caption: z.ZodString;
        prompt: z.ZodString;
        style: z.ZodEnum<{
            process: "process";
            diagram: "diagram";
            concept: "concept";
            comparison: "comparison";
        }>;
        aspectRatio: z.ZodOptional<z.ZodEnum<{
            "1:1": "1:1";
            "16:9": "16:9";
            "9:16": "9:16";
            "4:3": "4:3";
            "3:4": "3:4";
            "3:2": "3:2";
            "2:3": "2:3";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"svg_slot">;
        id: z.ZodOptional<z.ZodString>;
        intent: z.ZodObject<{
            visualKind: z.ZodEnum<{
                simple_structure: "simple_structure";
                spatial_relationship: "spatial_relationship";
                state_comparison: "state_comparison";
                step_derivation: "step_derivation";
            }>;
            setup: z.ZodString;
            learningGoal: z.ZodString;
            expectedInsight: z.ZodString;
            composition: z.ZodOptional<z.ZodString>;
            elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
            relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
            labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
            avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"compare">;
        id: z.ZodOptional<z.ZodString>;
        left: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        right: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>>;
    }, z.core.$strip>], "type">>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"heading">;
    level: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
    text: z.ZodString;
    topicId: z.ZodOptional<z.ZodString>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"paragraph">;
    text: z.ZodString;
    cue: z.ZodOptional<z.ZodObject<{
        music: z.ZodOptional<z.ZodObject<{
            figureId: z.ZodString;
            clipId: z.ZodString;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        target: z.ZodString;
        targetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        op: z.ZodOptional<z.ZodEnum<{
            highlight: "highlight";
            window: "window";
        }>>;
        regionIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        figureId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"code">;
    id: z.ZodOptional<z.ZodString>;
    code: z.ZodString;
    language: z.ZodOptional<z.ZodString>;
    parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        text: z.ZodString;
    }, z.core.$strip>>>;
    regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        match: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"conversation">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodOptional<z.ZodString>;
    turns: z.ZodArray<z.ZodObject<{
        speaker: z.ZodString;
        text: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"callout">;
    id: z.ZodOptional<z.ZodString>;
    variant: z.ZodEnum<{
        example: "example";
        warning: "warning";
        definition: "definition";
        tip: "tip";
    }>;
    title: z.ZodOptional<z.ZodString>;
    body: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"accordion">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    body: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"illustration">;
    id: z.ZodOptional<z.ZodString>;
    caption: z.ZodString;
    prompt: z.ZodString;
    style: z.ZodEnum<{
        process: "process";
        diagram: "diagram";
        concept: "concept";
        comparison: "comparison";
    }>;
    aspectRatio: z.ZodOptional<z.ZodEnum<{
        "1:1": "1:1";
        "16:9": "16:9";
        "9:16": "9:16";
        "4:3": "4:3";
        "3:4": "3:4";
        "3:2": "3:2";
        "2:3": "2:3";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"stage">;
    id: z.ZodOptional<z.ZodString>;
    layout: z.ZodEnum<{
        "split-h": "split-h";
        "split-v": "split-v";
        "main+rail": "main+rail";
        stack: "stack";
    }>;
    presentation: z.ZodOptional<z.ZodEnum<{
        compare: "compare";
        steps: "steps";
        focus: "focus";
    }>>;
    figures: z.ZodArray<z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"music">;
        id: z.ZodOptional<z.ZodString>;
        version: z.ZodLiteral<1>;
        title: z.ZodString;
        key: z.ZodLiteral<"C">;
        meter: z.ZodEnum<{
            "2/4": "2/4";
            "3/4": "3/4";
            "4/4": "4/4";
        }>;
        tempo: z.ZodNumber;
        keyboard: z.ZodBoolean;
        notation: z.ZodOptional<z.ZodEnum<{
            staff: "staff";
            both: "both";
            jianpu: "jianpu";
        }>>;
        parts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            clef: z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            bars: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodObject<{
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            id: z.ZodString;
            label: z.ZodString;
            focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
            compare: z.ZodOptional<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"music">;
        version: z.ZodLiteral<2>;
        id: z.ZodString;
        title: z.ZodString;
        layout: z.ZodEnum<{
            row: "row";
            column: "column";
            grid: "grid";
        }>;
        notes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            pitches: z.ZodArray<z.ZodString>;
            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
        }, z.core.$strict>>;
        views: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                staff: "staff";
                keyboard: "keyboard";
            }>;
            label: z.ZodString;
            notes: z.ZodArray<z.ZodString>;
            clef: z.ZodOptional<z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>>;
            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                label: "label";
                link: "link";
                bracket: "bracket";
                arrow: "arrow";
            }>;
            label: z.ZodString;
            anchors: z.ZodArray<z.ZodObject<{
                viewId: z.ZodString;
                noteId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            tempo: z.ZodNumber;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            events: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
        templateId: z.ZodLiteral<"general-question">;
        content: z.ZodObject<{
            objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            glyphs: z.ZodTuple<[z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>, z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>], null>;
            observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            question: z.ZodString;
            goal: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-layers">;
        content: z.ZodObject<{
            layers: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-flow">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodString>;
            caption: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-compare">;
        content: z.ZodObject<{
            names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            metrics: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                max: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-summary">;
        content: z.ZodObject<{
            concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            center: z.ZodString;
            transfer: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-pythagoras">;
        content: z.ZodObject<{
            a: z.ZodNumber;
            b: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-tangent">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            at: z.ZodNumber;
            startDx: z.ZodNumber;
            xmax: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-integral">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            end: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-probability">;
        content: z.ZodObject<{
            total: z.ZodNumber;
            condition: z.ZodNumber;
            intersection: z.ZodNumber;
            outsideTarget: z.ZodNumber;
            conditionName: z.ZodString;
            targetName: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-forces">;
        content: z.ZodObject<{
            mass: z.ZodNumber;
            drive: z.ZodNumber;
            resistance: z.ZodNumber;
            duration: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-waves">;
        content: z.ZodObject<{
            amplitude1: z.ZodNumber;
            amplitude2: z.ZodNumber;
            cycles1: z.ZodNumber;
            cycles2: z.ZodNumber;
            phase2: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-circuit">;
        content: z.ZodObject<{
            voltage: z.ZodNumber;
            resistance1: z.ZodNumber;
            resistance2: z.ZodNumber;
            topology: z.ZodEnum<{
                series: "series";
                parallel: "parallel";
            }>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-reaction">;
        content: z.ZodObject<{
            reactants: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            products: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-titration">;
        content: z.ZodObject<{
            acidMl: z.ZodNumber;
            acidMolarity: z.ZodNumber;
            baseMolarity: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-mitosis">;
        content: z.ZodObject<{
            chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-enzyme">;
        content: z.ZodObject<{
            enzyme: z.ZodString;
            substrate: z.ZodString;
            products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"geography-water">;
        content: z.ZodObject<{
            title: z.ZodString;
            nodes: z.ZodTuple<[z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>], null>;
            transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
            stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"history-timeline">;
        content: z.ZodObject<{
            range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            events: z.ZodTuple<[z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>], null>;
            caution: z.ZodString;
            conclusion: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-syntax">;
        content: z.ZodObject<{
            subject: z.ZodString;
            verb: z.ZodString;
            object: z.ZodString;
            question: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-perspective">;
        content: z.ZodObject<{
            object: z.ZodEnum<{
                door: "door";
                book: "book";
            }>;
            firstPerson: z.ZodString;
            observer: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-sorting">;
        content: z.ZodObject<{
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-recursion">;
        content: z.ZodObject<{
            operation: z.ZodEnum<{
                product: "product";
                sum: "sum";
            }>;
            start: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-score">;
        content: z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-harmony">;
        content: z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"economics-equilibrium">;
        content: z.ZodObject<{
            demandIntercept: z.ZodNumber;
            supplyIntercept: z.ZodNumber;
            demandSlope: z.ZodNumber;
            supplySlope: z.ZodNumber;
            demandShift: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-timeline">;
        content: z.ZodObject<{
            unit: z.ZodString;
            events: z.ZodArray<z.ZodObject<{
                at: z.ZodNumber;
                label: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-cycle">;
        content: z.ZodObject<{
            center: z.ZodString;
            nodes: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                process: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-decision">;
        content: z.ZodObject<{
            question: z.ZodString;
            branches: z.ZodArray<z.ZodObject<{
                condition: z.ZodString;
                outcome: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-funnel">;
        content: z.ZodObject<{
            unit: z.ZodString;
            stages: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-balance">;
        content: z.ZodObject<{
            unit: z.ZodString;
            left: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            right: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-matrix">;
        content: z.ZodObject<{
            columns: z.ZodArray<z.ZodString>;
            rows: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>>;
            unit: z.ZodString;
            max: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-proportion">;
        content: z.ZodObject<{
            whole: z.ZodString;
            unit: z.ZodString;
            parts: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-network">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
            links: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-counter">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            from: z.ZodNumber;
            to: z.ZodNumber;
            context: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-interval">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            min: z.ZodNumber;
            max: z.ZodNumber;
            low: z.ZodNumber;
            high: z.ZodNumber;
            points: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-hierarchy">;
        content: z.ZodObject<{
            root: z.ZodString;
            groups: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                members: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-ranking">;
        content: z.ZodObject<{
            unit: z.ZodString;
            before: z.ZodString;
            after: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>], "templateId">, z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        kind: z.ZodEnum<{
            process: "process";
            cycle: "cycle";
            layers: "layers";
        }>;
        items: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            id: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        unit: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"bars">;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"code">;
        id: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        language: z.ZodOptional<z.ZodString>;
        parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            text: z.ZodString;
        }, z.core.$strip>>>;
        regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            match: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"conversation">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        turns: z.ZodArray<z.ZodObject<{
            speaker: z.ZodString;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"callout">;
        id: z.ZodOptional<z.ZodString>;
        variant: z.ZodEnum<{
            example: "example";
            warning: "warning";
            definition: "definition";
            tip: "tip";
        }>;
        title: z.ZodOptional<z.ZodString>;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"accordion">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"illustration">;
        id: z.ZodOptional<z.ZodString>;
        caption: z.ZodString;
        prompt: z.ZodString;
        style: z.ZodEnum<{
            process: "process";
            diagram: "diagram";
            concept: "concept";
            comparison: "comparison";
        }>;
        aspectRatio: z.ZodOptional<z.ZodEnum<{
            "1:1": "1:1";
            "16:9": "16:9";
            "9:16": "9:16";
            "4:3": "4:3";
            "3:4": "3:4";
            "3:2": "3:2";
            "2:3": "2:3";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"svg_slot">;
        id: z.ZodOptional<z.ZodString>;
        intent: z.ZodObject<{
            visualKind: z.ZodEnum<{
                simple_structure: "simple_structure";
                spatial_relationship: "spatial_relationship";
                state_comparison: "state_comparison";
                step_derivation: "step_derivation";
            }>;
            setup: z.ZodString;
            learningGoal: z.ZodString;
            expectedInsight: z.ZodString;
            composition: z.ZodOptional<z.ZodString>;
            elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
            relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
            labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
            avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>;
    }, z.core.$strip>]>>;
}, z.core.$strip>]>;
export declare const sectionMaterialProviderBlockSchema: z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"music">;
    id: z.ZodOptional<z.ZodString>;
    version: z.ZodLiteral<1>;
    title: z.ZodString;
    key: z.ZodLiteral<"C">;
    meter: z.ZodEnum<{
        "2/4": "2/4";
        "3/4": "3/4";
        "4/4": "4/4";
    }>;
    tempo: z.ZodNumber;
    keyboard: z.ZodBoolean;
    notation: z.ZodOptional<z.ZodEnum<{
        staff: "staff";
        both: "both";
        jianpu: "jianpu";
    }>>;
    parts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        clef: z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        bars: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodObject<{
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    steps: z.ZodArray<z.ZodObject<{
        bars: z.ZodArray<z.ZodNumber>;
        parts: z.ZodArray<z.ZodString>;
        instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
            part: z.ZodString;
            instrument: z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>;
        }, z.core.$strict>>>;
        id: z.ZodString;
        label: z.ZodString;
        focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
        compare: z.ZodOptional<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"music">;
    version: z.ZodLiteral<2>;
    id: z.ZodString;
    title: z.ZodString;
    layout: z.ZodEnum<{
        row: "row";
        column: "column";
        grid: "grid";
    }>;
    notes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        pitches: z.ZodArray<z.ZodString>;
        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
    }, z.core.$strict>>;
    views: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            staff: "staff";
            keyboard: "keyboard";
        }>;
        label: z.ZodString;
        notes: z.ZodArray<z.ZodString>;
        clef: z.ZodOptional<z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>>;
        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            label: "label";
            link: "link";
            bracket: "bracket";
            arrow: "arrow";
        }>;
        label: z.ZodString;
        anchors: z.ZodArray<z.ZodObject<{
            viewId: z.ZodString;
            noteId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        tempo: z.ZodNumber;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        events: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
    templateId: z.ZodLiteral<"general-question">;
    content: z.ZodObject<{
        objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        glyphs: z.ZodTuple<[z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>, z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>], null>;
        observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        question: z.ZodString;
        goal: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-layers">;
    content: z.ZodObject<{
        layers: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-flow">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodString>;
        caption: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-compare">;
    content: z.ZodObject<{
        names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        metrics: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            max: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-summary">;
    content: z.ZodObject<{
        concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        center: z.ZodString;
        transfer: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-pythagoras">;
    content: z.ZodObject<{
        a: z.ZodNumber;
        b: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-tangent">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
        at: z.ZodNumber;
        startDx: z.ZodNumber;
        xmax: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-integral">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        end: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-probability">;
    content: z.ZodObject<{
        total: z.ZodNumber;
        condition: z.ZodNumber;
        intersection: z.ZodNumber;
        outsideTarget: z.ZodNumber;
        conditionName: z.ZodString;
        targetName: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-forces">;
    content: z.ZodObject<{
        mass: z.ZodNumber;
        drive: z.ZodNumber;
        resistance: z.ZodNumber;
        duration: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-waves">;
    content: z.ZodObject<{
        amplitude1: z.ZodNumber;
        amplitude2: z.ZodNumber;
        cycles1: z.ZodNumber;
        cycles2: z.ZodNumber;
        phase2: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-circuit">;
    content: z.ZodObject<{
        voltage: z.ZodNumber;
        resistance1: z.ZodNumber;
        resistance2: z.ZodNumber;
        topology: z.ZodEnum<{
            series: "series";
            parallel: "parallel";
        }>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-reaction">;
    content: z.ZodObject<{
        reactants: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        products: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-titration">;
    content: z.ZodObject<{
        acidMl: z.ZodNumber;
        acidMolarity: z.ZodNumber;
        baseMolarity: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-mitosis">;
    content: z.ZodObject<{
        chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-enzyme">;
    content: z.ZodObject<{
        enzyme: z.ZodString;
        substrate: z.ZodString;
        products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"geography-water">;
    content: z.ZodObject<{
        title: z.ZodString;
        nodes: z.ZodTuple<[z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>], null>;
        transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
        stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"history-timeline">;
    content: z.ZodObject<{
        range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
        events: z.ZodTuple<[z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>], null>;
        caution: z.ZodString;
        conclusion: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-syntax">;
    content: z.ZodObject<{
        subject: z.ZodString;
        verb: z.ZodString;
        object: z.ZodString;
        question: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-perspective">;
    content: z.ZodObject<{
        object: z.ZodEnum<{
            door: "door";
            book: "book";
        }>;
        firstPerson: z.ZodString;
        observer: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-sorting">;
    content: z.ZodObject<{
        values: z.ZodArray<z.ZodNumber>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-recursion">;
    content: z.ZodObject<{
        operation: z.ZodEnum<{
            product: "product";
            sum: "sum";
        }>;
        start: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-score">;
    content: z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-harmony">;
    content: z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"economics-equilibrium">;
    content: z.ZodObject<{
        demandIntercept: z.ZodNumber;
        supplyIntercept: z.ZodNumber;
        demandSlope: z.ZodNumber;
        supplySlope: z.ZodNumber;
        demandShift: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-timeline">;
    content: z.ZodObject<{
        unit: z.ZodString;
        events: z.ZodArray<z.ZodObject<{
            at: z.ZodNumber;
            label: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-cycle">;
    content: z.ZodObject<{
        center: z.ZodString;
        nodes: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            process: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-decision">;
    content: z.ZodObject<{
        question: z.ZodString;
        branches: z.ZodArray<z.ZodObject<{
            condition: z.ZodString;
            outcome: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-funnel">;
    content: z.ZodObject<{
        unit: z.ZodString;
        stages: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-balance">;
    content: z.ZodObject<{
        unit: z.ZodString;
        left: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        right: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-matrix">;
    content: z.ZodObject<{
        columns: z.ZodArray<z.ZodString>;
        rows: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>>;
        unit: z.ZodString;
        max: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-proportion">;
    content: z.ZodObject<{
        whole: z.ZodString;
        unit: z.ZodString;
        parts: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-network">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
        links: z.ZodArray<z.ZodObject<{
            from: z.ZodString;
            to: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-counter">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        from: z.ZodNumber;
        to: z.ZodNumber;
        context: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-interval">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        min: z.ZodNumber;
        max: z.ZodNumber;
        low: z.ZodNumber;
        high: z.ZodNumber;
        points: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-hierarchy">;
    content: z.ZodObject<{
        root: z.ZodString;
        groups: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            members: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-ranking">;
    content: z.ZodObject<{
        unit: z.ZodString;
        before: z.ZodString;
        after: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            before: z.ZodNumber;
            after: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>], "templateId">, z.ZodObject<{
    type: z.ZodLiteral<"visual">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    kind: z.ZodEnum<{
        process: "process";
        cycle: "cycle";
        layers: "layers";
    }>;
    items: z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
        id: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"visual">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    unit: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"bars">;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
        value: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
    templateId: z.ZodLiteral<"general-question">;
    content: z.ZodObject<{
        objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        glyphs: z.ZodTuple<[z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>, z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>], null>;
        observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        question: z.ZodString;
        goal: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-layers">;
    content: z.ZodObject<{
        layers: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-flow">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodString>;
        caption: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-compare">;
    content: z.ZodObject<{
        names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        metrics: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            max: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-summary">;
    content: z.ZodObject<{
        concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        center: z.ZodString;
        transfer: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-pythagoras">;
    content: z.ZodObject<{
        a: z.ZodNumber;
        b: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-tangent">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
        at: z.ZodNumber;
        startDx: z.ZodNumber;
        xmax: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-integral">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        end: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-probability">;
    content: z.ZodObject<{
        total: z.ZodNumber;
        condition: z.ZodNumber;
        intersection: z.ZodNumber;
        outsideTarget: z.ZodNumber;
        conditionName: z.ZodString;
        targetName: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-forces">;
    content: z.ZodObject<{
        mass: z.ZodNumber;
        drive: z.ZodNumber;
        resistance: z.ZodNumber;
        duration: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-waves">;
    content: z.ZodObject<{
        amplitude1: z.ZodNumber;
        amplitude2: z.ZodNumber;
        cycles1: z.ZodNumber;
        cycles2: z.ZodNumber;
        phase2: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-circuit">;
    content: z.ZodObject<{
        voltage: z.ZodNumber;
        resistance1: z.ZodNumber;
        resistance2: z.ZodNumber;
        topology: z.ZodEnum<{
            series: "series";
            parallel: "parallel";
        }>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-reaction">;
    content: z.ZodObject<{
        reactants: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        products: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-titration">;
    content: z.ZodObject<{
        acidMl: z.ZodNumber;
        acidMolarity: z.ZodNumber;
        baseMolarity: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-mitosis">;
    content: z.ZodObject<{
        chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-enzyme">;
    content: z.ZodObject<{
        enzyme: z.ZodString;
        substrate: z.ZodString;
        products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"geography-water">;
    content: z.ZodObject<{
        title: z.ZodString;
        nodes: z.ZodTuple<[z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>], null>;
        transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
        stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"history-timeline">;
    content: z.ZodObject<{
        range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
        events: z.ZodTuple<[z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>], null>;
        caution: z.ZodString;
        conclusion: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-syntax">;
    content: z.ZodObject<{
        subject: z.ZodString;
        verb: z.ZodString;
        object: z.ZodString;
        question: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-perspective">;
    content: z.ZodObject<{
        object: z.ZodEnum<{
            door: "door";
            book: "book";
        }>;
        firstPerson: z.ZodString;
        observer: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-sorting">;
    content: z.ZodObject<{
        values: z.ZodArray<z.ZodNumber>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-recursion">;
    content: z.ZodObject<{
        operation: z.ZodEnum<{
            product: "product";
            sum: "sum";
        }>;
        start: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-score">;
    content: z.ZodUnion<readonly [z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodObject<{
        source: z.ZodLiteral<"accepted-v2">;
        block: z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        clipId: z.ZodOptional<z.ZodString>;
        repeat: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>]>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-harmony">;
    content: z.ZodUnion<readonly [z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodObject<{
        source: z.ZodLiteral<"accepted-v2">;
        block: z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        clipId: z.ZodOptional<z.ZodString>;
        repeat: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>]>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"economics-equilibrium">;
    content: z.ZodObject<{
        demandIntercept: z.ZodNumber;
        supplyIntercept: z.ZodNumber;
        demandSlope: z.ZodNumber;
        supplySlope: z.ZodNumber;
        demandShift: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-timeline">;
    content: z.ZodObject<{
        unit: z.ZodString;
        events: z.ZodArray<z.ZodObject<{
            at: z.ZodNumber;
            label: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-cycle">;
    content: z.ZodObject<{
        center: z.ZodString;
        nodes: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            process: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-decision">;
    content: z.ZodObject<{
        question: z.ZodString;
        branches: z.ZodArray<z.ZodObject<{
            condition: z.ZodString;
            outcome: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-funnel">;
    content: z.ZodObject<{
        unit: z.ZodString;
        stages: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-balance">;
    content: z.ZodObject<{
        unit: z.ZodString;
        left: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        right: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-matrix">;
    content: z.ZodObject<{
        columns: z.ZodArray<z.ZodString>;
        rows: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>>;
        unit: z.ZodString;
        max: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-proportion">;
    content: z.ZodObject<{
        whole: z.ZodString;
        unit: z.ZodString;
        parts: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-network">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
        links: z.ZodArray<z.ZodObject<{
            from: z.ZodString;
            to: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-counter">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        from: z.ZodNumber;
        to: z.ZodNumber;
        context: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-interval">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        min: z.ZodNumber;
        max: z.ZodNumber;
        low: z.ZodNumber;
        high: z.ZodNumber;
        points: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-hierarchy">;
    content: z.ZodObject<{
        root: z.ZodString;
        groups: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            members: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-ranking">;
    content: z.ZodObject<{
        unit: z.ZodString;
        before: z.ZodString;
        after: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            before: z.ZodNumber;
            after: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>], "templateId"> | z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"music">;
    id: z.ZodOptional<z.ZodString>;
    version: z.ZodLiteral<1>;
    title: z.ZodString;
    key: z.ZodLiteral<"C">;
    meter: z.ZodEnum<{
        "2/4": "2/4";
        "3/4": "3/4";
        "4/4": "4/4";
    }>;
    tempo: z.ZodNumber;
    keyboard: z.ZodBoolean;
    notation: z.ZodOptional<z.ZodEnum<{
        staff: "staff";
        both: "both";
        jianpu: "jianpu";
    }>>;
    parts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        clef: z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        bars: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodObject<{
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    steps: z.ZodArray<z.ZodObject<{
        bars: z.ZodArray<z.ZodNumber>;
        parts: z.ZodArray<z.ZodString>;
        instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
            part: z.ZodString;
            instrument: z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>;
        }, z.core.$strict>>>;
        id: z.ZodString;
        label: z.ZodString;
        focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
        compare: z.ZodOptional<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"music">;
    version: z.ZodLiteral<2>;
    id: z.ZodString;
    title: z.ZodString;
    layout: z.ZodEnum<{
        row: "row";
        column: "column";
        grid: "grid";
    }>;
    notes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        pitches: z.ZodArray<z.ZodString>;
        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
    }, z.core.$strict>>;
    views: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            staff: "staff";
            keyboard: "keyboard";
        }>;
        label: z.ZodString;
        notes: z.ZodArray<z.ZodString>;
        clef: z.ZodOptional<z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>>;
        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            label: "label";
            link: "link";
            bracket: "bracket";
            arrow: "arrow";
        }>;
        label: z.ZodString;
        anchors: z.ZodArray<z.ZodObject<{
            viewId: z.ZodString;
            noteId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        tempo: z.ZodNumber;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        events: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strict>], "version"> | z.ZodObject<{
    type: z.ZodLiteral<"illustration">;
    id: z.ZodOptional<z.ZodString>;
    caption: z.ZodString;
    prompt: z.ZodString;
    style: z.ZodEnum<{
        process: "process";
        diagram: "diagram";
        concept: "concept";
        comparison: "comparison";
    }>;
    aspectRatio: z.ZodOptional<z.ZodEnum<{
        "1:1": "1:1";
        "16:9": "16:9";
        "9:16": "9:16";
        "4:3": "4:3";
        "3:4": "3:4";
        "3:2": "3:2";
        "2:3": "2:3";
    }>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"visual">;
    id: z.ZodOptional<z.ZodString>;
    kind: z.ZodEnum<{
        process: "process";
        cycle: "cycle";
        layers: "layers";
        bars: "bars";
    }>;
    title: z.ZodString;
    unit: z.ZodOptional<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
        value: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict> | z.ZodObject<{
    type: z.ZodLiteral<"code">;
    id: z.ZodOptional<z.ZodString>;
    code: z.ZodString;
    language: z.ZodOptional<z.ZodString>;
    parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        text: z.ZodString;
    }, z.core.$strip>>>;
    regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        match: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"conversation">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodOptional<z.ZodString>;
    turns: z.ZodArray<z.ZodObject<{
        speaker: z.ZodString;
        text: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"callout">;
    id: z.ZodOptional<z.ZodString>;
    variant: z.ZodEnum<{
        example: "example";
        warning: "warning";
        definition: "definition";
        tip: "tip";
    }>;
    title: z.ZodOptional<z.ZodString>;
    body: z.ZodString;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"accordion">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    body: z.ZodString;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"compare">;
    id: z.ZodOptional<z.ZodString>;
    left: z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    right: z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"stage">;
    id: z.ZodOptional<z.ZodString>;
    layout: z.ZodEnum<{
        "split-h": "split-h";
        "split-v": "split-v";
        "main+rail": "main+rail";
        stack: "stack";
    }>;
    presentation: z.ZodOptional<z.ZodEnum<{
        compare: "compare";
        steps: "steps";
        focus: "focus";
    }>>;
    figures: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"music">;
        id: z.ZodOptional<z.ZodString>;
        version: z.ZodLiteral<1>;
        title: z.ZodString;
        key: z.ZodLiteral<"C">;
        meter: z.ZodEnum<{
            "2/4": "2/4";
            "3/4": "3/4";
            "4/4": "4/4";
        }>;
        tempo: z.ZodNumber;
        keyboard: z.ZodBoolean;
        notation: z.ZodOptional<z.ZodEnum<{
            staff: "staff";
            both: "both";
            jianpu: "jianpu";
        }>>;
        parts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            clef: z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            bars: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodObject<{
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            id: z.ZodString;
            label: z.ZodString;
            focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
            compare: z.ZodOptional<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"music">;
        version: z.ZodLiteral<2>;
        id: z.ZodString;
        title: z.ZodString;
        layout: z.ZodEnum<{
            row: "row";
            column: "column";
            grid: "grid";
        }>;
        notes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            pitches: z.ZodArray<z.ZodString>;
            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
        }, z.core.$strict>>;
        views: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                staff: "staff";
                keyboard: "keyboard";
            }>;
            label: z.ZodString;
            notes: z.ZodArray<z.ZodString>;
            clef: z.ZodOptional<z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>>;
            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                label: "label";
                link: "link";
                bracket: "bracket";
                arrow: "arrow";
            }>;
            label: z.ZodString;
            anchors: z.ZodArray<z.ZodObject<{
                viewId: z.ZodString;
                noteId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            tempo: z.ZodNumber;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            events: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
        templateId: z.ZodLiteral<"general-question">;
        content: z.ZodObject<{
            objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            glyphs: z.ZodTuple<[z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>, z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>], null>;
            observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            question: z.ZodString;
            goal: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-layers">;
        content: z.ZodObject<{
            layers: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-flow">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodString>;
            caption: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-compare">;
        content: z.ZodObject<{
            names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            metrics: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                max: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-summary">;
        content: z.ZodObject<{
            concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            center: z.ZodString;
            transfer: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-pythagoras">;
        content: z.ZodObject<{
            a: z.ZodNumber;
            b: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-tangent">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            at: z.ZodNumber;
            startDx: z.ZodNumber;
            xmax: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-integral">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            end: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-probability">;
        content: z.ZodObject<{
            total: z.ZodNumber;
            condition: z.ZodNumber;
            intersection: z.ZodNumber;
            outsideTarget: z.ZodNumber;
            conditionName: z.ZodString;
            targetName: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-forces">;
        content: z.ZodObject<{
            mass: z.ZodNumber;
            drive: z.ZodNumber;
            resistance: z.ZodNumber;
            duration: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-waves">;
        content: z.ZodObject<{
            amplitude1: z.ZodNumber;
            amplitude2: z.ZodNumber;
            cycles1: z.ZodNumber;
            cycles2: z.ZodNumber;
            phase2: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-circuit">;
        content: z.ZodObject<{
            voltage: z.ZodNumber;
            resistance1: z.ZodNumber;
            resistance2: z.ZodNumber;
            topology: z.ZodEnum<{
                series: "series";
                parallel: "parallel";
            }>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-reaction">;
        content: z.ZodObject<{
            reactants: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            products: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-titration">;
        content: z.ZodObject<{
            acidMl: z.ZodNumber;
            acidMolarity: z.ZodNumber;
            baseMolarity: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-mitosis">;
        content: z.ZodObject<{
            chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-enzyme">;
        content: z.ZodObject<{
            enzyme: z.ZodString;
            substrate: z.ZodString;
            products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"geography-water">;
        content: z.ZodObject<{
            title: z.ZodString;
            nodes: z.ZodTuple<[z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>], null>;
            transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
            stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"history-timeline">;
        content: z.ZodObject<{
            range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            events: z.ZodTuple<[z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>], null>;
            caution: z.ZodString;
            conclusion: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-syntax">;
        content: z.ZodObject<{
            subject: z.ZodString;
            verb: z.ZodString;
            object: z.ZodString;
            question: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-perspective">;
        content: z.ZodObject<{
            object: z.ZodEnum<{
                door: "door";
                book: "book";
            }>;
            firstPerson: z.ZodString;
            observer: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-sorting">;
        content: z.ZodObject<{
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-recursion">;
        content: z.ZodObject<{
            operation: z.ZodEnum<{
                product: "product";
                sum: "sum";
            }>;
            start: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-score">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-harmony">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"economics-equilibrium">;
        content: z.ZodObject<{
            demandIntercept: z.ZodNumber;
            supplyIntercept: z.ZodNumber;
            demandSlope: z.ZodNumber;
            supplySlope: z.ZodNumber;
            demandShift: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-timeline">;
        content: z.ZodObject<{
            unit: z.ZodString;
            events: z.ZodArray<z.ZodObject<{
                at: z.ZodNumber;
                label: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-cycle">;
        content: z.ZodObject<{
            center: z.ZodString;
            nodes: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                process: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-decision">;
        content: z.ZodObject<{
            question: z.ZodString;
            branches: z.ZodArray<z.ZodObject<{
                condition: z.ZodString;
                outcome: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-funnel">;
        content: z.ZodObject<{
            unit: z.ZodString;
            stages: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-balance">;
        content: z.ZodObject<{
            unit: z.ZodString;
            left: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            right: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-matrix">;
        content: z.ZodObject<{
            columns: z.ZodArray<z.ZodString>;
            rows: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>>;
            unit: z.ZodString;
            max: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-proportion">;
        content: z.ZodObject<{
            whole: z.ZodString;
            unit: z.ZodString;
            parts: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-network">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
            links: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-counter">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            from: z.ZodNumber;
            to: z.ZodNumber;
            context: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-interval">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            min: z.ZodNumber;
            max: z.ZodNumber;
            low: z.ZodNumber;
            high: z.ZodNumber;
            points: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-hierarchy">;
        content: z.ZodObject<{
            root: z.ZodString;
            groups: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                members: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-ranking">;
        content: z.ZodObject<{
            unit: z.ZodString;
            before: z.ZodString;
            after: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>], "templateId">, z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        kind: z.ZodEnum<{
            process: "process";
            cycle: "cycle";
            layers: "layers";
            bars: "bars";
        }>;
        title: z.ZodString;
        unit: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            value: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"code">;
        id: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        language: z.ZodOptional<z.ZodString>;
        parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            text: z.ZodString;
        }, z.core.$strip>>>;
        regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            match: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"conversation">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        turns: z.ZodArray<z.ZodObject<{
            speaker: z.ZodString;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"callout">;
        id: z.ZodOptional<z.ZodString>;
        variant: z.ZodEnum<{
            example: "example";
            warning: "warning";
            definition: "definition";
            tip: "tip";
        }>;
        title: z.ZodOptional<z.ZodString>;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"accordion">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"illustration">;
        id: z.ZodOptional<z.ZodString>;
        caption: z.ZodString;
        prompt: z.ZodString;
        style: z.ZodEnum<{
            process: "process";
            diagram: "diagram";
            concept: "concept";
            comparison: "comparison";
        }>;
        aspectRatio: z.ZodOptional<z.ZodEnum<{
            "1:1": "1:1";
            "16:9": "16:9";
            "9:16": "9:16";
            "4:3": "4:3";
            "3:4": "3:4";
            "3:2": "3:2";
            "2:3": "2:3";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"svg_slot">;
        id: z.ZodOptional<z.ZodString>;
        intent: z.ZodObject<{
            visualKind: z.ZodEnum<{
                simple_structure: "simple_structure";
                spatial_relationship: "spatial_relationship";
                state_comparison: "state_comparison";
                step_derivation: "step_derivation";
            }>;
            setup: z.ZodString;
            learningGoal: z.ZodString;
            expectedInsight: z.ZodString;
            composition: z.ZodOptional<z.ZodString>;
            elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
            relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
            labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
            avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"compare">;
        id: z.ZodOptional<z.ZodString>;
        left: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        right: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>>;
    }, z.core.$strip>], "type">>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"heading">;
    level: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
    text: z.ZodString;
    topicId: z.ZodOptional<z.ZodString>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"paragraph">;
    text: z.ZodString;
    cue: z.ZodOptional<z.ZodObject<{
        music: z.ZodOptional<z.ZodObject<{
            figureId: z.ZodString;
            clipId: z.ZodString;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        target: z.ZodString;
        targetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        op: z.ZodOptional<z.ZodEnum<{
            highlight: "highlight";
            window: "window";
        }>>;
        regionIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        figureId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
    templateId: z.ZodLiteral<"general-question">;
    content: z.ZodObject<{
        objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        glyphs: z.ZodTuple<[z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>, z.ZodEnum<{
            object: "object";
            question: "question";
            paper: "paper";
            boat: "boat";
            read: "read";
            recall: "recall";
        }>], null>;
        observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        question: z.ZodString;
        goal: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-layers">;
    content: z.ZodObject<{
        layers: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-flow">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodString>;
        caption: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-compare">;
    content: z.ZodObject<{
        names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        metrics: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            max: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"general-summary">;
    content: z.ZodObject<{
        concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        center: z.ZodString;
        transfer: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-pythagoras">;
    content: z.ZodObject<{
        a: z.ZodNumber;
        b: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-tangent">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
        at: z.ZodNumber;
        startDx: z.ZodNumber;
        xmax: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-integral">;
    content: z.ZodObject<{
        coefficient: z.ZodNumber;
        power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        end: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"math-probability">;
    content: z.ZodObject<{
        total: z.ZodNumber;
        condition: z.ZodNumber;
        intersection: z.ZodNumber;
        outsideTarget: z.ZodNumber;
        conditionName: z.ZodString;
        targetName: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-forces">;
    content: z.ZodObject<{
        mass: z.ZodNumber;
        drive: z.ZodNumber;
        resistance: z.ZodNumber;
        duration: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-waves">;
    content: z.ZodObject<{
        amplitude1: z.ZodNumber;
        amplitude2: z.ZodNumber;
        cycles1: z.ZodNumber;
        cycles2: z.ZodNumber;
        phase2: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"physics-circuit">;
    content: z.ZodObject<{
        voltage: z.ZodNumber;
        resistance1: z.ZodNumber;
        resistance2: z.ZodNumber;
        topology: z.ZodEnum<{
            series: "series";
            parallel: "parallel";
        }>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-reaction">;
    content: z.ZodObject<{
        reactants: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        products: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            atoms: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                element: z.ZodString;
            }, z.core.$strict>>;
            bonds: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"chemistry-titration">;
    content: z.ZodObject<{
        acidMl: z.ZodNumber;
        acidMolarity: z.ZodNumber;
        baseMolarity: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-mitosis">;
    content: z.ZodObject<{
        chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"biology-enzyme">;
    content: z.ZodObject<{
        enzyme: z.ZodString;
        substrate: z.ZodString;
        products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"geography-water">;
    content: z.ZodObject<{
        title: z.ZodString;
        nodes: z.ZodTuple<[z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            label: z.ZodString;
            glyph: z.ZodEnum<{
                water: "water";
                vapor: "vapor";
                cloud: "cloud";
                drop: "drop";
                magma: "magma";
                rock: "rock";
                sediment: "sediment";
                strata: "strata";
            }>;
        }, z.core.$strict>], null>;
        transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
        stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"history-timeline">;
    content: z.ZodObject<{
        range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
        events: z.ZodTuple<[z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            year: z.ZodNumber;
            label: z.ZodString;
            evidence: z.ZodString;
            approximate: z.ZodOptional<z.ZodBoolean>;
            kind: z.ZodEnum<{
                type: "type";
                block: "block";
                moon: "moon";
                telescope: "telescope";
                event: "event";
            }>;
        }, z.core.$strict>], null>;
        caution: z.ZodString;
        conclusion: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-syntax">;
    content: z.ZodObject<{
        subject: z.ZodString;
        verb: z.ZodString;
        object: z.ZodString;
        question: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"language-perspective">;
    content: z.ZodObject<{
        object: z.ZodEnum<{
            door: "door";
            book: "book";
        }>;
        firstPerson: z.ZodString;
        observer: z.ZodString;
        note: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-sorting">;
    content: z.ZodObject<{
        values: z.ZodArray<z.ZodNumber>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"cs-recursion">;
    content: z.ZodObject<{
        operation: z.ZodEnum<{
            product: "product";
            sum: "sum";
        }>;
        start: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-score">;
    content: z.ZodUnion<readonly [z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodObject<{
        source: z.ZodLiteral<"accepted-v2">;
        block: z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        clipId: z.ZodOptional<z.ZodString>;
        repeat: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>]>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"music-harmony">;
    content: z.ZodUnion<readonly [z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        groups: z.ZodArray<z.ZodArray<z.ZodString>>;
        labels: z.ZodArray<z.ZodString>;
        beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
        range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        tempo: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodObject<{
        source: z.ZodLiteral<"accepted-v2">;
        block: z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        clipId: z.ZodOptional<z.ZodString>;
        repeat: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>]>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"economics-equilibrium">;
    content: z.ZodObject<{
        demandIntercept: z.ZodNumber;
        supplyIntercept: z.ZodNumber;
        demandSlope: z.ZodNumber;
        supplySlope: z.ZodNumber;
        demandShift: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-timeline">;
    content: z.ZodObject<{
        unit: z.ZodString;
        events: z.ZodArray<z.ZodObject<{
            at: z.ZodNumber;
            label: z.ZodString;
            detail: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-cycle">;
    content: z.ZodObject<{
        center: z.ZodString;
        nodes: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            process: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-decision">;
    content: z.ZodObject<{
        question: z.ZodString;
        branches: z.ZodArray<z.ZodObject<{
            condition: z.ZodString;
            outcome: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-funnel">;
    content: z.ZodObject<{
        unit: z.ZodString;
        stages: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-balance">;
    content: z.ZodObject<{
        unit: z.ZodString;
        left: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        right: z.ZodObject<{
            label: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-matrix">;
    content: z.ZodObject<{
        columns: z.ZodArray<z.ZodString>;
        rows: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>>;
        unit: z.ZodString;
        max: z.ZodNumber;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-proportion">;
    content: z.ZodObject<{
        whole: z.ZodString;
        unit: z.ZodString;
        parts: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-network">;
    content: z.ZodObject<{
        nodes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
        links: z.ZodArray<z.ZodObject<{
            from: z.ZodString;
            to: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-counter">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        from: z.ZodNumber;
        to: z.ZodNumber;
        context: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-interval">;
    content: z.ZodObject<{
        label: z.ZodString;
        unit: z.ZodString;
        min: z.ZodNumber;
        max: z.ZodNumber;
        low: z.ZodNumber;
        high: z.ZodNumber;
        points: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-hierarchy">;
    content: z.ZodObject<{
        root: z.ZodString;
        groups: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            members: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    templateId: z.ZodLiteral<"visual-ranking">;
    content: z.ZodObject<{
        unit: z.ZodString;
        before: z.ZodString;
        after: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            before: z.ZodNumber;
            after: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    type: z.ZodLiteral<"teaching">;
    version: z.ZodLiteral<1>;
    id: z.ZodString;
    title: z.ZodString;
}, z.core.$strict>], "templateId"> | z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"music">;
    id: z.ZodOptional<z.ZodString>;
    version: z.ZodLiteral<1>;
    title: z.ZodString;
    key: z.ZodLiteral<"C">;
    meter: z.ZodEnum<{
        "2/4": "2/4";
        "3/4": "3/4";
        "4/4": "4/4";
    }>;
    tempo: z.ZodNumber;
    keyboard: z.ZodBoolean;
    notation: z.ZodOptional<z.ZodEnum<{
        staff: "staff";
        both: "both";
        jianpu: "jianpu";
    }>>;
    parts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        clef: z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        bars: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodObject<{
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    steps: z.ZodArray<z.ZodObject<{
        bars: z.ZodArray<z.ZodNumber>;
        parts: z.ZodArray<z.ZodString>;
        instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
            part: z.ZodString;
            instrument: z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>;
        }, z.core.$strict>>>;
        id: z.ZodString;
        label: z.ZodString;
        focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
        compare: z.ZodOptional<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"music">;
    version: z.ZodLiteral<2>;
    id: z.ZodString;
    title: z.ZodString;
    layout: z.ZodEnum<{
        row: "row";
        column: "column";
        grid: "grid";
    }>;
    notes: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        pitches: z.ZodArray<z.ZodString>;
        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
    }, z.core.$strict>>;
    views: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            staff: "staff";
            keyboard: "keyboard";
        }>;
        label: z.ZodString;
        notes: z.ZodArray<z.ZodString>;
        clef: z.ZodOptional<z.ZodEnum<{
            treble: "treble";
            bass: "bass";
        }>>;
        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            label: "label";
            link: "link";
            bracket: "bracket";
            arrow: "arrow";
        }>;
        label: z.ZodString;
        anchors: z.ZodArray<z.ZodObject<{
            viewId: z.ZodString;
            noteId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        tempo: z.ZodNumber;
        instrument: z.ZodOptional<z.ZodEnum<{
            piano: "piano";
            electric_piano: "electric_piano";
            guitar: "guitar";
            violin: "violin";
            cello: "cello";
            flute: "flute";
            marimba: "marimba";
            organ: "organ";
        }>>;
        events: z.ZodArray<z.ZodObject<{
            notes: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strict>], "version"> | z.ZodObject<{
    type: z.ZodLiteral<"illustration">;
    id: z.ZodOptional<z.ZodString>;
    caption: z.ZodString;
    prompt: z.ZodString;
    style: z.ZodEnum<{
        process: "process";
        diagram: "diagram";
        concept: "concept";
        comparison: "comparison";
    }>;
    aspectRatio: z.ZodOptional<z.ZodEnum<{
        "1:1": "1:1";
        "16:9": "16:9";
        "9:16": "9:16";
        "4:3": "4:3";
        "3:4": "3:4";
        "3:2": "3:2";
        "2:3": "2:3";
    }>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"visual">;
    id: z.ZodOptional<z.ZodString>;
    kind: z.ZodEnum<{
        process: "process";
        cycle: "cycle";
        layers: "layers";
        bars: "bars";
    }>;
    title: z.ZodString;
    unit: z.ZodOptional<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
        value: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict> | z.ZodObject<{
    type: z.ZodLiteral<"code">;
    id: z.ZodOptional<z.ZodString>;
    code: z.ZodString;
    language: z.ZodOptional<z.ZodString>;
    parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        text: z.ZodString;
    }, z.core.$strip>>>;
    regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        match: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"conversation">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodOptional<z.ZodString>;
    turns: z.ZodArray<z.ZodObject<{
        speaker: z.ZodString;
        text: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"callout">;
    id: z.ZodOptional<z.ZodString>;
    variant: z.ZodEnum<{
        example: "example";
        warning: "warning";
        definition: "definition";
        tip: "tip";
    }>;
    title: z.ZodOptional<z.ZodString>;
    body: z.ZodString;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"accordion">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    body: z.ZodString;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"compare">;
    id: z.ZodOptional<z.ZodString>;
    left: z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    right: z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"stage">;
    id: z.ZodOptional<z.ZodString>;
    layout: z.ZodEnum<{
        "split-h": "split-h";
        "split-v": "split-v";
        "main+rail": "main+rail";
        stack: "stack";
    }>;
    presentation: z.ZodOptional<z.ZodEnum<{
        compare: "compare";
        steps: "steps";
        focus: "focus";
    }>>;
    figures: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"music">;
        id: z.ZodOptional<z.ZodString>;
        version: z.ZodLiteral<1>;
        title: z.ZodString;
        key: z.ZodLiteral<"C">;
        meter: z.ZodEnum<{
            "2/4": "2/4";
            "3/4": "3/4";
            "4/4": "4/4";
        }>;
        tempo: z.ZodNumber;
        keyboard: z.ZodBoolean;
        notation: z.ZodOptional<z.ZodEnum<{
            staff: "staff";
            both: "both";
            jianpu: "jianpu";
        }>>;
        parts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            clef: z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            bars: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodObject<{
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            id: z.ZodString;
            label: z.ZodString;
            focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
            compare: z.ZodOptional<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"music">;
        version: z.ZodLiteral<2>;
        id: z.ZodString;
        title: z.ZodString;
        layout: z.ZodEnum<{
            row: "row";
            column: "column";
            grid: "grid";
        }>;
        notes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            pitches: z.ZodArray<z.ZodString>;
            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
        }, z.core.$strict>>;
        views: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                staff: "staff";
                keyboard: "keyboard";
            }>;
            label: z.ZodString;
            notes: z.ZodArray<z.ZodString>;
            clef: z.ZodOptional<z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>>;
            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                label: "label";
                link: "link";
                bracket: "bracket";
                arrow: "arrow";
            }>;
            label: z.ZodString;
            anchors: z.ZodArray<z.ZodObject<{
                viewId: z.ZodString;
                noteId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            tempo: z.ZodNumber;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            events: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
        templateId: z.ZodLiteral<"general-question">;
        content: z.ZodObject<{
            objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            glyphs: z.ZodTuple<[z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>, z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>], null>;
            observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            question: z.ZodString;
            goal: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-layers">;
        content: z.ZodObject<{
            layers: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-flow">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodString>;
            caption: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-compare">;
        content: z.ZodObject<{
            names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            metrics: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                max: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-summary">;
        content: z.ZodObject<{
            concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            center: z.ZodString;
            transfer: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-pythagoras">;
        content: z.ZodObject<{
            a: z.ZodNumber;
            b: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-tangent">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            at: z.ZodNumber;
            startDx: z.ZodNumber;
            xmax: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-integral">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            end: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-probability">;
        content: z.ZodObject<{
            total: z.ZodNumber;
            condition: z.ZodNumber;
            intersection: z.ZodNumber;
            outsideTarget: z.ZodNumber;
            conditionName: z.ZodString;
            targetName: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-forces">;
        content: z.ZodObject<{
            mass: z.ZodNumber;
            drive: z.ZodNumber;
            resistance: z.ZodNumber;
            duration: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-waves">;
        content: z.ZodObject<{
            amplitude1: z.ZodNumber;
            amplitude2: z.ZodNumber;
            cycles1: z.ZodNumber;
            cycles2: z.ZodNumber;
            phase2: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-circuit">;
        content: z.ZodObject<{
            voltage: z.ZodNumber;
            resistance1: z.ZodNumber;
            resistance2: z.ZodNumber;
            topology: z.ZodEnum<{
                series: "series";
                parallel: "parallel";
            }>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-reaction">;
        content: z.ZodObject<{
            reactants: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            products: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-titration">;
        content: z.ZodObject<{
            acidMl: z.ZodNumber;
            acidMolarity: z.ZodNumber;
            baseMolarity: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-mitosis">;
        content: z.ZodObject<{
            chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-enzyme">;
        content: z.ZodObject<{
            enzyme: z.ZodString;
            substrate: z.ZodString;
            products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"geography-water">;
        content: z.ZodObject<{
            title: z.ZodString;
            nodes: z.ZodTuple<[z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>], null>;
            transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
            stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"history-timeline">;
        content: z.ZodObject<{
            range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            events: z.ZodTuple<[z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>], null>;
            caution: z.ZodString;
            conclusion: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-syntax">;
        content: z.ZodObject<{
            subject: z.ZodString;
            verb: z.ZodString;
            object: z.ZodString;
            question: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-perspective">;
        content: z.ZodObject<{
            object: z.ZodEnum<{
                door: "door";
                book: "book";
            }>;
            firstPerson: z.ZodString;
            observer: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-sorting">;
        content: z.ZodObject<{
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-recursion">;
        content: z.ZodObject<{
            operation: z.ZodEnum<{
                product: "product";
                sum: "sum";
            }>;
            start: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-score">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-harmony">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"economics-equilibrium">;
        content: z.ZodObject<{
            demandIntercept: z.ZodNumber;
            supplyIntercept: z.ZodNumber;
            demandSlope: z.ZodNumber;
            supplySlope: z.ZodNumber;
            demandShift: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-timeline">;
        content: z.ZodObject<{
            unit: z.ZodString;
            events: z.ZodArray<z.ZodObject<{
                at: z.ZodNumber;
                label: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-cycle">;
        content: z.ZodObject<{
            center: z.ZodString;
            nodes: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                process: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-decision">;
        content: z.ZodObject<{
            question: z.ZodString;
            branches: z.ZodArray<z.ZodObject<{
                condition: z.ZodString;
                outcome: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-funnel">;
        content: z.ZodObject<{
            unit: z.ZodString;
            stages: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-balance">;
        content: z.ZodObject<{
            unit: z.ZodString;
            left: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            right: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-matrix">;
        content: z.ZodObject<{
            columns: z.ZodArray<z.ZodString>;
            rows: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>>;
            unit: z.ZodString;
            max: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-proportion">;
        content: z.ZodObject<{
            whole: z.ZodString;
            unit: z.ZodString;
            parts: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-network">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
            links: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-counter">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            from: z.ZodNumber;
            to: z.ZodNumber;
            context: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-interval">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            min: z.ZodNumber;
            max: z.ZodNumber;
            low: z.ZodNumber;
            high: z.ZodNumber;
            points: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-hierarchy">;
        content: z.ZodObject<{
            root: z.ZodString;
            groups: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                members: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-ranking">;
        content: z.ZodObject<{
            unit: z.ZodString;
            before: z.ZodString;
            after: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>], "templateId">, z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        kind: z.ZodEnum<{
            process: "process";
            cycle: "cycle";
            layers: "layers";
            bars: "bars";
        }>;
        title: z.ZodString;
        unit: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            value: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"code">;
        id: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        language: z.ZodOptional<z.ZodString>;
        parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            text: z.ZodString;
        }, z.core.$strip>>>;
        regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            match: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"conversation">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        turns: z.ZodArray<z.ZodObject<{
            speaker: z.ZodString;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"callout">;
        id: z.ZodOptional<z.ZodString>;
        variant: z.ZodEnum<{
            example: "example";
            warning: "warning";
            definition: "definition";
            tip: "tip";
        }>;
        title: z.ZodOptional<z.ZodString>;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"accordion">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"illustration">;
        id: z.ZodOptional<z.ZodString>;
        caption: z.ZodString;
        prompt: z.ZodString;
        style: z.ZodEnum<{
            process: "process";
            diagram: "diagram";
            concept: "concept";
            comparison: "comparison";
        }>;
        aspectRatio: z.ZodOptional<z.ZodEnum<{
            "1:1": "1:1";
            "16:9": "16:9";
            "9:16": "9:16";
            "4:3": "4:3";
            "3:4": "3:4";
            "3:2": "3:2";
            "2:3": "2:3";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"svg_slot">;
        id: z.ZodOptional<z.ZodString>;
        intent: z.ZodObject<{
            visualKind: z.ZodEnum<{
                simple_structure: "simple_structure";
                spatial_relationship: "spatial_relationship";
                state_comparison: "state_comparison";
                step_derivation: "step_derivation";
            }>;
            setup: z.ZodString;
            learningGoal: z.ZodString;
            expectedInsight: z.ZodString;
            composition: z.ZodOptional<z.ZodString>;
            elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
            relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
            labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
            avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"compare">;
        id: z.ZodOptional<z.ZodString>;
        left: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        right: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>>;
    }, z.core.$strip>], "type">>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"heading">;
    level: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
    text: z.ZodString;
    topicId: z.ZodOptional<z.ZodString>;
}, z.core.$strip> | z.ZodObject<{
    type: z.ZodLiteral<"paragraph">;
    text: z.ZodString;
    cue: z.ZodOptional<z.ZodObject<{
        music: z.ZodOptional<z.ZodObject<{
            figureId: z.ZodString;
            clipId: z.ZodString;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        target: z.ZodString;
        targetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        op: z.ZodOptional<z.ZodEnum<{
            highlight: "highlight";
            window: "window";
        }>>;
        regionIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        figureId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"code">;
    id: z.ZodOptional<z.ZodString>;
    code: z.ZodString;
    language: z.ZodOptional<z.ZodString>;
    parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodOptional<z.ZodString>;
        text: z.ZodString;
    }, z.core.$strip>>>;
    regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        match: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"conversation">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodOptional<z.ZodString>;
    turns: z.ZodArray<z.ZodObject<{
        speaker: z.ZodString;
        text: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"callout">;
    id: z.ZodOptional<z.ZodString>;
    variant: z.ZodEnum<{
        example: "example";
        warning: "warning";
        definition: "definition";
        tip: "tip";
    }>;
    title: z.ZodOptional<z.ZodString>;
    body: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"accordion">;
    id: z.ZodOptional<z.ZodString>;
    title: z.ZodString;
    body: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"illustration">;
    id: z.ZodOptional<z.ZodString>;
    caption: z.ZodString;
    prompt: z.ZodString;
    style: z.ZodEnum<{
        process: "process";
        diagram: "diagram";
        concept: "concept";
        comparison: "comparison";
    }>;
    aspectRatio: z.ZodOptional<z.ZodEnum<{
        "1:1": "1:1";
        "16:9": "16:9";
        "9:16": "9:16";
        "4:3": "4:3";
        "3:4": "3:4";
        "3:2": "3:2";
        "2:3": "2:3";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"stage">;
    id: z.ZodOptional<z.ZodString>;
    layout: z.ZodEnum<{
        "split-h": "split-h";
        "split-v": "split-v";
        "main+rail": "main+rail";
        stack: "stack";
    }>;
    presentation: z.ZodOptional<z.ZodEnum<{
        compare: "compare";
        steps: "steps";
        focus: "focus";
    }>>;
    figures: z.ZodArray<z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"music">;
        id: z.ZodOptional<z.ZodString>;
        version: z.ZodLiteral<1>;
        title: z.ZodString;
        key: z.ZodLiteral<"C">;
        meter: z.ZodEnum<{
            "2/4": "2/4";
            "3/4": "3/4";
            "4/4": "4/4";
        }>;
        tempo: z.ZodNumber;
        keyboard: z.ZodBoolean;
        notation: z.ZodOptional<z.ZodEnum<{
            staff: "staff";
            both: "both";
            jianpu: "jianpu";
        }>>;
        parts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            clef: z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            bars: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodObject<{
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            id: z.ZodString;
            label: z.ZodString;
            focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
            compare: z.ZodOptional<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"music">;
        version: z.ZodLiteral<2>;
        id: z.ZodString;
        title: z.ZodString;
        layout: z.ZodEnum<{
            row: "row";
            column: "column";
            grid: "grid";
        }>;
        notes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            pitches: z.ZodArray<z.ZodString>;
            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
        }, z.core.$strict>>;
        views: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                staff: "staff";
                keyboard: "keyboard";
            }>;
            label: z.ZodString;
            notes: z.ZodArray<z.ZodString>;
            clef: z.ZodOptional<z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>>;
            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                label: "label";
                link: "link";
                bracket: "bracket";
                arrow: "arrow";
            }>;
            label: z.ZodString;
            anchors: z.ZodArray<z.ZodObject<{
                viewId: z.ZodString;
                noteId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            tempo: z.ZodNumber;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            events: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
        templateId: z.ZodLiteral<"general-question">;
        content: z.ZodObject<{
            objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            glyphs: z.ZodTuple<[z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>, z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>], null>;
            observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            question: z.ZodString;
            goal: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-layers">;
        content: z.ZodObject<{
            layers: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-flow">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodString>;
            caption: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-compare">;
        content: z.ZodObject<{
            names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            metrics: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                max: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-summary">;
        content: z.ZodObject<{
            concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            center: z.ZodString;
            transfer: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-pythagoras">;
        content: z.ZodObject<{
            a: z.ZodNumber;
            b: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-tangent">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            at: z.ZodNumber;
            startDx: z.ZodNumber;
            xmax: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-integral">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            end: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-probability">;
        content: z.ZodObject<{
            total: z.ZodNumber;
            condition: z.ZodNumber;
            intersection: z.ZodNumber;
            outsideTarget: z.ZodNumber;
            conditionName: z.ZodString;
            targetName: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-forces">;
        content: z.ZodObject<{
            mass: z.ZodNumber;
            drive: z.ZodNumber;
            resistance: z.ZodNumber;
            duration: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-waves">;
        content: z.ZodObject<{
            amplitude1: z.ZodNumber;
            amplitude2: z.ZodNumber;
            cycles1: z.ZodNumber;
            cycles2: z.ZodNumber;
            phase2: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-circuit">;
        content: z.ZodObject<{
            voltage: z.ZodNumber;
            resistance1: z.ZodNumber;
            resistance2: z.ZodNumber;
            topology: z.ZodEnum<{
                series: "series";
                parallel: "parallel";
            }>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-reaction">;
        content: z.ZodObject<{
            reactants: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            products: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-titration">;
        content: z.ZodObject<{
            acidMl: z.ZodNumber;
            acidMolarity: z.ZodNumber;
            baseMolarity: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-mitosis">;
        content: z.ZodObject<{
            chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-enzyme">;
        content: z.ZodObject<{
            enzyme: z.ZodString;
            substrate: z.ZodString;
            products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"geography-water">;
        content: z.ZodObject<{
            title: z.ZodString;
            nodes: z.ZodTuple<[z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>], null>;
            transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
            stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"history-timeline">;
        content: z.ZodObject<{
            range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            events: z.ZodTuple<[z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>], null>;
            caution: z.ZodString;
            conclusion: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-syntax">;
        content: z.ZodObject<{
            subject: z.ZodString;
            verb: z.ZodString;
            object: z.ZodString;
            question: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-perspective">;
        content: z.ZodObject<{
            object: z.ZodEnum<{
                door: "door";
                book: "book";
            }>;
            firstPerson: z.ZodString;
            observer: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-sorting">;
        content: z.ZodObject<{
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-recursion">;
        content: z.ZodObject<{
            operation: z.ZodEnum<{
                product: "product";
                sum: "sum";
            }>;
            start: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-score">;
        content: z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-harmony">;
        content: z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"economics-equilibrium">;
        content: z.ZodObject<{
            demandIntercept: z.ZodNumber;
            supplyIntercept: z.ZodNumber;
            demandSlope: z.ZodNumber;
            supplySlope: z.ZodNumber;
            demandShift: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-timeline">;
        content: z.ZodObject<{
            unit: z.ZodString;
            events: z.ZodArray<z.ZodObject<{
                at: z.ZodNumber;
                label: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-cycle">;
        content: z.ZodObject<{
            center: z.ZodString;
            nodes: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                process: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-decision">;
        content: z.ZodObject<{
            question: z.ZodString;
            branches: z.ZodArray<z.ZodObject<{
                condition: z.ZodString;
                outcome: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-funnel">;
        content: z.ZodObject<{
            unit: z.ZodString;
            stages: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-balance">;
        content: z.ZodObject<{
            unit: z.ZodString;
            left: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            right: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-matrix">;
        content: z.ZodObject<{
            columns: z.ZodArray<z.ZodString>;
            rows: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>>;
            unit: z.ZodString;
            max: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-proportion">;
        content: z.ZodObject<{
            whole: z.ZodString;
            unit: z.ZodString;
            parts: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-network">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
            links: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-counter">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            from: z.ZodNumber;
            to: z.ZodNumber;
            context: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-interval">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            min: z.ZodNumber;
            max: z.ZodNumber;
            low: z.ZodNumber;
            high: z.ZodNumber;
            points: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-hierarchy">;
        content: z.ZodObject<{
            root: z.ZodString;
            groups: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                members: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-ranking">;
        content: z.ZodObject<{
            unit: z.ZodString;
            before: z.ZodString;
            after: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>], "templateId">, z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        kind: z.ZodEnum<{
            process: "process";
            cycle: "cycle";
            layers: "layers";
        }>;
        items: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            id: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        unit: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"bars">;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"code">;
        id: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        language: z.ZodOptional<z.ZodString>;
        parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            text: z.ZodString;
        }, z.core.$strip>>>;
        regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            match: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"conversation">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        turns: z.ZodArray<z.ZodObject<{
            speaker: z.ZodString;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"callout">;
        id: z.ZodOptional<z.ZodString>;
        variant: z.ZodEnum<{
            example: "example";
            warning: "warning";
            definition: "definition";
            tip: "tip";
        }>;
        title: z.ZodOptional<z.ZodString>;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"accordion">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"illustration">;
        id: z.ZodOptional<z.ZodString>;
        caption: z.ZodString;
        prompt: z.ZodString;
        style: z.ZodEnum<{
            process: "process";
            diagram: "diagram";
            concept: "concept";
            comparison: "comparison";
        }>;
        aspectRatio: z.ZodOptional<z.ZodEnum<{
            "1:1": "1:1";
            "16:9": "16:9";
            "9:16": "9:16";
            "4:3": "4:3";
            "3:4": "3:4";
            "3:2": "3:2";
            "2:3": "2:3";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"svg_slot">;
        id: z.ZodOptional<z.ZodString>;
        intent: z.ZodObject<{
            visualKind: z.ZodEnum<{
                simple_structure: "simple_structure";
                spatial_relationship: "spatial_relationship";
                state_comparison: "state_comparison";
                step_derivation: "step_derivation";
            }>;
            setup: z.ZodString;
            learningGoal: z.ZodString;
            expectedInsight: z.ZodString;
            composition: z.ZodOptional<z.ZodString>;
            elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
            relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
            labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
            avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>;
    }, z.core.$strip>]>>;
}, z.core.$strip>]>, z.ZodUnion<readonly [z.ZodObject<{
    type: z.ZodLiteral<"component_slot">;
    slotRef: z.ZodString;
    intent: z.ZodObject<{
        setup: z.ZodString;
        learningGoal: z.ZodString;
        expectedInsight: z.ZodString;
    }, z.core.$strip>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"component_slot">;
    componentType: z.ZodEnum<{
        chart: "chart";
        math_scene: "math_scene";
        mechanics_sandbox: "mechanics_sandbox";
        circuit_sandbox: "circuit_sandbox";
        chemistry_lab: "chemistry_lab";
    }>;
    intent: z.ZodObject<{
        setup: z.ZodString;
        learningGoal: z.ZodString;
        expectedInsight: z.ZodString;
    }, z.core.$strip>;
}, z.core.$strip>]>, z.ZodObject<{
    type: z.ZodLiteral<"svg_slot">;
    intent: z.ZodObject<{
        visualKind: z.ZodEnum<{
            simple_structure: "simple_structure";
            spatial_relationship: "spatial_relationship";
            state_comparison: "state_comparison";
            step_derivation: "step_derivation";
        }>;
        setup: z.ZodString;
        learningGoal: z.ZodString;
        expectedInsight: z.ZodString;
        composition: z.ZodString;
        elements: z.ZodArray<z.ZodString>;
        relationships: z.ZodArray<z.ZodString>;
        labels: z.ZodArray<z.ZodString>;
        avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>]>;
export type SectionMaterialAuthoredBlock = z.infer<typeof sectionMaterialAuthoredBlockSchema>;
export type SectionMaterialProviderBlock = z.infer<typeof sectionMaterialProviderBlockSchema>;
export type SectionMaterialAuthoringPolicy = {
    allowedComponentTypes: readonly z.infer<typeof generatableComplexInteractiveBlockTypeSchema>[];
    maxComponentCount: number;
    allowIllustrations: boolean;
    minIllustrationCount?: number;
    maxIllustrationCount?: number;
    replaceInLessonVisualsWithIllustrations?: boolean;
    plannedComponents?: readonly {
        id: string;
        componentType: z.infer<typeof generatableComplexInteractiveBlockTypeSchema>;
    }[];
};
/** Same leaf cleanup used by hosted structured-generation recovery. */
export declare function normalizeSectionMaterialGeneratedJsonValue(value: unknown): unknown;
export declare function createSectionMaterialEnvelopeSchema(policy: SectionMaterialAuthoringPolicy): z.ZodPreprocess<z.ZodObject<{
    introduction: z.ZodString;
    blocks: z.ZodArray<z.ZodPreprocess<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"music">;
        id: z.ZodOptional<z.ZodString>;
        version: z.ZodLiteral<1>;
        title: z.ZodString;
        key: z.ZodLiteral<"C">;
        meter: z.ZodEnum<{
            "2/4": "2/4";
            "3/4": "3/4";
            "4/4": "4/4";
        }>;
        tempo: z.ZodNumber;
        keyboard: z.ZodBoolean;
        notation: z.ZodOptional<z.ZodEnum<{
            staff: "staff";
            both: "both";
            jianpu: "jianpu";
        }>>;
        parts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            clef: z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            bars: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodObject<{
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            id: z.ZodString;
            label: z.ZodString;
            focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
            compare: z.ZodOptional<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"music">;
        version: z.ZodLiteral<2>;
        id: z.ZodString;
        title: z.ZodString;
        layout: z.ZodEnum<{
            row: "row";
            column: "column";
            grid: "grid";
        }>;
        notes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            pitches: z.ZodArray<z.ZodString>;
            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
        }, z.core.$strict>>;
        views: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                staff: "staff";
                keyboard: "keyboard";
            }>;
            label: z.ZodString;
            notes: z.ZodArray<z.ZodString>;
            clef: z.ZodOptional<z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>>;
            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                label: "label";
                link: "link";
                bracket: "bracket";
                arrow: "arrow";
            }>;
            label: z.ZodString;
            anchors: z.ZodArray<z.ZodObject<{
                viewId: z.ZodString;
                noteId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            tempo: z.ZodNumber;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            events: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
        templateId: z.ZodLiteral<"general-question">;
        content: z.ZodObject<{
            objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            glyphs: z.ZodTuple<[z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>, z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>], null>;
            observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            question: z.ZodString;
            goal: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-layers">;
        content: z.ZodObject<{
            layers: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-flow">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodString>;
            caption: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-compare">;
        content: z.ZodObject<{
            names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            metrics: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                max: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-summary">;
        content: z.ZodObject<{
            concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            center: z.ZodString;
            transfer: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-pythagoras">;
        content: z.ZodObject<{
            a: z.ZodNumber;
            b: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-tangent">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            at: z.ZodNumber;
            startDx: z.ZodNumber;
            xmax: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-integral">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            end: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-probability">;
        content: z.ZodObject<{
            total: z.ZodNumber;
            condition: z.ZodNumber;
            intersection: z.ZodNumber;
            outsideTarget: z.ZodNumber;
            conditionName: z.ZodString;
            targetName: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-forces">;
        content: z.ZodObject<{
            mass: z.ZodNumber;
            drive: z.ZodNumber;
            resistance: z.ZodNumber;
            duration: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-waves">;
        content: z.ZodObject<{
            amplitude1: z.ZodNumber;
            amplitude2: z.ZodNumber;
            cycles1: z.ZodNumber;
            cycles2: z.ZodNumber;
            phase2: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-circuit">;
        content: z.ZodObject<{
            voltage: z.ZodNumber;
            resistance1: z.ZodNumber;
            resistance2: z.ZodNumber;
            topology: z.ZodEnum<{
                series: "series";
                parallel: "parallel";
            }>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-reaction">;
        content: z.ZodObject<{
            reactants: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            products: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-titration">;
        content: z.ZodObject<{
            acidMl: z.ZodNumber;
            acidMolarity: z.ZodNumber;
            baseMolarity: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-mitosis">;
        content: z.ZodObject<{
            chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-enzyme">;
        content: z.ZodObject<{
            enzyme: z.ZodString;
            substrate: z.ZodString;
            products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"geography-water">;
        content: z.ZodObject<{
            title: z.ZodString;
            nodes: z.ZodTuple<[z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>], null>;
            transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
            stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"history-timeline">;
        content: z.ZodObject<{
            range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            events: z.ZodTuple<[z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>], null>;
            caution: z.ZodString;
            conclusion: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-syntax">;
        content: z.ZodObject<{
            subject: z.ZodString;
            verb: z.ZodString;
            object: z.ZodString;
            question: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-perspective">;
        content: z.ZodObject<{
            object: z.ZodEnum<{
                door: "door";
                book: "book";
            }>;
            firstPerson: z.ZodString;
            observer: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-sorting">;
        content: z.ZodObject<{
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-recursion">;
        content: z.ZodObject<{
            operation: z.ZodEnum<{
                product: "product";
                sum: "sum";
            }>;
            start: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-score">;
        content: z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-harmony">;
        content: z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"economics-equilibrium">;
        content: z.ZodObject<{
            demandIntercept: z.ZodNumber;
            supplyIntercept: z.ZodNumber;
            demandSlope: z.ZodNumber;
            supplySlope: z.ZodNumber;
            demandShift: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-timeline">;
        content: z.ZodObject<{
            unit: z.ZodString;
            events: z.ZodArray<z.ZodObject<{
                at: z.ZodNumber;
                label: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-cycle">;
        content: z.ZodObject<{
            center: z.ZodString;
            nodes: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                process: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-decision">;
        content: z.ZodObject<{
            question: z.ZodString;
            branches: z.ZodArray<z.ZodObject<{
                condition: z.ZodString;
                outcome: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-funnel">;
        content: z.ZodObject<{
            unit: z.ZodString;
            stages: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-balance">;
        content: z.ZodObject<{
            unit: z.ZodString;
            left: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            right: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-matrix">;
        content: z.ZodObject<{
            columns: z.ZodArray<z.ZodString>;
            rows: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>>;
            unit: z.ZodString;
            max: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-proportion">;
        content: z.ZodObject<{
            whole: z.ZodString;
            unit: z.ZodString;
            parts: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-network">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
            links: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-counter">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            from: z.ZodNumber;
            to: z.ZodNumber;
            context: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-interval">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            min: z.ZodNumber;
            max: z.ZodNumber;
            low: z.ZodNumber;
            high: z.ZodNumber;
            points: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-hierarchy">;
        content: z.ZodObject<{
            root: z.ZodString;
            groups: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                members: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-ranking">;
        content: z.ZodObject<{
            unit: z.ZodString;
            before: z.ZodString;
            after: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>], "templateId">, z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        kind: z.ZodEnum<{
            process: "process";
            cycle: "cycle";
            layers: "layers";
        }>;
        items: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            id: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        unit: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"bars">;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            value: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        templateId: z.ZodLiteral<"general-question">;
        content: z.ZodObject<{
            objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            glyphs: z.ZodTuple<[z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>, z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>], null>;
            observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            question: z.ZodString;
            goal: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-layers">;
        content: z.ZodObject<{
            layers: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-flow">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodString>;
            caption: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-compare">;
        content: z.ZodObject<{
            names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            metrics: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                max: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-summary">;
        content: z.ZodObject<{
            concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            center: z.ZodString;
            transfer: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-pythagoras">;
        content: z.ZodObject<{
            a: z.ZodNumber;
            b: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-tangent">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            at: z.ZodNumber;
            startDx: z.ZodNumber;
            xmax: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-integral">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            end: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-probability">;
        content: z.ZodObject<{
            total: z.ZodNumber;
            condition: z.ZodNumber;
            intersection: z.ZodNumber;
            outsideTarget: z.ZodNumber;
            conditionName: z.ZodString;
            targetName: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-forces">;
        content: z.ZodObject<{
            mass: z.ZodNumber;
            drive: z.ZodNumber;
            resistance: z.ZodNumber;
            duration: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-waves">;
        content: z.ZodObject<{
            amplitude1: z.ZodNumber;
            amplitude2: z.ZodNumber;
            cycles1: z.ZodNumber;
            cycles2: z.ZodNumber;
            phase2: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-circuit">;
        content: z.ZodObject<{
            voltage: z.ZodNumber;
            resistance1: z.ZodNumber;
            resistance2: z.ZodNumber;
            topology: z.ZodEnum<{
                series: "series";
                parallel: "parallel";
            }>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-reaction">;
        content: z.ZodObject<{
            reactants: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            products: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-titration">;
        content: z.ZodObject<{
            acidMl: z.ZodNumber;
            acidMolarity: z.ZodNumber;
            baseMolarity: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-mitosis">;
        content: z.ZodObject<{
            chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-enzyme">;
        content: z.ZodObject<{
            enzyme: z.ZodString;
            substrate: z.ZodString;
            products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"geography-water">;
        content: z.ZodObject<{
            title: z.ZodString;
            nodes: z.ZodTuple<[z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>], null>;
            transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
            stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"history-timeline">;
        content: z.ZodObject<{
            range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            events: z.ZodTuple<[z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>], null>;
            caution: z.ZodString;
            conclusion: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-syntax">;
        content: z.ZodObject<{
            subject: z.ZodString;
            verb: z.ZodString;
            object: z.ZodString;
            question: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-perspective">;
        content: z.ZodObject<{
            object: z.ZodEnum<{
                door: "door";
                book: "book";
            }>;
            firstPerson: z.ZodString;
            observer: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-sorting">;
        content: z.ZodObject<{
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-recursion">;
        content: z.ZodObject<{
            operation: z.ZodEnum<{
                product: "product";
                sum: "sum";
            }>;
            start: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-score">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-harmony">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"economics-equilibrium">;
        content: z.ZodObject<{
            demandIntercept: z.ZodNumber;
            supplyIntercept: z.ZodNumber;
            demandSlope: z.ZodNumber;
            supplySlope: z.ZodNumber;
            demandShift: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-timeline">;
        content: z.ZodObject<{
            unit: z.ZodString;
            events: z.ZodArray<z.ZodObject<{
                at: z.ZodNumber;
                label: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-cycle">;
        content: z.ZodObject<{
            center: z.ZodString;
            nodes: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                process: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-decision">;
        content: z.ZodObject<{
            question: z.ZodString;
            branches: z.ZodArray<z.ZodObject<{
                condition: z.ZodString;
                outcome: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-funnel">;
        content: z.ZodObject<{
            unit: z.ZodString;
            stages: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-balance">;
        content: z.ZodObject<{
            unit: z.ZodString;
            left: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            right: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-matrix">;
        content: z.ZodObject<{
            columns: z.ZodArray<z.ZodString>;
            rows: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>>;
            unit: z.ZodString;
            max: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-proportion">;
        content: z.ZodObject<{
            whole: z.ZodString;
            unit: z.ZodString;
            parts: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-network">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
            links: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-counter">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            from: z.ZodNumber;
            to: z.ZodNumber;
            context: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-interval">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            min: z.ZodNumber;
            max: z.ZodNumber;
            low: z.ZodNumber;
            high: z.ZodNumber;
            points: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-hierarchy">;
        content: z.ZodObject<{
            root: z.ZodString;
            groups: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                members: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-ranking">;
        content: z.ZodObject<{
            unit: z.ZodString;
            before: z.ZodString;
            after: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>], "templateId"> | z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"music">;
        id: z.ZodOptional<z.ZodString>;
        version: z.ZodLiteral<1>;
        title: z.ZodString;
        key: z.ZodLiteral<"C">;
        meter: z.ZodEnum<{
            "2/4": "2/4";
            "3/4": "3/4";
            "4/4": "4/4";
        }>;
        tempo: z.ZodNumber;
        keyboard: z.ZodBoolean;
        notation: z.ZodOptional<z.ZodEnum<{
            staff: "staff";
            both: "both";
            jianpu: "jianpu";
        }>>;
        parts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            clef: z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            bars: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodObject<{
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            id: z.ZodString;
            label: z.ZodString;
            focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
            compare: z.ZodOptional<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"music">;
        version: z.ZodLiteral<2>;
        id: z.ZodString;
        title: z.ZodString;
        layout: z.ZodEnum<{
            row: "row";
            column: "column";
            grid: "grid";
        }>;
        notes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            pitches: z.ZodArray<z.ZodString>;
            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
        }, z.core.$strict>>;
        views: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                staff: "staff";
                keyboard: "keyboard";
            }>;
            label: z.ZodString;
            notes: z.ZodArray<z.ZodString>;
            clef: z.ZodOptional<z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>>;
            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                label: "label";
                link: "link";
                bracket: "bracket";
                arrow: "arrow";
            }>;
            label: z.ZodString;
            anchors: z.ZodArray<z.ZodObject<{
                viewId: z.ZodString;
                noteId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            tempo: z.ZodNumber;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            events: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>], "version"> | z.ZodObject<{
        type: z.ZodLiteral<"illustration">;
        id: z.ZodOptional<z.ZodString>;
        caption: z.ZodString;
        prompt: z.ZodString;
        style: z.ZodEnum<{
            process: "process";
            diagram: "diagram";
            concept: "concept";
            comparison: "comparison";
        }>;
        aspectRatio: z.ZodOptional<z.ZodEnum<{
            "1:1": "1:1";
            "16:9": "16:9";
            "9:16": "9:16";
            "4:3": "4:3";
            "3:4": "3:4";
            "3:2": "3:2";
            "2:3": "2:3";
        }>>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        kind: z.ZodEnum<{
            process: "process";
            cycle: "cycle";
            layers: "layers";
            bars: "bars";
        }>;
        title: z.ZodString;
        unit: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            value: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        type: z.ZodLiteral<"code">;
        id: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        language: z.ZodOptional<z.ZodString>;
        parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            text: z.ZodString;
        }, z.core.$strip>>>;
        regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            match: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"conversation">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        turns: z.ZodArray<z.ZodObject<{
            speaker: z.ZodString;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"callout">;
        id: z.ZodOptional<z.ZodString>;
        variant: z.ZodEnum<{
            example: "example";
            warning: "warning";
            definition: "definition";
            tip: "tip";
        }>;
        title: z.ZodOptional<z.ZodString>;
        body: z.ZodString;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"accordion">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"compare">;
        id: z.ZodOptional<z.ZodString>;
        left: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        right: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"stage">;
        id: z.ZodOptional<z.ZodString>;
        layout: z.ZodEnum<{
            "split-h": "split-h";
            "split-v": "split-v";
            "main+rail": "main+rail";
            stack: "stack";
        }>;
        presentation: z.ZodOptional<z.ZodEnum<{
            compare: "compare";
            steps: "steps";
            focus: "focus";
        }>>;
        figures: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"music">;
            id: z.ZodOptional<z.ZodString>;
            version: z.ZodLiteral<1>;
            title: z.ZodString;
            key: z.ZodLiteral<"C">;
            meter: z.ZodEnum<{
                "2/4": "2/4";
                "3/4": "3/4";
                "4/4": "4/4";
            }>;
            tempo: z.ZodNumber;
            keyboard: z.ZodBoolean;
            notation: z.ZodOptional<z.ZodEnum<{
                staff: "staff";
                both: "both";
                jianpu: "jianpu";
            }>>;
            parts: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                clef: z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                bars: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodObject<{
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            steps: z.ZodArray<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                id: z.ZodString;
                label: z.ZodString;
                focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                compare: z.ZodOptional<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
            templateId: z.ZodLiteral<"general-question">;
            content: z.ZodObject<{
                objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                glyphs: z.ZodTuple<[z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>, z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>], null>;
                observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                question: z.ZodString;
                goal: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-layers">;
            content: z.ZodObject<{
                layers: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-flow">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodString>;
                caption: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-compare">;
            content: z.ZodObject<{
                names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                metrics: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    max: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-summary">;
            content: z.ZodObject<{
                concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                center: z.ZodString;
                transfer: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-pythagoras">;
            content: z.ZodObject<{
                a: z.ZodNumber;
                b: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-tangent">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                at: z.ZodNumber;
                startDx: z.ZodNumber;
                xmax: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-integral">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                end: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-probability">;
            content: z.ZodObject<{
                total: z.ZodNumber;
                condition: z.ZodNumber;
                intersection: z.ZodNumber;
                outsideTarget: z.ZodNumber;
                conditionName: z.ZodString;
                targetName: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-forces">;
            content: z.ZodObject<{
                mass: z.ZodNumber;
                drive: z.ZodNumber;
                resistance: z.ZodNumber;
                duration: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-waves">;
            content: z.ZodObject<{
                amplitude1: z.ZodNumber;
                amplitude2: z.ZodNumber;
                cycles1: z.ZodNumber;
                cycles2: z.ZodNumber;
                phase2: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-circuit">;
            content: z.ZodObject<{
                voltage: z.ZodNumber;
                resistance1: z.ZodNumber;
                resistance2: z.ZodNumber;
                topology: z.ZodEnum<{
                    series: "series";
                    parallel: "parallel";
                }>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-reaction">;
            content: z.ZodObject<{
                reactants: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                products: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-titration">;
            content: z.ZodObject<{
                acidMl: z.ZodNumber;
                acidMolarity: z.ZodNumber;
                baseMolarity: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-mitosis">;
            content: z.ZodObject<{
                chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-enzyme">;
            content: z.ZodObject<{
                enzyme: z.ZodString;
                substrate: z.ZodString;
                products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"geography-water">;
            content: z.ZodObject<{
                title: z.ZodString;
                nodes: z.ZodTuple<[z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>], null>;
                transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"history-timeline">;
            content: z.ZodObject<{
                range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                events: z.ZodTuple<[z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>], null>;
                caution: z.ZodString;
                conclusion: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-syntax">;
            content: z.ZodObject<{
                subject: z.ZodString;
                verb: z.ZodString;
                object: z.ZodString;
                question: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-perspective">;
            content: z.ZodObject<{
                object: z.ZodEnum<{
                    door: "door";
                    book: "book";
                }>;
                firstPerson: z.ZodString;
                observer: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-sorting">;
            content: z.ZodObject<{
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-recursion">;
            content: z.ZodObject<{
                operation: z.ZodEnum<{
                    product: "product";
                    sum: "sum";
                }>;
                start: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-score">;
            content: z.ZodUnion<readonly [z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodLiteral<"accepted-v2">;
                block: z.ZodObject<{
                    type: z.ZodLiteral<"music">;
                    version: z.ZodLiteral<2>;
                    id: z.ZodString;
                    title: z.ZodString;
                    layout: z.ZodEnum<{
                        row: "row";
                        column: "column";
                        grid: "grid";
                    }>;
                    notes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                    }, z.core.$strict>>;
                    views: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            staff: "staff";
                            keyboard: "keyboard";
                        }>;
                        label: z.ZodString;
                        notes: z.ZodArray<z.ZodString>;
                        clef: z.ZodOptional<z.ZodEnum<{
                            treble: "treble";
                            bass: "bass";
                        }>>;
                        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            label: "label";
                            link: "link";
                            bracket: "bracket";
                            arrow: "arrow";
                        }>;
                        label: z.ZodString;
                        anchors: z.ZodArray<z.ZodObject<{
                            viewId: z.ZodString;
                            noteId: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                        tempo: z.ZodNumber;
                        instrument: z.ZodOptional<z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>>;
                        events: z.ZodArray<z.ZodObject<{
                            notes: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
                clipId: z.ZodOptional<z.ZodString>;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>]>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-harmony">;
            content: z.ZodUnion<readonly [z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodLiteral<"accepted-v2">;
                block: z.ZodObject<{
                    type: z.ZodLiteral<"music">;
                    version: z.ZodLiteral<2>;
                    id: z.ZodString;
                    title: z.ZodString;
                    layout: z.ZodEnum<{
                        row: "row";
                        column: "column";
                        grid: "grid";
                    }>;
                    notes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                    }, z.core.$strict>>;
                    views: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            staff: "staff";
                            keyboard: "keyboard";
                        }>;
                        label: z.ZodString;
                        notes: z.ZodArray<z.ZodString>;
                        clef: z.ZodOptional<z.ZodEnum<{
                            treble: "treble";
                            bass: "bass";
                        }>>;
                        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            label: "label";
                            link: "link";
                            bracket: "bracket";
                            arrow: "arrow";
                        }>;
                        label: z.ZodString;
                        anchors: z.ZodArray<z.ZodObject<{
                            viewId: z.ZodString;
                            noteId: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                        tempo: z.ZodNumber;
                        instrument: z.ZodOptional<z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>>;
                        events: z.ZodArray<z.ZodObject<{
                            notes: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
                clipId: z.ZodOptional<z.ZodString>;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>]>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"economics-equilibrium">;
            content: z.ZodObject<{
                demandIntercept: z.ZodNumber;
                supplyIntercept: z.ZodNumber;
                demandSlope: z.ZodNumber;
                supplySlope: z.ZodNumber;
                demandShift: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-timeline">;
            content: z.ZodObject<{
                unit: z.ZodString;
                events: z.ZodArray<z.ZodObject<{
                    at: z.ZodNumber;
                    label: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-cycle">;
            content: z.ZodObject<{
                center: z.ZodString;
                nodes: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    process: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-decision">;
            content: z.ZodObject<{
                question: z.ZodString;
                branches: z.ZodArray<z.ZodObject<{
                    condition: z.ZodString;
                    outcome: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-funnel">;
            content: z.ZodObject<{
                unit: z.ZodString;
                stages: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-balance">;
            content: z.ZodObject<{
                unit: z.ZodString;
                left: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                right: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-matrix">;
            content: z.ZodObject<{
                columns: z.ZodArray<z.ZodString>;
                rows: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>>;
                unit: z.ZodString;
                max: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-proportion">;
            content: z.ZodObject<{
                whole: z.ZodString;
                unit: z.ZodString;
                parts: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-network">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
                links: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-counter">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                from: z.ZodNumber;
                to: z.ZodNumber;
                context: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-interval">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                min: z.ZodNumber;
                max: z.ZodNumber;
                low: z.ZodNumber;
                high: z.ZodNumber;
                points: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-hierarchy">;
            content: z.ZodObject<{
                root: z.ZodString;
                groups: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    members: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-ranking">;
            content: z.ZodObject<{
                unit: z.ZodString;
                before: z.ZodString;
                after: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    before: z.ZodNumber;
                    after: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>], "templateId">, z.ZodObject<{
            type: z.ZodLiteral<"visual">;
            id: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                process: "process";
                cycle: "cycle";
                layers: "layers";
                bars: "bars";
            }>;
            title: z.ZodString;
            unit: z.ZodOptional<z.ZodString>;
            items: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
                value: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"code">;
            id: z.ZodOptional<z.ZodString>;
            code: z.ZodString;
            language: z.ZodOptional<z.ZodString>;
            parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                text: z.ZodString;
            }, z.core.$strip>>>;
            regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                match: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"conversation">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            turns: z.ZodArray<z.ZodObject<{
                speaker: z.ZodString;
                text: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"callout">;
            id: z.ZodOptional<z.ZodString>;
            variant: z.ZodEnum<{
                example: "example";
                warning: "warning";
                definition: "definition";
                tip: "tip";
            }>;
            title: z.ZodOptional<z.ZodString>;
            body: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"accordion">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"illustration">;
            id: z.ZodOptional<z.ZodString>;
            caption: z.ZodString;
            prompt: z.ZodString;
            style: z.ZodEnum<{
                process: "process";
                diagram: "diagram";
                concept: "concept";
                comparison: "comparison";
            }>;
            aspectRatio: z.ZodOptional<z.ZodEnum<{
                "1:1": "1:1";
                "16:9": "16:9";
                "9:16": "9:16";
                "4:3": "4:3";
                "3:4": "3:4";
                "3:2": "3:2";
                "2:3": "2:3";
            }>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"svg_slot">;
            id: z.ZodOptional<z.ZodString>;
            intent: z.ZodObject<{
                visualKind: z.ZodEnum<{
                    simple_structure: "simple_structure";
                    spatial_relationship: "spatial_relationship";
                    state_comparison: "state_comparison";
                    step_derivation: "step_derivation";
                }>;
                setup: z.ZodString;
                learningGoal: z.ZodString;
                expectedInsight: z.ZodString;
                composition: z.ZodOptional<z.ZodString>;
                elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
                relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
                labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
                avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"compare">;
            id: z.ZodOptional<z.ZodString>;
            left: z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>;
            right: z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>;
            sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>>;
        }, z.core.$strip>], "type">>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"heading">;
        level: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
        text: z.ZodString;
        topicId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"paragraph">;
        text: z.ZodString;
        cue: z.ZodOptional<z.ZodObject<{
            music: z.ZodOptional<z.ZodObject<{
                figureId: z.ZodString;
                clipId: z.ZodString;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            target: z.ZodString;
            targetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
            op: z.ZodOptional<z.ZodEnum<{
                highlight: "highlight";
                window: "window";
            }>>;
            regionIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
            figureId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        templateId: z.ZodLiteral<"general-question">;
        content: z.ZodObject<{
            objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            glyphs: z.ZodTuple<[z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>, z.ZodEnum<{
                object: "object";
                question: "question";
                paper: "paper";
                boat: "boat";
                read: "read";
                recall: "recall";
            }>], null>;
            observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            question: z.ZodString;
            goal: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-layers">;
        content: z.ZodObject<{
            layers: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-flow">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodString>;
            caption: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-compare">;
        content: z.ZodObject<{
            names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            metrics: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                max: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"general-summary">;
        content: z.ZodObject<{
            concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            center: z.ZodString;
            transfer: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-pythagoras">;
        content: z.ZodObject<{
            a: z.ZodNumber;
            b: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-tangent">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            at: z.ZodNumber;
            startDx: z.ZodNumber;
            xmax: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-integral">;
        content: z.ZodObject<{
            coefficient: z.ZodNumber;
            power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            end: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"math-probability">;
        content: z.ZodObject<{
            total: z.ZodNumber;
            condition: z.ZodNumber;
            intersection: z.ZodNumber;
            outsideTarget: z.ZodNumber;
            conditionName: z.ZodString;
            targetName: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-forces">;
        content: z.ZodObject<{
            mass: z.ZodNumber;
            drive: z.ZodNumber;
            resistance: z.ZodNumber;
            duration: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-waves">;
        content: z.ZodObject<{
            amplitude1: z.ZodNumber;
            amplitude2: z.ZodNumber;
            cycles1: z.ZodNumber;
            cycles2: z.ZodNumber;
            phase2: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"physics-circuit">;
        content: z.ZodObject<{
            voltage: z.ZodNumber;
            resistance1: z.ZodNumber;
            resistance2: z.ZodNumber;
            topology: z.ZodEnum<{
                series: "series";
                parallel: "parallel";
            }>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-reaction">;
        content: z.ZodObject<{
            reactants: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            products: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                atoms: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    element: z.ZodString;
                }, z.core.$strict>>;
                bonds: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"chemistry-titration">;
        content: z.ZodObject<{
            acidMl: z.ZodNumber;
            acidMolarity: z.ZodNumber;
            baseMolarity: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-mitosis">;
        content: z.ZodObject<{
            chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"biology-enzyme">;
        content: z.ZodObject<{
            enzyme: z.ZodString;
            substrate: z.ZodString;
            products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"geography-water">;
        content: z.ZodObject<{
            title: z.ZodString;
            nodes: z.ZodTuple<[z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                label: z.ZodString;
                glyph: z.ZodEnum<{
                    water: "water";
                    vapor: "vapor";
                    cloud: "cloud";
                    drop: "drop";
                    magma: "magma";
                    rock: "rock";
                    sediment: "sediment";
                    strata: "strata";
                }>;
            }, z.core.$strict>], null>;
            transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
            stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"history-timeline">;
        content: z.ZodObject<{
            range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            events: z.ZodTuple<[z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                year: z.ZodNumber;
                label: z.ZodString;
                evidence: z.ZodString;
                approximate: z.ZodOptional<z.ZodBoolean>;
                kind: z.ZodEnum<{
                    type: "type";
                    block: "block";
                    moon: "moon";
                    telescope: "telescope";
                    event: "event";
                }>;
            }, z.core.$strict>], null>;
            caution: z.ZodString;
            conclusion: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-syntax">;
        content: z.ZodObject<{
            subject: z.ZodString;
            verb: z.ZodString;
            object: z.ZodString;
            question: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"language-perspective">;
        content: z.ZodObject<{
            object: z.ZodEnum<{
                door: "door";
                book: "book";
            }>;
            firstPerson: z.ZodString;
            observer: z.ZodString;
            note: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-sorting">;
        content: z.ZodObject<{
            values: z.ZodArray<z.ZodNumber>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"cs-recursion">;
        content: z.ZodObject<{
            operation: z.ZodEnum<{
                product: "product";
                sum: "sum";
            }>;
            start: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-score">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"music-harmony">;
        content: z.ZodUnion<readonly [z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            groups: z.ZodArray<z.ZodArray<z.ZodString>>;
            labels: z.ZodArray<z.ZodString>;
            beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
            range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
            tempo: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodLiteral<"accepted-v2">;
            block: z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>;
            clipId: z.ZodOptional<z.ZodString>;
            repeat: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>]>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"economics-equilibrium">;
        content: z.ZodObject<{
            demandIntercept: z.ZodNumber;
            supplyIntercept: z.ZodNumber;
            demandSlope: z.ZodNumber;
            supplySlope: z.ZodNumber;
            demandShift: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-timeline">;
        content: z.ZodObject<{
            unit: z.ZodString;
            events: z.ZodArray<z.ZodObject<{
                at: z.ZodNumber;
                label: z.ZodString;
                detail: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-cycle">;
        content: z.ZodObject<{
            center: z.ZodString;
            nodes: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                process: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-decision">;
        content: z.ZodObject<{
            question: z.ZodString;
            branches: z.ZodArray<z.ZodObject<{
                condition: z.ZodString;
                outcome: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-funnel">;
        content: z.ZodObject<{
            unit: z.ZodString;
            stages: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-balance">;
        content: z.ZodObject<{
            unit: z.ZodString;
            left: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            right: z.ZodObject<{
                label: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-matrix">;
        content: z.ZodObject<{
            columns: z.ZodArray<z.ZodString>;
            rows: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>>;
            unit: z.ZodString;
            max: z.ZodNumber;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-proportion">;
        content: z.ZodObject<{
            whole: z.ZodString;
            unit: z.ZodString;
            parts: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-network">;
        content: z.ZodObject<{
            nodes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
            links: z.ZodArray<z.ZodObject<{
                from: z.ZodString;
                to: z.ZodString;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-counter">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            from: z.ZodNumber;
            to: z.ZodNumber;
            context: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-interval">;
        content: z.ZodObject<{
            label: z.ZodString;
            unit: z.ZodString;
            min: z.ZodNumber;
            max: z.ZodNumber;
            low: z.ZodNumber;
            high: z.ZodNumber;
            points: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-hierarchy">;
        content: z.ZodObject<{
            root: z.ZodString;
            groups: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                members: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        templateId: z.ZodLiteral<"visual-ranking">;
        content: z.ZodObject<{
            unit: z.ZodString;
            before: z.ZodString;
            after: z.ZodString;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        type: z.ZodLiteral<"teaching">;
        version: z.ZodLiteral<1>;
        id: z.ZodString;
        title: z.ZodString;
    }, z.core.$strict>], "templateId"> | z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"music">;
        id: z.ZodOptional<z.ZodString>;
        version: z.ZodLiteral<1>;
        title: z.ZodString;
        key: z.ZodLiteral<"C">;
        meter: z.ZodEnum<{
            "2/4": "2/4";
            "3/4": "3/4";
            "4/4": "4/4";
        }>;
        tempo: z.ZodNumber;
        keyboard: z.ZodBoolean;
        notation: z.ZodOptional<z.ZodEnum<{
            staff: "staff";
            both: "both";
            jianpu: "jianpu";
        }>>;
        parts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            clef: z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            bars: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodObject<{
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            bars: z.ZodArray<z.ZodNumber>;
            parts: z.ZodArray<z.ZodString>;
            instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                part: z.ZodString;
                instrument: z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>;
            }, z.core.$strict>>>;
            id: z.ZodString;
            label: z.ZodString;
            focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
            compare: z.ZodOptional<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                label: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"music">;
        version: z.ZodLiteral<2>;
        id: z.ZodString;
        title: z.ZodString;
        layout: z.ZodEnum<{
            row: "row";
            column: "column";
            grid: "grid";
        }>;
        notes: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            pitches: z.ZodArray<z.ZodString>;
            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
        }, z.core.$strict>>;
        views: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                staff: "staff";
                keyboard: "keyboard";
            }>;
            label: z.ZodString;
            notes: z.ZodArray<z.ZodString>;
            clef: z.ZodOptional<z.ZodEnum<{
                treble: "treble";
                bass: "bass";
            }>>;
            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                label: "label";
                link: "link";
                bracket: "bracket";
                arrow: "arrow";
            }>;
            label: z.ZodString;
            anchors: z.ZodArray<z.ZodObject<{
                viewId: z.ZodString;
                noteId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            tempo: z.ZodNumber;
            instrument: z.ZodOptional<z.ZodEnum<{
                piano: "piano";
                electric_piano: "electric_piano";
                guitar: "guitar";
                violin: "violin";
                cello: "cello";
                flute: "flute";
                marimba: "marimba";
                organ: "organ";
            }>>;
            events: z.ZodArray<z.ZodObject<{
                notes: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>], "version"> | z.ZodObject<{
        type: z.ZodLiteral<"illustration">;
        id: z.ZodOptional<z.ZodString>;
        caption: z.ZodString;
        prompt: z.ZodString;
        style: z.ZodEnum<{
            process: "process";
            diagram: "diagram";
            concept: "concept";
            comparison: "comparison";
        }>;
        aspectRatio: z.ZodOptional<z.ZodEnum<{
            "1:1": "1:1";
            "16:9": "16:9";
            "9:16": "9:16";
            "4:3": "4:3";
            "3:4": "3:4";
            "3:2": "3:2";
            "2:3": "2:3";
        }>>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"visual">;
        id: z.ZodOptional<z.ZodString>;
        kind: z.ZodEnum<{
            process: "process";
            cycle: "cycle";
            layers: "layers";
            bars: "bars";
        }>;
        title: z.ZodString;
        unit: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
            value: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        type: z.ZodLiteral<"code">;
        id: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        language: z.ZodOptional<z.ZodString>;
        parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            text: z.ZodString;
        }, z.core.$strip>>>;
        regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            match: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"conversation">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        turns: z.ZodArray<z.ZodObject<{
            speaker: z.ZodString;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"callout">;
        id: z.ZodOptional<z.ZodString>;
        variant: z.ZodEnum<{
            example: "example";
            warning: "warning";
            definition: "definition";
            tip: "tip";
        }>;
        title: z.ZodOptional<z.ZodString>;
        body: z.ZodString;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"accordion">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"compare">;
        id: z.ZodOptional<z.ZodString>;
        left: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        right: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>;
        sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            points: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"stage">;
        id: z.ZodOptional<z.ZodString>;
        layout: z.ZodEnum<{
            "split-h": "split-h";
            "split-v": "split-v";
            "main+rail": "main+rail";
            stack: "stack";
        }>;
        presentation: z.ZodOptional<z.ZodEnum<{
            compare: "compare";
            steps: "steps";
            focus: "focus";
        }>>;
        figures: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"music">;
            id: z.ZodOptional<z.ZodString>;
            version: z.ZodLiteral<1>;
            title: z.ZodString;
            key: z.ZodLiteral<"C">;
            meter: z.ZodEnum<{
                "2/4": "2/4";
                "3/4": "3/4";
                "4/4": "4/4";
            }>;
            tempo: z.ZodNumber;
            keyboard: z.ZodBoolean;
            notation: z.ZodOptional<z.ZodEnum<{
                staff: "staff";
                both: "both";
                jianpu: "jianpu";
            }>>;
            parts: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                clef: z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                bars: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodObject<{
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            steps: z.ZodArray<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                id: z.ZodString;
                label: z.ZodString;
                focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                compare: z.ZodOptional<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
            templateId: z.ZodLiteral<"general-question">;
            content: z.ZodObject<{
                objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                glyphs: z.ZodTuple<[z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>, z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>], null>;
                observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                question: z.ZodString;
                goal: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-layers">;
            content: z.ZodObject<{
                layers: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-flow">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodString>;
                caption: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-compare">;
            content: z.ZodObject<{
                names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                metrics: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    max: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-summary">;
            content: z.ZodObject<{
                concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                center: z.ZodString;
                transfer: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-pythagoras">;
            content: z.ZodObject<{
                a: z.ZodNumber;
                b: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-tangent">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                at: z.ZodNumber;
                startDx: z.ZodNumber;
                xmax: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-integral">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                end: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-probability">;
            content: z.ZodObject<{
                total: z.ZodNumber;
                condition: z.ZodNumber;
                intersection: z.ZodNumber;
                outsideTarget: z.ZodNumber;
                conditionName: z.ZodString;
                targetName: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-forces">;
            content: z.ZodObject<{
                mass: z.ZodNumber;
                drive: z.ZodNumber;
                resistance: z.ZodNumber;
                duration: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-waves">;
            content: z.ZodObject<{
                amplitude1: z.ZodNumber;
                amplitude2: z.ZodNumber;
                cycles1: z.ZodNumber;
                cycles2: z.ZodNumber;
                phase2: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-circuit">;
            content: z.ZodObject<{
                voltage: z.ZodNumber;
                resistance1: z.ZodNumber;
                resistance2: z.ZodNumber;
                topology: z.ZodEnum<{
                    series: "series";
                    parallel: "parallel";
                }>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-reaction">;
            content: z.ZodObject<{
                reactants: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                products: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-titration">;
            content: z.ZodObject<{
                acidMl: z.ZodNumber;
                acidMolarity: z.ZodNumber;
                baseMolarity: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-mitosis">;
            content: z.ZodObject<{
                chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-enzyme">;
            content: z.ZodObject<{
                enzyme: z.ZodString;
                substrate: z.ZodString;
                products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"geography-water">;
            content: z.ZodObject<{
                title: z.ZodString;
                nodes: z.ZodTuple<[z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>], null>;
                transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"history-timeline">;
            content: z.ZodObject<{
                range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                events: z.ZodTuple<[z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>], null>;
                caution: z.ZodString;
                conclusion: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-syntax">;
            content: z.ZodObject<{
                subject: z.ZodString;
                verb: z.ZodString;
                object: z.ZodString;
                question: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-perspective">;
            content: z.ZodObject<{
                object: z.ZodEnum<{
                    door: "door";
                    book: "book";
                }>;
                firstPerson: z.ZodString;
                observer: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-sorting">;
            content: z.ZodObject<{
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-recursion">;
            content: z.ZodObject<{
                operation: z.ZodEnum<{
                    product: "product";
                    sum: "sum";
                }>;
                start: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-score">;
            content: z.ZodUnion<readonly [z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodLiteral<"accepted-v2">;
                block: z.ZodObject<{
                    type: z.ZodLiteral<"music">;
                    version: z.ZodLiteral<2>;
                    id: z.ZodString;
                    title: z.ZodString;
                    layout: z.ZodEnum<{
                        row: "row";
                        column: "column";
                        grid: "grid";
                    }>;
                    notes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                    }, z.core.$strict>>;
                    views: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            staff: "staff";
                            keyboard: "keyboard";
                        }>;
                        label: z.ZodString;
                        notes: z.ZodArray<z.ZodString>;
                        clef: z.ZodOptional<z.ZodEnum<{
                            treble: "treble";
                            bass: "bass";
                        }>>;
                        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            label: "label";
                            link: "link";
                            bracket: "bracket";
                            arrow: "arrow";
                        }>;
                        label: z.ZodString;
                        anchors: z.ZodArray<z.ZodObject<{
                            viewId: z.ZodString;
                            noteId: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                        tempo: z.ZodNumber;
                        instrument: z.ZodOptional<z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>>;
                        events: z.ZodArray<z.ZodObject<{
                            notes: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
                clipId: z.ZodOptional<z.ZodString>;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>]>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-harmony">;
            content: z.ZodUnion<readonly [z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodLiteral<"accepted-v2">;
                block: z.ZodObject<{
                    type: z.ZodLiteral<"music">;
                    version: z.ZodLiteral<2>;
                    id: z.ZodString;
                    title: z.ZodString;
                    layout: z.ZodEnum<{
                        row: "row";
                        column: "column";
                        grid: "grid";
                    }>;
                    notes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                    }, z.core.$strict>>;
                    views: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            staff: "staff";
                            keyboard: "keyboard";
                        }>;
                        label: z.ZodString;
                        notes: z.ZodArray<z.ZodString>;
                        clef: z.ZodOptional<z.ZodEnum<{
                            treble: "treble";
                            bass: "bass";
                        }>>;
                        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            label: "label";
                            link: "link";
                            bracket: "bracket";
                            arrow: "arrow";
                        }>;
                        label: z.ZodString;
                        anchors: z.ZodArray<z.ZodObject<{
                            viewId: z.ZodString;
                            noteId: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                        tempo: z.ZodNumber;
                        instrument: z.ZodOptional<z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>>;
                        events: z.ZodArray<z.ZodObject<{
                            notes: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
                clipId: z.ZodOptional<z.ZodString>;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>]>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"economics-equilibrium">;
            content: z.ZodObject<{
                demandIntercept: z.ZodNumber;
                supplyIntercept: z.ZodNumber;
                demandSlope: z.ZodNumber;
                supplySlope: z.ZodNumber;
                demandShift: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-timeline">;
            content: z.ZodObject<{
                unit: z.ZodString;
                events: z.ZodArray<z.ZodObject<{
                    at: z.ZodNumber;
                    label: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-cycle">;
            content: z.ZodObject<{
                center: z.ZodString;
                nodes: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    process: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-decision">;
            content: z.ZodObject<{
                question: z.ZodString;
                branches: z.ZodArray<z.ZodObject<{
                    condition: z.ZodString;
                    outcome: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-funnel">;
            content: z.ZodObject<{
                unit: z.ZodString;
                stages: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-balance">;
            content: z.ZodObject<{
                unit: z.ZodString;
                left: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                right: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-matrix">;
            content: z.ZodObject<{
                columns: z.ZodArray<z.ZodString>;
                rows: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>>;
                unit: z.ZodString;
                max: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-proportion">;
            content: z.ZodObject<{
                whole: z.ZodString;
                unit: z.ZodString;
                parts: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-network">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
                links: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-counter">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                from: z.ZodNumber;
                to: z.ZodNumber;
                context: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-interval">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                min: z.ZodNumber;
                max: z.ZodNumber;
                low: z.ZodNumber;
                high: z.ZodNumber;
                points: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-hierarchy">;
            content: z.ZodObject<{
                root: z.ZodString;
                groups: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    members: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-ranking">;
            content: z.ZodObject<{
                unit: z.ZodString;
                before: z.ZodString;
                after: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    before: z.ZodNumber;
                    after: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>], "templateId">, z.ZodObject<{
            type: z.ZodLiteral<"visual">;
            id: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                process: "process";
                cycle: "cycle";
                layers: "layers";
                bars: "bars";
            }>;
            title: z.ZodString;
            unit: z.ZodOptional<z.ZodString>;
            items: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
                value: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"code">;
            id: z.ZodOptional<z.ZodString>;
            code: z.ZodString;
            language: z.ZodOptional<z.ZodString>;
            parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                text: z.ZodString;
            }, z.core.$strip>>>;
            regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                match: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"conversation">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            turns: z.ZodArray<z.ZodObject<{
                speaker: z.ZodString;
                text: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"callout">;
            id: z.ZodOptional<z.ZodString>;
            variant: z.ZodEnum<{
                example: "example";
                warning: "warning";
                definition: "definition";
                tip: "tip";
            }>;
            title: z.ZodOptional<z.ZodString>;
            body: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"accordion">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"illustration">;
            id: z.ZodOptional<z.ZodString>;
            caption: z.ZodString;
            prompt: z.ZodString;
            style: z.ZodEnum<{
                process: "process";
                diagram: "diagram";
                concept: "concept";
                comparison: "comparison";
            }>;
            aspectRatio: z.ZodOptional<z.ZodEnum<{
                "1:1": "1:1";
                "16:9": "16:9";
                "9:16": "9:16";
                "4:3": "4:3";
                "3:4": "3:4";
                "3:2": "3:2";
                "2:3": "2:3";
            }>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"svg_slot">;
            id: z.ZodOptional<z.ZodString>;
            intent: z.ZodObject<{
                visualKind: z.ZodEnum<{
                    simple_structure: "simple_structure";
                    spatial_relationship: "spatial_relationship";
                    state_comparison: "state_comparison";
                    step_derivation: "step_derivation";
                }>;
                setup: z.ZodString;
                learningGoal: z.ZodString;
                expectedInsight: z.ZodString;
                composition: z.ZodOptional<z.ZodString>;
                elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
                relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
                labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
                avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"compare">;
            id: z.ZodOptional<z.ZodString>;
            left: z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>;
            right: z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>;
            sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>>;
        }, z.core.$strip>], "type">>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"heading">;
        level: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
        text: z.ZodString;
        topicId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip> | z.ZodObject<{
        type: z.ZodLiteral<"paragraph">;
        text: z.ZodString;
        cue: z.ZodOptional<z.ZodObject<{
            music: z.ZodOptional<z.ZodObject<{
                figureId: z.ZodString;
                clipId: z.ZodString;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            target: z.ZodString;
            targetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
            op: z.ZodOptional<z.ZodEnum<{
                highlight: "highlight";
                window: "window";
            }>>;
            regionIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
            figureId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"code">;
        id: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        language: z.ZodOptional<z.ZodString>;
        parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            text: z.ZodString;
        }, z.core.$strip>>>;
        regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            match: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"conversation">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodOptional<z.ZodString>;
        turns: z.ZodArray<z.ZodObject<{
            speaker: z.ZodString;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"callout">;
        id: z.ZodOptional<z.ZodString>;
        variant: z.ZodEnum<{
            example: "example";
            warning: "warning";
            definition: "definition";
            tip: "tip";
        }>;
        title: z.ZodOptional<z.ZodString>;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"accordion">;
        id: z.ZodOptional<z.ZodString>;
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"illustration">;
        id: z.ZodOptional<z.ZodString>;
        caption: z.ZodString;
        prompt: z.ZodString;
        style: z.ZodEnum<{
            process: "process";
            diagram: "diagram";
            concept: "concept";
            comparison: "comparison";
        }>;
        aspectRatio: z.ZodOptional<z.ZodEnum<{
            "1:1": "1:1";
            "16:9": "16:9";
            "9:16": "9:16";
            "4:3": "4:3";
            "3:4": "3:4";
            "3:2": "3:2";
            "2:3": "2:3";
        }>>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"stage">;
        id: z.ZodOptional<z.ZodString>;
        layout: z.ZodEnum<{
            "split-h": "split-h";
            "split-v": "split-v";
            "main+rail": "main+rail";
            stack: "stack";
        }>;
        presentation: z.ZodOptional<z.ZodEnum<{
            compare: "compare";
            steps: "steps";
            focus: "focus";
        }>>;
        figures: z.ZodArray<z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"music">;
            id: z.ZodOptional<z.ZodString>;
            version: z.ZodLiteral<1>;
            title: z.ZodString;
            key: z.ZodLiteral<"C">;
            meter: z.ZodEnum<{
                "2/4": "2/4";
                "3/4": "3/4";
                "4/4": "4/4";
            }>;
            tempo: z.ZodNumber;
            keyboard: z.ZodBoolean;
            notation: z.ZodOptional<z.ZodEnum<{
                staff: "staff";
                both: "both";
                jianpu: "jianpu";
            }>>;
            parts: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                clef: z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                bars: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodObject<{
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            steps: z.ZodArray<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                id: z.ZodString;
                label: z.ZodString;
                focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                compare: z.ZodOptional<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
            templateId: z.ZodLiteral<"general-question">;
            content: z.ZodObject<{
                objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                glyphs: z.ZodTuple<[z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>, z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>], null>;
                observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                question: z.ZodString;
                goal: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-layers">;
            content: z.ZodObject<{
                layers: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-flow">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodString>;
                caption: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-compare">;
            content: z.ZodObject<{
                names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                metrics: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    max: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-summary">;
            content: z.ZodObject<{
                concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                center: z.ZodString;
                transfer: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-pythagoras">;
            content: z.ZodObject<{
                a: z.ZodNumber;
                b: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-tangent">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                at: z.ZodNumber;
                startDx: z.ZodNumber;
                xmax: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-integral">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                end: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-probability">;
            content: z.ZodObject<{
                total: z.ZodNumber;
                condition: z.ZodNumber;
                intersection: z.ZodNumber;
                outsideTarget: z.ZodNumber;
                conditionName: z.ZodString;
                targetName: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-forces">;
            content: z.ZodObject<{
                mass: z.ZodNumber;
                drive: z.ZodNumber;
                resistance: z.ZodNumber;
                duration: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-waves">;
            content: z.ZodObject<{
                amplitude1: z.ZodNumber;
                amplitude2: z.ZodNumber;
                cycles1: z.ZodNumber;
                cycles2: z.ZodNumber;
                phase2: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-circuit">;
            content: z.ZodObject<{
                voltage: z.ZodNumber;
                resistance1: z.ZodNumber;
                resistance2: z.ZodNumber;
                topology: z.ZodEnum<{
                    series: "series";
                    parallel: "parallel";
                }>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-reaction">;
            content: z.ZodObject<{
                reactants: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                products: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-titration">;
            content: z.ZodObject<{
                acidMl: z.ZodNumber;
                acidMolarity: z.ZodNumber;
                baseMolarity: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-mitosis">;
            content: z.ZodObject<{
                chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-enzyme">;
            content: z.ZodObject<{
                enzyme: z.ZodString;
                substrate: z.ZodString;
                products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"geography-water">;
            content: z.ZodObject<{
                title: z.ZodString;
                nodes: z.ZodTuple<[z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>], null>;
                transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"history-timeline">;
            content: z.ZodObject<{
                range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                events: z.ZodTuple<[z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>], null>;
                caution: z.ZodString;
                conclusion: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-syntax">;
            content: z.ZodObject<{
                subject: z.ZodString;
                verb: z.ZodString;
                object: z.ZodString;
                question: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-perspective">;
            content: z.ZodObject<{
                object: z.ZodEnum<{
                    door: "door";
                    book: "book";
                }>;
                firstPerson: z.ZodString;
                observer: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-sorting">;
            content: z.ZodObject<{
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-recursion">;
            content: z.ZodObject<{
                operation: z.ZodEnum<{
                    product: "product";
                    sum: "sum";
                }>;
                start: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-score">;
            content: z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-harmony">;
            content: z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"economics-equilibrium">;
            content: z.ZodObject<{
                demandIntercept: z.ZodNumber;
                supplyIntercept: z.ZodNumber;
                demandSlope: z.ZodNumber;
                supplySlope: z.ZodNumber;
                demandShift: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-timeline">;
            content: z.ZodObject<{
                unit: z.ZodString;
                events: z.ZodArray<z.ZodObject<{
                    at: z.ZodNumber;
                    label: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-cycle">;
            content: z.ZodObject<{
                center: z.ZodString;
                nodes: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    process: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-decision">;
            content: z.ZodObject<{
                question: z.ZodString;
                branches: z.ZodArray<z.ZodObject<{
                    condition: z.ZodString;
                    outcome: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-funnel">;
            content: z.ZodObject<{
                unit: z.ZodString;
                stages: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-balance">;
            content: z.ZodObject<{
                unit: z.ZodString;
                left: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                right: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-matrix">;
            content: z.ZodObject<{
                columns: z.ZodArray<z.ZodString>;
                rows: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>>;
                unit: z.ZodString;
                max: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-proportion">;
            content: z.ZodObject<{
                whole: z.ZodString;
                unit: z.ZodString;
                parts: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-network">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
                links: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-counter">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                from: z.ZodNumber;
                to: z.ZodNumber;
                context: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-interval">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                min: z.ZodNumber;
                max: z.ZodNumber;
                low: z.ZodNumber;
                high: z.ZodNumber;
                points: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-hierarchy">;
            content: z.ZodObject<{
                root: z.ZodString;
                groups: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    members: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-ranking">;
            content: z.ZodObject<{
                unit: z.ZodString;
                before: z.ZodString;
                after: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    before: z.ZodNumber;
                    after: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>], "templateId">, z.ZodObject<{
            type: z.ZodLiteral<"visual">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            kind: z.ZodEnum<{
                process: "process";
                cycle: "cycle";
                layers: "layers";
            }>;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
                id: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"visual">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            unit: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"bars">;
            items: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"code">;
            id: z.ZodOptional<z.ZodString>;
            code: z.ZodString;
            language: z.ZodOptional<z.ZodString>;
            parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                text: z.ZodString;
            }, z.core.$strip>>>;
            regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                match: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"conversation">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            turns: z.ZodArray<z.ZodObject<{
                speaker: z.ZodString;
                text: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"callout">;
            id: z.ZodOptional<z.ZodString>;
            variant: z.ZodEnum<{
                example: "example";
                warning: "warning";
                definition: "definition";
                tip: "tip";
            }>;
            title: z.ZodOptional<z.ZodString>;
            body: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"accordion">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"illustration">;
            id: z.ZodOptional<z.ZodString>;
            caption: z.ZodString;
            prompt: z.ZodString;
            style: z.ZodEnum<{
                process: "process";
                diagram: "diagram";
                concept: "concept";
                comparison: "comparison";
            }>;
            aspectRatio: z.ZodOptional<z.ZodEnum<{
                "1:1": "1:1";
                "16:9": "16:9";
                "9:16": "9:16";
                "4:3": "4:3";
                "3:4": "3:4";
                "3:2": "3:2";
                "2:3": "2:3";
            }>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"svg_slot">;
            id: z.ZodOptional<z.ZodString>;
            intent: z.ZodObject<{
                visualKind: z.ZodEnum<{
                    simple_structure: "simple_structure";
                    spatial_relationship: "spatial_relationship";
                    state_comparison: "state_comparison";
                    step_derivation: "step_derivation";
                }>;
                setup: z.ZodString;
                learningGoal: z.ZodString;
                expectedInsight: z.ZodString;
                composition: z.ZodOptional<z.ZodString>;
                elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
                relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
                labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
                avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>;
        }, z.core.$strip>]>>;
    }, z.core.$strip>]>, z.ZodUnion<readonly [z.ZodObject<{
        type: z.ZodLiteral<"component_slot">;
        slotRef: z.ZodString;
        intent: z.ZodObject<{
            setup: z.ZodString;
            learningGoal: z.ZodString;
            expectedInsight: z.ZodString;
        }, z.core.$strip>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"component_slot">;
        componentType: z.ZodEnum<{
            chart: "chart";
            math_scene: "math_scene";
            mechanics_sandbox: "mechanics_sandbox";
            circuit_sandbox: "circuit_sandbox";
            chemistry_lab: "chemistry_lab";
        }>;
        intent: z.ZodObject<{
            setup: z.ZodString;
            learningGoal: z.ZodString;
            expectedInsight: z.ZodString;
        }, z.core.$strip>;
    }, z.core.$strip>]>, z.ZodObject<{
        type: z.ZodLiteral<"svg_slot">;
        intent: z.ZodObject<{
            visualKind: z.ZodEnum<{
                simple_structure: "simple_structure";
                spatial_relationship: "spatial_relationship";
                state_comparison: "state_comparison";
                step_derivation: "step_derivation";
            }>;
            setup: z.ZodString;
            learningGoal: z.ZodString;
            expectedInsight: z.ZodString;
            composition: z.ZodString;
            elements: z.ZodArray<z.ZodString>;
            relationships: z.ZodArray<z.ZodString>;
            labels: z.ZodArray<z.ZodString>;
            avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>;
    }, z.core.$strip>]>>>;
    keyTakeaways: z.ZodArray<z.ZodString>;
}, z.core.$strip>>;
export type PrepareSectionMaterialAuthoringInput = {
    /** Exact capability-composed hosted prompt or an equivalent local projection. */
    prompt: string;
    policy: SectionMaterialAuthoringPolicy;
};
/** Provider-independent contract at the boundary before component/SVG compilation. */
export declare function prepareSectionMaterialAuthoring(input: PrepareSectionMaterialAuthoringInput): {
    operation: "unit.learning_material";
    prompt: string;
    policy: SectionMaterialAuthoringPolicy;
    resultSchema: z.ZodPreprocess<z.ZodObject<{
        introduction: z.ZodString;
        blocks: z.ZodArray<z.ZodPreprocess<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"music">;
            id: z.ZodOptional<z.ZodString>;
            version: z.ZodLiteral<1>;
            title: z.ZodString;
            key: z.ZodLiteral<"C">;
            meter: z.ZodEnum<{
                "2/4": "2/4";
                "3/4": "3/4";
                "4/4": "4/4";
            }>;
            tempo: z.ZodNumber;
            keyboard: z.ZodBoolean;
            notation: z.ZodOptional<z.ZodEnum<{
                staff: "staff";
                both: "both";
                jianpu: "jianpu";
            }>>;
            parts: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                clef: z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                bars: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodObject<{
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            steps: z.ZodArray<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                id: z.ZodString;
                label: z.ZodString;
                focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                compare: z.ZodOptional<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
            templateId: z.ZodLiteral<"general-question">;
            content: z.ZodObject<{
                objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                glyphs: z.ZodTuple<[z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>, z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>], null>;
                observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                question: z.ZodString;
                goal: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-layers">;
            content: z.ZodObject<{
                layers: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-flow">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodString>;
                caption: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-compare">;
            content: z.ZodObject<{
                names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                metrics: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    max: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-summary">;
            content: z.ZodObject<{
                concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                center: z.ZodString;
                transfer: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-pythagoras">;
            content: z.ZodObject<{
                a: z.ZodNumber;
                b: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-tangent">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                at: z.ZodNumber;
                startDx: z.ZodNumber;
                xmax: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-integral">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                end: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-probability">;
            content: z.ZodObject<{
                total: z.ZodNumber;
                condition: z.ZodNumber;
                intersection: z.ZodNumber;
                outsideTarget: z.ZodNumber;
                conditionName: z.ZodString;
                targetName: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-forces">;
            content: z.ZodObject<{
                mass: z.ZodNumber;
                drive: z.ZodNumber;
                resistance: z.ZodNumber;
                duration: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-waves">;
            content: z.ZodObject<{
                amplitude1: z.ZodNumber;
                amplitude2: z.ZodNumber;
                cycles1: z.ZodNumber;
                cycles2: z.ZodNumber;
                phase2: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-circuit">;
            content: z.ZodObject<{
                voltage: z.ZodNumber;
                resistance1: z.ZodNumber;
                resistance2: z.ZodNumber;
                topology: z.ZodEnum<{
                    series: "series";
                    parallel: "parallel";
                }>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-reaction">;
            content: z.ZodObject<{
                reactants: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                products: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-titration">;
            content: z.ZodObject<{
                acidMl: z.ZodNumber;
                acidMolarity: z.ZodNumber;
                baseMolarity: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-mitosis">;
            content: z.ZodObject<{
                chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-enzyme">;
            content: z.ZodObject<{
                enzyme: z.ZodString;
                substrate: z.ZodString;
                products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"geography-water">;
            content: z.ZodObject<{
                title: z.ZodString;
                nodes: z.ZodTuple<[z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>], null>;
                transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"history-timeline">;
            content: z.ZodObject<{
                range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                events: z.ZodTuple<[z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>], null>;
                caution: z.ZodString;
                conclusion: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-syntax">;
            content: z.ZodObject<{
                subject: z.ZodString;
                verb: z.ZodString;
                object: z.ZodString;
                question: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-perspective">;
            content: z.ZodObject<{
                object: z.ZodEnum<{
                    door: "door";
                    book: "book";
                }>;
                firstPerson: z.ZodString;
                observer: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-sorting">;
            content: z.ZodObject<{
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-recursion">;
            content: z.ZodObject<{
                operation: z.ZodEnum<{
                    product: "product";
                    sum: "sum";
                }>;
                start: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-score">;
            content: z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-harmony">;
            content: z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"economics-equilibrium">;
            content: z.ZodObject<{
                demandIntercept: z.ZodNumber;
                supplyIntercept: z.ZodNumber;
                demandSlope: z.ZodNumber;
                supplySlope: z.ZodNumber;
                demandShift: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-timeline">;
            content: z.ZodObject<{
                unit: z.ZodString;
                events: z.ZodArray<z.ZodObject<{
                    at: z.ZodNumber;
                    label: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-cycle">;
            content: z.ZodObject<{
                center: z.ZodString;
                nodes: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    process: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-decision">;
            content: z.ZodObject<{
                question: z.ZodString;
                branches: z.ZodArray<z.ZodObject<{
                    condition: z.ZodString;
                    outcome: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-funnel">;
            content: z.ZodObject<{
                unit: z.ZodString;
                stages: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-balance">;
            content: z.ZodObject<{
                unit: z.ZodString;
                left: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                right: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-matrix">;
            content: z.ZodObject<{
                columns: z.ZodArray<z.ZodString>;
                rows: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>>;
                unit: z.ZodString;
                max: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-proportion">;
            content: z.ZodObject<{
                whole: z.ZodString;
                unit: z.ZodString;
                parts: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-network">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
                links: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-counter">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                from: z.ZodNumber;
                to: z.ZodNumber;
                context: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-interval">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                min: z.ZodNumber;
                max: z.ZodNumber;
                low: z.ZodNumber;
                high: z.ZodNumber;
                points: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-hierarchy">;
            content: z.ZodObject<{
                root: z.ZodString;
                groups: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    members: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-ranking">;
            content: z.ZodObject<{
                unit: z.ZodString;
                before: z.ZodString;
                after: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    before: z.ZodNumber;
                    after: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>], "templateId">, z.ZodObject<{
            type: z.ZodLiteral<"visual">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            kind: z.ZodEnum<{
                process: "process";
                cycle: "cycle";
                layers: "layers";
            }>;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
                id: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"visual">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            unit: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"bars">;
            items: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
            templateId: z.ZodLiteral<"general-question">;
            content: z.ZodObject<{
                objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                glyphs: z.ZodTuple<[z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>, z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>], null>;
                observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                question: z.ZodString;
                goal: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-layers">;
            content: z.ZodObject<{
                layers: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-flow">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodString>;
                caption: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-compare">;
            content: z.ZodObject<{
                names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                metrics: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    max: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-summary">;
            content: z.ZodObject<{
                concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                center: z.ZodString;
                transfer: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-pythagoras">;
            content: z.ZodObject<{
                a: z.ZodNumber;
                b: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-tangent">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                at: z.ZodNumber;
                startDx: z.ZodNumber;
                xmax: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-integral">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                end: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-probability">;
            content: z.ZodObject<{
                total: z.ZodNumber;
                condition: z.ZodNumber;
                intersection: z.ZodNumber;
                outsideTarget: z.ZodNumber;
                conditionName: z.ZodString;
                targetName: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-forces">;
            content: z.ZodObject<{
                mass: z.ZodNumber;
                drive: z.ZodNumber;
                resistance: z.ZodNumber;
                duration: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-waves">;
            content: z.ZodObject<{
                amplitude1: z.ZodNumber;
                amplitude2: z.ZodNumber;
                cycles1: z.ZodNumber;
                cycles2: z.ZodNumber;
                phase2: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-circuit">;
            content: z.ZodObject<{
                voltage: z.ZodNumber;
                resistance1: z.ZodNumber;
                resistance2: z.ZodNumber;
                topology: z.ZodEnum<{
                    series: "series";
                    parallel: "parallel";
                }>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-reaction">;
            content: z.ZodObject<{
                reactants: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                products: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-titration">;
            content: z.ZodObject<{
                acidMl: z.ZodNumber;
                acidMolarity: z.ZodNumber;
                baseMolarity: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-mitosis">;
            content: z.ZodObject<{
                chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-enzyme">;
            content: z.ZodObject<{
                enzyme: z.ZodString;
                substrate: z.ZodString;
                products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"geography-water">;
            content: z.ZodObject<{
                title: z.ZodString;
                nodes: z.ZodTuple<[z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>], null>;
                transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"history-timeline">;
            content: z.ZodObject<{
                range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                events: z.ZodTuple<[z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>], null>;
                caution: z.ZodString;
                conclusion: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-syntax">;
            content: z.ZodObject<{
                subject: z.ZodString;
                verb: z.ZodString;
                object: z.ZodString;
                question: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-perspective">;
            content: z.ZodObject<{
                object: z.ZodEnum<{
                    door: "door";
                    book: "book";
                }>;
                firstPerson: z.ZodString;
                observer: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-sorting">;
            content: z.ZodObject<{
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-recursion">;
            content: z.ZodObject<{
                operation: z.ZodEnum<{
                    product: "product";
                    sum: "sum";
                }>;
                start: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-score">;
            content: z.ZodUnion<readonly [z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodLiteral<"accepted-v2">;
                block: z.ZodObject<{
                    type: z.ZodLiteral<"music">;
                    version: z.ZodLiteral<2>;
                    id: z.ZodString;
                    title: z.ZodString;
                    layout: z.ZodEnum<{
                        row: "row";
                        column: "column";
                        grid: "grid";
                    }>;
                    notes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                    }, z.core.$strict>>;
                    views: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            staff: "staff";
                            keyboard: "keyboard";
                        }>;
                        label: z.ZodString;
                        notes: z.ZodArray<z.ZodString>;
                        clef: z.ZodOptional<z.ZodEnum<{
                            treble: "treble";
                            bass: "bass";
                        }>>;
                        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            label: "label";
                            link: "link";
                            bracket: "bracket";
                            arrow: "arrow";
                        }>;
                        label: z.ZodString;
                        anchors: z.ZodArray<z.ZodObject<{
                            viewId: z.ZodString;
                            noteId: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                        tempo: z.ZodNumber;
                        instrument: z.ZodOptional<z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>>;
                        events: z.ZodArray<z.ZodObject<{
                            notes: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
                clipId: z.ZodOptional<z.ZodString>;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>]>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-harmony">;
            content: z.ZodUnion<readonly [z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodLiteral<"accepted-v2">;
                block: z.ZodObject<{
                    type: z.ZodLiteral<"music">;
                    version: z.ZodLiteral<2>;
                    id: z.ZodString;
                    title: z.ZodString;
                    layout: z.ZodEnum<{
                        row: "row";
                        column: "column";
                        grid: "grid";
                    }>;
                    notes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                    }, z.core.$strict>>;
                    views: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            staff: "staff";
                            keyboard: "keyboard";
                        }>;
                        label: z.ZodString;
                        notes: z.ZodArray<z.ZodString>;
                        clef: z.ZodOptional<z.ZodEnum<{
                            treble: "treble";
                            bass: "bass";
                        }>>;
                        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            label: "label";
                            link: "link";
                            bracket: "bracket";
                            arrow: "arrow";
                        }>;
                        label: z.ZodString;
                        anchors: z.ZodArray<z.ZodObject<{
                            viewId: z.ZodString;
                            noteId: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                        tempo: z.ZodNumber;
                        instrument: z.ZodOptional<z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>>;
                        events: z.ZodArray<z.ZodObject<{
                            notes: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
                clipId: z.ZodOptional<z.ZodString>;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>]>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"economics-equilibrium">;
            content: z.ZodObject<{
                demandIntercept: z.ZodNumber;
                supplyIntercept: z.ZodNumber;
                demandSlope: z.ZodNumber;
                supplySlope: z.ZodNumber;
                demandShift: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-timeline">;
            content: z.ZodObject<{
                unit: z.ZodString;
                events: z.ZodArray<z.ZodObject<{
                    at: z.ZodNumber;
                    label: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-cycle">;
            content: z.ZodObject<{
                center: z.ZodString;
                nodes: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    process: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-decision">;
            content: z.ZodObject<{
                question: z.ZodString;
                branches: z.ZodArray<z.ZodObject<{
                    condition: z.ZodString;
                    outcome: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-funnel">;
            content: z.ZodObject<{
                unit: z.ZodString;
                stages: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-balance">;
            content: z.ZodObject<{
                unit: z.ZodString;
                left: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                right: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-matrix">;
            content: z.ZodObject<{
                columns: z.ZodArray<z.ZodString>;
                rows: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>>;
                unit: z.ZodString;
                max: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-proportion">;
            content: z.ZodObject<{
                whole: z.ZodString;
                unit: z.ZodString;
                parts: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-network">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
                links: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-counter">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                from: z.ZodNumber;
                to: z.ZodNumber;
                context: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-interval">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                min: z.ZodNumber;
                max: z.ZodNumber;
                low: z.ZodNumber;
                high: z.ZodNumber;
                points: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-hierarchy">;
            content: z.ZodObject<{
                root: z.ZodString;
                groups: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    members: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-ranking">;
            content: z.ZodObject<{
                unit: z.ZodString;
                before: z.ZodString;
                after: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    before: z.ZodNumber;
                    after: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>], "templateId"> | z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"music">;
            id: z.ZodOptional<z.ZodString>;
            version: z.ZodLiteral<1>;
            title: z.ZodString;
            key: z.ZodLiteral<"C">;
            meter: z.ZodEnum<{
                "2/4": "2/4";
                "3/4": "3/4";
                "4/4": "4/4";
            }>;
            tempo: z.ZodNumber;
            keyboard: z.ZodBoolean;
            notation: z.ZodOptional<z.ZodEnum<{
                staff: "staff";
                both: "both";
                jianpu: "jianpu";
            }>>;
            parts: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                clef: z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                bars: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodObject<{
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            steps: z.ZodArray<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                id: z.ZodString;
                label: z.ZodString;
                focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                compare: z.ZodOptional<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>], "version"> | z.ZodObject<{
            type: z.ZodLiteral<"illustration">;
            id: z.ZodOptional<z.ZodString>;
            caption: z.ZodString;
            prompt: z.ZodString;
            style: z.ZodEnum<{
                process: "process";
                diagram: "diagram";
                concept: "concept";
                comparison: "comparison";
            }>;
            aspectRatio: z.ZodOptional<z.ZodEnum<{
                "1:1": "1:1";
                "16:9": "16:9";
                "9:16": "9:16";
                "4:3": "4:3";
                "3:4": "3:4";
                "3:2": "3:2";
                "2:3": "2:3";
            }>>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"visual">;
            id: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                process: "process";
                cycle: "cycle";
                layers: "layers";
                bars: "bars";
            }>;
            title: z.ZodString;
            unit: z.ZodOptional<z.ZodString>;
            items: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
                value: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict> | z.ZodObject<{
            type: z.ZodLiteral<"code">;
            id: z.ZodOptional<z.ZodString>;
            code: z.ZodString;
            language: z.ZodOptional<z.ZodString>;
            parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                text: z.ZodString;
            }, z.core.$strip>>>;
            regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                match: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"conversation">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            turns: z.ZodArray<z.ZodObject<{
                speaker: z.ZodString;
                text: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"callout">;
            id: z.ZodOptional<z.ZodString>;
            variant: z.ZodEnum<{
                example: "example";
                warning: "warning";
                definition: "definition";
                tip: "tip";
            }>;
            title: z.ZodOptional<z.ZodString>;
            body: z.ZodString;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"accordion">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"compare">;
            id: z.ZodOptional<z.ZodString>;
            left: z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>;
            right: z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>;
            sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"stage">;
            id: z.ZodOptional<z.ZodString>;
            layout: z.ZodEnum<{
                "split-h": "split-h";
                "split-v": "split-v";
                "main+rail": "main+rail";
                stack: "stack";
            }>;
            presentation: z.ZodOptional<z.ZodEnum<{
                compare: "compare";
                steps: "steps";
                focus: "focus";
            }>>;
            figures: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"music">;
                id: z.ZodOptional<z.ZodString>;
                version: z.ZodLiteral<1>;
                title: z.ZodString;
                key: z.ZodLiteral<"C">;
                meter: z.ZodEnum<{
                    "2/4": "2/4";
                    "3/4": "3/4";
                    "4/4": "4/4";
                }>;
                tempo: z.ZodNumber;
                keyboard: z.ZodBoolean;
                notation: z.ZodOptional<z.ZodEnum<{
                    staff: "staff";
                    both: "both";
                    jianpu: "jianpu";
                }>>;
                parts: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    clef: z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    bars: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodObject<{
                            pitches: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                steps: z.ZodArray<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    id: z.ZodString;
                    label: z.ZodString;
                    focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    compare: z.ZodOptional<z.ZodObject<{
                        bars: z.ZodArray<z.ZodNumber>;
                        parts: z.ZodArray<z.ZodString>;
                        instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            part: z.ZodString;
                            instrument: z.ZodEnum<{
                                piano: "piano";
                                electric_piano: "electric_piano";
                                guitar: "guitar";
                                violin: "violin";
                                cello: "cello";
                                flute: "flute";
                                marimba: "marimba";
                                organ: "organ";
                            }>;
                        }, z.core.$strict>>>;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
                templateId: z.ZodLiteral<"general-question">;
                content: z.ZodObject<{
                    objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    glyphs: z.ZodTuple<[z.ZodEnum<{
                        object: "object";
                        question: "question";
                        paper: "paper";
                        boat: "boat";
                        read: "read";
                        recall: "recall";
                    }>, z.ZodEnum<{
                        object: "object";
                        question: "question";
                        paper: "paper";
                        boat: "boat";
                        read: "read";
                        recall: "recall";
                    }>], null>;
                    observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    question: z.ZodString;
                    goal: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-layers">;
                content: z.ZodObject<{
                    layers: z.ZodArray<z.ZodObject<{
                        title: z.ZodString;
                        detail: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-flow">;
                content: z.ZodObject<{
                    nodes: z.ZodArray<z.ZodString>;
                    caption: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-compare">;
                content: z.ZodObject<{
                    names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    metrics: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        unit: z.ZodString;
                        values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                        max: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-summary">;
                content: z.ZodObject<{
                    concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                    center: z.ZodString;
                    transfer: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-pythagoras">;
                content: z.ZodObject<{
                    a: z.ZodNumber;
                    b: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-tangent">;
                content: z.ZodObject<{
                    coefficient: z.ZodNumber;
                    power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    at: z.ZodNumber;
                    startDx: z.ZodNumber;
                    xmax: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-integral">;
                content: z.ZodObject<{
                    coefficient: z.ZodNumber;
                    power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    end: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-probability">;
                content: z.ZodObject<{
                    total: z.ZodNumber;
                    condition: z.ZodNumber;
                    intersection: z.ZodNumber;
                    outsideTarget: z.ZodNumber;
                    conditionName: z.ZodString;
                    targetName: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-forces">;
                content: z.ZodObject<{
                    mass: z.ZodNumber;
                    drive: z.ZodNumber;
                    resistance: z.ZodNumber;
                    duration: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-waves">;
                content: z.ZodObject<{
                    amplitude1: z.ZodNumber;
                    amplitude2: z.ZodNumber;
                    cycles1: z.ZodNumber;
                    cycles2: z.ZodNumber;
                    phase2: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-circuit">;
                content: z.ZodObject<{
                    voltage: z.ZodNumber;
                    resistance1: z.ZodNumber;
                    resistance2: z.ZodNumber;
                    topology: z.ZodEnum<{
                        series: "series";
                        parallel: "parallel";
                    }>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"chemistry-reaction">;
                content: z.ZodObject<{
                    reactants: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        atoms: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            element: z.ZodString;
                        }, z.core.$strict>>;
                        bonds: z.ZodArray<z.ZodObject<{
                            from: z.ZodString;
                            to: z.ZodString;
                            order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    products: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        atoms: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            element: z.ZodString;
                        }, z.core.$strict>>;
                        bonds: z.ZodArray<z.ZodObject<{
                            from: z.ZodString;
                            to: z.ZodString;
                            order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"chemistry-titration">;
                content: z.ZodObject<{
                    acidMl: z.ZodNumber;
                    acidMolarity: z.ZodNumber;
                    baseMolarity: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"biology-mitosis">;
                content: z.ZodObject<{
                    chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"biology-enzyme">;
                content: z.ZodObject<{
                    enzyme: z.ZodString;
                    substrate: z.ZodString;
                    products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"geography-water">;
                content: z.ZodObject<{
                    title: z.ZodString;
                    nodes: z.ZodTuple<[z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>], null>;
                    transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                    stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"history-timeline">;
                content: z.ZodObject<{
                    range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    events: z.ZodTuple<[z.ZodObject<{
                        year: z.ZodNumber;
                        label: z.ZodString;
                        evidence: z.ZodString;
                        approximate: z.ZodOptional<z.ZodBoolean>;
                        kind: z.ZodEnum<{
                            type: "type";
                            block: "block";
                            moon: "moon";
                            telescope: "telescope";
                            event: "event";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        year: z.ZodNumber;
                        label: z.ZodString;
                        evidence: z.ZodString;
                        approximate: z.ZodOptional<z.ZodBoolean>;
                        kind: z.ZodEnum<{
                            type: "type";
                            block: "block";
                            moon: "moon";
                            telescope: "telescope";
                            event: "event";
                        }>;
                    }, z.core.$strict>], null>;
                    caution: z.ZodString;
                    conclusion: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"language-syntax">;
                content: z.ZodObject<{
                    subject: z.ZodString;
                    verb: z.ZodString;
                    object: z.ZodString;
                    question: z.ZodString;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"language-perspective">;
                content: z.ZodObject<{
                    object: z.ZodEnum<{
                        door: "door";
                        book: "book";
                    }>;
                    firstPerson: z.ZodString;
                    observer: z.ZodString;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"cs-sorting">;
                content: z.ZodObject<{
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"cs-recursion">;
                content: z.ZodObject<{
                    operation: z.ZodEnum<{
                        product: "product";
                        sum: "sum";
                    }>;
                    start: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"music-score">;
                content: z.ZodUnion<readonly [z.ZodObject<{
                    id: z.ZodString;
                    title: z.ZodString;
                    groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                    labels: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    tempo: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>, z.ZodObject<{
                    source: z.ZodLiteral<"accepted-v2">;
                    block: z.ZodObject<{
                        type: z.ZodLiteral<"music">;
                        version: z.ZodLiteral<2>;
                        id: z.ZodString;
                        title: z.ZodString;
                        layout: z.ZodEnum<{
                            row: "row";
                            column: "column";
                            grid: "grid";
                        }>;
                        notes: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            pitches: z.ZodArray<z.ZodString>;
                            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                        }, z.core.$strict>>;
                        views: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            kind: z.ZodEnum<{
                                staff: "staff";
                                keyboard: "keyboard";
                            }>;
                            label: z.ZodString;
                            notes: z.ZodArray<z.ZodString>;
                            clef: z.ZodOptional<z.ZodEnum<{
                                treble: "treble";
                                bass: "bass";
                            }>>;
                            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>>;
                        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            kind: z.ZodEnum<{
                                label: "label";
                                link: "link";
                                bracket: "bracket";
                                arrow: "arrow";
                            }>;
                            label: z.ZodString;
                            anchors: z.ZodArray<z.ZodObject<{
                                viewId: z.ZodString;
                                noteId: z.ZodOptional<z.ZodString>;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>>;
                        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            label: z.ZodString;
                            tempo: z.ZodNumber;
                            instrument: z.ZodOptional<z.ZodEnum<{
                                piano: "piano";
                                electric_piano: "electric_piano";
                                guitar: "guitar";
                                violin: "violin";
                                cello: "cello";
                                flute: "flute";
                                marimba: "marimba";
                                organ: "organ";
                            }>>;
                            events: z.ZodArray<z.ZodObject<{
                                notes: z.ZodArray<z.ZodString>;
                                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>;
                    clipId: z.ZodOptional<z.ZodString>;
                    repeat: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>]>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"music-harmony">;
                content: z.ZodUnion<readonly [z.ZodObject<{
                    id: z.ZodString;
                    title: z.ZodString;
                    groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                    labels: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    tempo: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>, z.ZodObject<{
                    source: z.ZodLiteral<"accepted-v2">;
                    block: z.ZodObject<{
                        type: z.ZodLiteral<"music">;
                        version: z.ZodLiteral<2>;
                        id: z.ZodString;
                        title: z.ZodString;
                        layout: z.ZodEnum<{
                            row: "row";
                            column: "column";
                            grid: "grid";
                        }>;
                        notes: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            pitches: z.ZodArray<z.ZodString>;
                            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                        }, z.core.$strict>>;
                        views: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            kind: z.ZodEnum<{
                                staff: "staff";
                                keyboard: "keyboard";
                            }>;
                            label: z.ZodString;
                            notes: z.ZodArray<z.ZodString>;
                            clef: z.ZodOptional<z.ZodEnum<{
                                treble: "treble";
                                bass: "bass";
                            }>>;
                            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>>;
                        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            kind: z.ZodEnum<{
                                label: "label";
                                link: "link";
                                bracket: "bracket";
                                arrow: "arrow";
                            }>;
                            label: z.ZodString;
                            anchors: z.ZodArray<z.ZodObject<{
                                viewId: z.ZodString;
                                noteId: z.ZodOptional<z.ZodString>;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>>;
                        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            label: z.ZodString;
                            tempo: z.ZodNumber;
                            instrument: z.ZodOptional<z.ZodEnum<{
                                piano: "piano";
                                electric_piano: "electric_piano";
                                guitar: "guitar";
                                violin: "violin";
                                cello: "cello";
                                flute: "flute";
                                marimba: "marimba";
                                organ: "organ";
                            }>>;
                            events: z.ZodArray<z.ZodObject<{
                                notes: z.ZodArray<z.ZodString>;
                                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>;
                    clipId: z.ZodOptional<z.ZodString>;
                    repeat: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>]>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"economics-equilibrium">;
                content: z.ZodObject<{
                    demandIntercept: z.ZodNumber;
                    supplyIntercept: z.ZodNumber;
                    demandSlope: z.ZodNumber;
                    supplySlope: z.ZodNumber;
                    demandShift: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-timeline">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    events: z.ZodArray<z.ZodObject<{
                        at: z.ZodNumber;
                        label: z.ZodString;
                        detail: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-cycle">;
                content: z.ZodObject<{
                    center: z.ZodString;
                    nodes: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        process: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-decision">;
                content: z.ZodObject<{
                    question: z.ZodString;
                    branches: z.ZodArray<z.ZodObject<{
                        condition: z.ZodString;
                        outcome: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-funnel">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    stages: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-balance">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    left: z.ZodObject<{
                        label: z.ZodString;
                        items: z.ZodArray<z.ZodObject<{
                            label: z.ZodString;
                            value: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>;
                    right: z.ZodObject<{
                        label: z.ZodString;
                        items: z.ZodArray<z.ZodObject<{
                            label: z.ZodString;
                            value: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-matrix">;
                content: z.ZodObject<{
                    columns: z.ZodArray<z.ZodString>;
                    rows: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        values: z.ZodArray<z.ZodNumber>;
                    }, z.core.$strict>>;
                    unit: z.ZodString;
                    max: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-proportion">;
                content: z.ZodObject<{
                    whole: z.ZodString;
                    unit: z.ZodString;
                    parts: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-network">;
                content: z.ZodObject<{
                    nodes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                    links: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-counter">;
                content: z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    from: z.ZodNumber;
                    to: z.ZodNumber;
                    context: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-interval">;
                content: z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    min: z.ZodNumber;
                    max: z.ZodNumber;
                    low: z.ZodNumber;
                    high: z.ZodNumber;
                    points: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-hierarchy">;
                content: z.ZodObject<{
                    root: z.ZodString;
                    groups: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        members: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-ranking">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    before: z.ZodString;
                    after: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        before: z.ZodNumber;
                        after: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>], "templateId">, z.ZodObject<{
                type: z.ZodLiteral<"visual">;
                id: z.ZodOptional<z.ZodString>;
                kind: z.ZodEnum<{
                    process: "process";
                    cycle: "cycle";
                    layers: "layers";
                    bars: "bars";
                }>;
                title: z.ZodString;
                unit: z.ZodOptional<z.ZodString>;
                items: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                    value: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"code">;
                id: z.ZodOptional<z.ZodString>;
                code: z.ZodString;
                language: z.ZodOptional<z.ZodString>;
                parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodOptional<z.ZodString>;
                    text: z.ZodString;
                }, z.core.$strip>>>;
                regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    match: z.ZodString;
                }, z.core.$strip>>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"conversation">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodOptional<z.ZodString>;
                turns: z.ZodArray<z.ZodObject<{
                    speaker: z.ZodString;
                    text: z.ZodString;
                }, z.core.$strip>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"callout">;
                id: z.ZodOptional<z.ZodString>;
                variant: z.ZodEnum<{
                    example: "example";
                    warning: "warning";
                    definition: "definition";
                    tip: "tip";
                }>;
                title: z.ZodOptional<z.ZodString>;
                body: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"accordion">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"illustration">;
                id: z.ZodOptional<z.ZodString>;
                caption: z.ZodString;
                prompt: z.ZodString;
                style: z.ZodEnum<{
                    process: "process";
                    diagram: "diagram";
                    concept: "concept";
                    comparison: "comparison";
                }>;
                aspectRatio: z.ZodOptional<z.ZodEnum<{
                    "1:1": "1:1";
                    "16:9": "16:9";
                    "9:16": "9:16";
                    "4:3": "4:3";
                    "3:4": "3:4";
                    "3:2": "3:2";
                    "2:3": "2:3";
                }>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"svg_slot">;
                id: z.ZodOptional<z.ZodString>;
                intent: z.ZodObject<{
                    visualKind: z.ZodEnum<{
                        simple_structure: "simple_structure";
                        spatial_relationship: "spatial_relationship";
                        state_comparison: "state_comparison";
                        step_derivation: "step_derivation";
                    }>;
                    setup: z.ZodString;
                    learningGoal: z.ZodString;
                    expectedInsight: z.ZodString;
                    composition: z.ZodOptional<z.ZodString>;
                    elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strip>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"compare">;
                id: z.ZodOptional<z.ZodString>;
                left: z.ZodObject<{
                    id: z.ZodOptional<z.ZodString>;
                    label: z.ZodString;
                    points: z.ZodArray<z.ZodString>;
                }, z.core.$strip>;
                right: z.ZodObject<{
                    id: z.ZodOptional<z.ZodString>;
                    label: z.ZodString;
                    points: z.ZodArray<z.ZodString>;
                }, z.core.$strip>;
                sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodOptional<z.ZodString>;
                    label: z.ZodString;
                    points: z.ZodArray<z.ZodString>;
                }, z.core.$strip>>>;
            }, z.core.$strip>], "type">>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"heading">;
            level: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            text: z.ZodString;
            topicId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"paragraph">;
            text: z.ZodString;
            cue: z.ZodOptional<z.ZodObject<{
                music: z.ZodOptional<z.ZodObject<{
                    figureId: z.ZodString;
                    clipId: z.ZodString;
                    repeat: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                target: z.ZodString;
                targetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
                op: z.ZodOptional<z.ZodEnum<{
                    highlight: "highlight";
                    window: "window";
                }>>;
                regionIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
                figureId: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>;
        }, z.core.$strip>, z.ZodDiscriminatedUnion<[z.ZodObject<{
            templateId: z.ZodLiteral<"general-question">;
            content: z.ZodObject<{
                objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                glyphs: z.ZodTuple<[z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>, z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>], null>;
                observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                question: z.ZodString;
                goal: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-layers">;
            content: z.ZodObject<{
                layers: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-flow">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodString>;
                caption: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-compare">;
            content: z.ZodObject<{
                names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                metrics: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    max: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-summary">;
            content: z.ZodObject<{
                concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                center: z.ZodString;
                transfer: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-pythagoras">;
            content: z.ZodObject<{
                a: z.ZodNumber;
                b: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-tangent">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                at: z.ZodNumber;
                startDx: z.ZodNumber;
                xmax: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-integral">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                end: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-probability">;
            content: z.ZodObject<{
                total: z.ZodNumber;
                condition: z.ZodNumber;
                intersection: z.ZodNumber;
                outsideTarget: z.ZodNumber;
                conditionName: z.ZodString;
                targetName: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-forces">;
            content: z.ZodObject<{
                mass: z.ZodNumber;
                drive: z.ZodNumber;
                resistance: z.ZodNumber;
                duration: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-waves">;
            content: z.ZodObject<{
                amplitude1: z.ZodNumber;
                amplitude2: z.ZodNumber;
                cycles1: z.ZodNumber;
                cycles2: z.ZodNumber;
                phase2: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-circuit">;
            content: z.ZodObject<{
                voltage: z.ZodNumber;
                resistance1: z.ZodNumber;
                resistance2: z.ZodNumber;
                topology: z.ZodEnum<{
                    series: "series";
                    parallel: "parallel";
                }>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-reaction">;
            content: z.ZodObject<{
                reactants: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                products: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-titration">;
            content: z.ZodObject<{
                acidMl: z.ZodNumber;
                acidMolarity: z.ZodNumber;
                baseMolarity: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-mitosis">;
            content: z.ZodObject<{
                chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-enzyme">;
            content: z.ZodObject<{
                enzyme: z.ZodString;
                substrate: z.ZodString;
                products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"geography-water">;
            content: z.ZodObject<{
                title: z.ZodString;
                nodes: z.ZodTuple<[z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>], null>;
                transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"history-timeline">;
            content: z.ZodObject<{
                range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                events: z.ZodTuple<[z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>], null>;
                caution: z.ZodString;
                conclusion: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-syntax">;
            content: z.ZodObject<{
                subject: z.ZodString;
                verb: z.ZodString;
                object: z.ZodString;
                question: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-perspective">;
            content: z.ZodObject<{
                object: z.ZodEnum<{
                    door: "door";
                    book: "book";
                }>;
                firstPerson: z.ZodString;
                observer: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-sorting">;
            content: z.ZodObject<{
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-recursion">;
            content: z.ZodObject<{
                operation: z.ZodEnum<{
                    product: "product";
                    sum: "sum";
                }>;
                start: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-score">;
            content: z.ZodUnion<readonly [z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodLiteral<"accepted-v2">;
                block: z.ZodObject<{
                    type: z.ZodLiteral<"music">;
                    version: z.ZodLiteral<2>;
                    id: z.ZodString;
                    title: z.ZodString;
                    layout: z.ZodEnum<{
                        row: "row";
                        column: "column";
                        grid: "grid";
                    }>;
                    notes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                    }, z.core.$strict>>;
                    views: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            staff: "staff";
                            keyboard: "keyboard";
                        }>;
                        label: z.ZodString;
                        notes: z.ZodArray<z.ZodString>;
                        clef: z.ZodOptional<z.ZodEnum<{
                            treble: "treble";
                            bass: "bass";
                        }>>;
                        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            label: "label";
                            link: "link";
                            bracket: "bracket";
                            arrow: "arrow";
                        }>;
                        label: z.ZodString;
                        anchors: z.ZodArray<z.ZodObject<{
                            viewId: z.ZodString;
                            noteId: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                        tempo: z.ZodNumber;
                        instrument: z.ZodOptional<z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>>;
                        events: z.ZodArray<z.ZodObject<{
                            notes: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
                clipId: z.ZodOptional<z.ZodString>;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>]>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-harmony">;
            content: z.ZodUnion<readonly [z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodLiteral<"accepted-v2">;
                block: z.ZodObject<{
                    type: z.ZodLiteral<"music">;
                    version: z.ZodLiteral<2>;
                    id: z.ZodString;
                    title: z.ZodString;
                    layout: z.ZodEnum<{
                        row: "row";
                        column: "column";
                        grid: "grid";
                    }>;
                    notes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                    }, z.core.$strict>>;
                    views: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            staff: "staff";
                            keyboard: "keyboard";
                        }>;
                        label: z.ZodString;
                        notes: z.ZodArray<z.ZodString>;
                        clef: z.ZodOptional<z.ZodEnum<{
                            treble: "treble";
                            bass: "bass";
                        }>>;
                        range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        kind: z.ZodEnum<{
                            label: "label";
                            link: "link";
                            bracket: "bracket";
                            arrow: "arrow";
                        }>;
                        label: z.ZodString;
                        anchors: z.ZodArray<z.ZodObject<{
                            viewId: z.ZodString;
                            noteId: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                    clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                        tempo: z.ZodNumber;
                        instrument: z.ZodOptional<z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>>;
                        events: z.ZodArray<z.ZodObject<{
                            notes: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>;
                clipId: z.ZodOptional<z.ZodString>;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>]>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"economics-equilibrium">;
            content: z.ZodObject<{
                demandIntercept: z.ZodNumber;
                supplyIntercept: z.ZodNumber;
                demandSlope: z.ZodNumber;
                supplySlope: z.ZodNumber;
                demandShift: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-timeline">;
            content: z.ZodObject<{
                unit: z.ZodString;
                events: z.ZodArray<z.ZodObject<{
                    at: z.ZodNumber;
                    label: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-cycle">;
            content: z.ZodObject<{
                center: z.ZodString;
                nodes: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    process: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-decision">;
            content: z.ZodObject<{
                question: z.ZodString;
                branches: z.ZodArray<z.ZodObject<{
                    condition: z.ZodString;
                    outcome: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-funnel">;
            content: z.ZodObject<{
                unit: z.ZodString;
                stages: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-balance">;
            content: z.ZodObject<{
                unit: z.ZodString;
                left: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                right: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-matrix">;
            content: z.ZodObject<{
                columns: z.ZodArray<z.ZodString>;
                rows: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>>;
                unit: z.ZodString;
                max: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-proportion">;
            content: z.ZodObject<{
                whole: z.ZodString;
                unit: z.ZodString;
                parts: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-network">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
                links: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-counter">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                from: z.ZodNumber;
                to: z.ZodNumber;
                context: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-interval">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                min: z.ZodNumber;
                max: z.ZodNumber;
                low: z.ZodNumber;
                high: z.ZodNumber;
                points: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-hierarchy">;
            content: z.ZodObject<{
                root: z.ZodString;
                groups: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    members: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-ranking">;
            content: z.ZodObject<{
                unit: z.ZodString;
                before: z.ZodString;
                after: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    before: z.ZodNumber;
                    after: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>], "templateId"> | z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"music">;
            id: z.ZodOptional<z.ZodString>;
            version: z.ZodLiteral<1>;
            title: z.ZodString;
            key: z.ZodLiteral<"C">;
            meter: z.ZodEnum<{
                "2/4": "2/4";
                "3/4": "3/4";
                "4/4": "4/4";
            }>;
            tempo: z.ZodNumber;
            keyboard: z.ZodBoolean;
            notation: z.ZodOptional<z.ZodEnum<{
                staff: "staff";
                both: "both";
                jianpu: "jianpu";
            }>>;
            parts: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                clef: z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                bars: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodObject<{
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            steps: z.ZodArray<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                id: z.ZodString;
                label: z.ZodString;
                focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                compare: z.ZodOptional<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>], "version"> | z.ZodObject<{
            type: z.ZodLiteral<"illustration">;
            id: z.ZodOptional<z.ZodString>;
            caption: z.ZodString;
            prompt: z.ZodString;
            style: z.ZodEnum<{
                process: "process";
                diagram: "diagram";
                concept: "concept";
                comparison: "comparison";
            }>;
            aspectRatio: z.ZodOptional<z.ZodEnum<{
                "1:1": "1:1";
                "16:9": "16:9";
                "9:16": "9:16";
                "4:3": "4:3";
                "3:4": "3:4";
                "3:2": "3:2";
                "2:3": "2:3";
            }>>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"visual">;
            id: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                process: "process";
                cycle: "cycle";
                layers: "layers";
                bars: "bars";
            }>;
            title: z.ZodString;
            unit: z.ZodOptional<z.ZodString>;
            items: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
                value: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict> | z.ZodObject<{
            type: z.ZodLiteral<"code">;
            id: z.ZodOptional<z.ZodString>;
            code: z.ZodString;
            language: z.ZodOptional<z.ZodString>;
            parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                text: z.ZodString;
            }, z.core.$strip>>>;
            regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                match: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"conversation">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            turns: z.ZodArray<z.ZodObject<{
                speaker: z.ZodString;
                text: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"callout">;
            id: z.ZodOptional<z.ZodString>;
            variant: z.ZodEnum<{
                example: "example";
                warning: "warning";
                definition: "definition";
                tip: "tip";
            }>;
            title: z.ZodOptional<z.ZodString>;
            body: z.ZodString;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"accordion">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"compare">;
            id: z.ZodOptional<z.ZodString>;
            left: z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>;
            right: z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>;
            sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                label: z.ZodString;
                points: z.ZodArray<z.ZodString>;
            }, z.core.$strip>>>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"stage">;
            id: z.ZodOptional<z.ZodString>;
            layout: z.ZodEnum<{
                "split-h": "split-h";
                "split-v": "split-v";
                "main+rail": "main+rail";
                stack: "stack";
            }>;
            presentation: z.ZodOptional<z.ZodEnum<{
                compare: "compare";
                steps: "steps";
                focus: "focus";
            }>>;
            figures: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"music">;
                id: z.ZodOptional<z.ZodString>;
                version: z.ZodLiteral<1>;
                title: z.ZodString;
                key: z.ZodLiteral<"C">;
                meter: z.ZodEnum<{
                    "2/4": "2/4";
                    "3/4": "3/4";
                    "4/4": "4/4";
                }>;
                tempo: z.ZodNumber;
                keyboard: z.ZodBoolean;
                notation: z.ZodOptional<z.ZodEnum<{
                    staff: "staff";
                    both: "both";
                    jianpu: "jianpu";
                }>>;
                parts: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    clef: z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    bars: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodObject<{
                            pitches: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                steps: z.ZodArray<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    id: z.ZodString;
                    label: z.ZodString;
                    focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    compare: z.ZodOptional<z.ZodObject<{
                        bars: z.ZodArray<z.ZodNumber>;
                        parts: z.ZodArray<z.ZodString>;
                        instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            part: z.ZodString;
                            instrument: z.ZodEnum<{
                                piano: "piano";
                                electric_piano: "electric_piano";
                                guitar: "guitar";
                                violin: "violin";
                                cello: "cello";
                                flute: "flute";
                                marimba: "marimba";
                                organ: "organ";
                            }>;
                        }, z.core.$strict>>>;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
                templateId: z.ZodLiteral<"general-question">;
                content: z.ZodObject<{
                    objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    glyphs: z.ZodTuple<[z.ZodEnum<{
                        object: "object";
                        question: "question";
                        paper: "paper";
                        boat: "boat";
                        read: "read";
                        recall: "recall";
                    }>, z.ZodEnum<{
                        object: "object";
                        question: "question";
                        paper: "paper";
                        boat: "boat";
                        read: "read";
                        recall: "recall";
                    }>], null>;
                    observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    question: z.ZodString;
                    goal: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-layers">;
                content: z.ZodObject<{
                    layers: z.ZodArray<z.ZodObject<{
                        title: z.ZodString;
                        detail: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-flow">;
                content: z.ZodObject<{
                    nodes: z.ZodArray<z.ZodString>;
                    caption: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-compare">;
                content: z.ZodObject<{
                    names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    metrics: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        unit: z.ZodString;
                        values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                        max: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-summary">;
                content: z.ZodObject<{
                    concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                    center: z.ZodString;
                    transfer: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-pythagoras">;
                content: z.ZodObject<{
                    a: z.ZodNumber;
                    b: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-tangent">;
                content: z.ZodObject<{
                    coefficient: z.ZodNumber;
                    power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    at: z.ZodNumber;
                    startDx: z.ZodNumber;
                    xmax: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-integral">;
                content: z.ZodObject<{
                    coefficient: z.ZodNumber;
                    power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    end: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-probability">;
                content: z.ZodObject<{
                    total: z.ZodNumber;
                    condition: z.ZodNumber;
                    intersection: z.ZodNumber;
                    outsideTarget: z.ZodNumber;
                    conditionName: z.ZodString;
                    targetName: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-forces">;
                content: z.ZodObject<{
                    mass: z.ZodNumber;
                    drive: z.ZodNumber;
                    resistance: z.ZodNumber;
                    duration: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-waves">;
                content: z.ZodObject<{
                    amplitude1: z.ZodNumber;
                    amplitude2: z.ZodNumber;
                    cycles1: z.ZodNumber;
                    cycles2: z.ZodNumber;
                    phase2: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-circuit">;
                content: z.ZodObject<{
                    voltage: z.ZodNumber;
                    resistance1: z.ZodNumber;
                    resistance2: z.ZodNumber;
                    topology: z.ZodEnum<{
                        series: "series";
                        parallel: "parallel";
                    }>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"chemistry-reaction">;
                content: z.ZodObject<{
                    reactants: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        atoms: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            element: z.ZodString;
                        }, z.core.$strict>>;
                        bonds: z.ZodArray<z.ZodObject<{
                            from: z.ZodString;
                            to: z.ZodString;
                            order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    products: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        atoms: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            element: z.ZodString;
                        }, z.core.$strict>>;
                        bonds: z.ZodArray<z.ZodObject<{
                            from: z.ZodString;
                            to: z.ZodString;
                            order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"chemistry-titration">;
                content: z.ZodObject<{
                    acidMl: z.ZodNumber;
                    acidMolarity: z.ZodNumber;
                    baseMolarity: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"biology-mitosis">;
                content: z.ZodObject<{
                    chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"biology-enzyme">;
                content: z.ZodObject<{
                    enzyme: z.ZodString;
                    substrate: z.ZodString;
                    products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"geography-water">;
                content: z.ZodObject<{
                    title: z.ZodString;
                    nodes: z.ZodTuple<[z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>], null>;
                    transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                    stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"history-timeline">;
                content: z.ZodObject<{
                    range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    events: z.ZodTuple<[z.ZodObject<{
                        year: z.ZodNumber;
                        label: z.ZodString;
                        evidence: z.ZodString;
                        approximate: z.ZodOptional<z.ZodBoolean>;
                        kind: z.ZodEnum<{
                            type: "type";
                            block: "block";
                            moon: "moon";
                            telescope: "telescope";
                            event: "event";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        year: z.ZodNumber;
                        label: z.ZodString;
                        evidence: z.ZodString;
                        approximate: z.ZodOptional<z.ZodBoolean>;
                        kind: z.ZodEnum<{
                            type: "type";
                            block: "block";
                            moon: "moon";
                            telescope: "telescope";
                            event: "event";
                        }>;
                    }, z.core.$strict>], null>;
                    caution: z.ZodString;
                    conclusion: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"language-syntax">;
                content: z.ZodObject<{
                    subject: z.ZodString;
                    verb: z.ZodString;
                    object: z.ZodString;
                    question: z.ZodString;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"language-perspective">;
                content: z.ZodObject<{
                    object: z.ZodEnum<{
                        door: "door";
                        book: "book";
                    }>;
                    firstPerson: z.ZodString;
                    observer: z.ZodString;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"cs-sorting">;
                content: z.ZodObject<{
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"cs-recursion">;
                content: z.ZodObject<{
                    operation: z.ZodEnum<{
                        product: "product";
                        sum: "sum";
                    }>;
                    start: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"music-score">;
                content: z.ZodUnion<readonly [z.ZodObject<{
                    id: z.ZodString;
                    title: z.ZodString;
                    groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                    labels: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    tempo: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>, z.ZodObject<{
                    source: z.ZodLiteral<"accepted-v2">;
                    block: z.ZodObject<{
                        type: z.ZodLiteral<"music">;
                        version: z.ZodLiteral<2>;
                        id: z.ZodString;
                        title: z.ZodString;
                        layout: z.ZodEnum<{
                            row: "row";
                            column: "column";
                            grid: "grid";
                        }>;
                        notes: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            pitches: z.ZodArray<z.ZodString>;
                            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                        }, z.core.$strict>>;
                        views: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            kind: z.ZodEnum<{
                                staff: "staff";
                                keyboard: "keyboard";
                            }>;
                            label: z.ZodString;
                            notes: z.ZodArray<z.ZodString>;
                            clef: z.ZodOptional<z.ZodEnum<{
                                treble: "treble";
                                bass: "bass";
                            }>>;
                            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>>;
                        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            kind: z.ZodEnum<{
                                label: "label";
                                link: "link";
                                bracket: "bracket";
                                arrow: "arrow";
                            }>;
                            label: z.ZodString;
                            anchors: z.ZodArray<z.ZodObject<{
                                viewId: z.ZodString;
                                noteId: z.ZodOptional<z.ZodString>;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>>;
                        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            label: z.ZodString;
                            tempo: z.ZodNumber;
                            instrument: z.ZodOptional<z.ZodEnum<{
                                piano: "piano";
                                electric_piano: "electric_piano";
                                guitar: "guitar";
                                violin: "violin";
                                cello: "cello";
                                flute: "flute";
                                marimba: "marimba";
                                organ: "organ";
                            }>>;
                            events: z.ZodArray<z.ZodObject<{
                                notes: z.ZodArray<z.ZodString>;
                                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>;
                    clipId: z.ZodOptional<z.ZodString>;
                    repeat: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>]>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"music-harmony">;
                content: z.ZodUnion<readonly [z.ZodObject<{
                    id: z.ZodString;
                    title: z.ZodString;
                    groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                    labels: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    tempo: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>, z.ZodObject<{
                    source: z.ZodLiteral<"accepted-v2">;
                    block: z.ZodObject<{
                        type: z.ZodLiteral<"music">;
                        version: z.ZodLiteral<2>;
                        id: z.ZodString;
                        title: z.ZodString;
                        layout: z.ZodEnum<{
                            row: "row";
                            column: "column";
                            grid: "grid";
                        }>;
                        notes: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            pitches: z.ZodArray<z.ZodString>;
                            beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                        }, z.core.$strict>>;
                        views: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            kind: z.ZodEnum<{
                                staff: "staff";
                                keyboard: "keyboard";
                            }>;
                            label: z.ZodString;
                            notes: z.ZodArray<z.ZodString>;
                            clef: z.ZodOptional<z.ZodEnum<{
                                treble: "treble";
                                bass: "bass";
                            }>>;
                            range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>>;
                        marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            kind: z.ZodEnum<{
                                label: "label";
                                link: "link";
                                bracket: "bracket";
                                arrow: "arrow";
                            }>;
                            label: z.ZodString;
                            anchors: z.ZodArray<z.ZodObject<{
                                viewId: z.ZodString;
                                noteId: z.ZodOptional<z.ZodString>;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>>;
                        clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            label: z.ZodString;
                            tempo: z.ZodNumber;
                            instrument: z.ZodOptional<z.ZodEnum<{
                                piano: "piano";
                                electric_piano: "electric_piano";
                                guitar: "guitar";
                                violin: "violin";
                                cello: "cello";
                                flute: "flute";
                                marimba: "marimba";
                                organ: "organ";
                            }>>;
                            events: z.ZodArray<z.ZodObject<{
                                notes: z.ZodArray<z.ZodString>;
                                beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>;
                    clipId: z.ZodOptional<z.ZodString>;
                    repeat: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>]>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"economics-equilibrium">;
                content: z.ZodObject<{
                    demandIntercept: z.ZodNumber;
                    supplyIntercept: z.ZodNumber;
                    demandSlope: z.ZodNumber;
                    supplySlope: z.ZodNumber;
                    demandShift: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-timeline">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    events: z.ZodArray<z.ZodObject<{
                        at: z.ZodNumber;
                        label: z.ZodString;
                        detail: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-cycle">;
                content: z.ZodObject<{
                    center: z.ZodString;
                    nodes: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        process: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-decision">;
                content: z.ZodObject<{
                    question: z.ZodString;
                    branches: z.ZodArray<z.ZodObject<{
                        condition: z.ZodString;
                        outcome: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-funnel">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    stages: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-balance">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    left: z.ZodObject<{
                        label: z.ZodString;
                        items: z.ZodArray<z.ZodObject<{
                            label: z.ZodString;
                            value: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>;
                    right: z.ZodObject<{
                        label: z.ZodString;
                        items: z.ZodArray<z.ZodObject<{
                            label: z.ZodString;
                            value: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-matrix">;
                content: z.ZodObject<{
                    columns: z.ZodArray<z.ZodString>;
                    rows: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        values: z.ZodArray<z.ZodNumber>;
                    }, z.core.$strict>>;
                    unit: z.ZodString;
                    max: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-proportion">;
                content: z.ZodObject<{
                    whole: z.ZodString;
                    unit: z.ZodString;
                    parts: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-network">;
                content: z.ZodObject<{
                    nodes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                    links: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-counter">;
                content: z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    from: z.ZodNumber;
                    to: z.ZodNumber;
                    context: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-interval">;
                content: z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    min: z.ZodNumber;
                    max: z.ZodNumber;
                    low: z.ZodNumber;
                    high: z.ZodNumber;
                    points: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-hierarchy">;
                content: z.ZodObject<{
                    root: z.ZodString;
                    groups: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        members: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-ranking">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    before: z.ZodString;
                    after: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        before: z.ZodNumber;
                        after: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>], "templateId">, z.ZodObject<{
                type: z.ZodLiteral<"visual">;
                id: z.ZodOptional<z.ZodString>;
                kind: z.ZodEnum<{
                    process: "process";
                    cycle: "cycle";
                    layers: "layers";
                    bars: "bars";
                }>;
                title: z.ZodString;
                unit: z.ZodOptional<z.ZodString>;
                items: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                    value: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"code">;
                id: z.ZodOptional<z.ZodString>;
                code: z.ZodString;
                language: z.ZodOptional<z.ZodString>;
                parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodOptional<z.ZodString>;
                    text: z.ZodString;
                }, z.core.$strip>>>;
                regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    match: z.ZodString;
                }, z.core.$strip>>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"conversation">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodOptional<z.ZodString>;
                turns: z.ZodArray<z.ZodObject<{
                    speaker: z.ZodString;
                    text: z.ZodString;
                }, z.core.$strip>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"callout">;
                id: z.ZodOptional<z.ZodString>;
                variant: z.ZodEnum<{
                    example: "example";
                    warning: "warning";
                    definition: "definition";
                    tip: "tip";
                }>;
                title: z.ZodOptional<z.ZodString>;
                body: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"accordion">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"illustration">;
                id: z.ZodOptional<z.ZodString>;
                caption: z.ZodString;
                prompt: z.ZodString;
                style: z.ZodEnum<{
                    process: "process";
                    diagram: "diagram";
                    concept: "concept";
                    comparison: "comparison";
                }>;
                aspectRatio: z.ZodOptional<z.ZodEnum<{
                    "1:1": "1:1";
                    "16:9": "16:9";
                    "9:16": "9:16";
                    "4:3": "4:3";
                    "3:4": "3:4";
                    "3:2": "3:2";
                    "2:3": "2:3";
                }>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"svg_slot">;
                id: z.ZodOptional<z.ZodString>;
                intent: z.ZodObject<{
                    visualKind: z.ZodEnum<{
                        simple_structure: "simple_structure";
                        spatial_relationship: "spatial_relationship";
                        state_comparison: "state_comparison";
                        step_derivation: "step_derivation";
                    }>;
                    setup: z.ZodString;
                    learningGoal: z.ZodString;
                    expectedInsight: z.ZodString;
                    composition: z.ZodOptional<z.ZodString>;
                    elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strip>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"compare">;
                id: z.ZodOptional<z.ZodString>;
                left: z.ZodObject<{
                    id: z.ZodOptional<z.ZodString>;
                    label: z.ZodString;
                    points: z.ZodArray<z.ZodString>;
                }, z.core.$strip>;
                right: z.ZodObject<{
                    id: z.ZodOptional<z.ZodString>;
                    label: z.ZodString;
                    points: z.ZodArray<z.ZodString>;
                }, z.core.$strip>;
                sides: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodOptional<z.ZodString>;
                    label: z.ZodString;
                    points: z.ZodArray<z.ZodString>;
                }, z.core.$strip>>>;
            }, z.core.$strip>], "type">>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"heading">;
            level: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
            text: z.ZodString;
            topicId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip> | z.ZodObject<{
            type: z.ZodLiteral<"paragraph">;
            text: z.ZodString;
            cue: z.ZodOptional<z.ZodObject<{
                music: z.ZodOptional<z.ZodObject<{
                    figureId: z.ZodString;
                    clipId: z.ZodString;
                    repeat: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                target: z.ZodString;
                targetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
                op: z.ZodOptional<z.ZodEnum<{
                    highlight: "highlight";
                    window: "window";
                }>>;
                regionIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
                figureId: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"code">;
            id: z.ZodOptional<z.ZodString>;
            code: z.ZodString;
            language: z.ZodOptional<z.ZodString>;
            parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                text: z.ZodString;
            }, z.core.$strip>>>;
            regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                match: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"conversation">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            turns: z.ZodArray<z.ZodObject<{
                speaker: z.ZodString;
                text: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"callout">;
            id: z.ZodOptional<z.ZodString>;
            variant: z.ZodEnum<{
                example: "example";
                warning: "warning";
                definition: "definition";
                tip: "tip";
            }>;
            title: z.ZodOptional<z.ZodString>;
            body: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"accordion">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"illustration">;
            id: z.ZodOptional<z.ZodString>;
            caption: z.ZodString;
            prompt: z.ZodString;
            style: z.ZodEnum<{
                process: "process";
                diagram: "diagram";
                concept: "concept";
                comparison: "comparison";
            }>;
            aspectRatio: z.ZodOptional<z.ZodEnum<{
                "1:1": "1:1";
                "16:9": "16:9";
                "9:16": "9:16";
                "4:3": "4:3";
                "3:4": "3:4";
                "3:2": "3:2";
                "2:3": "2:3";
            }>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"stage">;
            id: z.ZodOptional<z.ZodString>;
            layout: z.ZodEnum<{
                "split-h": "split-h";
                "split-v": "split-v";
                "main+rail": "main+rail";
                stack: "stack";
            }>;
            presentation: z.ZodOptional<z.ZodEnum<{
                compare: "compare";
                steps: "steps";
                focus: "focus";
            }>>;
            figures: z.ZodArray<z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"music">;
                id: z.ZodOptional<z.ZodString>;
                version: z.ZodLiteral<1>;
                title: z.ZodString;
                key: z.ZodLiteral<"C">;
                meter: z.ZodEnum<{
                    "2/4": "2/4";
                    "3/4": "3/4";
                    "4/4": "4/4";
                }>;
                tempo: z.ZodNumber;
                keyboard: z.ZodBoolean;
                notation: z.ZodOptional<z.ZodEnum<{
                    staff: "staff";
                    both: "both";
                    jianpu: "jianpu";
                }>>;
                parts: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    clef: z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    bars: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodObject<{
                            pitches: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                steps: z.ZodArray<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    id: z.ZodString;
                    label: z.ZodString;
                    focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    compare: z.ZodOptional<z.ZodObject<{
                        bars: z.ZodArray<z.ZodNumber>;
                        parts: z.ZodArray<z.ZodString>;
                        instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            part: z.ZodString;
                            instrument: z.ZodEnum<{
                                piano: "piano";
                                electric_piano: "electric_piano";
                                guitar: "guitar";
                                violin: "violin";
                                cello: "cello";
                                flute: "flute";
                                marimba: "marimba";
                                organ: "organ";
                            }>;
                        }, z.core.$strict>>>;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
                templateId: z.ZodLiteral<"general-question">;
                content: z.ZodObject<{
                    objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    glyphs: z.ZodTuple<[z.ZodEnum<{
                        object: "object";
                        question: "question";
                        paper: "paper";
                        boat: "boat";
                        read: "read";
                        recall: "recall";
                    }>, z.ZodEnum<{
                        object: "object";
                        question: "question";
                        paper: "paper";
                        boat: "boat";
                        read: "read";
                        recall: "recall";
                    }>], null>;
                    observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    question: z.ZodString;
                    goal: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-layers">;
                content: z.ZodObject<{
                    layers: z.ZodArray<z.ZodObject<{
                        title: z.ZodString;
                        detail: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-flow">;
                content: z.ZodObject<{
                    nodes: z.ZodArray<z.ZodString>;
                    caption: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-compare">;
                content: z.ZodObject<{
                    names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    metrics: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        unit: z.ZodString;
                        values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                        max: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-summary">;
                content: z.ZodObject<{
                    concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                    center: z.ZodString;
                    transfer: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-pythagoras">;
                content: z.ZodObject<{
                    a: z.ZodNumber;
                    b: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-tangent">;
                content: z.ZodObject<{
                    coefficient: z.ZodNumber;
                    power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    at: z.ZodNumber;
                    startDx: z.ZodNumber;
                    xmax: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-integral">;
                content: z.ZodObject<{
                    coefficient: z.ZodNumber;
                    power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    end: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-probability">;
                content: z.ZodObject<{
                    total: z.ZodNumber;
                    condition: z.ZodNumber;
                    intersection: z.ZodNumber;
                    outsideTarget: z.ZodNumber;
                    conditionName: z.ZodString;
                    targetName: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-forces">;
                content: z.ZodObject<{
                    mass: z.ZodNumber;
                    drive: z.ZodNumber;
                    resistance: z.ZodNumber;
                    duration: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-waves">;
                content: z.ZodObject<{
                    amplitude1: z.ZodNumber;
                    amplitude2: z.ZodNumber;
                    cycles1: z.ZodNumber;
                    cycles2: z.ZodNumber;
                    phase2: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-circuit">;
                content: z.ZodObject<{
                    voltage: z.ZodNumber;
                    resistance1: z.ZodNumber;
                    resistance2: z.ZodNumber;
                    topology: z.ZodEnum<{
                        series: "series";
                        parallel: "parallel";
                    }>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"chemistry-reaction">;
                content: z.ZodObject<{
                    reactants: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        atoms: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            element: z.ZodString;
                        }, z.core.$strict>>;
                        bonds: z.ZodArray<z.ZodObject<{
                            from: z.ZodString;
                            to: z.ZodString;
                            order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    products: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        atoms: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            element: z.ZodString;
                        }, z.core.$strict>>;
                        bonds: z.ZodArray<z.ZodObject<{
                            from: z.ZodString;
                            to: z.ZodString;
                            order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"chemistry-titration">;
                content: z.ZodObject<{
                    acidMl: z.ZodNumber;
                    acidMolarity: z.ZodNumber;
                    baseMolarity: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"biology-mitosis">;
                content: z.ZodObject<{
                    chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"biology-enzyme">;
                content: z.ZodObject<{
                    enzyme: z.ZodString;
                    substrate: z.ZodString;
                    products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"geography-water">;
                content: z.ZodObject<{
                    title: z.ZodString;
                    nodes: z.ZodTuple<[z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>], null>;
                    transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                    stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"history-timeline">;
                content: z.ZodObject<{
                    range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    events: z.ZodTuple<[z.ZodObject<{
                        year: z.ZodNumber;
                        label: z.ZodString;
                        evidence: z.ZodString;
                        approximate: z.ZodOptional<z.ZodBoolean>;
                        kind: z.ZodEnum<{
                            type: "type";
                            block: "block";
                            moon: "moon";
                            telescope: "telescope";
                            event: "event";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        year: z.ZodNumber;
                        label: z.ZodString;
                        evidence: z.ZodString;
                        approximate: z.ZodOptional<z.ZodBoolean>;
                        kind: z.ZodEnum<{
                            type: "type";
                            block: "block";
                            moon: "moon";
                            telescope: "telescope";
                            event: "event";
                        }>;
                    }, z.core.$strict>], null>;
                    caution: z.ZodString;
                    conclusion: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"language-syntax">;
                content: z.ZodObject<{
                    subject: z.ZodString;
                    verb: z.ZodString;
                    object: z.ZodString;
                    question: z.ZodString;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"language-perspective">;
                content: z.ZodObject<{
                    object: z.ZodEnum<{
                        door: "door";
                        book: "book";
                    }>;
                    firstPerson: z.ZodString;
                    observer: z.ZodString;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"cs-sorting">;
                content: z.ZodObject<{
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"cs-recursion">;
                content: z.ZodObject<{
                    operation: z.ZodEnum<{
                        product: "product";
                        sum: "sum";
                    }>;
                    start: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"music-score">;
                content: z.ZodObject<{
                    id: z.ZodString;
                    title: z.ZodString;
                    groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                    labels: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    tempo: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"music-harmony">;
                content: z.ZodObject<{
                    id: z.ZodString;
                    title: z.ZodString;
                    groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                    labels: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    tempo: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"economics-equilibrium">;
                content: z.ZodObject<{
                    demandIntercept: z.ZodNumber;
                    supplyIntercept: z.ZodNumber;
                    demandSlope: z.ZodNumber;
                    supplySlope: z.ZodNumber;
                    demandShift: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-timeline">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    events: z.ZodArray<z.ZodObject<{
                        at: z.ZodNumber;
                        label: z.ZodString;
                        detail: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-cycle">;
                content: z.ZodObject<{
                    center: z.ZodString;
                    nodes: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        process: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-decision">;
                content: z.ZodObject<{
                    question: z.ZodString;
                    branches: z.ZodArray<z.ZodObject<{
                        condition: z.ZodString;
                        outcome: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-funnel">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    stages: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-balance">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    left: z.ZodObject<{
                        label: z.ZodString;
                        items: z.ZodArray<z.ZodObject<{
                            label: z.ZodString;
                            value: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>;
                    right: z.ZodObject<{
                        label: z.ZodString;
                        items: z.ZodArray<z.ZodObject<{
                            label: z.ZodString;
                            value: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-matrix">;
                content: z.ZodObject<{
                    columns: z.ZodArray<z.ZodString>;
                    rows: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        values: z.ZodArray<z.ZodNumber>;
                    }, z.core.$strict>>;
                    unit: z.ZodString;
                    max: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-proportion">;
                content: z.ZodObject<{
                    whole: z.ZodString;
                    unit: z.ZodString;
                    parts: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-network">;
                content: z.ZodObject<{
                    nodes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                    links: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-counter">;
                content: z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    from: z.ZodNumber;
                    to: z.ZodNumber;
                    context: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-interval">;
                content: z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    min: z.ZodNumber;
                    max: z.ZodNumber;
                    low: z.ZodNumber;
                    high: z.ZodNumber;
                    points: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-hierarchy">;
                content: z.ZodObject<{
                    root: z.ZodString;
                    groups: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        members: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-ranking">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    before: z.ZodString;
                    after: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        before: z.ZodNumber;
                        after: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>], "templateId">, z.ZodObject<{
                type: z.ZodLiteral<"visual">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
                kind: z.ZodEnum<{
                    process: "process";
                    cycle: "cycle";
                    layers: "layers";
                }>;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                    id: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"visual">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
                unit: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bars">;
                items: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"code">;
                id: z.ZodOptional<z.ZodString>;
                code: z.ZodString;
                language: z.ZodOptional<z.ZodString>;
                parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodOptional<z.ZodString>;
                    text: z.ZodString;
                }, z.core.$strip>>>;
                regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    match: z.ZodString;
                }, z.core.$strip>>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"conversation">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodOptional<z.ZodString>;
                turns: z.ZodArray<z.ZodObject<{
                    speaker: z.ZodString;
                    text: z.ZodString;
                }, z.core.$strip>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"callout">;
                id: z.ZodOptional<z.ZodString>;
                variant: z.ZodEnum<{
                    example: "example";
                    warning: "warning";
                    definition: "definition";
                    tip: "tip";
                }>;
                title: z.ZodOptional<z.ZodString>;
                body: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"accordion">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"illustration">;
                id: z.ZodOptional<z.ZodString>;
                caption: z.ZodString;
                prompt: z.ZodString;
                style: z.ZodEnum<{
                    process: "process";
                    diagram: "diagram";
                    concept: "concept";
                    comparison: "comparison";
                }>;
                aspectRatio: z.ZodOptional<z.ZodEnum<{
                    "1:1": "1:1";
                    "16:9": "16:9";
                    "9:16": "9:16";
                    "4:3": "4:3";
                    "3:4": "3:4";
                    "3:2": "3:2";
                    "2:3": "2:3";
                }>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"svg_slot">;
                id: z.ZodOptional<z.ZodString>;
                intent: z.ZodObject<{
                    visualKind: z.ZodEnum<{
                        simple_structure: "simple_structure";
                        spatial_relationship: "spatial_relationship";
                        state_comparison: "state_comparison";
                        step_derivation: "step_derivation";
                    }>;
                    setup: z.ZodString;
                    learningGoal: z.ZodString;
                    expectedInsight: z.ZodString;
                    composition: z.ZodOptional<z.ZodString>;
                    elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strip>;
            }, z.core.$strip>]>>;
        }, z.core.$strip>]>, z.ZodUnion<readonly [z.ZodObject<{
            type: z.ZodLiteral<"component_slot">;
            slotRef: z.ZodString;
            intent: z.ZodObject<{
                setup: z.ZodString;
                learningGoal: z.ZodString;
                expectedInsight: z.ZodString;
            }, z.core.$strip>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"component_slot">;
            componentType: z.ZodEnum<{
                chart: "chart";
                math_scene: "math_scene";
                mechanics_sandbox: "mechanics_sandbox";
                circuit_sandbox: "circuit_sandbox";
                chemistry_lab: "chemistry_lab";
            }>;
            intent: z.ZodObject<{
                setup: z.ZodString;
                learningGoal: z.ZodString;
                expectedInsight: z.ZodString;
            }, z.core.$strip>;
        }, z.core.$strip>]>, z.ZodObject<{
            type: z.ZodLiteral<"svg_slot">;
            intent: z.ZodObject<{
                visualKind: z.ZodEnum<{
                    simple_structure: "simple_structure";
                    spatial_relationship: "spatial_relationship";
                    state_comparison: "state_comparison";
                    step_derivation: "step_derivation";
                }>;
                setup: z.ZodString;
                learningGoal: z.ZodString;
                expectedInsight: z.ZodString;
                composition: z.ZodString;
                elements: z.ZodArray<z.ZodString>;
                relationships: z.ZodArray<z.ZodString>;
                labels: z.ZodArray<z.ZodString>;
                avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>;
        }, z.core.$strip>]>>>;
        keyTakeaways: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>;
    parseProviderOutput: (content: string) => {
        introduction: string;
        blocks: ({
            templateId: "general-question";
            content: {
                objects: [string?, string?, ...unknown[]];
                glyphs: [("object" | "question" | "paper" | "boat" | "read" | "recall")?, ("object" | "question" | "paper" | "boat" | "read" | "recall")?, ...unknown[]];
                observations: [string?, string?, ...unknown[]];
                question: string;
                goal: string;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "general-layers";
            content: {
                layers: {
                    title: string;
                    detail: string;
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "general-flow";
            content: {
                nodes: string[];
                caption: string;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "general-compare";
            content: {
                names: [string?, string?, ...unknown[]];
                metrics: {
                    label: string;
                    unit: string;
                    values: [number?, number?, ...unknown[]];
                    max: number;
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "general-summary";
            content: {
                concepts: [string?, string?, string?, ...unknown[]];
                center: string;
                transfer: string;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "math-pythagoras";
            content: {
                a: number;
                b: number;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "math-tangent";
            content: {
                coefficient: number;
                at: number;
                startDx: number;
                xmax: number;
                power?: 2 | 3;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "math-integral";
            content: {
                coefficient: number;
                end: number;
                power?: 1 | 2;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "math-probability";
            content: {
                total: number;
                condition: number;
                intersection: number;
                outsideTarget: number;
                conditionName: string;
                targetName: string;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "physics-forces";
            content: {
                mass: number;
                drive: number;
                resistance: number;
                duration: number;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "physics-waves";
            content: {
                amplitude1: number;
                amplitude2: number;
                cycles1: number;
                cycles2: number;
                phase2: number;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "physics-circuit";
            content: {
                voltage: number;
                resistance1: number;
                resistance2: number;
                topology: "series" | "parallel";
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "chemistry-reaction";
            content: {
                reactants: {
                    label: string;
                    atoms: {
                        id: string;
                        element: string;
                    }[];
                    bonds: {
                        from: string;
                        to: string;
                        order?: 1 | 2 | 3;
                    }[];
                }[];
                products: {
                    label: string;
                    atoms: {
                        id: string;
                        element: string;
                    }[];
                    bonds: {
                        from: string;
                        to: string;
                        order?: 1 | 2 | 3;
                    }[];
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "chemistry-titration";
            content: {
                acidMl: number;
                acidMolarity: number;
                baseMolarity: number;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "biology-mitosis";
            content: {
                chromosomeCount?: 2 | 4;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "biology-enzyme";
            content: {
                enzyme: string;
                substrate: string;
                products: [string?, string?, ...unknown[]];
                note: string;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "geography-water";
            content: {
                title: string;
                nodes: [{
                    label: string;
                    glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                }?, {
                    label: string;
                    glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                }?, {
                    label: string;
                    glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                }?, {
                    label: string;
                    glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                }?, {
                    label: string;
                    glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                }?, ...unknown[]];
                transitions: [string?, string?, string?, string?, string?, ...unknown[]];
                stages: [string?, string?, string?, ...unknown[]];
                note: string;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "history-timeline";
            content: {
                range: [number?, number?, ...unknown[]];
                events: [{
                    year: number;
                    label: string;
                    evidence: string;
                    kind: "type" | "block" | "moon" | "telescope" | "event";
                    approximate?: boolean;
                }?, {
                    year: number;
                    label: string;
                    evidence: string;
                    kind: "type" | "block" | "moon" | "telescope" | "event";
                    approximate?: boolean;
                }?, ...unknown[]];
                caution: string;
                conclusion: string;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "language-syntax";
            content: {
                subject: string;
                verb: string;
                object: string;
                question: string;
                note: string;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "language-perspective";
            content: {
                object: "door" | "book";
                firstPerson: string;
                observer: string;
                note: string;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "cs-sorting";
            content: {
                values: number[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "cs-recursion";
            content: {
                operation: "product" | "sum";
                start: number;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "music-score";
            type: "teaching";
            version: 1;
            id: string;
            title: string;
            content?: {
                source: "accepted-v2";
                block: {
                    type: "music";
                    version: 2;
                    id: string;
                    title: string;
                    layout: "row" | "column" | "grid";
                    notes: {
                        id: string;
                        pitches: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                    views: {
                        id: string;
                        kind: "staff" | "keyboard";
                        label: string;
                        notes: string[];
                        clef?: "treble" | "bass";
                        range?: string[];
                    }[];
                    marks?: {
                        id: string;
                        kind: "label" | "link" | "bracket" | "arrow";
                        label: string;
                        anchors: {
                            viewId: string;
                            noteId?: string;
                        }[];
                    }[];
                    clips?: {
                        id: string;
                        label: string;
                        tempo: number;
                        events: {
                            notes: string[];
                            beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                        }[];
                        instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                    }[];
                };
                clipId?: string;
                repeat?: number;
            } | {
                id: string;
                title: string;
                groups: string[][];
                labels: string[];
                range: [string?, string?, ...unknown[]];
                beats?: 1 | 2;
                tempo?: number;
            };
        } | {
            templateId: "music-harmony";
            type: "teaching";
            version: 1;
            id: string;
            title: string;
            content?: {
                source: "accepted-v2";
                block: {
                    type: "music";
                    version: 2;
                    id: string;
                    title: string;
                    layout: "row" | "column" | "grid";
                    notes: {
                        id: string;
                        pitches: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                    views: {
                        id: string;
                        kind: "staff" | "keyboard";
                        label: string;
                        notes: string[];
                        clef?: "treble" | "bass";
                        range?: string[];
                    }[];
                    marks?: {
                        id: string;
                        kind: "label" | "link" | "bracket" | "arrow";
                        label: string;
                        anchors: {
                            viewId: string;
                            noteId?: string;
                        }[];
                    }[];
                    clips?: {
                        id: string;
                        label: string;
                        tempo: number;
                        events: {
                            notes: string[];
                            beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                        }[];
                        instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                    }[];
                };
                clipId?: string;
                repeat?: number;
            } | {
                id: string;
                title: string;
                groups: string[][];
                labels: string[];
                range: [string?, string?, ...unknown[]];
                beats?: 1 | 2;
                tempo?: number;
            };
        } | {
            templateId: "economics-equilibrium";
            content: {
                demandIntercept: number;
                supplyIntercept: number;
                demandSlope: number;
                supplySlope: number;
                demandShift: number;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-timeline";
            content: {
                unit: string;
                events: {
                    at: number;
                    label: string;
                    detail: string;
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-cycle";
            content: {
                center: string;
                nodes: {
                    label: string;
                    process: string;
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-decision";
            content: {
                question: string;
                branches: {
                    condition: string;
                    outcome: string;
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-funnel";
            content: {
                unit: string;
                stages: {
                    label: string;
                    value: number;
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-balance";
            content: {
                unit: string;
                left: {
                    label: string;
                    items: {
                        label: string;
                        value: number;
                    }[];
                };
                right: {
                    label: string;
                    items: {
                        label: string;
                        value: number;
                    }[];
                };
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-matrix";
            content: {
                columns: string[];
                rows: {
                    label: string;
                    values: number[];
                }[];
                unit: string;
                max: number;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-proportion";
            content: {
                whole: string;
                unit: string;
                parts: {
                    label: string;
                    value: number;
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-network";
            content: {
                nodes: {
                    id: string;
                    label: string;
                }[];
                links: {
                    from: string;
                    to: string;
                    label: string;
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-counter";
            content: {
                label: string;
                unit: string;
                from: number;
                to: number;
                context: string;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-interval";
            content: {
                label: string;
                unit: string;
                min: number;
                max: number;
                low: number;
                high: number;
                points: {
                    label: string;
                    value: number;
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-hierarchy";
            content: {
                root: string;
                groups: {
                    label: string;
                    members: string[];
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "visual-ranking";
            content: {
                unit: string;
                before: string;
                after: string;
                items: {
                    label: string;
                    before: number;
                    after: number;
                }[];
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "music-score";
            content: {
                id: string;
                title: string;
                groups: string[][];
                labels: string[];
                range: [string?, string?, ...unknown[]];
                beats?: 1 | 2;
                tempo?: number;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            templateId: "music-harmony";
            content: {
                id: string;
                title: string;
                groups: string[][];
                labels: string[];
                range: [string?, string?, ...unknown[]];
                beats?: 1 | 2;
                tempo?: number;
            };
            type: "teaching";
            version: 1;
            id: string;
            title: string;
        } | {
            type: "music";
            version: 1;
            title: string;
            key: "C";
            meter: "2/4" | "3/4" | "4/4";
            tempo: number;
            keyboard: boolean;
            parts: {
                id: string;
                label: string;
                clef: "treble" | "bass";
                bars: {
                    notes: {
                        pitches: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                }[];
                instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
            }[];
            steps: {
                bars: number[];
                parts: string[];
                id: string;
                label: string;
                instruments?: {
                    part: string;
                    instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
                focus?: string[];
                compare?: {
                    bars: number[];
                    parts: string[];
                    label: string;
                    instruments?: {
                        part: string;
                        instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                    }[];
                };
            }[];
            id?: string;
            notation?: "staff" | "both" | "jianpu";
        } | {
            type: "music";
            version: 2;
            id: string;
            title: string;
            layout: "row" | "column" | "grid";
            notes: {
                id: string;
                pitches: string[];
                beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
            }[];
            views: {
                id: string;
                kind: "staff" | "keyboard";
                label: string;
                notes: string[];
                clef?: "treble" | "bass";
                range?: string[];
            }[];
            marks?: {
                id: string;
                kind: "label" | "link" | "bracket" | "arrow";
                label: string;
                anchors: {
                    viewId: string;
                    noteId?: string;
                }[];
            }[];
            clips?: {
                id: string;
                label: string;
                tempo: number;
                events: {
                    notes: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
                instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
            }[];
        } | {
            type: "visual";
            kind: "process" | "cycle" | "layers" | "bars";
            title: string;
            items: {
                id: string;
                label: string;
                detail?: string;
                value?: number;
            }[];
            id?: string;
            unit?: string;
        } | {
            type: "code";
            code: string;
            id?: string;
            language?: string;
            parts?: {
                text: string;
                id?: string;
            }[];
            regions?: {
                id: string;
                match: string;
            }[];
        } | {
            type: "conversation";
            turns: {
                speaker: string;
                text: string;
            }[];
            id?: string;
            title?: string;
        } | {
            type: "callout";
            variant: "example" | "warning" | "definition" | "tip";
            body: string;
            id?: string;
            title?: string;
        } | {
            type: "accordion";
            title: string;
            body: string;
            id?: string;
        } | {
            type: "illustration";
            caption: string;
            prompt: string;
            style: "process" | "diagram" | "concept" | "comparison";
            id?: string;
            aspectRatio?: "1:1" | "16:9" | "9:16" | "4:3" | "3:4" | "3:2" | "2:3";
        } | {
            type: "compare";
            left: {
                label: string;
                points: string[];
                id?: string;
            };
            right: {
                label: string;
                points: string[];
                id?: string;
            };
            id?: string;
            sides?: {
                label: string;
                points: string[];
                id?: string;
            }[];
        } | {
            type: "stage";
            layout: "split-h" | "split-v" | "main+rail" | "stack";
            figures: ({
                templateId: "general-question";
                content: {
                    objects: [string?, string?, ...unknown[]];
                    glyphs: [("object" | "question" | "paper" | "boat" | "read" | "recall")?, ("object" | "question" | "paper" | "boat" | "read" | "recall")?, ...unknown[]];
                    observations: [string?, string?, ...unknown[]];
                    question: string;
                    goal: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "general-layers";
                content: {
                    layers: {
                        title: string;
                        detail: string;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "general-flow";
                content: {
                    nodes: string[];
                    caption: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "general-compare";
                content: {
                    names: [string?, string?, ...unknown[]];
                    metrics: {
                        label: string;
                        unit: string;
                        values: [number?, number?, ...unknown[]];
                        max: number;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "general-summary";
                content: {
                    concepts: [string?, string?, string?, ...unknown[]];
                    center: string;
                    transfer: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "math-pythagoras";
                content: {
                    a: number;
                    b: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "math-tangent";
                content: {
                    coefficient: number;
                    at: number;
                    startDx: number;
                    xmax: number;
                    power?: 2 | 3;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "math-integral";
                content: {
                    coefficient: number;
                    end: number;
                    power?: 1 | 2;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "math-probability";
                content: {
                    total: number;
                    condition: number;
                    intersection: number;
                    outsideTarget: number;
                    conditionName: string;
                    targetName: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "physics-forces";
                content: {
                    mass: number;
                    drive: number;
                    resistance: number;
                    duration: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "physics-waves";
                content: {
                    amplitude1: number;
                    amplitude2: number;
                    cycles1: number;
                    cycles2: number;
                    phase2: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "physics-circuit";
                content: {
                    voltage: number;
                    resistance1: number;
                    resistance2: number;
                    topology: "series" | "parallel";
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "chemistry-reaction";
                content: {
                    reactants: {
                        label: string;
                        atoms: {
                            id: string;
                            element: string;
                        }[];
                        bonds: {
                            from: string;
                            to: string;
                            order?: 1 | 2 | 3;
                        }[];
                    }[];
                    products: {
                        label: string;
                        atoms: {
                            id: string;
                            element: string;
                        }[];
                        bonds: {
                            from: string;
                            to: string;
                            order?: 1 | 2 | 3;
                        }[];
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "chemistry-titration";
                content: {
                    acidMl: number;
                    acidMolarity: number;
                    baseMolarity: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "biology-mitosis";
                content: {
                    chromosomeCount?: 2 | 4;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "biology-enzyme";
                content: {
                    enzyme: string;
                    substrate: string;
                    products: [string?, string?, ...unknown[]];
                    note: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "geography-water";
                content: {
                    title: string;
                    nodes: [{
                        label: string;
                        glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                    }?, {
                        label: string;
                        glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                    }?, {
                        label: string;
                        glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                    }?, {
                        label: string;
                        glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                    }?, {
                        label: string;
                        glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                    }?, ...unknown[]];
                    transitions: [string?, string?, string?, string?, string?, ...unknown[]];
                    stages: [string?, string?, string?, ...unknown[]];
                    note: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "history-timeline";
                content: {
                    range: [number?, number?, ...unknown[]];
                    events: [{
                        year: number;
                        label: string;
                        evidence: string;
                        kind: "type" | "block" | "moon" | "telescope" | "event";
                        approximate?: boolean;
                    }?, {
                        year: number;
                        label: string;
                        evidence: string;
                        kind: "type" | "block" | "moon" | "telescope" | "event";
                        approximate?: boolean;
                    }?, ...unknown[]];
                    caution: string;
                    conclusion: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "language-syntax";
                content: {
                    subject: string;
                    verb: string;
                    object: string;
                    question: string;
                    note: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "language-perspective";
                content: {
                    object: "door" | "book";
                    firstPerson: string;
                    observer: string;
                    note: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "cs-sorting";
                content: {
                    values: number[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "cs-recursion";
                content: {
                    operation: "product" | "sum";
                    start: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "music-score";
                type: "teaching";
                version: 1;
                id: string;
                title: string;
                content?: {
                    source: "accepted-v2";
                    block: {
                        type: "music";
                        version: 2;
                        id: string;
                        title: string;
                        layout: "row" | "column" | "grid";
                        notes: {
                            id: string;
                            pitches: string[];
                            beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                        }[];
                        views: {
                            id: string;
                            kind: "staff" | "keyboard";
                            label: string;
                            notes: string[];
                            clef?: "treble" | "bass";
                            range?: string[];
                        }[];
                        marks?: {
                            id: string;
                            kind: "label" | "link" | "bracket" | "arrow";
                            label: string;
                            anchors: {
                                viewId: string;
                                noteId?: string;
                            }[];
                        }[];
                        clips?: {
                            id: string;
                            label: string;
                            tempo: number;
                            events: {
                                notes: string[];
                                beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                            }[];
                            instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                        }[];
                    };
                    clipId?: string;
                    repeat?: number;
                } | {
                    id: string;
                    title: string;
                    groups: string[][];
                    labels: string[];
                    range: [string?, string?, ...unknown[]];
                    beats?: 1 | 2;
                    tempo?: number;
                };
            } | {
                templateId: "music-harmony";
                type: "teaching";
                version: 1;
                id: string;
                title: string;
                content?: {
                    source: "accepted-v2";
                    block: {
                        type: "music";
                        version: 2;
                        id: string;
                        title: string;
                        layout: "row" | "column" | "grid";
                        notes: {
                            id: string;
                            pitches: string[];
                            beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                        }[];
                        views: {
                            id: string;
                            kind: "staff" | "keyboard";
                            label: string;
                            notes: string[];
                            clef?: "treble" | "bass";
                            range?: string[];
                        }[];
                        marks?: {
                            id: string;
                            kind: "label" | "link" | "bracket" | "arrow";
                            label: string;
                            anchors: {
                                viewId: string;
                                noteId?: string;
                            }[];
                        }[];
                        clips?: {
                            id: string;
                            label: string;
                            tempo: number;
                            events: {
                                notes: string[];
                                beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                            }[];
                            instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                        }[];
                    };
                    clipId?: string;
                    repeat?: number;
                } | {
                    id: string;
                    title: string;
                    groups: string[][];
                    labels: string[];
                    range: [string?, string?, ...unknown[]];
                    beats?: 1 | 2;
                    tempo?: number;
                };
            } | {
                templateId: "economics-equilibrium";
                content: {
                    demandIntercept: number;
                    supplyIntercept: number;
                    demandSlope: number;
                    supplySlope: number;
                    demandShift: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-timeline";
                content: {
                    unit: string;
                    events: {
                        at: number;
                        label: string;
                        detail: string;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-cycle";
                content: {
                    center: string;
                    nodes: {
                        label: string;
                        process: string;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-decision";
                content: {
                    question: string;
                    branches: {
                        condition: string;
                        outcome: string;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-funnel";
                content: {
                    unit: string;
                    stages: {
                        label: string;
                        value: number;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-balance";
                content: {
                    unit: string;
                    left: {
                        label: string;
                        items: {
                            label: string;
                            value: number;
                        }[];
                    };
                    right: {
                        label: string;
                        items: {
                            label: string;
                            value: number;
                        }[];
                    };
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-matrix";
                content: {
                    columns: string[];
                    rows: {
                        label: string;
                        values: number[];
                    }[];
                    unit: string;
                    max: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-proportion";
                content: {
                    whole: string;
                    unit: string;
                    parts: {
                        label: string;
                        value: number;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-network";
                content: {
                    nodes: {
                        id: string;
                        label: string;
                    }[];
                    links: {
                        from: string;
                        to: string;
                        label: string;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-counter";
                content: {
                    label: string;
                    unit: string;
                    from: number;
                    to: number;
                    context: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-interval";
                content: {
                    label: string;
                    unit: string;
                    min: number;
                    max: number;
                    low: number;
                    high: number;
                    points: {
                        label: string;
                        value: number;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-hierarchy";
                content: {
                    root: string;
                    groups: {
                        label: string;
                        members: string[];
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-ranking";
                content: {
                    unit: string;
                    before: string;
                    after: string;
                    items: {
                        label: string;
                        before: number;
                        after: number;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                type: "music";
                version: 1;
                title: string;
                key: "C";
                meter: "2/4" | "3/4" | "4/4";
                tempo: number;
                keyboard: boolean;
                parts: {
                    id: string;
                    label: string;
                    clef: "treble" | "bass";
                    bars: {
                        notes: {
                            pitches: string[];
                            beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                        }[];
                    }[];
                    instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
                steps: {
                    bars: number[];
                    parts: string[];
                    id: string;
                    label: string;
                    instruments?: {
                        part: string;
                        instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                    }[];
                    focus?: string[];
                    compare?: {
                        bars: number[];
                        parts: string[];
                        label: string;
                        instruments?: {
                            part: string;
                            instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                        }[];
                    };
                }[];
                id?: string;
                notation?: "staff" | "both" | "jianpu";
            } | {
                type: "music";
                version: 2;
                id: string;
                title: string;
                layout: "row" | "column" | "grid";
                notes: {
                    id: string;
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
                views: {
                    id: string;
                    kind: "staff" | "keyboard";
                    label: string;
                    notes: string[];
                    clef?: "treble" | "bass";
                    range?: string[];
                }[];
                marks?: {
                    id: string;
                    kind: "label" | "link" | "bracket" | "arrow";
                    label: string;
                    anchors: {
                        viewId: string;
                        noteId?: string;
                    }[];
                }[];
                clips?: {
                    id: string;
                    label: string;
                    tempo: number;
                    events: {
                        notes: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                    instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            } | {
                type: "visual";
                kind: "process" | "cycle" | "layers" | "bars";
                title: string;
                items: {
                    id: string;
                    label: string;
                    detail?: string;
                    value?: number;
                }[];
                id?: string;
                unit?: string;
            } | {
                type: "code";
                code: string;
                id?: string;
                language?: string;
                parts?: {
                    text: string;
                    id?: string;
                }[];
                regions?: {
                    id: string;
                    match: string;
                }[];
            } | {
                type: "conversation";
                turns: {
                    speaker: string;
                    text: string;
                }[];
                id?: string;
                title?: string;
            } | {
                type: "callout";
                variant: "example" | "warning" | "definition" | "tip";
                body: string;
                id?: string;
                title?: string;
            } | {
                type: "accordion";
                title: string;
                body: string;
                id?: string;
            } | {
                type: "illustration";
                caption: string;
                prompt: string;
                style: "process" | "diagram" | "concept" | "comparison";
                id?: string;
                aspectRatio?: "1:1" | "16:9" | "9:16" | "4:3" | "3:4" | "3:2" | "2:3";
            } | {
                type: "svg_slot";
                intent: {
                    visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
                    setup: string;
                    learningGoal: string;
                    expectedInsight: string;
                    composition?: string;
                    elements?: string[];
                    relationships?: string[];
                    labels?: string[];
                    avoid?: string[];
                };
                id?: string;
            } | {
                type: "compare";
                left: {
                    label: string;
                    points: string[];
                    id?: string;
                };
                right: {
                    label: string;
                    points: string[];
                    id?: string;
                };
                id?: string;
                sides?: {
                    label: string;
                    points: string[];
                    id?: string;
                }[];
            })[];
            id?: string;
            presentation?: "compare" | "steps" | "focus";
        } | {
            type: "visual";
            title: string;
            kind: "process" | "cycle" | "layers";
            items: {
                label: string;
                id: string;
                detail?: string;
            }[];
            id?: string;
        } | {
            type: "visual";
            title: string;
            kind: "bars";
            items: {
                id: string;
                label: string;
                value: number;
                detail?: string;
            }[];
            id?: string;
            unit?: string;
        } | {
            type: "heading";
            text: string;
            level?: 2 | 3;
            topicId?: string;
        } | {
            type: "paragraph";
            text: string;
            cue?: {
                target: string;
                music?: {
                    figureId: string;
                    clipId: string;
                    repeat?: number;
                };
                targetIds?: string[];
                op?: "highlight" | "window";
                regionIds?: string[];
                figureId?: string;
            };
        } | {
            type: "stage";
            layout: "split-h" | "split-v" | "main+rail" | "stack";
            figures: ({
                templateId: "general-question";
                content: {
                    objects: [string?, string?, ...unknown[]];
                    glyphs: [("object" | "question" | "paper" | "boat" | "read" | "recall")?, ("object" | "question" | "paper" | "boat" | "read" | "recall")?, ...unknown[]];
                    observations: [string?, string?, ...unknown[]];
                    question: string;
                    goal: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "general-layers";
                content: {
                    layers: {
                        title: string;
                        detail: string;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "general-flow";
                content: {
                    nodes: string[];
                    caption: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "general-compare";
                content: {
                    names: [string?, string?, ...unknown[]];
                    metrics: {
                        label: string;
                        unit: string;
                        values: [number?, number?, ...unknown[]];
                        max: number;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "general-summary";
                content: {
                    concepts: [string?, string?, string?, ...unknown[]];
                    center: string;
                    transfer: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "math-pythagoras";
                content: {
                    a: number;
                    b: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "math-tangent";
                content: {
                    coefficient: number;
                    at: number;
                    startDx: number;
                    xmax: number;
                    power?: 2 | 3;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "math-integral";
                content: {
                    coefficient: number;
                    end: number;
                    power?: 1 | 2;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "math-probability";
                content: {
                    total: number;
                    condition: number;
                    intersection: number;
                    outsideTarget: number;
                    conditionName: string;
                    targetName: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "physics-forces";
                content: {
                    mass: number;
                    drive: number;
                    resistance: number;
                    duration: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "physics-waves";
                content: {
                    amplitude1: number;
                    amplitude2: number;
                    cycles1: number;
                    cycles2: number;
                    phase2: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "physics-circuit";
                content: {
                    voltage: number;
                    resistance1: number;
                    resistance2: number;
                    topology: "series" | "parallel";
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "chemistry-reaction";
                content: {
                    reactants: {
                        label: string;
                        atoms: {
                            id: string;
                            element: string;
                        }[];
                        bonds: {
                            from: string;
                            to: string;
                            order?: 1 | 2 | 3;
                        }[];
                    }[];
                    products: {
                        label: string;
                        atoms: {
                            id: string;
                            element: string;
                        }[];
                        bonds: {
                            from: string;
                            to: string;
                            order?: 1 | 2 | 3;
                        }[];
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "chemistry-titration";
                content: {
                    acidMl: number;
                    acidMolarity: number;
                    baseMolarity: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "biology-mitosis";
                content: {
                    chromosomeCount?: 2 | 4;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "biology-enzyme";
                content: {
                    enzyme: string;
                    substrate: string;
                    products: [string?, string?, ...unknown[]];
                    note: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "geography-water";
                content: {
                    title: string;
                    nodes: [{
                        label: string;
                        glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                    }?, {
                        label: string;
                        glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                    }?, {
                        label: string;
                        glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                    }?, {
                        label: string;
                        glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                    }?, {
                        label: string;
                        glyph: "water" | "vapor" | "cloud" | "drop" | "magma" | "rock" | "sediment" | "strata";
                    }?, ...unknown[]];
                    transitions: [string?, string?, string?, string?, string?, ...unknown[]];
                    stages: [string?, string?, string?, ...unknown[]];
                    note: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "history-timeline";
                content: {
                    range: [number?, number?, ...unknown[]];
                    events: [{
                        year: number;
                        label: string;
                        evidence: string;
                        kind: "type" | "block" | "moon" | "telescope" | "event";
                        approximate?: boolean;
                    }?, {
                        year: number;
                        label: string;
                        evidence: string;
                        kind: "type" | "block" | "moon" | "telescope" | "event";
                        approximate?: boolean;
                    }?, ...unknown[]];
                    caution: string;
                    conclusion: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "language-syntax";
                content: {
                    subject: string;
                    verb: string;
                    object: string;
                    question: string;
                    note: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "language-perspective";
                content: {
                    object: "door" | "book";
                    firstPerson: string;
                    observer: string;
                    note: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "cs-sorting";
                content: {
                    values: number[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "cs-recursion";
                content: {
                    operation: "product" | "sum";
                    start: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "economics-equilibrium";
                content: {
                    demandIntercept: number;
                    supplyIntercept: number;
                    demandSlope: number;
                    supplySlope: number;
                    demandShift: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-timeline";
                content: {
                    unit: string;
                    events: {
                        at: number;
                        label: string;
                        detail: string;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-cycle";
                content: {
                    center: string;
                    nodes: {
                        label: string;
                        process: string;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-decision";
                content: {
                    question: string;
                    branches: {
                        condition: string;
                        outcome: string;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-funnel";
                content: {
                    unit: string;
                    stages: {
                        label: string;
                        value: number;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-balance";
                content: {
                    unit: string;
                    left: {
                        label: string;
                        items: {
                            label: string;
                            value: number;
                        }[];
                    };
                    right: {
                        label: string;
                        items: {
                            label: string;
                            value: number;
                        }[];
                    };
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-matrix";
                content: {
                    columns: string[];
                    rows: {
                        label: string;
                        values: number[];
                    }[];
                    unit: string;
                    max: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-proportion";
                content: {
                    whole: string;
                    unit: string;
                    parts: {
                        label: string;
                        value: number;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-network";
                content: {
                    nodes: {
                        id: string;
                        label: string;
                    }[];
                    links: {
                        from: string;
                        to: string;
                        label: string;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-counter";
                content: {
                    label: string;
                    unit: string;
                    from: number;
                    to: number;
                    context: string;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-interval";
                content: {
                    label: string;
                    unit: string;
                    min: number;
                    max: number;
                    low: number;
                    high: number;
                    points: {
                        label: string;
                        value: number;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-hierarchy";
                content: {
                    root: string;
                    groups: {
                        label: string;
                        members: string[];
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "visual-ranking";
                content: {
                    unit: string;
                    before: string;
                    after: string;
                    items: {
                        label: string;
                        before: number;
                        after: number;
                    }[];
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "music-score";
                content: {
                    id: string;
                    title: string;
                    groups: string[][];
                    labels: string[];
                    range: [string?, string?, ...unknown[]];
                    beats?: 1 | 2;
                    tempo?: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                templateId: "music-harmony";
                content: {
                    id: string;
                    title: string;
                    groups: string[][];
                    labels: string[];
                    range: [string?, string?, ...unknown[]];
                    beats?: 1 | 2;
                    tempo?: number;
                };
                type: "teaching";
                version: 1;
                id: string;
                title: string;
            } | {
                type: "music";
                version: 1;
                title: string;
                key: "C";
                meter: "2/4" | "3/4" | "4/4";
                tempo: number;
                keyboard: boolean;
                parts: {
                    id: string;
                    label: string;
                    clef: "treble" | "bass";
                    bars: {
                        notes: {
                            pitches: string[];
                            beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                        }[];
                    }[];
                    instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
                steps: {
                    bars: number[];
                    parts: string[];
                    id: string;
                    label: string;
                    instruments?: {
                        part: string;
                        instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                    }[];
                    focus?: string[];
                    compare?: {
                        bars: number[];
                        parts: string[];
                        label: string;
                        instruments?: {
                            part: string;
                            instrument: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                        }[];
                    };
                }[];
                id?: string;
                notation?: "staff" | "both" | "jianpu";
            } | {
                type: "music";
                version: 2;
                id: string;
                title: string;
                layout: "row" | "column" | "grid";
                notes: {
                    id: string;
                    pitches: string[];
                    beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                }[];
                views: {
                    id: string;
                    kind: "staff" | "keyboard";
                    label: string;
                    notes: string[];
                    clef?: "treble" | "bass";
                    range?: string[];
                }[];
                marks?: {
                    id: string;
                    kind: "label" | "link" | "bracket" | "arrow";
                    label: string;
                    anchors: {
                        viewId: string;
                        noteId?: string;
                    }[];
                }[];
                clips?: {
                    id: string;
                    label: string;
                    tempo: number;
                    events: {
                        notes: string[];
                        beats?: 0.25 | 0.5 | 0.75 | 1 | 1.5 | 2 | 3 | 4;
                    }[];
                    instrument?: "piano" | "electric_piano" | "guitar" | "violin" | "cello" | "flute" | "marimba" | "organ";
                }[];
            } | {
                type: "code";
                code: string;
                id?: string;
                language?: string;
                parts?: {
                    text: string;
                    id?: string;
                }[];
                regions?: {
                    id: string;
                    match: string;
                }[];
            } | {
                type: "conversation";
                turns: {
                    speaker: string;
                    text: string;
                }[];
                id?: string;
                title?: string;
            } | {
                type: "callout";
                variant: "example" | "warning" | "definition" | "tip";
                body: string;
                id?: string;
                title?: string;
            } | {
                type: "accordion";
                title: string;
                body: string;
                id?: string;
            } | {
                type: "illustration";
                caption: string;
                prompt: string;
                style: "process" | "diagram" | "concept" | "comparison";
                id?: string;
                aspectRatio?: "1:1" | "16:9" | "9:16" | "4:3" | "3:4" | "3:2" | "2:3";
            } | {
                type: "svg_slot";
                intent: {
                    visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
                    setup: string;
                    learningGoal: string;
                    expectedInsight: string;
                    composition?: string;
                    elements?: string[];
                    relationships?: string[];
                    labels?: string[];
                    avoid?: string[];
                };
                id?: string;
            } | {
                type: "visual";
                title: string;
                kind: "process" | "cycle" | "layers";
                items: {
                    label: string;
                    id: string;
                    detail?: string;
                }[];
                id?: string;
            } | {
                type: "visual";
                title: string;
                kind: "bars";
                items: {
                    id: string;
                    label: string;
                    value: number;
                    detail?: string;
                }[];
                id?: string;
                unit?: string;
            })[];
            id?: string;
            presentation?: "compare" | "steps" | "focus";
        } | {
            type: "component_slot";
            slotRef: string;
            intent: {
                setup: string;
                learningGoal: string;
                expectedInsight: string;
            };
        } | {
            type: "component_slot";
            componentType: "chart" | "math_scene" | "mechanics_sandbox" | "circuit_sandbox" | "chemistry_lab";
            intent: {
                setup: string;
                learningGoal: string;
                expectedInsight: string;
            };
        } | {
            type: "svg_slot";
            intent: {
                visualKind: "simple_structure" | "spatial_relationship" | "state_comparison" | "step_derivation";
                setup: string;
                learningGoal: string;
                expectedInsight: string;
                composition: string;
                elements: string[];
                relationships: string[];
                labels: string[];
                avoid?: string[];
            };
        })[];
        keyTakeaways: string[];
    };
};
export type SectionMaterialAuthoringResult = z.infer<ReturnType<typeof createSectionMaterialEnvelopeSchema>>;
export declare function hasUnresolvedSectionMaterialIntents(material: SectionMaterialAuthoringResult): boolean;
