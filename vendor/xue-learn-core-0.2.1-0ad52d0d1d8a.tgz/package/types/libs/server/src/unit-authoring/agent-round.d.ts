import { type BaseMessage } from "@langchain/core/messages";
import { z } from "zod";
import { recoverValidatedStreamedToolArgs } from "../agents/core/streamed-tool-args.js";
import type { LlmMessageRecord } from "../agents/core/types.js";
export declare const UNIT_AUTHORING_OPERATION = "unit.authoring_agent";
/**
 * Some OpenAI-compatible gateways do not reliably reject an in-flight stream
 * when the caller aborts. Keep the authoring request and its log bounded even
 * when the provider's AsyncIterable ignores the signal.
 */
export declare function consumeAbortableAuthoringStream<T>(streamPromise: Promise<AsyncIterable<T>>, signal: AbortSignal | undefined, onChunk: (chunk: T) => void | Promise<void>): Promise<void>;
/**
 * Capability-composed policy and durable learner/unit context are instructions,
 * not learner-authored stage input. Keep them in the system role for the whole
 * durable unit-authoring conversation.
 */
export declare function splitUnitAuthoringBootstrapPrompt(prompt: string): {
    systemPrompt?: string;
    userPrompt: string;
};
/**
 * A durable authoring transcript already contains prior context and accepted
 * artifacts. Do not pay for or weaken attention with exact lines repeated by
 * stateless legacy prompt builders; append only the new stage delta.
 */
export declare function compactUnitAuthoringStagePrompt(prompt: string, transcript: readonly LlmMessageRecord[]): string;
export declare const unitAuthoringCornellCommitBindingSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            note: "note";
            summary: "summary";
            cue: "cue";
        }>;
        text: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const unitAuthoringKeyPointsCommitBindingSchema: z.ZodObject<{
    points: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export declare const unitAuthoringFlashcardsCommitBindingSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        front: z.ZodString;
        back: z.ZodString;
        learningTargetIds: z.ZodArray<z.ZodString>;
        anchor: z.ZodOptional<z.ZodObject<{
            scope: z.ZodEnum<{
                block: "block";
                introduction: "introduction";
                key_takeaway: "key_takeaway";
                cornell_cue: "cornell_cue";
            }>;
            sectionId: z.ZodOptional<z.ZodString>;
            blockIndex: z.ZodOptional<z.ZodNumber>;
            takeawayIndex: z.ZodOptional<z.ZodNumber>;
            blockKey: z.ZodOptional<z.ZodString>;
            blockType: z.ZodOptional<z.ZodString>;
            subPath: z.ZodOptional<z.ZodString>;
            selectedText: z.ZodOptional<z.ZodString>;
            textRange: z.ZodOptional<z.ZodObject<{
                start: z.ZodNumber;
                end: z.ZodNumber;
            }, z.core.$strip>>;
            wrongOptionIndex: z.ZodOptional<z.ZodNumber>;
            highlightKey: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        sourceExcerpt: z.ZodDefault<z.ZodString>;
        tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const unitAuthoringQuizCommitBindingSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodType<import("../quiz/authoring.js").QuizQuestion, unknown, z.core.$ZodTypeInternals<import("../quiz/authoring.js").QuizQuestion, unknown>>>;
}, z.core.$strip>;
export declare const unitAuthoringToolCatalog: readonly [{
    readonly name: "commit_component_selection";
    readonly description: "Commit the component-category palette that constrains Survey and lesson authoring.";
    readonly schema: z.ZodObject<{
        mainCategory: z.ZodEnum<{
            chemistry_lab: "chemistry_lab";
            base: "base";
            math_visualization: "math_visualization";
            data_visualization: "data_visualization";
            mechanics_lab: "mechanics_lab";
            circuit_lab: "circuit_lab";
        }>;
        enabledCategories: z.ZodPipe<z.ZodArray<z.ZodEnum<{
            chemistry_lab: "chemistry_lab";
            base: "base";
            math_visualization: "math_visualization";
            data_visualization: "data_visualization";
            mechanics_lab: "mechanics_lab";
            circuit_lab: "circuit_lab";
        }>>, z.ZodTransform<("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[], ("chemistry_lab" | "base" | "math_visualization" | "data_visualization" | "mechanics_lab" | "circuit_lab")[]>>;
        rationale: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
}, {
    readonly name: "commit_survey";
    readonly description: "Commit the complete validated Survey outline and guiding questions.";
    readonly schema: z.ZodObject<{
        items: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                question: "question";
                outline: "outline";
            }>;
            text: z.ZodString;
            scope: z.ZodOptional<z.ZodString>;
            learningTargetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
            checkpointAfter: z.ZodOptional<z.ZodBoolean>;
            contentKind: z.ZodOptional<z.ZodEnum<{
                standard: "standard";
                formal_derivation: "formal_derivation";
            }>>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
}, {
    readonly name: "commit_section_plan";
    readonly description: "Commit the complete grouping of the frozen Survey outline into teaching sections.";
    readonly schema: z.ZodObject<{
        sections: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            scope: z.ZodString;
            outlineIndexes: z.ZodArray<z.ZodNumber>;
            contentKind: z.ZodOptional<z.ZodEnum<{
                standard: "standard";
                formal_derivation: "formal_derivation";
            }>>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
}, {
    readonly name: "commit_section_topics";
    readonly description: "Commit the optional introduction and ordered small-topic titles for the current section. Call this before commit_topic_material.";
    readonly schema: z.ZodPreprocess<z.ZodObject<{
        introduction: z.ZodOptional<z.ZodObject<{
            text: z.ZodString;
        }, z.core.$strip>>;
        topics: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, {
    readonly name: "commit_topic_material";
    readonly description: "Commit one topic: a single display plus as many lecture-style spoken cues as needed to teach the board clearly (explain every subview and their relationship). Learner-facing copy must stay in the goal content language; do not switch to English because this schema is English. Repair only this topic; do not rewrite earlier accepted topics.";
    readonly schema: z.ZodObject<{
        topicId: z.ZodString;
        display: z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"music">;
            id: z.ZodOptional<z.ZodString>;
            version: z.ZodLiteral<1>;
            title: z.ZodString;
            key: z.ZodLiteral<"C">;
            meter: z.ZodEnum<{
                "2/4": "2/4";
                "3/4": "3/4";
                "4/4": "4/4";
            }>;
            tempo: z.ZodNumber;
            keyboard: z.ZodBoolean;
            notation: z.ZodOptional<z.ZodEnum<{
                staff: "staff";
                both: "both";
                jianpu: "jianpu";
            }>>;
            parts: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                clef: z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                bars: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodObject<{
                        pitches: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            steps: z.ZodArray<z.ZodObject<{
                bars: z.ZodArray<z.ZodNumber>;
                parts: z.ZodArray<z.ZodString>;
                instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    part: z.ZodString;
                    instrument: z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>;
                }, z.core.$strict>>>;
                id: z.ZodString;
                label: z.ZodString;
                focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                compare: z.ZodOptional<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"music">;
            version: z.ZodLiteral<2>;
            id: z.ZodString;
            title: z.ZodString;
            layout: z.ZodEnum<{
                row: "row";
                column: "column";
                grid: "grid";
            }>;
            notes: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                pitches: z.ZodArray<z.ZodString>;
                beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
            }, z.core.$strict>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    staff: "staff";
                    keyboard: "keyboard";
                }>;
                label: z.ZodString;
                notes: z.ZodArray<z.ZodString>;
                clef: z.ZodOptional<z.ZodEnum<{
                    treble: "treble";
                    bass: "bass";
                }>>;
                range: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    label: "label";
                    link: "link";
                    bracket: "bracket";
                    arrow: "arrow";
                }>;
                label: z.ZodString;
                anchors: z.ZodArray<z.ZodObject<{
                    viewId: z.ZodString;
                    noteId: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
            clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                tempo: z.ZodNumber;
                instrument: z.ZodOptional<z.ZodEnum<{
                    piano: "piano";
                    electric_piano: "electric_piano";
                    guitar: "guitar";
                    violin: "violin";
                    cello: "cello";
                    flute: "flute";
                    marimba: "marimba";
                    organ: "organ";
                }>>;
                events: z.ZodArray<z.ZodObject<{
                    notes: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
            templateId: z.ZodLiteral<"general-question">;
            content: z.ZodObject<{
                objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                glyphs: z.ZodTuple<[z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>, z.ZodEnum<{
                    object: "object";
                    question: "question";
                    paper: "paper";
                    boat: "boat";
                    read: "read";
                    recall: "recall";
                }>], null>;
                observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                question: z.ZodString;
                goal: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-layers">;
            content: z.ZodObject<{
                layers: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-flow">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodString>;
                caption: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-compare">;
            content: z.ZodObject<{
                names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                metrics: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    max: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"general-summary">;
            content: z.ZodObject<{
                concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                center: z.ZodString;
                transfer: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-pythagoras">;
            content: z.ZodObject<{
                a: z.ZodNumber;
                b: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-tangent">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                at: z.ZodNumber;
                startDx: z.ZodNumber;
                xmax: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-integral">;
            content: z.ZodObject<{
                coefficient: z.ZodNumber;
                power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                end: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"math-probability">;
            content: z.ZodObject<{
                total: z.ZodNumber;
                condition: z.ZodNumber;
                intersection: z.ZodNumber;
                outsideTarget: z.ZodNumber;
                conditionName: z.ZodString;
                targetName: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-forces">;
            content: z.ZodObject<{
                mass: z.ZodNumber;
                drive: z.ZodNumber;
                resistance: z.ZodNumber;
                duration: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-waves">;
            content: z.ZodObject<{
                amplitude1: z.ZodNumber;
                amplitude2: z.ZodNumber;
                cycles1: z.ZodNumber;
                cycles2: z.ZodNumber;
                phase2: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"physics-circuit">;
            content: z.ZodObject<{
                voltage: z.ZodNumber;
                resistance1: z.ZodNumber;
                resistance2: z.ZodNumber;
                topology: z.ZodEnum<{
                    series: "series";
                    parallel: "parallel";
                }>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-reaction">;
            content: z.ZodObject<{
                reactants: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                products: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    atoms: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        element: z.ZodString;
                    }, z.core.$strict>>;
                    bonds: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"chemistry-titration">;
            content: z.ZodObject<{
                acidMl: z.ZodNumber;
                acidMolarity: z.ZodNumber;
                baseMolarity: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-mitosis">;
            content: z.ZodObject<{
                chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"biology-enzyme">;
            content: z.ZodObject<{
                enzyme: z.ZodString;
                substrate: z.ZodString;
                products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"geography-water">;
            content: z.ZodObject<{
                title: z.ZodString;
                nodes: z.ZodTuple<[z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    label: z.ZodString;
                    glyph: z.ZodEnum<{
                        water: "water";
                        vapor: "vapor";
                        cloud: "cloud";
                        drop: "drop";
                        magma: "magma";
                        rock: "rock";
                        sediment: "sediment";
                        strata: "strata";
                    }>;
                }, z.core.$strict>], null>;
                transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"history-timeline">;
            content: z.ZodObject<{
                range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                events: z.ZodTuple<[z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    year: z.ZodNumber;
                    label: z.ZodString;
                    evidence: z.ZodString;
                    approximate: z.ZodOptional<z.ZodBoolean>;
                    kind: z.ZodEnum<{
                        type: "type";
                        block: "block";
                        moon: "moon";
                        telescope: "telescope";
                        event: "event";
                    }>;
                }, z.core.$strict>], null>;
                caution: z.ZodString;
                conclusion: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-syntax">;
            content: z.ZodObject<{
                subject: z.ZodString;
                verb: z.ZodString;
                object: z.ZodString;
                question: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"language-perspective">;
            content: z.ZodObject<{
                object: z.ZodEnum<{
                    door: "door";
                    book: "book";
                }>;
                firstPerson: z.ZodString;
                observer: z.ZodString;
                note: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-sorting">;
            content: z.ZodObject<{
                values: z.ZodArray<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"cs-recursion">;
            content: z.ZodObject<{
                operation: z.ZodEnum<{
                    product: "product";
                    sum: "sum";
                }>;
                start: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-score">;
            content: z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"music-harmony">;
            content: z.ZodObject<{
                id: z.ZodString;
                title: z.ZodString;
                groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                labels: z.ZodArray<z.ZodString>;
                beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                tempo: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"economics-equilibrium">;
            content: z.ZodObject<{
                demandIntercept: z.ZodNumber;
                supplyIntercept: z.ZodNumber;
                demandSlope: z.ZodNumber;
                supplySlope: z.ZodNumber;
                demandShift: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-timeline">;
            content: z.ZodObject<{
                unit: z.ZodString;
                events: z.ZodArray<z.ZodObject<{
                    at: z.ZodNumber;
                    label: z.ZodString;
                    detail: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-cycle">;
            content: z.ZodObject<{
                center: z.ZodString;
                nodes: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    process: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-decision">;
            content: z.ZodObject<{
                question: z.ZodString;
                branches: z.ZodArray<z.ZodObject<{
                    condition: z.ZodString;
                    outcome: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-funnel">;
            content: z.ZodObject<{
                unit: z.ZodString;
                stages: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-balance">;
            content: z.ZodObject<{
                unit: z.ZodString;
                left: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                right: z.ZodObject<{
                    label: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-matrix">;
            content: z.ZodObject<{
                columns: z.ZodArray<z.ZodString>;
                rows: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>>;
                unit: z.ZodString;
                max: z.ZodNumber;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-proportion">;
            content: z.ZodObject<{
                whole: z.ZodString;
                unit: z.ZodString;
                parts: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-network">;
            content: z.ZodObject<{
                nodes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
                links: z.ZodArray<z.ZodObject<{
                    from: z.ZodString;
                    to: z.ZodString;
                    label: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-counter">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                from: z.ZodNumber;
                to: z.ZodNumber;
                context: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-interval">;
            content: z.ZodObject<{
                label: z.ZodString;
                unit: z.ZodString;
                min: z.ZodNumber;
                max: z.ZodNumber;
                low: z.ZodNumber;
                high: z.ZodNumber;
                points: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-hierarchy">;
            content: z.ZodObject<{
                root: z.ZodString;
                groups: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    members: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            templateId: z.ZodLiteral<"visual-ranking">;
            content: z.ZodObject<{
                unit: z.ZodString;
                before: z.ZodString;
                after: z.ZodString;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    before: z.ZodNumber;
                    after: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            type: z.ZodLiteral<"teaching">;
            version: z.ZodLiteral<1>;
            id: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>], "templateId">, z.ZodObject<{
            type: z.ZodLiteral<"visual">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            kind: z.ZodEnum<{
                process: "process";
                cycle: "cycle";
                layers: "layers";
            }>;
            items: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
                id: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"visual">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            unit: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"bars">;
            items: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
                value: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"code">;
            id: z.ZodOptional<z.ZodString>;
            code: z.ZodString;
            language: z.ZodOptional<z.ZodString>;
            parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodOptional<z.ZodString>;
                text: z.ZodString;
            }, z.core.$strip>>>;
            regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                match: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"conversation">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            turns: z.ZodArray<z.ZodObject<{
                speaker: z.ZodString;
                text: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"callout">;
            id: z.ZodOptional<z.ZodString>;
            variant: z.ZodEnum<{
                example: "example";
                warning: "warning";
                definition: "definition";
                tip: "tip";
            }>;
            title: z.ZodOptional<z.ZodString>;
            body: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"accordion">;
            id: z.ZodOptional<z.ZodString>;
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"illustration">;
            id: z.ZodOptional<z.ZodString>;
            caption: z.ZodString;
            prompt: z.ZodString;
            style: z.ZodEnum<{
                process: "process";
                diagram: "diagram";
                concept: "concept";
                comparison: "comparison";
            }>;
            aspectRatio: z.ZodOptional<z.ZodEnum<{
                "1:1": "1:1";
                "16:9": "16:9";
                "9:16": "9:16";
                "4:3": "4:3";
                "3:4": "3:4";
                "3:2": "3:2";
                "2:3": "2:3";
            }>>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"svg_slot">;
            id: z.ZodOptional<z.ZodString>;
            intent: z.ZodObject<{
                visualKind: z.ZodEnum<{
                    simple_structure: "simple_structure";
                    spatial_relationship: "spatial_relationship";
                    state_comparison: "state_comparison";
                    step_derivation: "step_derivation";
                }>;
                setup: z.ZodString;
                learningGoal: z.ZodString;
                expectedInsight: z.ZodString;
                composition: z.ZodOptional<z.ZodString>;
                elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
                relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
                labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
                avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>;
        }, z.core.$strip>, z.ZodObject<{
            type: z.ZodLiteral<"stage">;
            id: z.ZodOptional<z.ZodString>;
            layout: z.ZodEnum<{
                "split-h": "split-h";
                "split-v": "split-v";
                "main+rail": "main+rail";
                stack: "stack";
            }>;
            presentation: z.ZodOptional<z.ZodEnum<{
                compare: "compare";
                steps: "steps";
                focus: "focus";
            }>>;
            figures: z.ZodArray<z.ZodUnion<readonly [z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"music">;
                id: z.ZodOptional<z.ZodString>;
                version: z.ZodLiteral<1>;
                title: z.ZodString;
                key: z.ZodLiteral<"C">;
                meter: z.ZodEnum<{
                    "2/4": "2/4";
                    "3/4": "3/4";
                    "4/4": "4/4";
                }>;
                tempo: z.ZodNumber;
                keyboard: z.ZodBoolean;
                notation: z.ZodOptional<z.ZodEnum<{
                    staff: "staff";
                    both: "both";
                    jianpu: "jianpu";
                }>>;
                parts: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    clef: z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    bars: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodObject<{
                            pitches: z.ZodArray<z.ZodString>;
                            beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                steps: z.ZodArray<z.ZodObject<{
                    bars: z.ZodArray<z.ZodNumber>;
                    parts: z.ZodArray<z.ZodString>;
                    instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        part: z.ZodString;
                        instrument: z.ZodEnum<{
                            piano: "piano";
                            electric_piano: "electric_piano";
                            guitar: "guitar";
                            violin: "violin";
                            cello: "cello";
                            flute: "flute";
                            marimba: "marimba";
                            organ: "organ";
                        }>;
                    }, z.core.$strict>>>;
                    id: z.ZodString;
                    label: z.ZodString;
                    focus: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    compare: z.ZodOptional<z.ZodObject<{
                        bars: z.ZodArray<z.ZodNumber>;
                        parts: z.ZodArray<z.ZodString>;
                        instruments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            part: z.ZodString;
                            instrument: z.ZodEnum<{
                                piano: "piano";
                                electric_piano: "electric_piano";
                                guitar: "guitar";
                                violin: "violin";
                                cello: "cello";
                                flute: "flute";
                                marimba: "marimba";
                                organ: "organ";
                            }>;
                        }, z.core.$strict>>>;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"music">;
                version: z.ZodLiteral<2>;
                id: z.ZodString;
                title: z.ZodString;
                layout: z.ZodEnum<{
                    row: "row";
                    column: "column";
                    grid: "grid";
                }>;
                notes: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    pitches: z.ZodArray<z.ZodString>;
                    beats: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>>;
                }, z.core.$strict>>;
                views: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        staff: "staff";
                        keyboard: "keyboard";
                    }>;
                    label: z.ZodString;
                    notes: z.ZodArray<z.ZodString>;
                    clef: z.ZodOptional<z.ZodEnum<{
                        treble: "treble";
                        bass: "bass";
                    }>>;
                    range: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                marks: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    kind: z.ZodEnum<{
                        label: "label";
                        link: "link";
                        bracket: "bracket";
                        arrow: "arrow";
                    }>;
                    label: z.ZodString;
                    anchors: z.ZodArray<z.ZodObject<{
                        viewId: z.ZodString;
                        noteId: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
                clips: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    tempo: z.ZodNumber;
                    instrument: z.ZodOptional<z.ZodEnum<{
                        piano: "piano";
                        electric_piano: "electric_piano";
                        guitar: "guitar";
                        violin: "violin";
                        cello: "cello";
                        flute: "flute";
                        marimba: "marimba";
                        organ: "organ";
                    }>>;
                    events: z.ZodArray<z.ZodObject<{
                        notes: z.ZodArray<z.ZodString>;
                        beats: z.ZodUnion<readonly [z.ZodLiteral<0.25>, z.ZodLiteral<0.5>, z.ZodLiteral<0.75>, z.ZodLiteral<1>, z.ZodLiteral<1.5>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>]>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>], "version">, z.ZodDiscriminatedUnion<[z.ZodObject<{
                templateId: z.ZodLiteral<"general-question">;
                content: z.ZodObject<{
                    objects: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    glyphs: z.ZodTuple<[z.ZodEnum<{
                        object: "object";
                        question: "question";
                        paper: "paper";
                        boat: "boat";
                        read: "read";
                        recall: "recall";
                    }>, z.ZodEnum<{
                        object: "object";
                        question: "question";
                        paper: "paper";
                        boat: "boat";
                        read: "read";
                        recall: "recall";
                    }>], null>;
                    observations: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    question: z.ZodString;
                    goal: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-layers">;
                content: z.ZodObject<{
                    layers: z.ZodArray<z.ZodObject<{
                        title: z.ZodString;
                        detail: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-flow">;
                content: z.ZodObject<{
                    nodes: z.ZodArray<z.ZodString>;
                    caption: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-compare">;
                content: z.ZodObject<{
                    names: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    metrics: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        unit: z.ZodString;
                        values: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                        max: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"general-summary">;
                content: z.ZodObject<{
                    concepts: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                    center: z.ZodString;
                    transfer: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-pythagoras">;
                content: z.ZodObject<{
                    a: z.ZodNumber;
                    b: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-tangent">;
                content: z.ZodObject<{
                    coefficient: z.ZodNumber;
                    power: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                    at: z.ZodNumber;
                    startDx: z.ZodNumber;
                    xmax: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-integral">;
                content: z.ZodObject<{
                    coefficient: z.ZodNumber;
                    power: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    end: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"math-probability">;
                content: z.ZodObject<{
                    total: z.ZodNumber;
                    condition: z.ZodNumber;
                    intersection: z.ZodNumber;
                    outsideTarget: z.ZodNumber;
                    conditionName: z.ZodString;
                    targetName: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-forces">;
                content: z.ZodObject<{
                    mass: z.ZodNumber;
                    drive: z.ZodNumber;
                    resistance: z.ZodNumber;
                    duration: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-waves">;
                content: z.ZodObject<{
                    amplitude1: z.ZodNumber;
                    amplitude2: z.ZodNumber;
                    cycles1: z.ZodNumber;
                    cycles2: z.ZodNumber;
                    phase2: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"physics-circuit">;
                content: z.ZodObject<{
                    voltage: z.ZodNumber;
                    resistance1: z.ZodNumber;
                    resistance2: z.ZodNumber;
                    topology: z.ZodEnum<{
                        series: "series";
                        parallel: "parallel";
                    }>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"chemistry-reaction">;
                content: z.ZodObject<{
                    reactants: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        atoms: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            element: z.ZodString;
                        }, z.core.$strict>>;
                        bonds: z.ZodArray<z.ZodObject<{
                            from: z.ZodString;
                            to: z.ZodString;
                            order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    products: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        atoms: z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            element: z.ZodString;
                        }, z.core.$strict>>;
                        bonds: z.ZodArray<z.ZodObject<{
                            from: z.ZodString;
                            to: z.ZodString;
                            order: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"chemistry-titration">;
                content: z.ZodObject<{
                    acidMl: z.ZodNumber;
                    acidMolarity: z.ZodNumber;
                    baseMolarity: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"biology-mitosis">;
                content: z.ZodObject<{
                    chromosomeCount: z.ZodUnion<readonly [z.ZodLiteral<2>, z.ZodLiteral<4>]>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"biology-enzyme">;
                content: z.ZodObject<{
                    enzyme: z.ZodString;
                    substrate: z.ZodString;
                    products: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"geography-water">;
                content: z.ZodObject<{
                    title: z.ZodString;
                    nodes: z.ZodTuple<[z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        label: z.ZodString;
                        glyph: z.ZodEnum<{
                            water: "water";
                            vapor: "vapor";
                            cloud: "cloud";
                            drop: "drop";
                            magma: "magma";
                            rock: "rock";
                            sediment: "sediment";
                            strata: "strata";
                        }>;
                    }, z.core.$strict>], null>;
                    transitions: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString, z.ZodString, z.ZodString], null>;
                    stages: z.ZodTuple<[z.ZodString, z.ZodString, z.ZodString], null>;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"history-timeline">;
                content: z.ZodObject<{
                    range: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    events: z.ZodTuple<[z.ZodObject<{
                        year: z.ZodNumber;
                        label: z.ZodString;
                        evidence: z.ZodString;
                        approximate: z.ZodOptional<z.ZodBoolean>;
                        kind: z.ZodEnum<{
                            type: "type";
                            block: "block";
                            moon: "moon";
                            telescope: "telescope";
                            event: "event";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        year: z.ZodNumber;
                        label: z.ZodString;
                        evidence: z.ZodString;
                        approximate: z.ZodOptional<z.ZodBoolean>;
                        kind: z.ZodEnum<{
                            type: "type";
                            block: "block";
                            moon: "moon";
                            telescope: "telescope";
                            event: "event";
                        }>;
                    }, z.core.$strict>], null>;
                    caution: z.ZodString;
                    conclusion: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"language-syntax">;
                content: z.ZodObject<{
                    subject: z.ZodString;
                    verb: z.ZodString;
                    object: z.ZodString;
                    question: z.ZodString;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"language-perspective">;
                content: z.ZodObject<{
                    object: z.ZodEnum<{
                        door: "door";
                        book: "book";
                    }>;
                    firstPerson: z.ZodString;
                    observer: z.ZodString;
                    note: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"cs-sorting">;
                content: z.ZodObject<{
                    values: z.ZodArray<z.ZodNumber>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"cs-recursion">;
                content: z.ZodObject<{
                    operation: z.ZodEnum<{
                        product: "product";
                        sum: "sum";
                    }>;
                    start: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"music-score">;
                content: z.ZodObject<{
                    id: z.ZodString;
                    title: z.ZodString;
                    groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                    labels: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    tempo: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"music-harmony">;
                content: z.ZodObject<{
                    id: z.ZodString;
                    title: z.ZodString;
                    groups: z.ZodArray<z.ZodArray<z.ZodString>>;
                    labels: z.ZodArray<z.ZodString>;
                    beats: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
                    range: z.ZodTuple<[z.ZodString, z.ZodString], null>;
                    tempo: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"economics-equilibrium">;
                content: z.ZodObject<{
                    demandIntercept: z.ZodNumber;
                    supplyIntercept: z.ZodNumber;
                    demandSlope: z.ZodNumber;
                    supplySlope: z.ZodNumber;
                    demandShift: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-timeline">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    events: z.ZodArray<z.ZodObject<{
                        at: z.ZodNumber;
                        label: z.ZodString;
                        detail: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-cycle">;
                content: z.ZodObject<{
                    center: z.ZodString;
                    nodes: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        process: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-decision">;
                content: z.ZodObject<{
                    question: z.ZodString;
                    branches: z.ZodArray<z.ZodObject<{
                        condition: z.ZodString;
                        outcome: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-funnel">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    stages: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-balance">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    left: z.ZodObject<{
                        label: z.ZodString;
                        items: z.ZodArray<z.ZodObject<{
                            label: z.ZodString;
                            value: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>;
                    right: z.ZodObject<{
                        label: z.ZodString;
                        items: z.ZodArray<z.ZodObject<{
                            label: z.ZodString;
                            value: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-matrix">;
                content: z.ZodObject<{
                    columns: z.ZodArray<z.ZodString>;
                    rows: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        values: z.ZodArray<z.ZodNumber>;
                    }, z.core.$strict>>;
                    unit: z.ZodString;
                    max: z.ZodNumber;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-proportion">;
                content: z.ZodObject<{
                    whole: z.ZodString;
                    unit: z.ZodString;
                    parts: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-network">;
                content: z.ZodObject<{
                    nodes: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                    links: z.ZodArray<z.ZodObject<{
                        from: z.ZodString;
                        to: z.ZodString;
                        label: z.ZodString;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-counter">;
                content: z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    from: z.ZodNumber;
                    to: z.ZodNumber;
                    context: z.ZodString;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-interval">;
                content: z.ZodObject<{
                    label: z.ZodString;
                    unit: z.ZodString;
                    min: z.ZodNumber;
                    max: z.ZodNumber;
                    low: z.ZodNumber;
                    high: z.ZodNumber;
                    points: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        value: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-hierarchy">;
                content: z.ZodObject<{
                    root: z.ZodString;
                    groups: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        members: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                templateId: z.ZodLiteral<"visual-ranking">;
                content: z.ZodObject<{
                    unit: z.ZodString;
                    before: z.ZodString;
                    after: z.ZodString;
                    items: z.ZodArray<z.ZodObject<{
                        label: z.ZodString;
                        before: z.ZodNumber;
                        after: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                type: z.ZodLiteral<"teaching">;
                version: z.ZodLiteral<1>;
                id: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>], "templateId">, z.ZodObject<{
                type: z.ZodLiteral<"visual">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
                kind: z.ZodEnum<{
                    process: "process";
                    cycle: "cycle";
                    layers: "layers";
                }>;
                items: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                    id: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"visual">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
                unit: z.ZodOptional<z.ZodString>;
                kind: z.ZodLiteral<"bars">;
                items: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                    value: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"code">;
                id: z.ZodOptional<z.ZodString>;
                code: z.ZodString;
                language: z.ZodOptional<z.ZodString>;
                parts: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodOptional<z.ZodString>;
                    text: z.ZodString;
                }, z.core.$strip>>>;
                regions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    match: z.ZodString;
                }, z.core.$strip>>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"conversation">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodOptional<z.ZodString>;
                turns: z.ZodArray<z.ZodObject<{
                    speaker: z.ZodString;
                    text: z.ZodString;
                }, z.core.$strip>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"callout">;
                id: z.ZodOptional<z.ZodString>;
                variant: z.ZodEnum<{
                    example: "example";
                    warning: "warning";
                    definition: "definition";
                    tip: "tip";
                }>;
                title: z.ZodOptional<z.ZodString>;
                body: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"accordion">;
                id: z.ZodOptional<z.ZodString>;
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"illustration">;
                id: z.ZodOptional<z.ZodString>;
                caption: z.ZodString;
                prompt: z.ZodString;
                style: z.ZodEnum<{
                    process: "process";
                    diagram: "diagram";
                    concept: "concept";
                    comparison: "comparison";
                }>;
                aspectRatio: z.ZodOptional<z.ZodEnum<{
                    "1:1": "1:1";
                    "16:9": "16:9";
                    "9:16": "9:16";
                    "4:3": "4:3";
                    "3:4": "3:4";
                    "3:2": "3:2";
                    "2:3": "2:3";
                }>>;
            }, z.core.$strip>, z.ZodObject<{
                type: z.ZodLiteral<"svg_slot">;
                id: z.ZodOptional<z.ZodString>;
                intent: z.ZodObject<{
                    visualKind: z.ZodEnum<{
                        simple_structure: "simple_structure";
                        spatial_relationship: "spatial_relationship";
                        state_comparison: "state_comparison";
                        step_derivation: "step_derivation";
                    }>;
                    setup: z.ZodString;
                    learningGoal: z.ZodString;
                    expectedInsight: z.ZodString;
                    composition: z.ZodOptional<z.ZodString>;
                    elements: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    relationships: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    labels: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    avoid: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strip>;
            }, z.core.$strip>]>>;
        }, z.core.$strip>]>;
        cues: z.ZodArray<z.ZodObject<{
            music: z.ZodOptional<z.ZodObject<{
                figureId: z.ZodString;
                clipId: z.ZodString;
                repeat: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            text: z.ZodString;
            figureId: z.ZodOptional<z.ZodString>;
            targetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
            target: z.ZodOptional<z.ZodString>;
            op: z.ZodOptional<z.ZodEnum<{
                highlight: "highlight";
                window: "window";
            }>>;
            regionIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
}, {
    readonly name: "commit_section_material";
    readonly description: "Commit the current section's complete learning-material envelope with at least 6 content items; the streamed arguments may grow progressively, but the final items array must not be empty or partial.";
    readonly schema: z.ZodObject<{
        items: z.ZodArray<z.ZodUnknown>;
    }, z.core.$strip>;
}, {
    readonly name: "commit_cornell";
    readonly description: "Commit Cornell study notes for the unit (note items, cue items, one summary).";
    readonly schema: z.ZodObject<{
        items: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                note: "note";
                summary: "summary";
                cue: "cue";
            }>;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>;
}, {
    readonly name: "commit_key_points";
    readonly description: "Commit the unit's course key points: 1 or 2 one-sentence takeaways per content section, concatenated in section order.";
    readonly schema: z.ZodObject<{
        points: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
}, {
    readonly name: "commit_flashcards";
    readonly description: "Commit the progressive flashcard deck items for the unit.";
    readonly schema: z.ZodObject<{
        items: z.ZodArray<z.ZodObject<{
            front: z.ZodString;
            back: z.ZodString;
            learningTargetIds: z.ZodArray<z.ZodString>;
            anchor: z.ZodOptional<z.ZodObject<{
                scope: z.ZodEnum<{
                    block: "block";
                    introduction: "introduction";
                    key_takeaway: "key_takeaway";
                    cornell_cue: "cornell_cue";
                }>;
                sectionId: z.ZodOptional<z.ZodString>;
                blockIndex: z.ZodOptional<z.ZodNumber>;
                takeawayIndex: z.ZodOptional<z.ZodNumber>;
                blockKey: z.ZodOptional<z.ZodString>;
                blockType: z.ZodOptional<z.ZodString>;
                subPath: z.ZodOptional<z.ZodString>;
                selectedText: z.ZodOptional<z.ZodString>;
                textRange: z.ZodOptional<z.ZodObject<{
                    start: z.ZodNumber;
                    end: z.ZodNumber;
                }, z.core.$strip>>;
                wrongOptionIndex: z.ZodOptional<z.ZodNumber>;
                highlightKey: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>;
            sourceExcerpt: z.ZodDefault<z.ZodString>;
            tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
}, {
    readonly name: "commit_quiz";
    readonly description: "Commit the active-recall quiz question items for the unit.";
    readonly schema: z.ZodObject<{
        items: z.ZodArray<z.ZodType<import("../quiz/authoring.js").QuizQuestion, unknown, z.core.$ZodTypeInternals<import("../quiz/authoring.js").QuizQuestion, unknown>>>;
    }, z.core.$strip>;
}];
export type UnitAuthoringToolName = (typeof unitAuthoringToolCatalog)[number]["name"];
export declare function toUnitAuthoringBaseMessages(records: readonly LlmMessageRecord[]): BaseMessage[];
export type DurableAuthoringTool = Readonly<{
    name: string;
    description: string;
    schema: z.ZodTypeAny;
}>;
export type UnitAuthoringToolChoice = "auto" | "required" | {
    type: "function";
    function: {
        name: string;
    };
};
export declare function resolveUnitAuthoringToolBinding(provider: string | undefined, expectedTool: string, toolCatalog: readonly DurableAuthoringTool[], options?: {
    model?: string;
}): {
    toolChoice: UnitAuthoringToolChoice;
    toolCatalog: readonly DurableAuthoringTool[];
};
export { recoverValidatedStreamedToolArgs };
export declare function langChainTools(catalog: readonly DurableAuthoringTool[], options?: {
    strict?: boolean;
}): {
    type: "function";
    function: {
        name: string;
        description: string;
        parameters: Record<string, unknown>;
        strict: boolean;
    };
}[];
export type UnitAuthoringRoundResult<TResult> = {
    result: TResult;
    /** Failed validation turns kept in linear history (UI may hide `repair`). */
    repairMessages: LlmMessageRecord[];
    userMessage: LlmMessageRecord;
    assistantMessage: LlmMessageRecord;
    toolMessage: LlmMessageRecord;
};
/**
 * Keep tool_choice byte-stable across Survey / section-plan / material stages.
 * DeepSeek (and similar) prefix caches match from the start of the tokenized
 * request; forcing a different function name each stage breaks the shared
 * tools/tool_choice prefix even when the message transcript is identical.
 * Stage prompts still name the expected commit tool; the server validates it.
 */
export declare const UNIT_AUTHORING_TOOL_CHOICE: "required";
export declare function unitAuthoringValidationRepairPrompt(expectedTool: string, validationError: string): string;
export declare function isExpectedAuthoringToolChunk(chunkName: string | undefined, observedName: string | undefined, expectedTool: string): boolean;
export declare function runUnitAuthoringAgentRound<TResult>(input: {
    transcript: readonly LlmMessageRecord[];
    prompt: string;
    expectedTool: UnitAuthoringToolName | string;
    resultSchema: z.ZodType<TResult>;
    toolCatalog?: readonly DurableAuthoringTool[];
    authoringKind?: "unit" | "goal";
    /** Billing/routing key; defaults to unit.authoring_agent. */
    operation?: string;
    signal?: AbortSignal;
    meta?: Record<string, unknown>;
    onToken?: (delta: string) => void | Promise<void>;
    onPartialCandidate?: (candidate: unknown) => void | Promise<void>;
}): Promise<UnitAuthoringRoundResult<TResult>>;
