import { z } from "zod";
export declare const hybridLogicalClockSchema: z.ZodObject<{
    wallTimeMs: z.ZodNumber;
    counter: z.ZodNumber;
    deviceId: z.ZodString;
}, z.core.$strip>;
export type HybridLogicalClock = z.infer<typeof hybridLogicalClockSchema>;
export declare function compareHybridLogicalClock(left: HybridLogicalClock, right: HybridLogicalClock): number;
export declare function tickHybridLogicalClock(input: {
    deviceId: string;
    previous?: HybridLogicalClock | null;
    received?: HybridLogicalClock | null;
    nowMs?: number;
}): HybridLogicalClock;
