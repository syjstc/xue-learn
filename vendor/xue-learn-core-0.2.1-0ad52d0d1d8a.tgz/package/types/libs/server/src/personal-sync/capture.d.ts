export type PersonalSyncCaptureContext = Readonly<{
    commitId: string;
    mode: "capture" | "apply";
}>;
/** Hosts may observe the current scope while implementing their own capture. */
export declare function getPersonalSyncCaptureContext(): PersonalSyncCaptureContext | undefined;
export declare function runWithPersonalSyncCapture<T>(work: () => T, commitId?: `${string}-${string}-${string}-${string}-${string}`): T;
export declare function runWithPersonalSyncApply<T>(work: () => T): T;
/** Re-enter the application scope when native callbacks dropped its context. */
export declare function ensurePersonalSyncCapture<T>(work: () => T): T;
