import { z } from "zod";
export declare const PERSONAL_SYNC_KDF: Readonly<{
    name: "scrypt";
    version: 1;
    N: 131072;
    r: 8;
    p: 1;
    keyLength: 32;
    maxmem: number;
}>;
declare const encryptedValueSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    algorithm: z.ZodLiteral<"aes-256-gcm">;
    nonce: z.ZodString;
    ciphertext: z.ZodString;
    authTag: z.ZodString;
}, z.core.$strip>;
export type EncryptedSyncValue = z.infer<typeof encryptedValueSchema>;
export declare const wrappedWorkspaceKeySchema: z.ZodObject<{
    formatVersion: z.ZodLiteral<1>;
    kdf: z.ZodObject<{
        name: z.ZodLiteral<"scrypt">;
        version: z.ZodLiteral<1>;
        N: z.ZodLiteral<131072>;
        r: z.ZodLiteral<8>;
        p: z.ZodLiteral<1>;
        keyLength: z.ZodLiteral<32>;
    }, z.core.$strip>;
    salt: z.ZodString;
    wrappedKey: z.ZodObject<{
        version: z.ZodLiteral<1>;
        algorithm: z.ZodLiteral<"aes-256-gcm">;
        nonce: z.ZodString;
        ciphertext: z.ZodString;
        authTag: z.ZodString;
    }, z.core.$strip>;
    verifier: z.ZodString;
}, z.core.$strip>;
export type WrappedWorkspaceKey = z.infer<typeof wrappedWorkspaceKeySchema>;
export declare const encryptedSyncEnvelopeSchema: z.ZodObject<{
    formatVersion: z.ZodLiteral<1>;
    compression: z.ZodLiteral<"brotli">;
    value: z.ZodObject<{
        version: z.ZodLiteral<1>;
        algorithm: z.ZodLiteral<"aes-256-gcm">;
        nonce: z.ZodString;
        ciphertext: z.ZodString;
        authTag: z.ZodString;
    }, z.core.$strip>;
}, z.core.$strip>;
export type EncryptedSyncEnvelope = z.infer<typeof encryptedSyncEnvelopeSchema>;
export declare function createWrappedWorkspaceKey(workspaceId: string, passphrase: string): Promise<{
    workspaceKey: Buffer;
    bundle: WrappedWorkspaceKey;
}>;
export declare function unwrapWorkspaceKey(workspaceId: string, passphrase: string, rawBundle: WrappedWorkspaceKey): Promise<Buffer>;
export declare function rewrapWorkspaceKey(input: {
    workspaceId: string;
    currentPassphrase: string;
    nextPassphrase: string;
    bundle: WrappedWorkspaceKey;
}): Promise<WrappedWorkspaceKey>;
export declare function encryptSyncPayload(input: {
    workspaceId: string;
    valueId: string;
    purpose: "commit" | "snapshot" | "blob" | "metadata";
    workspaceKey: Buffer;
    plaintext: Buffer;
}): Promise<EncryptedSyncEnvelope>;
export declare function decryptSyncPayload(input: {
    workspaceId: string;
    valueId: string;
    purpose: "commit" | "snapshot" | "blob" | "metadata";
    workspaceKey: Buffer;
    envelope: EncryptedSyncEnvelope;
}): Promise<Buffer>;
export {};
