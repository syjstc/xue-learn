export declare function getBatchSqPreviewConcurrency(): number;
export declare function getBatchMaterialConcurrency(): number;
export declare function getMapExpansionConcurrency(): number;
