import type { EvaluableOperation, OperationExecutionEvidence, OperationExecutionOptions, OperationExecutionResult } from "./types.js";
export declare class OperationExecutionError extends Error {
    readonly evidence: OperationExecutionEvidence;
    readonly cause?: unknown;
    constructor(message: string, evidence: OperationExecutionEvidence, cause?: unknown);
}
export declare function executeOperation<TInput, TOutput>(operation: EvaluableOperation<TInput, TOutput>, input: TInput, options: OperationExecutionOptions): Promise<OperationExecutionResult<TOutput>>;
export declare function executeRegisteredOperation<TInput, TOutput>(key: string, input: TInput, options: OperationExecutionOptions): Promise<OperationExecutionResult<TOutput>>;
