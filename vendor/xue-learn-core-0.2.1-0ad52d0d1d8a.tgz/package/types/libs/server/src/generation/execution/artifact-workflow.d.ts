import { z } from "zod";
import type { OperationExecutionContext } from "./types.js";
export declare const artifactContextEntrySchema: z.ZodObject<{
    stage: z.ZodString;
    kind: z.ZodEnum<{
        related_artifact: "related_artifact";
        generation_failure: "generation_failure";
        audit_failure: "audit_failure";
    }>;
    summary: z.ZodString;
    contentHash: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type ArtifactContextEntry = z.infer<typeof artifactContextEntrySchema>;
export declare const artifactContextSeedSchema: z.ZodObject<{
    sequenceId: z.ZodString;
    entries: z.ZodDefault<z.ZodArray<z.ZodObject<{
        stage: z.ZodString;
        kind: z.ZodEnum<{
            related_artifact: "related_artifact";
            generation_failure: "generation_failure";
            audit_failure: "audit_failure";
        }>;
        summary: z.ZodString;
        contentHash: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>>;
}, z.core.$strip>;
export type ArtifactContextSeed = z.infer<typeof artifactContextSeedSchema>;
export type ArtifactGenerationOutcome<T> = {
    status: "ready";
    sequenceId: string;
    artifact: T;
    attempts: number;
} | {
    status: "retryable";
    sequenceId: string;
    failedStage: "author" | "verify";
    attempts: number;
    issues: string[];
    validPreview?: T;
};
export declare class ArtifactGenerationExhaustedError<T = unknown> extends Error {
    readonly outcome: Extract<ArtifactGenerationOutcome<T>, {
        status: "retryable";
    }>;
    readonly retryable = true;
    constructor(outcome: Extract<ArtifactGenerationOutcome<T>, {
        status: "retryable";
    }>);
}
export declare function hashArtifactContext(value: string): string;
export declare function renderAppendableArtifactPrompt(basePrompt: string, seed: ArtifactContextSeed, entries: readonly ArtifactContextEntry[]): string;
export declare function appendArtifactInvocationContext(invocation: unknown, seed: ArtifactContextSeed, entries: readonly ArtifactContextEntry[]): Record<string, unknown>;
export type ArtifactWorkflowRoundContext = {
    attempt: number;
    prompt: string;
    entries: readonly ArtifactContextEntry[];
    invocation: Record<string, unknown>;
};
export declare function runArtifactGenerationWorkflow<T>(params: {
    operation: string;
    basePrompt: string;
    contextSeed: ArtifactContextSeed;
    contextInvocation?: unknown;
    executionContext: OperationExecutionContext;
    maxAuthorAttempts?: number;
    author(round: ArtifactWorkflowRoundContext): Promise<T>;
    verify(candidate: T, round: ArtifactWorkflowRoundContext): Promise<T>;
}): Promise<ArtifactGenerationOutcome<T>>;
