import { z } from "zod";
import { type QuizDifficulty } from "../learning-systems/capabilities/assessment-runtime/quiz-prompt.js";
export type QuizQuestion = {
    type: "mcq";
    question: string;
    options: string[];
    correctIndex: number;
    primaryLearningTargetId: string;
    learningTargetIds: string[];
    primaryCognitiveEntityId?: string;
    evidenceDimension: "memory" | "understanding";
    criterionRef: string;
    contextDistance: "same" | "near" | "far";
} | {
    type: "mcq_multi";
    question: string;
    options: string[];
    correctIndices: number[];
    primaryLearningTargetId: string;
    learningTargetIds: string[];
    primaryCognitiveEntityId?: string;
    evidenceDimension: "memory" | "understanding";
    criterionRef: string;
    contextDistance: "same" | "near" | "far";
} | {
    type: "true_false";
    question: string;
    correctAnswer: boolean;
    primaryLearningTargetId: string;
    learningTargetIds: string[];
    primaryCognitiveEntityId?: string;
    evidenceDimension: "memory" | "understanding";
    criterionRef: string;
    contextDistance: "same" | "near" | "far";
};
export type UnitQuizBatchPlan = {
    batchSize: number;
    slots: Array<{
        slotIndex: number;
        questionType: "mcq" | "mcq_multi" | "true_false";
        primaryLearningTargetId: string;
        primaryCognitiveEntityId: string;
        evidenceDimension: "memory" | "understanding";
        criterionRef: string;
        contextDistance: "same" | "near" | "far";
        targetLabel?: string;
    }>;
};
export declare const portableQuizQuestionSchema: z.ZodType<QuizQuestion>;
declare const quizJitItemSchema: z.ZodPreprocess<z.ZodType<QuizQuestion, unknown, z.core.$ZodTypeInternals<QuizQuestion, unknown>>>;
declare const quizJitItemBindingSchema: z.ZodType<QuizQuestion, unknown, z.core.$ZodTypeInternals<QuizQuestion, unknown>>;
export type UnitQuizAuthoringResult = {
    questions: QuizQuestion[];
    interleaved: QuizQuestion[];
};
export type PrepareUnitQuizAuthoringInput = {
    unitTitle: string;
    materialJson: string;
    languageBlock: string;
    styleBlock?: string;
    optionsBlock?: string;
    topicCategory?: unknown;
    goalTitle?: string;
    difficulty?: QuizDifficulty;
    learningTargetsBlock?: string;
    standaloneMicro?: boolean;
    batchPlan?: UnitQuizBatchPlan;
    decoratePrompt?: (prompt: string) => string;
    alignQuestions?: (questions: QuizQuestion[]) => QuizQuestion[];
    validateQuiz?: (quiz: UnitQuizAuthoringResult) => void;
};
export type PreparedUnitQuizAuthoring = {
    operation: "unit.quiz";
    questionCount: number;
    prompt: string;
    contextInvocation: Record<string, unknown>;
    itemSchema: typeof quizJitItemSchema;
    bindingItemSchema: typeof quizJitItemBindingSchema;
    resultSchema: z.ZodType<UnitQuizAuthoringResult>;
    alignQuestions: (questions: QuizQuestion[]) => QuizQuestion[];
    parseProviderOutput: (content: string) => UnitQuizAuthoringResult;
};
/**
 * Prepare the provider-independent active-recall authoring contract.
 *
 * Both hosted and desktop-local use this exact prompt, compatibility
 * normalization, server-owned batch-slot binding, and authoritative final
 * schema. A topology supplies only its provider transport and optional
 * published-target alignment/validation.
 */
export declare function prepareUnitQuizAuthoring(input: PrepareUnitQuizAuthoringInput): PreparedUnitQuizAuthoring;
export {};
