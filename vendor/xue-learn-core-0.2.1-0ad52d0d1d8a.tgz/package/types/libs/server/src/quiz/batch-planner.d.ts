import type { LearningTargetCognitiveAssessment } from "../assessment/activities.js";
export type QuizAssessmentFormat = "mcq" | "mcq_multi" | "true_false";
export type QuizBatchSlot = {
    slotIndex: number;
    questionType: QuizAssessmentFormat;
    primaryLearningTargetId: string;
    primaryCognitiveEntityId: string;
    evidenceDimension: "memory" | "understanding";
    criterionRef: string;
    contextDistance: "same" | "near" | "far";
    targetLabel?: string;
};
export type QuizBatchPlan = {
    batchSize: number;
    slots: QuizBatchSlot[];
};
export type QuizBatchPlannerInput = {
    targets: readonly {
        id: string;
        localRef: string;
        title?: string;
        label?: string;
        required: boolean;
        importance?: "core" | "supporting" | "enrichment";
        assessmentCriteria: readonly {
            ref: string;
            text: string;
        }[];
        requirements: readonly {
            cognitiveEntityId: string;
            dimension: string;
            required?: boolean;
        }[];
    }[];
    priorQuestions?: readonly {
        type: string;
        question: string;
        primaryLearningTargetId?: string;
        learningTargetIds?: string[];
        evidenceDimension?: string;
        primaryCognitiveEntityId?: string;
        contextDistance?: string;
    }[];
    observations?: readonly {
        cognitiveEntityId: string;
        dimension: string;
        status?: "unobserved" | "forming" | "demonstrated" | "robust" | "revalidate";
        evidenceSufficiency?: number;
        lastOutcome?: "correct" | "partial" | "incorrect";
    }[];
    desiredBatchSize?: number;
};
export type RecallProgress = {
    completedBatches: number;
    totalAnswers: number;
    recommendation: "continue_now" | "review_later";
    targets: Array<{
        learningTargetId: string;
        localRef: string;
        title: string;
        evidenceSufficiency: number;
        cognitiveStatus?: string;
    }>;
};
export declare function assessmentFormatEvidenceStrength(format: QuizAssessmentFormat): "weak" | "moderate";
export declare function planQuizBatch(input: QuizBatchPlannerInput): QuizBatchPlan;
export declare function buildRecallProgress(params: {
    targets: readonly {
        id: string;
        localRef: string;
        title: string;
        required: boolean;
    }[];
    assessments: readonly LearningTargetCognitiveAssessment[];
    completedBatches: number;
    totalAnswers: number;
}): RecallProgress;
/**
 * Force server-owned batch bindings onto LLM-authored question content.
 * Stems/options/answers come from the model; type/target/entity/dim/criterion/distance do not.
 */
export declare function applyQuizBatchSlots<T extends {
    type: QuizAssessmentFormat;
    question: string;
    options?: string[];
    correctIndex?: number;
    correctIndices?: number[];
    correctAnswer?: boolean;
    primaryLearningTargetId?: string;
    learningTargetIds?: string[];
    primaryCognitiveEntityId?: string;
    evidenceDimension?: "memory" | "understanding";
    criterionRef?: string;
    contextDistance?: "same" | "near" | "far";
}>(questions: readonly T[], plan: QuizBatchPlan): T[];
export declare function observationHintsFromAssessments(targets: QuizBatchPlannerInput["targets"], assessments: readonly LearningTargetCognitiveAssessment[]): NonNullable<QuizBatchPlannerInput["observations"]>;
