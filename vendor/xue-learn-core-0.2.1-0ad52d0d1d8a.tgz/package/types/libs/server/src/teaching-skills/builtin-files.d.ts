export declare function builtinRoot(): string;
export declare function readPackageDirectory(directory: string): Promise<Record<string, string>>;
