export declare const GOAL_MODULE_STRUCTURE_DRAFT_PREPARE_EVENT = "goal.module_structure.draft.prepare";
export declare const GOAL_MODULE_STRUCTURE_AUDIT_EVENT = "goal.module_structure.audit";
export declare const GOAL_CREATION_COORDINATE_EVENT = "goal.creation.coordinate";
/** Outbox statuses that must stay unpublished so the next poll can continue. */
export declare const AGENTIC_OUTBOX_HOLD_STATUSES: Set<string>;
export declare const AGENTIC_AUTHORING_REMOTE_CONCURRENCY = 10;
export declare const AGENTIC_AUTHORING_OLLAMA_CONCURRENCY = 1;
export declare const AGENTIC_RESEARCH_CONCURRENCY = 4;
export declare const MODULE_STRUCTURE_DRAFT_LEASE_MS: number;
export declare const MAX_MODULE_AUDIT_REPAIR_ROUNDS = 1;
export declare function createConcurrencyLimiter(max: number): <T>(work: () => Promise<T>) => Promise<T>;
export declare function serializeSqlitePublication<T>(work: () => Promise<T>): Promise<T>;
