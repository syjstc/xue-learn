export declare const AGENTIC_CACHE_ACCEPTANCE: {
    readonly minWarmCallsPerGroup: 30;
    readonly minMeasurementCoverage: 0.9;
    readonly minTokenWeightedHitRate: 0.65;
};
export type AuthoringCacheClass = "cold_seed" | "warm_fanout";
export declare function classifyAuthoringCacheClass(reason: string | undefined): AuthoringCacheClass;
export type CacheTelemetryCall = Readonly<{
    operation?: string;
    goalId?: string;
    sessionId?: string;
    cacheClass?: string;
    cacheReadTokens?: number | null;
    inputTokens?: number | null;
    uncachedInputTokens?: number | null;
    cost?: number | null;
}>;
export type CacheTelemetrySummary = Readonly<{
    totalCalls: number;
    measuredCalls: number;
    unknownCalls: number;
    measurementCoverage: number | "unknown";
    cacheReadTokens: number | "unknown";
    inputTokens: number | "unknown";
    uncachedInputTokens: number | "unknown";
    tokenWeightedHitRate: number | "unknown";
    cost: number | "unknown";
    meetsAcceptance: boolean | "unknown";
}>;
export declare function summarizeCacheTelemetry(calls: readonly CacheTelemetryCall[]): CacheTelemetrySummary;
