import { z } from "zod";
export declare const mainlineCommandSchema: z.ZodObject<{
    commandId: z.ZodString;
    sessionId: z.ZodString;
    expectedRevision: z.ZodNumber;
    action: z.ZodEnum<{
        start: "start";
        position: "position";
        pause: "pause";
        preference: "preference";
        resume: "resume";
        return: "return";
        shown: "shown";
        later: "later";
        today: "today";
    }>;
    activityId: z.ZodOptional<z.ZodString>;
    activityRevision: z.ZodOptional<z.ZodNumber>;
    goalId: z.ZodOptional<z.ZodString>;
    unitId: z.ZodOptional<z.ZodString>;
    kind: z.ZodOptional<z.ZodEnum<{
        lesson: "lesson";
        review: "review";
        supplement: "supplement";
    }>>;
    branchId: z.ZodOptional<z.ZodString>;
    position: z.ZodOptional<z.ZodObject<{
        version: z.ZodLiteral<1>;
        unitId: z.ZodString;
        sectionId: z.ZodOptional<z.ZodString>;
        topicId: z.ZodOptional<z.ZodString>;
        topicTitle: z.ZodOptional<z.ZodString>;
        blockIdentity: z.ZodOptional<z.ZodString>;
        blockIndex: z.ZodOptional<z.ZodNumber>;
        contentRevision: z.ZodOptional<z.ZodNumber>;
        anchorText: z.ZodOptional<z.ZodString>;
        scrollOffset: z.ZodOptional<z.ZodNumber>;
        mode: z.ZodEnum<{
            classroom: "classroom";
            reading: "reading";
        }>;
        readingPage: z.ZodOptional<z.ZodObject<{
            renderer: z.ZodLiteral<"godot">;
            identity: z.ZodString;
        }, z.core.$strict>>;
        classroom: z.ZodOptional<z.ZodObject<{
            projectId: z.ZodString;
            sourceHash: z.ZodString;
            sceneId: z.ZodString;
            beatId: z.ZodOptional<z.ZodString>;
            tick: z.ZodNumber;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    preference: z.ZodOptional<z.ZodObject<{
        newLearning: z.ZodEnum<{
            active: "active";
            paused: "paused";
        }>;
        reviews: z.ZodBoolean;
        priority: z.ZodNumber;
        revision: z.ZodNumber;
    }, z.core.$strict>>;
    timeLimitMinutes: z.ZodOptional<z.ZodNumber>;
    reviewSource: z.ZodOptional<z.ZodEnum<{
        course: "course";
        flashcards: "flashcards";
    }>>;
    candidateId: z.ZodOptional<z.ZodString>;
    snapshotVersion: z.ZodOptional<z.ZodString>;
    timezone: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
