import type { ImageAspectRatio } from "./providers/types.js";
/** Short edge for compact inline illustrations (~512px). */
export declare const COMPACT_SHORT_EDGE = 512;
/** Compact pixel dimensions preserving aspect ratio (multiples of 16 for provider APIs). */
export declare function compactImagePixelSize(aspectRatio?: ImageAspectRatio): {
    width: number;
    height: number;
    size: string;
};
