import type { Env } from "../../env.js";
import type { ImageProvider } from "./types.js";
export declare function createApimartImageProvider(env: Env, model: string): ImageProvider;
