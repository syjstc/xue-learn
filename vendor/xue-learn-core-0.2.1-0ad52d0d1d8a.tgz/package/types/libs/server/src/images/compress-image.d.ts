export type CompressImageOptions = {
    maxDimension?: number;
    maxWidth?: number;
    quality?: number;
};
/** Stored unit / room illustrations (~512–1024px). */
export declare const STORED_IMAGE_OPTIONS: CompressImageOptions;
/** Stored 2K desktop-local illustrations (up to 2848x1600 / 2048x2048). */
export declare const STORED_2K_IMAGE_OPTIONS: CompressImageOptions;
/** PDF embed: cap width at 512px (matches inline illustration size). */
export declare const PDF_EMBED_IMAGE_OPTIONS: CompressImageOptions;
export declare function compressImageBuffer(data: Buffer, mimeType: string, options?: CompressImageOptions): Promise<{
    data: Buffer;
    mimeType: string;
}>;
