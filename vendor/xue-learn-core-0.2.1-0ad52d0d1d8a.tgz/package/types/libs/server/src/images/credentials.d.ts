import { type Env } from "../env.js";
import type { ActiveImageProviderId } from "./provider-ids.js";
export declare function hasImageProviderCredentials(provider: ActiveImageProviderId, env?: Env): boolean;
