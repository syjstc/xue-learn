export declare function imageGenerationUnavailableReason(): string | null;
export declare function assertImageGenerationConfigured(): void;
