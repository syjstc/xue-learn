export declare function chatAudioObjectKey(userId: string, unitId: string, audioId: string): string;
export declare function saveChatAudioObject(objectKey: string, body: Buffer): Promise<void>;
export declare function readChatAudioObject(objectKey: string): Promise<Buffer | null>;
export declare function deleteChatAudioPrefix(prefix: string): Promise<number>;
export declare function chatAudioUserPrefix(userId: string): string;
