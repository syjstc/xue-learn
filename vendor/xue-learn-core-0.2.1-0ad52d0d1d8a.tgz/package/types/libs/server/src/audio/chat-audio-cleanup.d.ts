export declare const CHAT_AUDIO_CLEANUP_EVENT = "chat.audio.cleanup";
export declare function processChatAudioCleanupEvent(payload: string): Promise<{
    deletedObjects: number;
}>;
