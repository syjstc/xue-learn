import type { PersistenceClient } from "../persistence/persistence-compat.js";
import type { ChatNarrationRepository } from "../../../domain/src/index.js";
import type { LearningMaterialContent } from "../llm/schemas.js";
import { type TeachingPersona } from "../teaching-personas/index.js";
import { type ChatNarrationCharTiming, type TtsProvider } from "../providers/audio/index.js";
import { type BuiltinChatVoiceProfile } from "./minimax-teacher-voices.js";
export declare const CHAT_NARRATION_BATCH_SIZE = 5;
export declare const CHAT_NARRATION_PER_ENTRY_CONCURRENCY = 2;
export declare function configureChatNarrationPersistence(repository: ChatNarrationRepository | undefined): void;
export type ChatNarrationEntry = {
    contentKey: string;
    text: string;
};
export type ChatNarrationVoiceProfile = BuiltinChatVoiceProfile & {
    speaker: string;
};
export declare function chatNarrationVoiceProfile(persona: Pick<TeachingPersona, "avatarCode" | "gender">): ChatNarrationVoiceProfile;
export type ChatNarrationAsset = {
    audioId: string;
    contentKey: string;
    textHash: string;
    audioUrl: string;
    mimeType: string;
    durationMs: number;
    audioStartMs: number;
    audioEndMs: number;
    chars: ChatNarrationCharTiming[];
};
export declare function chatNarrationTextHash(text: string, timingVersion?: string): string;
export declare function chatNarrationEntries(material: LearningMaterialContent): ChatNarrationEntry[];
export declare function chatNarrationEnabled(userId: string, goalId: string, client?: PersistenceClient): Promise<boolean>;
export declare function claimChatNarrationAudioRow(input: {
    userId: string;
    unitId: string;
    sectionId?: string | null;
    contentKey: string;
    textHash: string;
    provider: TtsProvider;
    speaker?: string;
    client?: PersistenceClient;
}): Promise<{
    row: any;
    claimed: boolean;
}>;
export declare function synthesizeChatNarration(input: {
    userId: string;
    unitId: string;
    sectionId?: string | null;
    contentKey: string;
    text: string;
    signal?: AbortSignal;
    client?: PersistenceClient;
}): Promise<ChatNarrationAsset | null>;
export declare function synthesizeChatNarrationBatch(input: {
    userId: string;
    unitId: string;
    sectionId?: string | null;
    entries: ChatNarrationEntry[];
    voiceProfile?: ChatNarrationVoiceProfile;
    signal?: AbortSignal;
    client?: PersistenceClient;
}): Promise<ChatNarrationAsset[]>;
export declare function mapChatNarrationWithConcurrency<T, R>(entries: T[], concurrency: number, run: (entry: T, index: number) => Promise<R>): Promise<R[]>;
export declare function createChatNarrationBatchQueue(input: {
    batchSize?: number;
    run: (entries: ChatNarrationEntry[]) => Promise<void>;
}): {
    add(entry: ChatNarrationEntry): void;
    finish(): Promise<void>;
};
export declare function createProgressiveChatNarrationQueue(input: {
    batchSize?: number;
    run: (entries: ChatNarrationEntry[]) => Promise<void>;
}): {
    observe(material: LearningMaterialContent, completeBlockCount?: number): void;
    finish(): Promise<void>;
};
export declare function createChatNarrationCoordinator(input: {
    userId: string;
    goalId: string;
    unitId: string;
    sectionId?: string | null;
    signal?: AbortSignal;
    client?: PersistenceClient;
    batchSize?: number;
    onReady?: (asset: ChatNarrationAsset) => void | Promise<void>;
}): Promise<{
    enabled: boolean;
    observe: (material: LearningMaterialContent, completeBlockCount?: number) => void;
    finish: () => Promise<void>;
}>;
export declare function listCurrentChatNarration(input: {
    userId: string;
    unitId: string;
    sectionId?: string;
    client?: PersistenceClient;
}): Promise<ChatNarrationAsset[]>;
export declare function ensureCurrentChatNarration(input: {
    userId: string;
    unitId: string;
    sectionId?: string;
    signal?: AbortSignal;
    client?: PersistenceClient;
    onReady?: (asset: ChatNarrationAsset) => void | Promise<void>;
}): Promise<void>;
export declare function readOwnedChatNarration(input: {
    userId: string;
    unitId: string;
    audioId: string;
    client?: PersistenceClient;
}): Promise<{
    body: Buffer<ArrayBufferLike>;
    mimeType: any;
}>;
