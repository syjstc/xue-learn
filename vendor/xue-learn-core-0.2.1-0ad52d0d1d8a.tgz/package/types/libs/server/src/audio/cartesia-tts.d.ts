export declare const CARTESIA_TTS_MODEL = "sonic-3.6";
export declare const CARTESIA_TTS_VOICE = "a1740ddf-75ec-4848-87eb-1ede58638baf";
export declare const CARTESIA_TTS_VERSION = "2026-08-14";
export declare const CARTESIA_TTS_SAMPLE_RATE = 44100;
export declare const CARTESIA_TTS_TIMING_VERSION = "cartesia-sonic-3.6-sse-word-ms-v3";
export type CartesiaTtsRequestOptions = {
    voiceId?: string;
    model?: string;
    /** ISO-639-1 language or a regional locale such as `zh-CN`. */
    languageHint?: string;
    /** Cartesia generation speed; values outside the provider range are clamped. */
    rate?: number;
    /** Shared TTS option expressed as the existing 0-100 volume scale. */
    volume?: number;
    requireWordTimings?: boolean;
    logOperation?: string;
    logMeta?: Record<string, unknown>;
};
export type CartesiaTimedSpeech = {
    audio: Buffer;
    mimeType: "audio/mpeg";
    durationMs: number;
    chars: Array<{
        char: string;
        startMs: number;
        endMs: number;
    }>;
};
export type CartesiaTimedSpeechSegment = {
    text: string;
    startMs: number;
    endMs: number;
    durationMs: number;
    chars: Array<{
        char: string;
        startMs: number;
        endMs: number;
    }>;
};
export type CartesiaTimedSpeechBatch = {
    audio: Buffer;
    mimeType: "audio/mpeg";
    durationMs: number;
    segments: CartesiaTimedSpeechSegment[];
};
type CartesiaWord = {
    word: string;
    startMs: number;
    endMs: number;
};
type AlignedChar = {
    char: string;
    startMs: number;
    endMs: number;
    startOffset: number;
    endOffset: number;
};
/**
 * Keep the learner-facing narration unchanged while making the small amount
 * of provider-specific Chinese read-out repair that the classroom voice needs.
 * Cartesia's normalizer remains enabled for all other numbers and symbols.
 */
export declare function normalizeCartesiaTranscript(text: string, languageHint?: string): {
    text: string;
    transforms: string[];
};
export declare function alignCartesiaWordsToText(text: string, words: CartesiaWord[], durationMs: number): AlignedChar[];
export declare function synthesizeCartesiaTimedSpeech(text: string, options?: CartesiaTtsRequestOptions, signal?: AbortSignal): Promise<CartesiaTimedSpeech>;
export declare function synthesizeCartesiaSpeech(text: string, options?: CartesiaTtsRequestOptions, signal?: AbortSignal): Promise<CartesiaTimedSpeech>;
export declare function synthesizeCartesiaSegmentedSpeech(segments: string[], options?: CartesiaTtsRequestOptions, signal?: AbortSignal): Promise<CartesiaTimedSpeechBatch>;
export {};
