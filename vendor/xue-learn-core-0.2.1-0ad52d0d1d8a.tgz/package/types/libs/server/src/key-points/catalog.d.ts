export type UnitKeyPointSectionSource = Readonly<{
    id: string;
    title: string;
    orderIndex: number;
    contentKind: string;
    generationStatus: string;
    keyTakeaways: string;
    blocks: string | null;
}>;
export declare function parseStoredKeyTakeaways(value: string): string[];
export declare function headingTitlesFromBlocksJson(blocks: string | null): string[];
export declare function isStandardContentSection(section: UnitKeyPointSectionSource): boolean;
export declare function formatKeyPointCatalog(sections: readonly UnitKeyPointSectionSource[]): string;
export declare function unitNeedsCourseKeyPoints(sections: readonly UnitKeyPointSectionSource[]): boolean;
