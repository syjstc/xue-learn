import { z } from "zod";
export declare const UNIT_KEY_POINTS_OPERATION: "unit.key_points";
export declare const MAX_UNIT_KEY_POINTS = 8;
export declare const MAX_KEY_POINT_CHARS = 120;
export declare const unitKeyPointsCommitBindingSchema: z.ZodObject<{
    points: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export declare function unitKeyPointsCountBounds(sectionCount: number): {
    min: number;
    max: number;
};
export declare function unitKeyPointsResultSchema(sectionCount: number): z.ZodObject<{
    points: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export declare function keyPointsFromCommitArgs(value: unknown): unknown;
export declare function normalizedKeyPointText(text: string): string;
export declare function uniqueKeyPointTexts(points: readonly string[]): string[];
export declare function distributeKeyPoints(points: readonly string[], sectionCount: number): string[][];
export declare function buildKeyPointsHistoryContinuationPrompt(input: {
    unitTitle: string;
    sectionCount: number;
    languageBlock: string;
    styleBlock?: string;
    catalog: string;
}): string;
export declare function buildKeyPointsStandalonePrompt(input: {
    unitTitle: string;
    sectionCount: number;
    goalBlock: string;
    languageBlock: string;
    styleBlock?: string;
    catalog: string;
}): string;
