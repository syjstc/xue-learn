import { z } from "zod";
export declare const surveyLearningTargetSchema: z.ZodObject<{
    id: z.ZodString;
    durableId: z.ZodOptional<z.ZodString>;
    cognitiveEntityIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    label: z.ZodString;
    explanation: z.ZodOptional<z.ZodString>;
    learningObjective: z.ZodOptional<z.ZodString>;
    assessmentCriteria: z.ZodOptional<z.ZodArray<z.ZodString>>;
    importance: z.ZodOptional<z.ZodEnum<{
        core: "core";
        supporting: "supporting";
        enrichment: "enrichment";
    }>>;
    importanceWeight: z.ZodOptional<z.ZodNumber>;
    difficulty: z.ZodOptional<z.ZodEnum<{
        medium: "medium";
        easy: "easy";
        hard: "hard";
    }>>;
    targetCognitiveLevel: z.ZodOptional<z.ZodEnum<{
        remember: "remember";
        understand: "understand";
        apply: "apply";
        analyze: "analyze";
        evaluate: "evaluate";
        create: "create";
    }>>;
    rationale: z.ZodOptional<z.ZodString>;
    isEntry: z.ZodOptional<z.ZodBoolean>;
    isExit: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
export declare const surveyGuidingQuestionSchema: z.ZodObject<{
    text: z.ZodString;
    learningTargetIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export declare const surveyComplexComponentTypeSchema: z.ZodEnum<{
    step_sort: "step_sort";
    graph: "graph";
    chart: "chart";
    math_scene: "math_scene";
    mechanics_sandbox: "mechanics_sandbox";
    circuit_sandbox: "circuit_sandbox";
    chemistry_lab: "chemistry_lab";
}>;
/** Complex types selectable for new SQ/material generation. */
export declare const generatableSurveyComponentTypeSchema: z.ZodEnum<{
    chart: "chart";
    math_scene: "math_scene";
    mechanics_sandbox: "mechanics_sandbox";
    circuit_sandbox: "circuit_sandbox";
    chemistry_lab: "chemistry_lab";
}>;
export declare const surveySectionContentKindSchema: z.ZodEnum<{
    standard: "standard";
    formal_derivation: "formal_derivation";
}>;
export type SurveySectionContentKind = z.infer<typeof surveySectionContentKindSchema>;
export declare function persistedSectionContentKind(value: unknown): SurveySectionContentKind;
export declare function optionalSectionContentKind(value: unknown): {
    contentKind?: "formal_derivation";
};
/** Micro courses stay one section; a formal_derivation Survey label applies to that whole lesson. */
export declare function microCourseSectionPlanDraft(input: {
    unitTitle: string;
    unitContentSummary?: string;
    outlinePlans?: ReadonlyArray<{
        title: string;
        contentSummary: string;
        contentKind?: string;
    }>;
    surveyContentKind?: string;
}): {
    title: string;
    contentSummary: string;
    assessmentAfter: false;
    contentKind: SurveySectionContentKind;
    targets: [];
};
export declare const surveySectionOutlineItemSchema: z.ZodObject<{
    title: z.ZodString;
    scope: z.ZodString;
    learningTargetIds: z.ZodArray<z.ZodString>;
    checkpointAfter: z.ZodBoolean;
    contentKind: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        formal_derivation: "formal_derivation";
    }>>;
}, z.core.$strip>;
export declare const surveySectionPlanItemSchema: z.ZodObject<{
    title: z.ZodString;
    scope: z.ZodString;
    outlineIndexes: z.ZodArray<z.ZodNumber>;
    contentKind: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        formal_derivation: "formal_derivation";
    }>>;
}, z.core.$strip>;
export declare const surveySectionPlanSchema: z.ZodArray<z.ZodObject<{
    title: z.ZodString;
    scope: z.ZodString;
    outlineIndexes: z.ZodArray<z.ZodNumber>;
    contentKind: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        formal_derivation: "formal_derivation";
    }>>;
}, z.core.$strip>>;
export declare const portableSurveyPreviewSchema: z.ZodObject<{
    survey: z.ZodObject<{
        outline: z.ZodArray<z.ZodString>;
        contentKind: z.ZodOptional<z.ZodEnum<{
            standard: "standard";
            formal_derivation: "formal_derivation";
        }>>;
        sectionOutline: z.ZodOptional<z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            scope: z.ZodString;
            learningTargetIds: z.ZodArray<z.ZodString>;
            checkpointAfter: z.ZodBoolean;
            contentKind: z.ZodOptional<z.ZodEnum<{
                standard: "standard";
                formal_derivation: "formal_derivation";
            }>>;
        }, z.core.$strip>>>;
        sectionPlan: z.ZodOptional<z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            scope: z.ZodString;
            outlineIndexes: z.ZodArray<z.ZodNumber>;
            contentKind: z.ZodOptional<z.ZodEnum<{
                standard: "standard";
                formal_derivation: "formal_derivation";
            }>>;
        }, z.core.$strip>>>;
        learningTargetLabels: z.ZodArray<z.ZodString>;
    }, z.core.$strip>;
    learningTargets: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        durableId: z.ZodOptional<z.ZodString>;
        cognitiveEntityIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        label: z.ZodString;
        explanation: z.ZodOptional<z.ZodString>;
        learningObjective: z.ZodOptional<z.ZodString>;
        assessmentCriteria: z.ZodOptional<z.ZodArray<z.ZodString>>;
        importance: z.ZodOptional<z.ZodEnum<{
            core: "core";
            supporting: "supporting";
            enrichment: "enrichment";
        }>>;
        importanceWeight: z.ZodOptional<z.ZodNumber>;
        difficulty: z.ZodOptional<z.ZodEnum<{
            medium: "medium";
            easy: "easy";
            hard: "hard";
        }>>;
        targetCognitiveLevel: z.ZodOptional<z.ZodEnum<{
            remember: "remember";
            understand: "understand";
            apply: "apply";
            analyze: "analyze";
            evaluate: "evaluate";
            create: "create";
        }>>;
        rationale: z.ZodOptional<z.ZodString>;
        isEntry: z.ZodOptional<z.ZodBoolean>;
        isExit: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>>;
    questions: z.ZodArray<z.ZodObject<{
        text: z.ZodString;
        learningTargetIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>>;
    componentSelection: z.ZodOptional<z.ZodObject<{
        mainCategory: z.ZodEnum<{
            chemistry_lab: "chemistry_lab";
            base: "base";
            math_visualization: "math_visualization";
            process_sequence: "process_sequence";
            data_visualization: "data_visualization";
            mechanics_lab: "mechanics_lab";
            circuit_lab: "circuit_lab";
        }>;
        enabledCategories: z.ZodArray<z.ZodEnum<{
            chemistry_lab: "chemistry_lab";
            base: "base";
            math_visualization: "math_visualization";
            process_sequence: "process_sequence";
            data_visualization: "data_visualization";
            mechanics_lab: "mechanics_lab";
            circuit_lab: "circuit_lab";
        }>>;
        rationale: z.ZodOptional<z.ZodString>;
        plannedComponents: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            componentType: z.ZodEnum<{
                step_sort: "step_sort";
                graph: "graph";
                chart: "chart";
                math_scene: "math_scene";
                mechanics_sandbox: "mechanics_sandbox";
                circuit_sandbox: "circuit_sandbox";
                chemistry_lab: "chemistry_lab";
            }>;
            description: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type SurveyPreview = z.infer<typeof portableSurveyPreviewSchema>;
export type SurveyLearningTarget = z.infer<typeof surveyLearningTargetSchema>;
export declare const surveyOutlineItemSchema: z.ZodObject<{
    kind: z.ZodLiteral<"outline">;
    text: z.ZodString;
    scope: z.ZodOptional<z.ZodString>;
    learningTargetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    checkpointAfter: z.ZodOptional<z.ZodBoolean>;
    contentKind: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        formal_derivation: "formal_derivation";
    }>>;
}, z.core.$strip>;
export declare const surveyQuestionItemSchema: z.ZodObject<{
    kind: z.ZodLiteral<"question">;
    question: z.ZodObject<{
        text: z.ZodString;
        learningTargetIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const surveySectionPlanItemContractSchema: z.ZodObject<{
    kind: z.ZodLiteral<"section_plan">;
    sections: z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        scope: z.ZodString;
        outlineIndexes: z.ZodArray<z.ZodNumber>;
        contentKind: z.ZodOptional<z.ZodEnum<{
            standard: "standard";
            formal_derivation: "formal_derivation";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const surveyAuthoringItemSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"outline">;
    text: z.ZodString;
    scope: z.ZodOptional<z.ZodString>;
    learningTargetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    checkpointAfter: z.ZodOptional<z.ZodBoolean>;
    contentKind: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        formal_derivation: "formal_derivation";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"question">;
    question: z.ZodObject<{
        text: z.ZodString;
        learningTargetIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>], "kind">;
export declare const surveyPreviewItemSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"outline">;
    text: z.ZodString;
    scope: z.ZodOptional<z.ZodString>;
    learningTargetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    checkpointAfter: z.ZodOptional<z.ZodBoolean>;
    contentKind: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        formal_derivation: "formal_derivation";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"section_plan">;
    sections: z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        scope: z.ZodString;
        outlineIndexes: z.ZodArray<z.ZodNumber>;
        contentKind: z.ZodOptional<z.ZodEnum<{
            standard: "standard";
            formal_derivation: "formal_derivation";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"question">;
    question: z.ZodObject<{
        text: z.ZodString;
        learningTargetIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>], "kind">;
export type SurveyAuthoringItem = z.infer<typeof surveyAuthoringItemSchema>;
export type SurveyPreviewItem = z.infer<typeof surveyPreviewItemSchema>;
/**
 * Provider-native Survey envelope. MiniMax/OpenAI-compatible function tools
 * need one object (`type`/`properties`/`required`), not an `anyOf` union.
 * A single growing `items` array lets parsePartialJson emit each complete
 * outline/question as soon as that object closes — two sibling arrays would
 * hold the first paint until `questions` exists.
 */
export declare const compactSurveyPreviewItemBindingSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        question: "question";
        outline: "outline";
    }>;
    text: z.ZodString;
    scope: z.ZodOptional<z.ZodString>;
    learningTargetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    checkpointAfter: z.ZodOptional<z.ZodBoolean>;
    contentKind: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        formal_derivation: "formal_derivation";
    }>>;
}, z.core.$strip>;
export declare const compactSurveyPreviewBindingSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            question: "question";
            outline: "outline";
        }>;
        text: z.ZodString;
        scope: z.ZodOptional<z.ZodString>;
        learningTargetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
        checkpointAfter: z.ZodOptional<z.ZodBoolean>;
        contentKind: z.ZodOptional<z.ZodEnum<{
            standard: "standard";
            formal_derivation: "formal_derivation";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** Convert the provider object envelope into the internal progressive item list. */
export declare function normalizeSurveyPreviewEnvelopeCandidate(candidate: unknown): unknown;
export declare function surveyItemsFromProviderPayload(value: unknown): unknown;
/** Same leaf normalization used by hosted structured-generation recovery. */
export declare function normalizeSurveyGeneratedJsonValue(value: unknown): unknown;
declare const surveyAuthoringInputItemSchema: z.ZodPreprocess<z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"outline">;
    text: z.ZodString;
    scope: z.ZodOptional<z.ZodString>;
    learningTargetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    checkpointAfter: z.ZodOptional<z.ZodBoolean>;
    contentKind: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        formal_derivation: "formal_derivation";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"question">;
    question: z.ZodObject<{
        text: z.ZodString;
        learningTargetIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>], "kind">>;
export declare function surveyAuthoringItemsSchemaFor(sectionPlanningMode: SurveySectionPlanningMode): z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"outline">;
    text: z.ZodString;
    scope: z.ZodOptional<z.ZodString>;
    learningTargetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    checkpointAfter: z.ZodOptional<z.ZodBoolean>;
    contentKind: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        formal_derivation: "formal_derivation";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"question">;
    question: z.ZodObject<{
        text: z.ZodString;
        learningTargetIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>], "kind">>;
export declare const surveyAuthoringItemsSchema: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"outline">;
    text: z.ZodString;
    scope: z.ZodOptional<z.ZodString>;
    learningTargetIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    checkpointAfter: z.ZodOptional<z.ZodBoolean>;
    contentKind: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        formal_derivation: "formal_derivation";
    }>>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"question">;
    question: z.ZodObject<{
        text: z.ZodString;
        learningTargetIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>;
}, z.core.$strip>], "kind">>;
export type SurveySectionPlanningMode = "kacom" | "exploration" | "micro";
export type PrepareSurveyAuthoringInput = {
    unitTitle: string;
    goalBlock: string;
    difficultyBlock: string;
    styleBlock: string;
    languageBlock: string;
    optionsBlock?: string;
    context: string;
    canonicalLearningTargetsBlock: string;
    canonicalLearningTargets?: SurveyLearningTarget[];
    moduleContext?: string;
    sharedContextReuseLine?: string;
    sectionPlanningMode: SurveySectionPlanningMode;
    finalizeSurvey?: (draft: SurveyPreview) => SurveyPreview;
};
export type PreparedSurveyAuthoring = {
    operation: "unit.sq_preview";
    prompt: string;
    contextInvocation: Record<string, unknown>;
    itemSchema: typeof surveyAuthoringInputItemSchema;
    bindingItemSchema: typeof surveyAuthoringItemSchema;
    bindingSchema: typeof compactSurveyPreviewBindingSchema;
    resultSchema: z.ZodType<SurveyPreview>;
    parseProviderOutput(content: string): SurveyPreview;
};
export declare function assembleSurveyItems(items: SurveyAuthoringItem[], learningTargets: SurveyLearningTarget[], sectionPlanningMode: SurveySectionPlanningMode): SurveyPreview;
/** Shared provider-independent Survey/SQ authoring contract. */
export declare function prepareSurveyAuthoring(input: PrepareSurveyAuthoringInput): PreparedSurveyAuthoring;
export {};
