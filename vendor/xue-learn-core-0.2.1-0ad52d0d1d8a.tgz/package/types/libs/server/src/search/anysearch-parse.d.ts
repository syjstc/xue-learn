/** Parse AnySearch MCP markdown tool responses into structured web hits. */
export type AnySearchWebResult = {
    title: string;
    url: string;
    content: string;
};
/**
 * AnySearch `search` returns markdown like:
 * ## Search Results (N results, Xms)
 * ### 1. Title
 * - **URL**: https://...
 * - snippet...
 */
export declare function parseAnySearchResultsMarkdown(text: string): {
    results: AnySearchWebResult[];
    resultCount?: number;
    responseTimeMs?: number;
};
/**
 * AnySearch `extract` returns markdown with an optional **Source**: URL line.
 */
export declare function parseAnySearchExtractMarkdown(text: string, fallbackUrl: string): {
    url: string;
    title: string | null;
    rawContent: string;
};
