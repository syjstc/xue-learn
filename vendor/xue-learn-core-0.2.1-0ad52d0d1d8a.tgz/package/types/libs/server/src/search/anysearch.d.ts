import { type ContentSource } from "../rag/content-sources.js";
import type { LearningPathSearchPurpose } from "./tavily.js";
export type AnySearchPayload = {
    context: string;
    sources: ContentSource[];
    sourceContents: Record<string, string>;
};
/** Web search for plan summary / cognitive map when no uploaded materials. */
export declare function searchLearningPathWithAnySearchSources(query: string, options?: {
    purpose?: LearningPathSearchPurpose;
    maxResults?: number;
    extractTopUrls?: number;
    meta?: Record<string, unknown>;
}): Promise<AnySearchPayload>;
