export type ProviderCacheKeyInput = {
    scopeKey: string;
    selectionKey: string;
};
export declare function providerCacheKey(input: ProviderCacheKeyInput): string;
export declare class ProviderCache<T> {
    private readonly store;
    get(key: string): T | undefined;
    has(key: string): boolean;
    set(key: string, value: T): void;
    delete(key: string): void;
    clear(): void;
    deleteByScopePrefix(scopeKey: string): void;
}
