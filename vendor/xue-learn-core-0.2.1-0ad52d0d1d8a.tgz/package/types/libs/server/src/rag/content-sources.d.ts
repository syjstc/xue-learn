import type { Document } from "@langchain/core/documents";
import type { ContentSource } from "../../../domain/src/index.js";
export type { ContentSource, ContentSourceKind } from "../../../domain/src/index.js";
export declare function sourcesFromRagDocs(docs: Document[]): ContentSource[];
export declare function sourcesFromWebResults(results: {
    title: string;
    url: string;
    content: string;
}[]): ContentSource[];
export declare function formatRetrievedDocs(docs: Document[]): string;
export declare function formatWebResultsForPrompt(results: {
    title: string;
    url: string;
    content: string;
}[]): string;
export declare function trimWebContextText(text: string, maxChars: number): string;
/** Full-page extracts from Tavily (trimmed per URL, then joined). */
export declare function formatExtractedPagesForPrompt(pages: {
    url: string;
    title: string | null;
    rawContent: string;
}[], maxTotalChars: number, sourceIndexByUrl?: Map<string, number>): string;
export declare function enrichWebSourcesWithExtract(sources: ContentSource[], pages: {
    url: string;
    rawContent: string;
}[]): ContentSource[];
export declare function serializeContentSources(sources: ContentSource[]): string;
export declare function parseContentSources(raw: string | null | undefined): ContentSource[];
export declare function dedupeContentSources(sources: ContentSource[]): ContentSource[];
/** Reuse stored generation sources in prompts (no new RAG/search). */
export declare function formatContentSourcesExcerptsForPrompt(sources: ContentSource[]): string;
