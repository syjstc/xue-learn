/** Stable-looking, collision-safe chunk PK for concurrent scoped ingest. */
export declare function buildRagChunkId(scopeId: string): string;
