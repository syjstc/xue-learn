import { type FormalMotionRendererProps } from "./renderer.js";
/** Classroom host: interpolation is a pure function of `progress`. Fit to the
 * board, but never exceed `MAX_MOTION_EM`. Default alignment is center; highlight
 * is glyph ink, not a background wash. */
export declare function FormalMotionClockedRenderer(props: FormalMotionRendererProps & {
    progress: number;
}): import("react").JSX.Element;
