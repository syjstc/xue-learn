import type { FormalDocument, FormalNode, LayoutNode } from "../../formal-expression-core/src/index.js";
export declare function glyphValue(node: FormalNode | undefined): string;
/** Layout-kind / apply words that models sometimes emit as visible tokens. */
export declare function isStructuralLayoutToken(node: FormalNode | undefined): boolean;
export declare function isIntegralNode(node: FormalNode): boolean;
export declare function isFractionNode(node: FormalNode): boolean;
export declare function isProductOperator(node: FormalNode): boolean;
export declare function isImplicitProduct(node: FormalNode | undefined): boolean;
/** Infix connectors that must repeat between every operand (`a + b + c`). */
export declare function isInfixChainOperator(node: FormalNode | undefined): boolean;
export declare function isPrimeOperator(node: FormalNode): boolean;
export declare function isPowerOperator(node: FormalNode): boolean;
export declare function isApplyOperator(node: FormalNode | undefined): boolean;
/** Leibniz differential `d` / `∂`, typeset as juxtaposition (`dy`), not `d(y)`. */
export declare function isDifferentialSymbol(node: FormalNode | undefined): boolean;
export declare function isCallName(node: FormalNode): boolean;
export declare function isToArrow(node: FormalNode): boolean;
export declare function arrowRole(node: FormalNode): import("./types.js").StretchRole | undefined;
export declare function axisBinopRole(node: FormalNode): import("./types.js").StretchRole | undefined;
export declare function limitCommand(node: FormalNode): string | undefined;
export declare function isFunctionRenderer(node: FormalNode): boolean;
export declare function subjectRef(layoutId: string, doc: FormalDocument): {
    id: string;
    node: FormalNode;
} | undefined;
export declare function firstSubject(layoutId: string, doc: FormalDocument): string | undefined;
export declare function containmentParentId(child: string, doc: FormalDocument): string | undefined;
export declare function wrapperNodeId(layoutId: string): string | undefined;
export declare function isFractionStack(layout: LayoutNode, doc: FormalDocument): boolean;
export declare function isIncompleteFractionStack(layoutId: string, layout: LayoutNode, doc: FormalDocument): boolean;
export declare function isLeftDelimiter(value: string): boolean;
export declare function isRightDelimiter(value: string): boolean;
export declare function delimiterRole(value: string, side: "left" | "right"): import("./types.js").StretchRole;
