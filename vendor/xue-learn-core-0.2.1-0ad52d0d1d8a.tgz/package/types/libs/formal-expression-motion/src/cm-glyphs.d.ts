/**
 * Computer Modern outlines from KaTeX (1000 units = 1 em).
 *
 * Parentheses: `tallDelim` paths from katex/src/svgGeometry.ts (Size4 hooks
 * plus a curved recipe, not a straight pipe). Integrals: Size2-Regular U+222B;
 * nested growth translates the teardrop terminals and only lengthens the stem.
 */
export declare const CM_UNIT = 1000;
export declare const SIZE4_PAREN_NATIVE: number;
export declare const SIZE4_PAREN_WAIST = 251;
export declare const SIZE4_PAREN_ADVANCE = 792;
export declare const SIZE2_INT_NATIVE: number;
export declare const SIZE2_INT_AXIS = 250;
export declare const SIZE2_INT_WIDTH: number;
export declare const SIZE2_INT_HEIGHT = 1360;
export declare const SIZE2_INT_DEPTH = 862;
export declare function cmParenPath(side: "left" | "right", extent: number, em: number): string;
export declare function cmBracketPath(side: "left" | "right", extent: number, em: number): string;
export declare function cmIntegralPath(extent: number, em: number): string;
export declare function cmParenWidth(extent: number, em: number): number;
export declare function cmBracketWidth(extent: number, em: number): number;
export declare function cmIntegralWidth(em: number): number;
