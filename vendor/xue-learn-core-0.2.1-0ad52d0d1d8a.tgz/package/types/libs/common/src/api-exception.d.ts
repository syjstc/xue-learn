export type ApiExceptionDetails = {
    message: string;
    code?: string;
    status?: number;
};
export declare function formatApiException(error: unknown): ApiExceptionDetails;
