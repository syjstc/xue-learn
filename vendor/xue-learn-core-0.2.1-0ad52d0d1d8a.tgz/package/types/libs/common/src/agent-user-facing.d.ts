/**
 * Fail closed when a model narrates an internal tool-schema repair beside
 * rendered UI. Such text is transport/debug detail, never learner content.
 */
export declare function sanitizeToolUserFacingText(content: string, toolName?: string): string;
