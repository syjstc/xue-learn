/**
 * Multer/busboy reads multipart `filename` as Latin-1, but browsers send UTF-8 bytes.
 * Re-decode when every non-ASCII code point fits in a single byte (typical mojibake).
 */
export declare function decodeMultipartFilename(filename: string): string;
