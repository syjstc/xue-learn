/** Owner identity comes from the host's authenticated ingress. */
export declare function getUserIdFromHeaders(headers: Record<string, string | string[] | undefined>): string | undefined;
export declare function requireUserIdFromHeaders(headers: Record<string, string | string[] | undefined>): string;
export declare const CurrentUserId: (...dataOrPipes: unknown[]) => ParameterDecorator;
export declare const OptionalCurrentUserId: (...dataOrPipes: unknown[]) => ParameterDecorator;
