import type { INestApplication } from '@nestjs/common';
export declare function configureUserContext(app: INestApplication): void;
