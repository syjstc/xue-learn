import type { INestApplication } from "@nestjs/common";
/**
 * Match an Origin against an allowlist entry.
 * Supports exact origins and wildcards:
 * - `https://www.xue-learn.com` (exact)
 * - `https://*.xue-learn.com` (scheme + single subdomain label)
 * - `*.xue-learn.com` (any http/https origin for that host pattern)
 */
export declare function matchesCorsOriginPattern(origin: string, pattern: string): boolean;
/** CORS for API gateway and direct-facing Nest services in local dev. */
export declare function configureAppCors(app: INestApplication): void;
/** Strip upstream CORS headers so the gateway remains the single CORS authority. */
export declare function stripUpstreamCorsHeaders(headers: Record<string, unknown>): Record<string, string | string[]>;
