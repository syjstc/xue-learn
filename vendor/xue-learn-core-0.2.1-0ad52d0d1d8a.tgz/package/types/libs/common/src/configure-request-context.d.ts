import type { INestApplication } from "@nestjs/common";
export declare function configureRequestContext(app: INestApplication, options: {
    serviceName: string;
}): void;
