import type { AuthoringContainer, AuthoringOperator, AuthoringToken, AuthoringTree } from "../../formal-expression-core/src/index.js";
export declare function tok(value: string, id?: string, extras?: Partial<AuthoringToken>): AuthoringToken;
export declare function op(token: string, operands: AuthoringTree[], id?: string, extras?: Partial<AuthoringOperator>): AuthoringOperator;
export declare function eq(left: AuthoringTree, right: AuthoringTree, id?: string): AuthoringOperator;
export declare function minus(left: AuthoringTree, right: AuthoringTree, id?: string): AuthoringOperator;
export declare function plus(left: AuthoringTree, right: AuthoringTree, id?: string): AuthoringOperator;
export declare function times(left: AuthoringTree, right: AuthoringTree, id?: string): AuthoringOperator;
export declare function frac(numerator: AuthoringTree, denominator: AuthoringTree, id?: string): AuthoringContainer;
/**
 * Semantically empty root that stacks sibling statements on one formula tree.
 * Parallel working lines stay in the same document, with animation scoped to
 * each row so identities never travel between independent statements.
 */
export declare function board(lines: AuthoringTree[], id?: string): AuthoringContainer;
export declare function group(inner: AuthoringTree, id?: string): AuthoringContainer;
export declare function radical(inner: AuthoringTree, id?: string): AuthoringContainer;
/** Invisible infix so `f` and `(x)` typeset as juxtaposition / application. */
export declare function call(callee: AuthoringTree, argument: AuthoringTree, id?: string): AuthoringOperator;
export declare function fn(name: string, argument: AuthoringTree, id?: string): AuthoringOperator;
export declare function replaceAuthoringNode(tree: AuthoringTree, targetId: string, replacement: AuthoringTree): AuthoringTree;
export declare function authoringContainsId(tree: AuthoringTree, targetId: string): boolean;
export declare function collectAuthoringIds(tree: AuthoringTree): string[];
export declare function authoringNodeCount(tree: AuthoringTree): number;
export declare function findAuthoringNode(tree: AuthoringTree, targetId: string): AuthoringTree | undefined;
