import type { DerivationBranchV1, DerivationStepV1, DerivationTimelineItemV1, MaterializedBranchCursorV1 } from "./types.js";
export declare function applyBranchCursor(previous: MaterializedBranchCursorV1 | undefined, branch: DerivationBranchV1 | undefined, stepId: string): MaterializedBranchCursorV1 | undefined;
export declare function groupExpansionRuns(steps: readonly DerivationStepV1[]): Array<Extract<DerivationTimelineItemV1, {
    type: "step" | "expansion";
}>>;
export declare function groupDerivationTimeline(steps: readonly DerivationStepV1[]): DerivationTimelineItemV1[];
