import type { FormalDocument, Patch, SerializedCommand } from "./types.js";
export declare function prepareCommand(doc: FormalDocument, command: SerializedCommand): Patch[];
