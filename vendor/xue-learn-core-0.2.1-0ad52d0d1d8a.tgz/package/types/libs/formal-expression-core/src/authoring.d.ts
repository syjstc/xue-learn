import type { FormalDocument, JsonObject, JsonValue, LayoutNode } from "./types.js";
interface AuthoringBase {
    /** Optional human-readable stable key. Otherwise derived from the tree path. */
    id?: string;
    attributes?: JsonObject;
    layout?: {
        kind: LayoutNode["kind"];
        props?: JsonObject;
        includeSelf?: boolean;
    };
}
export interface AuthoringToken extends AuthoringBase {
    kind: "token";
    value: JsonValue;
    contentType?: string;
    renderer?: string;
}
export interface AuthoringOperator extends AuthoringBase {
    kind: "operator";
    token: string;
    renderer?: string;
    operands: Array<{
        port?: string;
        direction?: "in" | "out" | "neutral";
        role?: string;
        node: AuthoringTree;
    }>;
}
export interface AuthoringContainer extends AuthoringBase {
    kind: "container";
    renderer: string;
    slots: Array<{
        name: string;
        role?: string;
        node: AuthoringTree;
    }>;
}
export interface AuthoringPlaceholder extends AuthoringBase {
    kind: "placeholder";
    label?: string;
    renderer?: string;
}
export interface AuthoringReference extends AuthoringBase {
    kind: "reference";
    targetId: string;
    renderer?: string;
}
export type AuthoringTree = AuthoringToken | AuthoringOperator | AuthoringContainer | AuthoringPlaceholder | AuthoringReference;
/**
 * Carry semantic node identities across a model-authored subtree rewrite.
 *
 * Exact unchanged subtrees are matched first, then remaining compatible nodes
 * are paired in reading order. This gives every renderer one durable identity
 * model even when an author supplies fresh cosmetic ids for each revision.
 */
export declare function reconcileAuthoringTreeIdentity(previous: AuthoringTree, next: AuthoringTree, options?: {
    rootId?: string;
}): AuthoringTree;
export declare const FORMAL_AUTHORING_TREE_JSON_SCHEMA: {
    readonly $schema: "https://json-schema.org/draft/2020-12/schema";
    readonly title: "Formal expression authoring tree";
    readonly $ref: "#/$defs/node";
    readonly $defs: {
        readonly node: {
            readonly oneOf: readonly [{
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["kind", "value"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                    };
                    readonly kind: {
                        readonly const: "token";
                    };
                    readonly value: {};
                    readonly contentType: {
                        readonly type: "string";
                    };
                    readonly renderer: {
                        readonly type: "string";
                    };
                    readonly attributes: {
                        readonly type: "object";
                    };
                    readonly layout: {
                        readonly $ref: "#/$defs/layout";
                    };
                };
            }, {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["kind", "token", "operands"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                    };
                    readonly kind: {
                        readonly const: "operator";
                    };
                    readonly token: {
                        readonly type: "string";
                    };
                    readonly renderer: {
                        readonly type: "string";
                    };
                    readonly attributes: {
                        readonly type: "object";
                    };
                    readonly layout: {
                        readonly $ref: "#/$defs/layout";
                    };
                    readonly operands: {
                        readonly type: "array";
                        readonly minItems: 1;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["node"];
                            readonly properties: {
                                readonly port: {
                                    readonly type: "string";
                                };
                                readonly direction: {
                                    readonly enum: readonly ["in", "out", "neutral"];
                                };
                                readonly role: {
                                    readonly type: "string";
                                };
                                readonly node: {
                                    readonly $ref: "#/$defs/node";
                                };
                            };
                        };
                    };
                };
            }, {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["kind", "renderer", "slots"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                    };
                    readonly kind: {
                        readonly const: "container";
                    };
                    readonly renderer: {
                        readonly type: "string";
                    };
                    readonly attributes: {
                        readonly type: "object";
                    };
                    readonly layout: {
                        readonly $ref: "#/$defs/layout";
                    };
                    readonly slots: {
                        readonly type: "array";
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["name", "node"];
                            readonly properties: {
                                readonly name: {
                                    readonly type: "string";
                                };
                                readonly role: {
                                    readonly type: "string";
                                };
                                readonly node: {
                                    readonly $ref: "#/$defs/node";
                                };
                            };
                        };
                    };
                };
            }, {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["kind"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                    };
                    readonly kind: {
                        readonly const: "placeholder";
                    };
                    readonly label: {
                        readonly type: "string";
                    };
                    readonly attributes: {
                        readonly type: "object";
                    };
                    readonly layout: {
                        readonly $ref: "#/$defs/layout";
                    };
                };
            }, {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["kind", "targetId"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                    };
                    readonly kind: {
                        readonly const: "reference";
                    };
                    readonly targetId: {
                        readonly type: "string";
                    };
                    readonly attributes: {
                        readonly type: "object";
                    };
                    readonly layout: {
                        readonly $ref: "#/$defs/layout";
                    };
                };
            }];
        };
        readonly layout: {
            readonly type: "object";
            readonly additionalProperties: false;
            readonly required: readonly ["kind"];
            readonly properties: {
                readonly kind: {
                    readonly enum: readonly ["subject", "flow", "stack", "overlay", "grid", "attach", "surround", "free"];
                };
                readonly props: {
                    readonly type: "object";
                };
                readonly includeSelf: {
                    readonly type: "boolean";
                };
            };
        };
    };
};
/** Flatten model-authored nested token payloads into a single glyph string. */
export declare function coerceGlyphValue(value: unknown, seen?: Set<unknown>): string;
/**
 * Inspect/compile path ids and classroom 讲解 speech that models sometimes
 * put in token.value. Those must not typeset as mathematics.
 */
export declare function isNonMathAuthoringGlyph(value: unknown): boolean;
/** Map TeX/word operator names (`minus`, `\\cdot`) onto a single glyph. */
export declare function normalizeFormalGlyph(value: unknown): string;
export declare function isIntegralGlyph(value: unknown): boolean;
/**
 * Recover presentation slips that do not change grouping: a two-slot fraction
 * missing its bar, infix "/" / "÷", a Leibniz `dy/dx` apply-token, a sqrt
 * surround that used left "√" instead of a radical, and ∫ / int without
 * renderer "integral". Integral operators are prefix (`∫ f`, never `f ∫`).
 * Idempotent. Does not wrap products or invent parentheses.
 */
export declare function normalizeAuthoringPresentation(tree: AuthoringTree): AuthoringTree;
export declare function incompleteFractionContainers(tree: AuthoringTree): Array<{
    nodeId?: string;
}>;
/** Compile an AI-friendly recursive tree into normalized runtime tables. */
export declare function compileAuthoringTree(tree: AuthoringTree, documentId?: string): FormalDocument;
/** Pure staged-authoring helper: replace one placeholder, then compile again. */
export declare function fillAuthoringPlaceholder(tree: AuthoringTree, placeholderId: string, replacement: AuthoringTree): AuthoringTree;
/** Convert a normalized document back to the compact recursive authoring form. */
export declare function decompileAuthoringTree(document: FormalDocument, rootId?: string): AuthoringTree;
export {};
