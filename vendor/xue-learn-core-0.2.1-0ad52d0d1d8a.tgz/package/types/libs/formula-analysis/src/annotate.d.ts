import type { FormulaNode } from "./types.js";
export declare function wrapNodeId(nodeId: string): string;
/** Wrap selected non-overlapping source ranges with KaTeX \\htmlId. */
export declare function annotateLatex(source: string, nodes: readonly FormulaNode[], allowNested?: boolean): {
    latex: string;
    wrappedNodeIds: string[];
    fallback: boolean;
};
