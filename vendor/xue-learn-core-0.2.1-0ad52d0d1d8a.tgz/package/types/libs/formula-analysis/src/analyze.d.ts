import type { FormulaAnalysis, SymbolContext } from "./types.js";
export declare function analyzeFormula(source: string, symbolContext?: SymbolContext): FormulaAnalysis;
