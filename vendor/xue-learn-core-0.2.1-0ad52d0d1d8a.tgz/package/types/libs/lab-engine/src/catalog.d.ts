import { applyChemistryOperation, getChemistryExperiment, normalizeChemistryLabDefinition, type ChemistryLabDefinition, type ChemistryLabSnapshot, type ChemistryOperation } from "../../domain/src/chemistry-lab.js";
import { getPhysicsExperiment, normalizePhysicsLabDefinition, type PhysicsLabDefinition } from "../../domain/src/physics-lab.js";
import type { LabManifestV1 } from "../../lab-protocol/src/index.js";
/**
 * The certified experiment boundary consumed by the standalone Lab runtime.
 * This module deliberately exposes only deterministic catalog operations; it
 * has no UI, persistence, network, learner, or model dependencies.
 */
export { applyChemistryOperation, getChemistryExperiment, normalizeChemistryLabDefinition, getPhysicsExperiment, normalizePhysicsLabDefinition, };
export type { ChemistryLabDefinition, ChemistryLabSnapshot, ChemistryOperation, PhysicsLabDefinition, };
export type CertifiedLabEvaluation = {
    observations: readonly {
        id: string;
        label: string;
        value: number | string;
        unit?: string;
        kind?: string;
    }[];
    chemistrySnapshot?: ChemistryLabSnapshot;
};
export declare function evaluateCertifiedManifest(domain: "physics" | "chemistry", experimentId: string, experimentVersion: number, parameters: Record<string, number>, chemistrySnapshot?: ChemistryLabSnapshot): CertifiedLabEvaluation | null;
export declare function normalizeCertifiedParameters(domain: "physics" | "chemistry", experimentId: string, experimentVersion: number, parameters: Record<string, number>): Record<string, number>;
export declare function validateCertifiedParameter(domain: "physics" | "chemistry", experimentId: string, experimentVersion: number, id: string, value: number): {
    valid: false;
    code: string;
    message: string;
    spec?: undefined;
} | {
    valid: true;
    spec: import("../../domain/src/physics-lab.js").PhysicsParameterSpec;
    code?: undefined;
    message?: undefined;
};
export declare function certifiedActionIds(domain: "physics" | "chemistry", experimentId: string): Set<string>;
export declare function validateCertifiedManifest(manifest: LabManifestV1): string[];
export declare function applyCertifiedChemistryAction(definition: ChemistryLabDefinition, operation: ChemistryOperation): import("../../domain/src/chemistry-lab.js").ChemistryOperationResult;
