import type { ChemistryLabDefinition } from "../../domain/src/chemistry-lab.js";
import type { LabManifestV1 } from "../../lab-protocol/src/index.js";
import type { LabSceneDefinition } from "./types.js";
/**
 * Certified chemistry bench layout. Domain state stays in the definition;
 * this only maps vessels and tools onto registered scene components.
 */
export declare function createChemistryScene(block: ChemistryLabDefinition): LabSceneDefinition;
export declare function chemistrySceneToManifestScene(scene: LabSceneDefinition): LabManifestV1["scene"];
