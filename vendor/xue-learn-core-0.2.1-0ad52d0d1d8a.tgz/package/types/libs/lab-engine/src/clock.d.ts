export type LabClockOptions = {
    fixedStepSeconds?: number;
    maxFrameDeltaSeconds?: number;
    maxStepsPerFrame?: number;
};
/**
 * A bounded fixed-step clock. Renderers may run at any frame rate while the
 * domain engine receives the same sequence of time steps for the same input.
 */
export declare class LabClock {
    readonly fixedStepSeconds: number;
    readonly maxFrameDeltaSeconds: number;
    readonly maxStepsPerFrame: number;
    private accumulatorSeconds;
    private elapsedSeconds;
    constructor(options?: LabClockOptions);
    get elapsed(): number;
    /** Advances by real time and invokes onStep for each bounded fixed step. */
    advance(realDeltaSeconds: number, onStep: (dt: number) => void): number;
    reset(): void;
    restore(elapsedSeconds: number): void;
}
