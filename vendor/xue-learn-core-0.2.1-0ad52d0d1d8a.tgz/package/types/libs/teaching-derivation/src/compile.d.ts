import type { TeachingDerivationDerivedV1, TeachingDerivationDocumentV1 } from "./types.js";
export declare function compileTeachingDerivation(document: TeachingDerivationDocumentV1): TeachingDerivationDerivedV1;
/** Old derived caches are disposable; the committed document remains authority. */
export declare function resolveTeachingDerivationDerived(document: TeachingDerivationDocumentV1, stored?: TeachingDerivationDerivedV1 | null): TeachingDerivationDerivedV1;
