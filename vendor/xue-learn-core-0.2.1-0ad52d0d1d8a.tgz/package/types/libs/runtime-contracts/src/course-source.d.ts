import { z } from "zod";
export declare const courseSourceAssetSchema: z.ZodObject<{
    resourceId: z.ZodString;
    sha256: z.ZodNullable<z.ZodString>;
    mediaType: z.ZodNullable<z.ZodString>;
    byteLength: z.ZodNullable<z.ZodNumber>;
    availability: z.ZodEnum<{
        external: "external";
        available: "available";
        missing: "missing";
    }>;
    source: z.ZodString;
}, z.core.$strict>;
/** Original accepted JSON remains opaque here; its owning Core format validates it. */
export declare const courseSourceSectionSchema: z.ZodObject<{
    id: z.ZodString;
    orderIndex: z.ZodNumber;
    title: z.ZodString;
    scope: z.ZodString;
    contentKind: z.ZodString;
    assessmentAfter: z.ZodBoolean;
    testGenerationStatus: z.ZodString;
    generationStatus: z.ZodString;
    publishedRevision: z.ZodNumber;
    availability: z.ZodEnum<{
        missing: "missing";
        published: "published";
    }>;
    derivationFormat: z.ZodNullable<z.ZodString>;
    material: z.ZodNullable<z.ZodObject<{
        introduction: z.ZodString;
        blocks: z.ZodUnknown;
        keyTakeaways: z.ZodUnknown;
    }, z.core.$strict>>;
    derivationDocument: z.ZodNullable<z.ZodUnknown>;
    teachingDerivationDocument: z.ZodNullable<z.ZodUnknown>;
    teachingDerivationDerived: z.ZodNullable<z.ZodUnknown>;
    presentationVersions: z.ZodRecord<z.ZodString, z.ZodString>;
}, z.core.$strict>;
export declare const courseSourceSnapshotSchema: z.ZodObject<{
    contractVersion: z.ZodLiteral<"course-source.v1">;
    snapshotId: z.ZodString;
    contentHash: z.ZodString;
    capturedAt: z.ZodString;
    source: z.ZodObject<{
        workspaceId: z.ZodString;
        ownerId: z.ZodString;
        goalId: z.ZodString;
        moduleId: z.ZodNullable<z.ZodString>;
        unitId: z.ZodString;
        moduleOrderIndex: z.ZodNullable<z.ZodNumber>;
        unitOrderIndex: z.ZodNumber;
    }, z.core.$strict>;
    metadata: z.ZodObject<{
        goalTitle: z.ZodString;
        goalKind: z.ZodString;
        title: z.ZodString;
        unitKind: z.ZodString;
        contentLanguage: z.ZodString;
        scope: z.ZodString;
        publishedRevision: z.ZodNumber;
        learningTargets: z.ZodArray<z.ZodUnknown>;
    }, z.core.$strict>;
    preview: z.ZodObject<{
        status: z.ZodEnum<{
            ready: "ready";
            pending: "pending";
            missing: "missing";
            "not-required": "not-required";
        }>;
        data: z.ZodNullable<z.ZodUnknown>;
    }, z.core.$strict>;
    sections: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        orderIndex: z.ZodNumber;
        title: z.ZodString;
        scope: z.ZodString;
        contentKind: z.ZodString;
        assessmentAfter: z.ZodBoolean;
        testGenerationStatus: z.ZodString;
        generationStatus: z.ZodString;
        publishedRevision: z.ZodNumber;
        availability: z.ZodEnum<{
            missing: "missing";
            published: "published";
        }>;
        derivationFormat: z.ZodNullable<z.ZodString>;
        material: z.ZodNullable<z.ZodObject<{
            introduction: z.ZodString;
            blocks: z.ZodUnknown;
            keyTakeaways: z.ZodUnknown;
        }, z.core.$strict>>;
        derivationDocument: z.ZodNullable<z.ZodUnknown>;
        teachingDerivationDocument: z.ZodNullable<z.ZodUnknown>;
        teachingDerivationDerived: z.ZodNullable<z.ZodUnknown>;
        presentationVersions: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strict>>;
    legacyMaterial: z.ZodNullable<z.ZodObject<{
        introduction: z.ZodString;
        sections: z.ZodUnknown;
        keyTakeaways: z.ZodUnknown;
    }, z.core.$strict>>;
    assets: z.ZodArray<z.ZodObject<{
        resourceId: z.ZodString;
        sha256: z.ZodNullable<z.ZodString>;
        mediaType: z.ZodNullable<z.ZodString>;
        byteLength: z.ZodNullable<z.ZodNumber>;
        availability: z.ZodEnum<{
            external: "external";
            available: "available";
            missing: "missing";
        }>;
        source: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CourseSourceSnapshotV1 = z.infer<typeof courseSourceSnapshotSchema>;
export type CourseSourceSectionV1 = z.infer<typeof courseSourceSectionSchema>;
export type CourseSourceAssetV1 = z.infer<typeof courseSourceAssetSchema>;
