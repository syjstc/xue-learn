import type { InteractiveBlock } from "../../contracts/src/index.js";
export type CompareSide = {
    id?: string;
    label: string;
    points: string[];
};
export declare function compareSideObjectId(side: Pick<CompareSide, "id"> | null | undefined, index: number): string;
export type CompareBlock = Extract<InteractiveBlock, {
    type: "compare";
}>;
export declare function compareBlockSides(block: CompareBlock): CompareSide[];
export declare function buildCompareBlock(sides: CompareSide[]): CompareBlock;
export declare function compareBlockSideTags(): Array<"CMPL" | "CMPR">;
export declare function compareSideTagForIndex(index: number): "CMPL" | "CMPR";
