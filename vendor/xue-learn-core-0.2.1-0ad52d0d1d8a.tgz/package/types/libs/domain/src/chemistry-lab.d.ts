/**
 * Certified, renderer-neutral chemistry experiments.
 *
 * Chemistry labs intentionally expose a small operation vocabulary.  The
 * renderer can present these operations as buttons, drag/drop, or native
 * controls, but it cannot invent substances, reactions, or calculations.
 */
export type ChemistryExperimentId = "acid_base_indicator" | "acid_base_titration" | "precipitation_reaction" | "mass_conservation";
export type ChemistryStage = "middle_school" | "high_school" | "undergraduate";
export type ChemistrySubstanceId = "water" | "hydrochloric_acid" | "sodium_hydroxide" | "phenolphthalein" | "methyl_orange" | "silver_nitrate" | "sodium_chloride" | "copper_sulfate" | "sodium_carbonate";
export declare const CHEMISTRY_SUBSTANCES: readonly ChemistrySubstanceId[];
export type ChemistryVesselKind = "beaker" | "conical_flask" | "test_tube" | "dropper" | "burette" | "graduated_cylinder" | "balance";
export type ChemistryParameterSpec = {
    id: string;
    label: string;
    unit: string;
    min: number;
    max: number;
    step: number;
    default: number;
};
export type ChemistryObservation = {
    id: string;
    label: string;
    value: number | string;
    unit?: string;
    kind?: "scalar" | "text" | "state";
};
export type ChemistryVesselState = {
    id: string;
    kind: ChemistryVesselKind;
    label: string;
    volumeMl: number;
    contents: Partial<Record<ChemistrySubstanceId, number>>;
    color?: string;
    precipitateG?: number;
};
export type ChemistryLabSnapshot = {
    step: number;
    scaleZeroed: boolean;
    completed: boolean;
    pH?: number;
    indicatorColor?: string;
    titrantVolumeMl?: number;
    measuredVolumeMl?: number;
    precipitateG?: number;
    measuredMassG?: number;
    totalMassG?: number;
    observations: ChemistryObservation[];
    vessels: ChemistryVesselState[];
};
export type ChemistryLabDefinition = {
    type: "chemistry_lab";
    experimentId: ChemistryExperimentId;
    experimentVersion: 1;
    title: string;
    summary: string;
    stage: ChemistryStage;
    renderMode: "2d" | "3d";
    parameters: Record<string, number>;
    targetObservation?: string;
    controls?: string[];
    observations?: ChemistryObservation[];
    snapshot?: ChemistryLabSnapshot;
};
export type ChemistryOperation = {
    kind: "add_reagent";
    vesselId: string;
    substance: ChemistrySubstanceId;
    amountMl: number;
} | {
    kind: "mix";
    vesselId: string;
} | {
    kind: "titrate";
    vesselId: string;
    amountMl: number;
} | {
    kind: "measure_volume";
    vesselId: string;
} | {
    kind: "transfer";
    sourceVesselId: string;
    targetVesselId: string;
    amountMl: number;
} | {
    kind: "tare_scale";
} | {
    kind: "measure_mass";
    vesselId: string;
};
export type ChemistryOperationResult = {
    accepted: boolean;
    state: ChemistryLabSnapshot;
    message: string;
};
export type ChemistryExperiment = {
    id: ChemistryExperimentId;
    version: 1;
    title: string;
    summary: string;
    stages: readonly ChemistryStage[];
    renderMode: "2d" | "3d";
    parameters: readonly ChemistryParameterSpec[];
    controls: readonly string[];
    initial: (parameters: Record<string, number>) => ChemistryLabSnapshot;
    evaluate: (parameters: Record<string, number>, snapshot?: ChemistryLabSnapshot) => {
        observations: ChemistryObservation[];
        snapshot: ChemistryLabSnapshot;
    };
};
export declare const CHEMISTRY_EXPERIMENTS: readonly ChemistryExperiment[];
export declare const CHEMISTRY_EXPERIMENT_REGISTRY: ReadonlyMap<ChemistryExperimentId, ChemistryExperiment>;
export declare function getChemistryExperiment(id: string, version?: number): ChemistryExperiment | null;
export declare function normalizeChemistryLabDefinition(input: {
    experimentId: string;
    experimentVersion?: number;
    title?: string;
    summary?: string;
    stage?: ChemistryStage;
    targetObservation?: string;
    parameters?: Record<string, number>;
    snapshot?: ChemistryLabSnapshot;
    /** Server callers can reject authored values instead of repairing them. */
    strictParameters?: boolean;
}): ChemistryLabDefinition | null;
/** Apply one allowlisted operation. Rejected operations return the original state. */
export declare function applyChemistryOperation(definition: ChemistryLabDefinition, operation: ChemistryOperation): ChemistryOperationResult;
