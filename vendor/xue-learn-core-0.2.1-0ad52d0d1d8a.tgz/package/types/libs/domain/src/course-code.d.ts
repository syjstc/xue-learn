export type CourseCodeBlock = Readonly<{
    type: string;
    [key: string]: unknown;
}>;
/** Fallback visible-line cap when the lecture pane has not been measured. */
export declare const CLASSROOM_CODE_MAX_VISIBLE_LINES = 16;
export declare const CLASSROOM_CODE_MIN_VISIBLE_LINES = 6;
export declare const CLASSROOM_CODE_MAX_CAPACITY = 22;
export type ClassroomCodeDensity = "comfortable" | "compact";
/**
 * Non-executable code blocks are classroom writing rather than source code.
 * Keep this separate from `isPlainCodeLanguage`: markdown still benefits from
 * being rendered as escaped, source-like text in a lesson-performance board.
 */
export declare function isClassroomTextBoardLanguage(language?: string): boolean;
export type ClassroomCodeLineBox = Readonly<{
    top: number;
    height: number;
}>;
export type ClassroomCodeFit = Readonly<{
    visibleCode: string;
    fullCode: string;
    allLines: readonly string[];
    startLine: number;
    endLine: number;
    totalLines: number;
    overflow: boolean;
    density: ClassroomCodeDensity;
    scrollLines: number;
    maxScrollLines: number;
    visibleLineCount: number;
}>;
export declare function classroomCodeSource(block: CourseCodeBlock | undefined): string;
export declare function classroomCodeLanguage(block: CourseCodeBlock | undefined): string | undefined;
export declare function classroomCodeLanguageLabel(language?: string): string;
export declare function clampClassroomCodeVisibleLines(value: number): number;
export declare function computeClassroomCodeScrollLines(totalLines: number, focus?: Readonly<{
    startLine: number;
    endLine?: number;
}>, maxVisibleLines?: number): number;
/**
 * Center an authored focus range using the browser's measured line boxes.
 * Unlike line-count scrolling, this also works when a long source line wraps
 * into multiple visual rows.
 */
export declare function computeClassroomCodeScrollOffset(lineBoxes: readonly ClassroomCodeLineBox[], focus: Readonly<{
    startLine: number;
    endLine?: number;
}> | undefined, viewportHeight: number, contentHeight: number): number;
export declare function fitClassroomCode(code: string, focus?: Readonly<{
    startLine: number;
    endLine: number;
}>, maxVisibleLines?: number): ClassroomCodeFit;
