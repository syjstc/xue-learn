/**
 * DC circuit lab: LLM authors a nested series/parallel tree; the engine
 * compiles a netlist, solves it with MNA, and lays out a schematic.
 *
 * Example (series + parallel):
 * {
 *   type: "circuit_sandbox",
 *   title: "并联分流",
 *   summary: "…",
 *   circuit: {
 *     series: [
 *       { id: "bat", kind: "battery", v: 6 },
 *       { id: "sw", kind: "switch", closed: true },
 *       { parallel: [
 *         { id: "l1", kind: "bulb" },
 *         { id: "r1", kind: "resistor", ohm: 20 }
 *       ]}
 *     ]
 *   }
 * }
 */
export declare const CIRCUIT_PART_KINDS: readonly ["battery", "resistor", "rheostat", "switch", "bulb", "ammeter", "voltmeter"];
export type CircuitPartKind = (typeof CIRCUIT_PART_KINDS)[number];
export type CircuitPart = {
    id: string;
    kind: CircuitPartKind;
    label?: string;
    /** Battery voltage (V). */
    v?: number;
    /** Resistance (Ω) for resistor / rheostat. */
    ohm?: number;
    min?: number;
    max?: number;
    /** Switch closed = conducting. */
    closed?: boolean;
    /** Bulb rated voltage (V). */
    ratedV?: number;
    /** Bulb rated power (W). */
    ratedW?: number;
};
export type CircuitSeries = {
    series: CircuitNode[];
};
export type CircuitParallel = {
    parallel: CircuitNode[];
};
export type CircuitNode = CircuitPart | CircuitSeries | CircuitParallel;
/** @deprecated Stored lessons may still use a node-id netlist. */
export type CircuitComponentKind = "voltage_source" | "resistor" | "potentiometer" | "switch" | "lightbulb" | "voltmeter" | "ammeter" | CircuitPartKind;
/** @deprecated Prefer `circuit` tree. */
export type CircuitComponent = {
    id: string;
    kind: CircuitComponentKind;
    label?: string;
    nodeA: string;
    nodeB: string;
    value?: number;
    minValue?: number;
    maxValue?: number;
    closed?: boolean;
    ratedVoltage?: number;
    ratedPower?: number;
    position?: [number, number];
};
/** @deprecated Prefer tree layout; kept for stored lessons. */
export type CircuitWire = {
    id: string;
    from: string;
    to: string;
    points?: [number, number][];
};
export type CircuitSandbox = {
    type: "circuit_sandbox";
    title: string;
    summary: string;
    /** Nested series/parallel composition. Preferred authoring form. */
    circuit?: CircuitNode;
    targetObservation?: string;
    /** Legacy netlist. Used only when `circuit` is absent. */
    components?: CircuitComponent[];
    wires?: CircuitWire[];
    groundNode?: string;
};
export type CircuitOverride = {
    ohm?: number;
    closed?: boolean;
    v?: number;
};
export type CircuitSolvedPart = {
    id: string;
    kind: CircuitPartKind;
    label?: string;
    voltageDrop: number;
    current: number;
    power: number;
    brightnessRatio?: number;
};
export type CircuitSolution = {
    nodeVoltages: Record<string, number>;
    parts: Record<string, CircuitSolvedPart>;
    /** @deprecated Use `parts`. */
    components: Record<string, CircuitSolvedPart>;
    isCompleteCircuit: boolean;
};
export type SchematicSymbol = {
    id: string;
    kind: CircuitPartKind;
    x: number;
    y: number;
    rotation: 0 | 90;
    label: string;
    valueText?: string;
};
export type SchematicWire = {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    /** Solved current is taken from this part when present. */
    partId?: string;
};
export type CircuitSchematic = {
    width: number;
    height: number;
    symbols: SchematicSymbol[];
    wires: SchematicWire[];
    dots: Array<{
        x: number;
        y: number;
    }>;
};
/** Current used to animate a schematic wire. Missing part tags are treated as no current. */
export declare function schematicWireCurrent(wire: SchematicWire, solution: CircuitSolution): number;
export declare function isSchematicWireLive(wire: SchematicWire, solution: CircuitSolution): boolean;
export declare function normalizeCircuitKind(kind: string): CircuitPartKind | null;
export declare function isCircuitPart(node: CircuitNode): node is CircuitPart;
export declare function isCircuitSeries(node: CircuitNode): node is CircuitSeries;
export declare function isCircuitParallel(node: CircuitNode): node is CircuitParallel;
/**
 * Unwraps trivial groups (`parallel`/`series` of 0–1 items) and maps kind
 * aliases so LLM JSON does not fail closed on provider-omitted minItems.
 */
export declare function normalizeCircuitTree(node: unknown): unknown;
export declare function normalizeCircuitSandboxPayload(value: unknown): unknown;
export declare function collectCircuitParts(node: CircuitNode | undefined): CircuitPart[];
export declare function listSandboxParts(sandbox: CircuitSandbox): CircuitPart[];
type CompiledBranch = {
    id: string;
    kind: CircuitPartKind;
    label?: string;
    nodeA: string;
    nodeB: string;
    part: CircuitPart;
};
/**
 * Top-level `series` is a closed loop (battery negative = ground).
 * Nested series/parallel are two-terminal networks.
 */
export declare function compileCircuit(sandbox: CircuitSandbox): CompiledBranch[];
export declare function solveCircuit(sandbox: CircuitSandbox, overrides?: Record<string, CircuitOverride>): CircuitSolution;
export declare function initialCircuitOverrides(sandbox: CircuitSandbox): Record<string, CircuitOverride>;
export declare function partDisplayValue(part: CircuitPart, override?: CircuitOverride): string;
export declare function defaultPartLabel(part: CircuitPart): string;
/** Distance from the symbol center to where layout leads meet the glyph body. */
export declare function schematicBodyHalf(kind: CircuitPartKind): {
    left: number;
    right: number;
};
export declare function layoutCircuit(sandbox: CircuitSandbox, overrides?: Record<string, CircuitOverride>): CircuitSchematic;
export {};
